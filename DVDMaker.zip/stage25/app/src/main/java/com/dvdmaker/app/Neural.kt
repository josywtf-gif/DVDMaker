package com.dvdmaker.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.nio.FloatBuffer
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Нейросетевой апскейлинг Real-ESRGAN (realesr-general-x4v3, ONNX) прямо на устройстве, без интернета.
 * Модель всегда увеличивает ×4; картинка обрабатывается плитками, чтобы хватило памяти.
 */
object NeuralUpscaler {
    private const val MODEL = "models/realesr-general-x4v3.onnx"
    private const val SCALE = 4
    private const val CORE = 160
    private const val PAD = 20

    fun available(ctx: Context): Boolean = try {
        ctx.assets.open(MODEL).close(); true
    } catch (_: Throwable) {
        false
    }

    /** Keep the multi-megabyte ONNX model on disk instead of duplicating it in a large byte array. */
    @Synchronized
    private fun modelFile(ctx: Context): File {
        val target = File(ctx.noBackupFilesDir, "realesr-general-x4v3.onnx")
        val expectedSize = ctx.assets.openFd(MODEL).use { it.length }
        if (target.exists() && target.length() == expectedSize) return target
        val temp = File(target.parentFile, target.name + ".tmp")
        ctx.assets.open(MODEL).use { input -> temp.outputStream().use { output -> input.copyTo(output, 1 shl 16) } }
        if (temp.length() != expectedSize) {
            temp.delete()
            throw IllegalStateException("Файл модели улучшения скопирован не полностью")
        }
        if (target.exists() && !target.delete()) throw IllegalStateException("Не удалось обновить файл модели")
        if (!temp.renameTo(target)) {
            temp.delete()
            throw IllegalStateException("Не удалось подготовить файл модели")
        }
        return target
    }

    /**
     * Увеличивает [src] нейросетью ×4 плитками и сразу собирает результат в [targetW]×[targetH].
     * Полный промежуточный bitmap ×4 не создаётся. [onProgress] получает 0…100.
     */
    suspend fun upscale(ctx: Context, src: Bitmap, targetW: Int, targetH: Int, onProgress: (Int) -> Unit): Bitmap {
        require(targetW > 0 && targetH > 0) { "Недопустимый размер результата" }
        require(max(targetW, targetH) <= Enhancer.MAX_SIDE) { "Размер результата превышает ${Enhancer.MAX_SIDE} px" }

        // Не уменьшаем исходник до 1 Мп: каждый фрагмент проходит сеть отдельно,
        // а его центральная часть сразу рисуется в финальный bitmap нужного размера.
        // Поэтому промежуточное полное изображение ×4 не создаётся.
        val inW = src.width
        val inH = src.height
        val output = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            val cores = Runtime.getRuntime().availableProcessors()
            setIntraOpNumThreads(min(2, max(1, cores - 1)))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        var outputReady = false
        try {
            env.createSession(modelFile(ctx.applicationContext).absolutePath, opts).use { session ->
                val inName = session.inputNames.first()
                val tilesX = (inW + CORE - 1) / CORE
                val tilesY = (inH + CORE - 1) / CORE
                val total = tilesX * tilesY
                var done = 0
                var last = -1
                for (ty in 0 until tilesY) for (tx in 0 until tilesX) {
                    currentCoroutineContext().ensureActive()
                    val x0 = tx * CORE
                    val y0 = ty * CORE
                    val x1 = min(x0 + CORE, inW)
                    val y1 = min(y0 + CORE, inH)
                    val sx0 = max(0, x0 - PAD)
                    val sy0 = max(0, y0 - PAD)
                    val sx1 = min(inW, x1 + PAD)
                    val sy1 = min(inH, y1 + PAD)
                    val tw = sx1 - sx0
                    val th = sy1 - sy0
                    val tilePixels = IntArray(tw * th)
                    src.getPixels(tilePixels, 0, tw, sx0, sy0, tw, th)
                    val plane = tw * th
                    val data = FloatArray(3 * plane)
                    for (i in 0 until plane) {
                        val c = tilePixels[i]
                        data[i] = ((c shr 16) and 255) / 255f
                        data[plane + i] = ((c shr 8) and 255) / 255f
                        data[2 * plane + i] = (c and 255) / 255f
                    }
                    OnnxTensor.createTensor(env, FloatBuffer.wrap(data), longArrayOf(1, 3, th.toLong(), tw.toLong())).use { tensor ->
                        session.run(mapOf(inName to tensor)).use { result ->
                            val out = result.get(0) as OnnxTensor
                            val shape = out.info.shape
                            val ow = tw * SCALE
                            val oh = th * SCALE
                            if (shape.size < 4 || shape[2] != oh.toLong() || shape[3] != ow.toLong()) {
                                throw IllegalStateException("Модель улучшения вернула неожиданный размер плитки")
                            }
                            val fb = out.floatBuffer
                            val oPlane = ow * oh
                            val cx = (x0 - sx0) * SCALE
                            val cy = (y0 - sy0) * SCALE
                            val cw = (x1 - x0) * SCALE
                            val ch = (y1 - y0) * SCALE
                            val pixels = IntArray(cw * ch)
                            for (y in 0 until ch) {
                                val row = (cy + y) * ow + cx
                                for (x in 0 until cw) {
                                    val i = row + x
                                    val r = (fb.get(i) * 255f + 0.5f).toInt().coerceIn(0, 255)
                                    val g = (fb.get(oPlane + i) * 255f + 0.5f).toInt().coerceIn(0, 255)
                                    val b = (fb.get(2 * oPlane + i) * 255f + 0.5f).toInt().coerceIn(0, 255)
                                    pixels[y * cw + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
                                }
                            }
                            val tile = Bitmap.createBitmap(pixels, cw, ch, Bitmap.Config.ARGB_8888)
                            try {
                                val dst = RectF(
                                    x0.toFloat() * targetW / inW,
                                    y0.toFloat() * targetH / inH,
                                    x1.toFloat() * targetW / inW,
                                    y1.toFloat() * targetH / inH
                                )
                                canvas.drawBitmap(tile, null, dst, paint)
                            } finally {
                                tile.recycle()
                            }
                        }
                    }
                    done++
                    val progress = done * 92 / total
                    if (progress != last) { last = progress; onProgress(progress) }
                }
            }

            // Real-ESRGAN не восстанавливает альфу. Сохраняем прозрачность исходника,
            // масштабируя её отдельно полосами, не создавая ещё один полный IntArray.
            if (src.hasAlpha()) {
                // Билинейно интерполируем только альфа-канал из двух строк исходника:
                // дополнительный bitmap размером с результат не нужен.
                val srcA = IntArray(src.width)
                val srcB = IntArray(src.width)
                val dst = IntArray(targetW)
                var cachedA = -1
                var cachedB = -1
                for (y in 0 until targetH) {
                    currentCoroutineContext().ensureActive()
                    val fy = ((y + 0.5f) * src.height / targetH - 0.5f).coerceIn(0f, (src.height - 1).toFloat())
                    val y0 = fy.toInt()
                    val y1 = min(y0 + 1, src.height - 1)
                    val ty = fy - y0
                    if (cachedA != y0) {
                        src.getPixels(srcA, 0, src.width, 0, y0, src.width, 1)
                        cachedA = y0
                    }
                    if (cachedB != y1) {
                        src.getPixels(srcB, 0, src.width, 0, y1, src.width, 1)
                        cachedB = y1
                    }
                    output.getPixels(dst, 0, targetW, 0, y, targetW, 1)
                    for (x in 0 until targetW) {
                        val fx = ((x + 0.5f) * src.width / targetW - 0.5f).coerceIn(0f, (src.width - 1).toFloat())
                        val x0 = fx.toInt()
                        val x1 = min(x0 + 1, src.width - 1)
                        val tx = fx - x0
                        val a0 = ((srcA[x0] ushr 24) * (1f - tx) + (srcA[x1] ushr 24) * tx)
                        val a1 = ((srcB[x0] ushr 24) * (1f - tx) + (srcB[x1] ushr 24) * tx)
                        val a = (a0 * (1f - ty) + a1 * ty + 0.5f).toInt().coerceIn(0, 255)
                        dst[x] = (a shl 24) or (dst[x] and 0x00FFFFFF)
                    }
                    output.setPixels(dst, 0, targetW, 0, y, targetW, 1)
                    onProgress(92 + (y + 1) * 8 / targetH)
                }
            } else onProgress(100)
            outputReady = true
            return output
        } finally {
            opts.close()
            if (!outputReady && !output.isRecycled) output.recycle()
        }
    }

}
