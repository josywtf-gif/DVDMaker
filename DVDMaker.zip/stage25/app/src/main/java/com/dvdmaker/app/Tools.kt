package com.dvdmaker.app

import kotlin.math.abs
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.material3.TextButton
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

// ---------- Иконки (рисуются кодом, без внешних библиотек) ----------

enum class Ico {
    PLUS, MOVE, TEXT, FONT, PALETTE, OUTLINE, SHADOW, FRAME, BLEND, TONE, QUALITY, CUTOUT,
    COPY, UP, DOWN, TRASH, BG, LAYERS, GRID, WAND, FX, SHAPE, PHOTO, CHEVRON_UP, CHEVRON_DOWN, MORE, SAVE, EYE, EYE_OFF, LOCK, UNLOCK, EDIT, DRAG, CHECK, CHECK_EMPTY
}

/** Инструменты нижней панели: каждый открывает небольшое окно с настройками. */
enum class Tool(val label: String, val ico: Ico) {
    ADD("Добавить", Ico.PLUS),
    BG("Фон", Ico.BG),
    LAYERS("Слои", Ico.LAYERS),
    FX("Эффекты", Ico.FX),
    POS("Положение", Ico.MOVE),
    TEXT("Текст", Ico.TEXT),
    FONT("Шрифт", Ico.FONT),
    COLOR("Цвет", Ico.PALETTE),
    OUTLINE("Контур", Ico.OUTLINE),
    SHADOW("Тень", Ico.SHADOW),
    MIRROR("Зеркало", Ico.OUTLINE),
    FRAME("Рамка", Ico.FRAME),
    BLEND("Слияние", Ico.BLEND),
    TONE("Цвет и свет", Ico.TONE),
    QUALITY("Качество", Ico.QUALITY),
    CUTOUT("Вырезать", Ico.CUTOUT),
    TEXT_STYLE("Стиль", Ico.PALETTE),
    SHAPE_STYLE("Вид", Ico.SHAPE)
}

@Composable
fun ToolIcon(ico: Ico, tint: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) { drawIco(ico, tint) }
}

private fun DrawScope.drawIco(ico: Ico, c: Color) {
    val s = size.width / 24f
    val sw = 1.8f * s
    val st = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun o(x: Float, y: Float) = Offset(x * s, y * s)
    fun ln(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(c, o(x1, y1), o(x2, y2), sw, StrokeCap.Round)
    fun poly(vararg pts: Float, close: Boolean = false, fill: Boolean = false, color: Color = c) {
        val path = Path()
        for (i in 0 until pts.size / 2) {
            if (i == 0) path.moveTo(pts[0] * s, pts[1] * s) else path.lineTo(pts[i * 2] * s, pts[i * 2 + 1] * s)
        }
        if (close) path.close()
        drawPath(path, color, style = if (fill) Fill else st)
    }
    fun box(x1: Float, y1: Float, x2: Float, y2: Float, r: Float = 2f, color: Color = c, fill: Boolean = false) =
        drawRoundRect(color, o(x1, y1), Size((x2 - x1) * s, (y2 - y1) * s),
            androidx.compose.ui.geometry.CornerRadius(r * s, r * s), style = if (fill) Fill else st)
    when (ico) {
        Ico.PLUS -> { ln(12f, 5f, 12f, 19f); ln(5f, 12f, 19f, 12f) }
        Ico.MOVE -> {
            ln(12f, 4f, 12f, 20f); ln(4f, 12f, 20f, 12f)
            poly(9f, 7f, 12f, 4f, 15f, 7f); poly(9f, 17f, 12f, 20f, 15f, 17f)
            poly(7f, 9f, 4f, 12f, 7f, 15f); poly(17f, 9f, 20f, 12f, 17f, 15f)
        }
        Ico.TEXT -> { ln(5f, 6f, 19f, 6f); ln(12f, 6f, 12f, 19f); ln(9f, 19f, 15f, 19f) }
        Ico.FONT -> {
            poly(3.5f, 19f, 8.5f, 6f, 13.5f, 19f); ln(5.4f, 14.5f, 11.6f, 14.5f)
            drawCircle(c, 2.7f * s, o(18f, 15.8f), style = st); ln(20.7f, 13.2f, 20.7f, 19f)
        }
        Ico.PALETTE -> {
            drawCircle(c, 8f * s, o(12f, 12f), style = st)
            drawCircle(c, 1.3f * s, o(8.5f, 11f)); drawCircle(c, 1.3f * s, o(12f, 8f))
            drawCircle(c, 1.3f * s, o(15.5f, 11f)); drawCircle(c, 1.3f * s, o(12f, 15f))
        }
        Ico.OUTLINE -> {
            drawRoundRect(c, o(4.5f, 4.5f), Size(15f * s, 15f * s),
                androidx.compose.ui.geometry.CornerRadius(2f * s, 2f * s),
                style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2.6f * s, 2.2f * s))))
            ln(9f, 10f, 15f, 10f); ln(12f, 10f, 12f, 16f)
        }
        Ico.SHADOW -> {
            drawCircle(c.copy(alpha = 0.35f), 5.6f * s, o(14f, 14f))
            drawCircle(c, 5.6f * s, o(10f, 10f), style = st)
        }
        Ico.SAVE -> { box(4f, 4f, 20f, 20f, 2f); poly(8f, 4f, 8f, 9f, 15f, 9f, 15f, 4f); box(8f, 14f, 16f, 20f, 1f) }
        Ico.FRAME -> { box(3.5f, 5.5f, 20.5f, 18.5f, 1.5f); box(7f, 9f, 17f, 15f, 1f) }
        Ico.BLEND -> {
            drawRoundRect(Brush.horizontalGradient(listOf(c, c.copy(alpha = 0f)), startX = 4f * s, endX = 20f * s),
                o(4f, 4f), Size(16f * s, 16f * s), androidx.compose.ui.geometry.CornerRadius(3f * s, 3f * s))
            box(4f, 4f, 20f, 20f, 3f)
        }
        Ico.TONE -> {
            drawCircle(c, 8f * s, o(12f, 12f), style = st)
            drawArc(c, -90f, 180f, true, o(4f, 4f), Size(16f * s, 16f * s))
        }
        Ico.QUALITY -> poly(12f, 3f, 14f, 10f, 21f, 12f, 14f, 14f, 12f, 21f, 10f, 14f, 3f, 12f, 10f, 10f, close = true)
        Ico.CUTOUT -> {
            drawRoundRect(c, o(3.5f, 3.5f), Size(17f * s, 17f * s),
                androidx.compose.ui.geometry.CornerRadius(2f * s, 2f * s),
                style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2.6f * s, 2.2f * s))))
            drawCircle(c, 2.4f * s, o(12f, 9.5f), style = st)
            poly(7.5f, 17f, 8.5f, 13.5f, 15.5f, 13.5f, 16.5f, 17f)
        }
        Ico.COPY -> { box(4f, 4f, 14f, 14f, 2f); box(10f, 10f, 20f, 20f, 2f) }
        Ico.UP -> { ln(6f, 4f, 18f, 4f); ln(12f, 20f, 12f, 8f); poly(7f, 13f, 12f, 8f, 17f, 13f) }
        Ico.DOWN -> { ln(6f, 20f, 18f, 20f); ln(12f, 4f, 12f, 16f); poly(7f, 11f, 12f, 16f, 17f, 11f) }
        Ico.TRASH -> {
            ln(5f, 7f, 19f, 7f); poly(9f, 7f, 9f, 4.5f, 15f, 4.5f, 15f, 7f)
            poly(7f, 7f, 8f, 20f, 16f, 20f, 17f, 7f); ln(10.5f, 10.5f, 10.5f, 16.5f); ln(13.5f, 10.5f, 13.5f, 16.5f)
        }
        Ico.BG -> {
            box(4f, 4f, 20f, 20f, 2.5f)
            poly(20f, 4f, 20f, 20f, 4f, 20f, close = true, fill = true, color = c.copy(alpha = 0.35f))
        }
        Ico.LAYERS -> {
            poly(12f, 4f, 21f, 9f, 12f, 14f, 3f, 9f, close = true)
            poly(3f, 13.5f, 12f, 18.5f, 21f, 13.5f)
        }
        Ico.GRID -> {
            drawRoundRect(c, o(4.5f, 4.5f), Size(15f * s, 15f * s),
                androidx.compose.ui.geometry.CornerRadius(1.5f * s, 1.5f * s),
                style = Stroke(sw, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2.6f * s, 2.2f * s))))
            drawCircle(c, 1.3f * s, o(12f, 12f))
        }
        Ico.WAND -> {
            ln(4.5f, 19.5f, 13.5f, 10.5f); ln(17f, 3.5f, 17f, 9.5f); ln(14f, 6.5f, 20f, 6.5f)
            ln(18.5f, 14f, 18.5f, 18f); ln(16.5f, 16f, 20.5f, 16f)
        }
        Ico.FX -> { ln(12f, 3f, 12f, 21f); ln(4.2f, 7.5f, 19.8f, 16.5f); ln(4.2f, 16.5f, 19.8f, 7.5f) }
        Ico.SHAPE -> box(4f, 7f, 20f, 17f, 2f, fill = true)
        Ico.CHEVRON_UP -> poly(6f, 15f, 12f, 9f, 18f, 15f)
        Ico.CHEVRON_DOWN -> poly(6f, 9f, 12f, 15f, 18f, 9f)
        Ico.MORE -> { drawCircle(c, 1.6f * s, o(12f, 5f)); drawCircle(c, 1.6f * s, o(12f, 12f)); drawCircle(c, 1.6f * s, o(12f, 19f)) }
        Ico.PHOTO -> {
            box(3.5f, 5f, 20.5f, 19f, 2f)
            poly(4f, 17f, 9f, 11.5f, 13f, 15.5f, 15.5f, 13f, 20f, 17.5f)
            drawCircle(c, 1.5f * s, o(16f, 9f))
        }
        Ico.EYE -> {
            poly(2.5f, 12f, 6f, 7.5f, 12f, 5.5f, 18f, 7.5f, 21.5f, 12f, 18f, 16.5f, 12f, 18.5f, 6f, 16.5f, close = true)
            drawCircle(c, 3f * s, o(12f, 12f), style = st)
        }
        Ico.EYE_OFF -> {
            poly(3f, 8f, 6f, 6f, 12f, 5.5f, 18f, 7.5f, 21f, 11f)
            poly(21f, 16f, 18f, 17.5f, 12f, 18.5f, 6f, 16.5f, 3f, 13f)
            ln(4f, 4f, 20f, 20f)
        }
        Ico.LOCK -> {
            box(5f, 10f, 19f, 21f, 2f)
            drawArc(c, 180f, 180f, false, o(8f, 3f), Size(8f * s, 12f * s), style = st)
            drawCircle(c, 1.2f * s, o(12f, 15f))
        }
        Ico.UNLOCK -> {
            box(5f, 10f, 19f, 21f, 2f)
            drawArc(c, 180f, 180f, false, o(8f, 3f), Size(8f * s, 12f * s), style = st)
            ln(16f, 4f, 19f, 7f)
            drawCircle(c, 1.2f * s, o(12f, 15f))
        }
        Ico.EDIT -> {
            poly(4f, 17f, 15.5f, 5.5f, 19f, 7f, 7.5f, 18.5f, 4f, 20f, close = true)
            ln(13.5f, 7.5f, 16.5f, 10.5f)
        }
        Ico.DRAG -> {
            for (x in listOf(8f, 16f)) for (y in listOf(6f, 12f, 18f)) drawCircle(c, 1.2f * s, o(x, y))
        }
        Ico.CHECK -> {
            box(3f, 3f, 21f, 21f, 3f)
            poly(6.5f, 12f, 10f, 15.5f, 17.5f, 8f)
        }
        Ico.CHECK_EMPTY -> box(3f, 3f, 21f, 21f, 3f)
    }
}

// ---------- Нижняя панель ----------

class BarItem(
    val label: String,
    val ico: Ico,
    val active: Boolean = false,
    val danger: Boolean = false,
    val onClick: () -> Unit
)

/** Строка значков с подписями (как в Snapseed): белые значки, выбранный — в чёрной рамке; null — разделитель. */
@Composable
fun ToolBar(items: List<BarItem?>, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(18.dp)).background(Card)
            .border(BorderStroke(1.dp, Line), RoundedCornerShape(18.dp))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { item ->
            if (item == null) {
                Box(Modifier.padding(horizontal = 4.dp, vertical = 8.dp).size(1.dp, 30.dp).background(Line))
            } else {
                val tint = if (item.danger) Color(0xFFFF8A8A) else Color.White
                Column(
                    Modifier.width(64.dp).heightIn(min = 56.dp).clip(RoundedCornerShape(12.dp))
                        .then(if (item.active) Modifier.background(Card2).border(BorderStroke(1.5.dp, Violet), RoundedCornerShape(12.dp)) else Modifier)
                        .clickable(onClick = item.onClick)
                        .padding(vertical = 6.dp, horizontal = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    ToolIcon(item.ico, if (item.active) Violet else tint, Modifier.size(22.dp))
                    Spacer(Modifier.size(3.dp))
                    Text(item.label, color = if (item.active) Violet else tint, fontSize = 9.sp, maxLines = 1, softWrap = false,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                }
            }
        }
    }
}

/** Нижние вкладки: «Стили» · «Инструменты ⌃» · «Экспорт». */
@Composable
fun BottomTabs(onStyles: () -> Unit, onTools: () -> Unit, onExport: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).background(Bg).padding(top = 2.dp, bottom = 2.dp), verticalAlignment = Alignment.Bottom) {
        Box(Modifier.weight(1f).clickable(onClick = onStyles).heightIn(min = 48.dp).padding(vertical = 10.dp), contentAlignment = Alignment.Center) { TabLabel("Стили") }
        Column(Modifier.weight(1.25f).heightIn(min = 48.dp).clickable(onClick = onTools), horizontalAlignment = Alignment.CenterHorizontally) {
            ToolIcon(Ico.CHEVRON_UP, Color.White, Modifier.size(17.dp))
            Box(Modifier.padding(bottom = 5.dp)) { TabLabel("Инструменты") }
        }
        Box(Modifier.weight(1f).clickable(onClick = onExport).heightIn(min = 48.dp).padding(vertical = 10.dp), contentAlignment = Alignment.Center) { TabLabel("Экспорт") }
    }
}

@Composable
private fun TabLabel(text: String) {
    Text(text.uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 0.35.sp, maxLines = 1)
}

/** Пункт большой сетки инструментов. group: 1 — объект, 2 — страница. */
class GridItem(val label: String, val ico: Ico, val group: Int, val danger: Boolean = false, val onClick: () -> Unit)

/** Полная сетка инструментов (как «Инструменты» в Snapseed): вкладки Все / Объект / Страница и кнопка «Закрыть». */
@Composable
fun ToolGrid(items: List<GridItem>, hasObject: Boolean, onClose: () -> Unit, modifier: Modifier = Modifier) {
    var tab by remember { mutableIntStateOf(0) }
    Box(modifier.background(Bg)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TabChip("Все", tab == 0, { tab = 0 })
                TabChip("Объект", tab == 1, { tab = 1 })
                TabChip("Страница", tab == 2, { tab = 2 })
            }
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
                val shown = items.filter { tab == 0 || it.group == tab }
                if (shown.isEmpty()) {
                    EmptyState(
                        title = if (!hasObject) "Сначала выберите объект" else "Нет инструментов в разделе",
                        message = if (!hasObject) "Коснитесь фотографии, текста или фигуры на холсте, чтобы открыть подходящие настройки." else "Переключитесь на другой раздел инструментов."
                    )
                }
                shown.chunked(3).forEach { line ->
                    Row(Modifier.fillMaxWidth()) {
                        line.forEach { g ->
                            val tint = if (g.danger) Color(0xFFFF8A8A) else Color.White
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).clickable(onClick = g.onClick)
                                    .padding(vertical = 14.dp, horizontal = 4.dp).heightIn(min = 92.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                ToolIcon(g.ico, tint, Modifier.size(30.dp))
                                Spacer(Modifier.size(8.dp))
                                Text(g.label, color = tint, fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 2)
                            }
                        }
                        repeat(3 - line.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Spacer(Modifier.size(86.dp))
            }
        }
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 14.dp)
                .clip(RoundedCornerShape(12.dp)).background(Card2)
                .border(BorderStroke(1.dp, Line), RoundedCornerShape(12.dp))
                .clickable(onClick = onClose).padding(horizontal = 34.dp, vertical = 14.dp)
        ) { Text("ЗАКРЫТЬ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp, letterSpacing = 0.6.sp) }
    }
}

// ---------- Всплывающее окно настроек ----------

/**
 * Небольшое окно поверх затемнённого изображения. Пока палец держит ползунок ([hidden]),
 * окно и затемнение плавно исчезают — видно только изображение; после отпускания возвращаются.
 * Содержимое остаётся в композиции, поэтому жест ползунка не обрывается.
 */
@Composable
fun BoxScope.ToolSheetHost(
    visible: Boolean,
    hidden: Boolean,
    title: String,
    bottomPad: Dp,
    onClose: () -> Unit,
    onHeight: (Int) -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val a by animateFloatAsState(if (hidden) 0f else 1f, tween(if (hidden) 90 else 160), label = "sheetAlpha")
    val configuration = LocalConfiguration.current
    val landscape = configuration.screenWidthDp > configuration.screenHeightDp
    val maxH = (configuration.screenHeightDp * if (landscape) 0.62f else 0.52f).dp
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(tween(180)) { it / 2 } + fadeIn(tween(140)),
        exit = slideOutVertically(tween(140)) { it / 2 } + fadeOut(tween(120)),
        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomPad)
    ) {
        // Без затемнения: обложка остаётся видна и доступна для жестов над панелью.
        Column(
            Modifier.fillMaxWidth().onSizeChanged { onHeight(it.height) }
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .graphicsLayer { alpha = a }
                .clip(RoundedCornerShape(18.dp))
                .background(Card)
                .border(BorderStroke(1.dp, Line), RoundedCornerShape(18.dp))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                .padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 10.dp)
        ) {
            Box(Modifier.align(Alignment.CenterHorizontally).size(38.dp, 4.dp).clip(RoundedCornerShape(50)).background(Violet))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Box(
                    Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onClose)
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) { Text("Готово", color = Violet, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            }
            Column(
                Modifier.heightIn(max = maxH).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) { content() }
        }
    }
}

/** Всплывающая подпись значения, пока двигается ползунок. */
@Composable
fun SliderValueHud(hud: SliderHud, modifier: Modifier = Modifier) {
    if (hud.count > 0) {
        Box(
            modifier.clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.72f))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) { Text(hud.text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
    }
}

// ---------- Контекст выбранного слоя ----------

/**
 * Всё, что нужно окнам настроек, чтобы править выбранный слой — обычный (на панели) или общий (на «Обзоре»).
 * [update] получает короткий ключ (для склейки шагов отмены) и функцию изменения слоя.
 */
class LayerCtx(
    val layer: Layer,
    val wMm: Float,
    val hMm: Float,
    val spine: Boolean,
    val shared: Boolean,
    val update: (String, (Layer) -> Layer) -> Unit,
    val applyFont: (Int, String, Boolean?) -> Unit
)

/** Действия, которые окнам нужно запускать у экрана (выбор файлов, диалоги). */
class SheetActions(
    val onPhoto: () -> Unit,
    val onBgPhoto: () -> Unit,
    val onSharedPhoto: () -> Unit,
    val onSharedText: () -> Unit,
    val onUnifiedBg: () -> Unit,
    val onUnifiedImage: () -> Unit,
    val onPickFrontColor: () -> Unit,
    val onConfirmResetBackground: () -> Unit,
    val toggleGuides: () -> Unit,
    val close: () -> Unit
)

fun layerTools(l: Layer, shared: Boolean): List<Tool> = when (l.kind) {
    // Текстовые эффекты объединены в одну категорию «Стиль»; сами панели настроек остаются независимыми.
    Kind.TEXT -> listOf(Tool.POS, Tool.TEXT, Tool.FONT, Tool.TEXT_STYLE)
    Kind.IMAGE -> listOfNotNull(Tool.POS, Tool.BLEND, Tool.TONE, Tool.MIRROR, if (shared) null else Tool.QUALITY, if (shared) null else Tool.CUTOUT, Tool.FRAME)
    // Цвет/заливка и рамка фигуры собраны в одном контекстном разделе.
    Kind.RECT -> listOf(Tool.POS, Tool.SHAPE_STYLE)
    Kind.SYMBOL -> listOf(Tool.POS, Tool.FRAME)
}

// ---------- Содержимое окон ----------

@Composable
private fun ListButton(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(if (selected) Violet.copy(alpha = 0.25f) else Card2)
            .border(BorderStroke(1.dp, if (selected) Violet else Line), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 11.dp)
    ) { Text(text, color = if (selected) Color.White else Color(0xFFD0D4F0), fontSize = 14.sp) }
}

@Composable
private fun ToolTile(label: String, ico: Ico, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(Card2)
            .border(BorderStroke(1.dp, Line), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick).padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ToolIcon(ico, Color.White, Modifier.size(26.dp))
        Spacer(Modifier.size(5.dp))
        Text(label, color = Color(0xFFD0D4F0), fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
private fun TileGrid(tiles: List<Triple<String, Ico, () -> Unit>>, perRow: Int = 3) {
    tiles.chunked(perRow).forEach { line ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            line.forEach { (label, ico, click) -> ToolTile(label, ico, Modifier.weight(1f), click) }
            repeat(perRow - line.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

private fun tile(label: String, ico: Ico, click: () -> Unit) = Triple(label, ico, click)

fun Layer.shortLabel(index: Int = 0): String = name.takeIf { it.isNotBlank() } ?: when (kind) {
    Kind.TEXT -> text.replace("\n", " ").take(18).ifBlank { "Текст" }
    Kind.IMAGE -> if (index > 0) "Фото $index" else "Фото"
    Kind.RECT -> "Фигура"
    Kind.SYMBOL -> "Значок: $text"
}

/** Содержимое окна «Добавить» / «Фон» / «Слои» / «Эффекты» — то, что не относится к конкретному слою. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GlobalSheet(tool: Tool, vm: AppVm, p: Project, guides: Boolean, act: SheetActions) {
    when (tool) {
        Tool.ADD -> if (!vm.overview) {
            TileGrid(listOf(
                tile("Текст", Ico.TEXT) { vm.addText(); act.close() },
                tile("Фигура", Ico.SHAPE) { vm.addRect(); act.close() },
                tile("Фото", Ico.PHOTO) { act.onPhoto(); act.close() },
                tile("Фото-фон", Ico.BG) { act.onBgPhoto(); act.close() }
            ), 4)
        } else {
            val items = ArrayList<Triple<String, Ico, () -> Unit>>()
            items += tile("Текст", Ico.TEXT) { act.onSharedText(); act.close() }
            items += tile("Фото", Ico.PHOTO) { act.onSharedPhoto(); act.close() }
            items += tile("Фигура", Ico.SHAPE) { vm.addSharedRect(); act.close() }
            if (!p.format.photo) {
                items += tile("Фото на всю обложку", Ico.BG) { act.onUnifiedBg(); act.close() }
                items += tile("Сквозное фото", Ico.BLEND) { act.onUnifiedImage(); act.close() }
            }
            TileGrid(items, 3)
            Text("Общие слои лежат поверх всех частей обложки. «Фото на всю обложку» одно фото на оборот, корешок и лицо; слои панелей остаются поверх.", color = Dim, fontSize = 12.sp)
        }
        Tool.BG -> {
            val side = vm.panel == PanelId.BACK || vm.panel == PanelId.SPINE
            if (side) {
                SectionLabel("Подобрать по лицу")
                ListButton("Пипетка с лица") { act.onPickFrontColor() }
                ListButton("Размытый фон с лица") { vm.useBlurredFrontAsBackground(vm.panel); act.close() }
                ListButton("Палитра с лица") { vm.paletteFromFront(vm.panel); act.close() }
                ListButton("Перенос цвета с лица") { vm.applyColorTransfer(vm.panel); act.close() }
                ListButton("Единый фон оборот + корешок") { vm.unifyBackAndSpine(); act.close() }
                if (vm.panel == PanelId.SPINE) ListButton("Цвета с оборота и лица") { vm.spineFromNeighbors(); act.close() }
            }
            if (vm.panel == PanelId.DISC) ListButton("Фон с лицевой стороны") { vm.discFromFront(); act.close() }
            ListButton("Сбросить фон") { act.onConfirmResetBackground() }
            Text(
                when (vm.panel) {
                    PanelId.DISC -> "Печать на диске: круг 118 мм, отверстие 22 мм. Затемнённое не напечатается."
                    PanelId.SPINE -> "Корешок подстраивается под оборот и лицо — стыков не будет."
                    PanelId.BACK -> "Фон оборота можно согласовать с лицом."
                    else -> "Фон формируется автоматически. Для оформления используйте фото и слои."
                }, color = Dim, fontSize = 12.sp
            )
        }
        Tool.LAYERS -> {
            if (!vm.overview) LayerManager(vm, p, act.close)
            else {
                var n = 0
                p.canvasLayers.forEach { l ->
                    val idx = if (l.kind == Kind.IMAGE) ++n else 0
                    ListButton(l.shortLabel(idx), l.id == vm.sharedSelected) {
                        vm.sharedSelected = if (vm.sharedSelected == l.id) null else l.id; act.close()
                    }
                }
            }
        }
        Tool.FX -> FxControls(vm, p)
        else -> Unit
    }
}

@Composable
private fun LayerManager(vm: AppVm, p: Project, close: () -> Unit) {
    val layers = p.panel(vm.panel).layers
    var renameId by remember { mutableStateOf<String?>(null) }
    var renameValue by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Группа", color = Violet, modifier = Modifier.clickable { vm.groupSelected() }.padding(4.dp), fontSize = 11.sp)
            Text("Разгрупп.", color = Violet, modifier = Modifier.clickable { vm.ungroupSelected() }.padding(4.dp), fontSize = 11.sp)
            Text("Копия", color = Violet, modifier = Modifier.clickable { vm.duplicateMany() }.padding(4.dp), fontSize = 11.sp)
            Text("Слить", color = Violet, modifier = Modifier.clickable { vm.mergeSelected() }.padding(4.dp), fontSize = 11.sp)
        }
        Text("Выбрано: ${vm.multiSelected.size}", color = Dim, fontSize = 11.sp)
        Column(Modifier.fillMaxWidth().heightIn(max = 330.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            layers.asReversed().forEachIndexed { reverseIndex, l ->
                val index = layers.lastIndex - reverseIndex
                val active = l.id == vm.selected
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(if (active) Color(0xFF29243D) else Card)
                        .border(1.dp, if (active) Violet else Line, RoundedCornerShape(10.dp))
                        .combinedClickable(onClick = { vm.selected = l.id; close() }, onLongClick = { vm.selectMany(l.id) })
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(7.dp)).background(Color(0xFF171923)), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize().padding(5.dp)) {
                            val color = Color(l.color)
                            when (l.kind) {
                                Kind.TEXT -> {
                                    drawLine(color, Offset(size.width*.18f, size.height*.25f), Offset(size.width*.82f, size.height*.25f), strokeWidth = size.height*.13f)
                                    drawLine(color, Offset(size.width*.5f, size.height*.25f), Offset(size.width*.5f, size.height*.82f), strokeWidth = size.height*.13f)
                                }
                                Kind.IMAGE -> drawRect(color = Color(0xFF68758A), topLeft = Offset(size.width*.1f,size.height*.1f), size = Size(size.width*.8f,size.height*.8f))
                                Kind.RECT -> drawRect(color = color, topLeft = Offset(size.width*.12f,size.height*.28f), size = Size(size.width*.76f,size.height*.44f))
                                Kind.SYMBOL -> drawCircle(color = color, radius = size.minDimension*.34f)
                            }
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(l.name.ifBlank { l.shortLabel() }, color = Color.White, fontSize = 12.sp, maxLines = 1)
                        Text("${l.kind.name.lowercase()}${if (l.groupId.isNotBlank()) " · группа" else ""}", color = Dim, fontSize = 9.sp)
                    }
                    ToolIcon(if (l.id in vm.multiSelected) Ico.CHECK else Ico.CHECK_EMPTY,
                        if (l.id in vm.multiSelected) Violet else Dim,
                        Modifier.size(19.dp).clickable { vm.selectMany(l.id) })
                    ToolIcon(if (l.visible) Ico.EYE else Ico.EYE_OFF, Color.White,
                        Modifier.size(19.dp).clickable { vm.toggleLayerVisible(l.id) })
                    ToolIcon(if (l.locked) Ico.LOCK else Ico.UNLOCK, Dim,
                        Modifier.size(19.dp).clickable { vm.toggleLayerLocked(l.id) })
                    ToolIcon(Ico.EDIT, Color.White, Modifier.size(18.dp).clickable {
                        renameId = l.id; renameValue = l.name.ifBlank { l.shortLabel() }
                    })
                    var dragDistance by remember(l.id) { mutableStateOf(0f) }
                    ToolIcon(Ico.DRAG, Dim, Modifier.size(20.dp).pointerInput(l.id, index) {
                        detectDragGestures(onDragEnd = {
                            if (kotlin.math.abs(dragDistance) > 24f) {
                                val target = (index + if (dragDistance < 0f) 1 else -1).coerceIn(0, layers.lastIndex)
                                vm.reorderLayer(l.id, target)
                            }
                            dragDistance = 0f
                        }) { change, amount -> dragDistance += amount.y; change.consume() }
                    })
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        ToolIcon(Ico.UP, Color.White, Modifier.size(16.dp).clickable {
                            vm.reorderLayer(l.id, (index+1).coerceAtMost(layers.lastIndex))
                        })
                        ToolIcon(Ico.DOWN, Color.White, Modifier.size(16.dp).clickable {
                            vm.reorderLayer(l.id, (index-1).coerceAtLeast(0))
                        })
                    }
                }
                if (renameId == l.id) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(renameValue, { renameValue = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Имя слоя") })
                        TextButton(onClick = { vm.renameLayer(l.id, renameValue); renameId = null }) { Text("OK") }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Дублировать выбранное", color = Violet, modifier = Modifier.clickable { vm.duplicateMany() }.padding(4.dp), fontSize = 11.sp)
            Text("Снять выбор", color = Dim, modifier = Modifier.clickable { vm.clearMultiSelection() }.padding(4.dp), fontSize = 11.sp)
        }
        Text("Нажатие — выбрать · удержание/□ — мультивыбор. Скрытые слои не отображаются; заблокированные нельзя двигать.", color = Dim, fontSize = 10.sp)
    }
}

@Composable
private fun ExactNumberField(label: String, value: Float, suffix: String, key: String = label, onValue: (Float) -> Unit) {
    var draft by remember(key) { mutableStateOf(String.format(java.util.Locale.US, "%.2f", value)) }
    OutlinedTextField(
        value = draft,
        onValueChange = { raw -> draft = raw.filter { it.isDigit() || it == '.' || it == ',' || it == '-' } },
        modifier = Modifier.width(112.dp), singleLine = true,
        label = { Text(label, fontSize = 10.sp) }, trailingIcon = { Text(suffix, fontSize = 10.sp, color = Dim) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { draft.replace(',', '.').toFloatOrNull()?.takeIf { it.isFinite() }?.let(onValue) }),
        colors = fieldColors()
    )
}

/** Компактный заголовок группы настроек: раскрывает параметры, не меняя сами значения. */
@Composable
private fun ToolGroupHeader(title: String, detail: String, expanded: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp)).background(Card2)
            .clickable(onClick = onClick).padding(horizontal = 11.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Dim, fontSize = 10.sp)
        }
        Text(if (expanded) "Свернуть  ▴" else "Настроить  ▾", color = Violet, fontSize = 10.sp)
    }
}

/** Содержимое окон настроек выбранного слоя. */
@Composable
fun LayerSheet(tool: Tool, vm: AppVm, p: Project, x: LayerCtx) {
    val l = x.layer
    when (tool) {
        Tool.TEXT_STYLE -> {
            var section by remember(l.id) { mutableStateOf(Tool.COLOR) }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    Tool.COLOR to "Цвет",
                    Tool.OUTLINE to "Контур",
                    Tool.SHADOW to "Тень",
                    Tool.MIRROR to "Зеркало",
                    Tool.FRAME to "Рамка"
                ).forEach { (target, label) ->
                    Pill(label, section == target, { section = target })
                }
            }
            LayerToolContent(section, vm, p, x)
        }
        Tool.SHAPE_STYLE -> {
            var section by remember(l.id) { mutableStateOf(Tool.COLOR) }
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Pill("Цвет и заливка", section == Tool.COLOR, { section = Tool.COLOR })
                Pill("Рамка", section == Tool.FRAME, { section = Tool.FRAME })
            }
            LayerToolContent(section, vm, p, x)
        }
        else -> LayerToolContent(tool, vm, p, x)
    }
}

@Composable
private fun LayerToolContent(tool: Tool, vm: AppVm, p: Project, x: LayerCtx) {
    val l = x.layer
    androidx.compose.runtime.DisposableEffect(l.id) { onDispose { vm.clearLayerPreview() } }
    when (tool) {
        Tool.POS -> {
            var manual by remember(l.id) { mutableStateOf(false) }
            val big = max(x.wMm, x.hMm)
            val refW = if (x.spine) x.hMm else x.wMm
            // Положение (на корешке холст повёрнут: экранная «вертикаль» — это ось X панели).
            fun hAt(v: Float): (Layer) -> Layer = { if (x.spine) it.copy(y = v) else it.copy(x = v) }
            fun vAt(v: Float): (Layer) -> Layer = { if (x.spine) it.copy(x = 1f - v) else it.copy(y = v) }
            PresetRow {
                Pill("Центр", abs(l.x - 0.5f) < 0.01f && abs(l.y - 0.5f) < 0.01f, { x.update("pp") { it.copy(x = 0.5f, y = 0.5f) } })
                Pill("Вверх", false, { x.update("pp") { vAt(0.15f)(it) } })
                Pill("Вниз", false, { x.update("pp") { vAt(0.85f)(it) } })
                Pill("Влево", false, { x.update("pp") { hAt(0.15f)(it) } })
                Pill("Вправо", false, { x.update("pp") { hAt(0.85f)(it) } })
            }
            // Размер
            val sizes = if (l.kind == Kind.TEXT) {
                val f = if (x.spine) floatArrayOf(0.35f, 0.55f, 0.8f) else floatArrayOf(0.05f, 0.09f, 0.16f)
                val base = if (x.spine) x.wMm else x.wMm
                listOf("Малый" to base * f[0], "Средний" to base * f[1], "Крупный" to base * f[2])
            } else listOf("Малый" to refW * 0.3f, "Средний" to refW * 0.6f, "Крупный" to refW * 0.9f)
            PresetRow {
                sizes.forEach { (name, v) ->
                    val cur = if (l.kind == Kind.TEXT) l.sizeMm else l.widthMm
                    Pill(name, abs(cur - v) < v * 0.04f, {
                        x.update("ps") { if (it.kind == Kind.TEXT) it.copy(sizeMm = v.coerceAtLeast(1f)) else it.copy(widthMm = v.coerceAtLeast(2f)) }
                    })
                }
                if (l.kind == Kind.IMAGE && !x.shared) {
                    Pill("Заполнить макет", false, { vm.fillSelected(true) })
                    Pill("Вписать целиком", false, { vm.fillSelected(false) })
                }
            }
            // Поворот и прозрачность
            PresetRow {
                Pill("Прямо", normRot(l.rot) == 0f, { x.update("pr") { it.copy(rot = 0f) } })
                Pill("90°", normRot(l.rot) == 90f, { x.update("pr") { it.copy(rot = 90f) } })
                Pill("−90°", normRot(l.rot) == -90f, { x.update("pr") { it.copy(rot = -90f) } })
                Pill("Непрозрачный", l.alpha >= 0.99f, { x.update("pa") { it.copy(alpha = 1f) } })
                Pill("Полупрозрачный", abs(l.alpha - 0.6f) < 0.05f, { x.update("pa") { it.copy(alpha = 0.6f) } })
                Pill("Лёгкий", abs(l.alpha - 0.3f) < 0.05f, { x.update("pa") { it.copy(alpha = 0.3f) } })
                Pill("Настроить", manual, { manual = !manual })
            }
            if (manual) {
                PositionSliders(l.x, l.y, x.wMm, x.hMm, x.spine,
                    onX = { v -> x.update("px") { it.copy(x = v) } },
                    onY = { v -> x.update("py") { it.copy(y = v) } })
                Text("Координаты от левого верхнего угла панели", color = Dim, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ExactNumberField("X", l.x * x.wMm, "мм", "x-${l.id}") { v -> x.update("exact-x") { it.copy(x = (v / x.wMm).coerceIn(-0.2f, 1.2f)) } }
                    ExactNumberField("Y", l.y * x.hMm, "мм", "y-${l.id}") { v -> x.update("exact-y") { it.copy(y = (v / x.hMm).coerceIn(-0.2f, 1.2f)) } }
                }
                when (l.kind) {
                    Kind.TEXT -> LabeledSlider("Размер", l.sizeMm, 1f..(if (x.shared) 120f else 80f), "${f1(l.sizeMm)} мм") { v ->
                        x.update("s") { it.copy(sizeMm = v) }
                    }
                    Kind.RECT -> {
                        LabeledSlider("Ширина", l.widthMm, 0.5f..(big * 1.5f), "${f1(l.widthMm)} мм") { v -> x.update("w") { it.copy(widthMm = v) } }
                        LabeledSlider("Высота", l.sizeMm, 0.3f..(big * 1.5f), "${f1(l.sizeMm)} мм") { v -> x.update("h") { it.copy(sizeMm = v) } }
                    }
                    else -> LabeledSlider("Размер (ширина)", l.widthMm, 2f..(big * 2.5f), "${f1(l.widthMm)} мм") { v ->
                        x.update("w") { it.copy(widthMm = v) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (l.kind == Kind.TEXT) ExactNumberField("Размер", l.sizeMm, "мм", "size-${l.id}") { v -> x.update("exact-size") { it.copy(sizeMm = v.coerceIn(1f, 120f)) } }
                    else {
                        ExactNumberField("Ширина", l.widthMm, "мм", "width-${l.id}") { v -> x.update("exact-width") { it.copy(widthMm = v.coerceIn(0.5f, 900f)) } }
                        if (l.kind == Kind.RECT) ExactNumberField("Высота", l.sizeMm, "мм", "height-${l.id}") { v -> x.update("exact-height") { it.copy(sizeMm = v.coerceIn(0.3f, 900f)) } }
                    }
                    ExactNumberField("Угол", normRot(l.rot), "°", "rot-${l.id}") { v -> x.update("exact-rot") { it.copy(rot = v.coerceIn(-360f, 360f)) } }
                }
                LabeledSlider("Поворот", normRot(l.rot), -180f..180f, "${normRot(l.rot).toInt()}°") { v -> x.update("r") { it.copy(rot = v) } }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill("Отразить ↔", l.flipX, { x.update("mirror-x") { it.copy(flipX = !it.flipX) } })
                    Pill("Отразить ↕", l.flipY, { x.update("mirror-y") { it.copy(flipY = !it.flipY) } })
                    Pill("Центр", false, { x.update("center") { it.copy(x = .5f, y = .5f) } })
                }
                if (!x.shared) {
                    Text("Выравнивание выбранных слоёв", color = Dim, fontSize = 11.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Pill("Левый край", false, { vm.alignSelected("left") })
                        Pill("Центр X", false, { vm.alignSelected("center-x") })
                        Pill("Правый", false, { vm.alignSelected("right") })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Pill("Верх", false, { vm.alignSelected("top") })
                        Pill("Центр Y", false, { vm.alignSelected("center-y") })
                        Pill("Низ", false, { vm.alignSelected("bottom") })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Pill("Распределить X", false, { vm.distributeSelected(true) })
                        Pill("Распределить Y", false, { vm.distributeSelected(false) })
                    }
                    Text("Сетка привязки: ${f1(vm.gridMm)} мм", color = Dim, fontSize = 11.sp)
                    LabeledSlider("Шаг сетки", vm.gridMm, 0f..20f, if (vm.gridMm == 0f) "Выкл." else "${f1(vm.gridMm)} мм") { vm.updateGridMm(it) }
                }
                LabeledSlider("Прозрачность", l.alpha, 0.05f..1f, "${(l.alpha * 100).toInt()}%") { v -> x.update("a") { it.copy(alpha = v) } }
            }
        }
        Tool.TEXT -> SettingsGroup("Содержание и выравнивание", initiallyExpanded = true) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionLabel("Текст на обложке")
            OutlinedTextField(
                value = l.text, onValueChange = { t -> x.update("t") { it.copy(text = t) } },
                modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 6,
                colors = fieldColors(), label = { Text("Текст", color = Dim) }
            )
            SectionLabel("Форматирование")
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill("Курсив", l.italic, { x.applyFont(l.font, l.fontFile, !l.italic) })
                Pill("ЗАГЛАВНЫЕ", l.upper, { x.update("up") { it.copy(upper = !it.upper) } })
                Pill("Слева", l.align == 0, { x.update("al") { it.copy(align = 0) } })
                Pill("Центр", l.align == 1, { x.update("al") { it.copy(align = 1) } })
                Pill("Справа", l.align == 2, { x.update("al") { it.copy(align = 2) } })
            }
            }
        }
        Tool.FONT -> SettingsGroup("Шрифт и типографика", initiallyExpanded = true) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            var fontQuery by remember { mutableStateOf("") }
            var favoritesOnly by remember { mutableStateOf(false) }
            var favoritesRefresh by remember { mutableStateOf(false) }
            var showFinder by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = fontQuery, onValueChange = { fontQuery = it }, singleLine = true,
                    modifier = Modifier.weight(1f), colors = fieldColors(), label = { Text("Поиск шрифта", color = Dim) }
                )
                if (!x.shared) Pill("По картинке", false, { showFinder = true })
            }
            if (showFinder) FontFinderDialog(vm, p, l) { showFinder = false }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill("Все", !favoritesOnly, { favoritesOnly = false })
                Pill("★ Избранные", favoritesOnly, { favoritesOnly = !favoritesOnly })
            }
            val visibleFonts = remember(fontQuery, favoritesOnly, favoritesRefresh) {
                Fonts.entries.filter { e ->
                    (fontQuery.isBlank() || e.name.contains(fontQuery.trim(), ignoreCase = true)) &&
                        (!favoritesOnly || vm.isFavoriteFont(e.file, e.sys))
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                visibleFonts.forEach { e ->
                    val on = if (e.file.isNotEmpty()) l.fontFile == e.file else (l.fontFile.isEmpty() && l.font == e.sys)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) {
                            FontChip(
                                e = e,
                                selected = on,
                                onClick = { x.applyFont(e.sys, e.file, null) },
                                onLongPress = { vm.previewLayer(l.id) { it.copy(font = e.sys, fontFile = e.file) } },
                                onRelease = { vm.clearLayerPreview() }
                            )
                        }
                        Text(if (vm.isFavoriteFont(e.file, e.sys)) "★" else "☆", color = if (vm.isFavoriteFont(e.file, e.sys)) Color(0xFFFFD166) else Dim,
                            modifier = Modifier.clickable { vm.toggleFavoriteFont(e.file, e.sys); favoritesRefresh = !favoritesRefresh }.padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                }
            }
            var manual by remember(l.id) { mutableStateOf(false) }
            PresetRow {
                Pill("Обычно", l.spacing <= 0.001f, { x.update("sp") { it.copy(spacing = 0f) } })
                Pill("Шире", abs(l.spacing - 0.12f) < 0.02f, { x.update("sp") { it.copy(spacing = 0.12f) } })
                Pill("Очень широко", l.spacing >= 0.28f, { x.update("sp") { it.copy(spacing = 0.3f) } })
                Pill("Блок авто", l.boxMm <= 0f, { x.update("b") { it.copy(boxMm = 0f) } })
                Pill("Блок 60%", l.boxMm > 0f && abs(l.boxMm - x.wMm * 0.6f) < 1f, { x.update("b") { it.copy(boxMm = x.wMm * 0.6f) } })
                Pill("Блок 90%", l.boxMm > 0f && abs(l.boxMm - x.wMm * 0.9f) < 1f, { x.update("b") { it.copy(boxMm = x.wMm * 0.9f) } })
                Pill("Настроить", manual, { manual = !manual })
            }
            if (manual) {
                LabeledSlider("Интервал букв", l.spacing, 0f..0.5f, f1(l.spacing * 100) + "%") { v -> x.update("sp") { it.copy(spacing = v) } }
                LabeledSlider("Межстрочный интервал", l.lineSpacing, 0.8f..2.5f, "${(l.lineSpacing * 100).toInt()}%") { v -> x.update("line-spacing") { it.copy(lineSpacing = v) } }
                LabeledSlider("Масштаб по горизонтали", l.textScaleX, 0.5f..2f, "${(l.textScaleX * 100).toInt()}%") { v -> x.update("text-scale-x") { it.copy(textScaleX = v) } }
                LabeledSlider("Масштаб по вертикали", l.textScaleY, 0.5f..2f, "${(l.textScaleY * 100).toInt()}%") { v -> x.update("text-scale-y") { it.copy(textScaleY = v) } }
                Pill("Автоподгонка по ширине", l.textAutoFit, { x.update("text-autofit") { it.copy(textAutoFit = !it.textAutoFit, boxMm = if (!it.textAutoFit && it.boxMm <= 0f) x.wMm * 0.9f else it.boxMm) } })
                LabeledSlider("Изгиб текста по дуге", l.textArc, -90f..90f, "${l.textArc.toInt()}°") { v -> x.update("text-arc") { it.copy(textArc = v) } }
                LabeledSlider("Ширина блока", l.boxMm, 0f..max(x.wMm, 20f),
                    if (l.boxMm <= 0f) "авто" else "${f1(l.boxMm)} мм") { v ->
                    x.update("b") { it.copy(boxMm = if (v < 2f) 0f else v) }
                }
            }
            }
        }
        Tool.COLOR -> {
            if (l.kind == Kind.TEXT) {
                SettingsGroup("Цвет текста", initiallyExpanded = true) {
                    Text("Выберите основной цвет надписи", color = Dim, fontSize = 11.sp)
                    ColorRow(l.color) { c -> x.update("c") { it.copy(color = c) } }
                }
                SettingsGroup("Мои стили", initiallyExpanded = true) {
                    var styleName by remember(l.id) { mutableStateOf("") }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(styleName, { styleName = it }, modifier = Modifier.weight(1f), singleLine = true,
                            colors = fieldColors(), label = { Text("Название стиля") })
                        TextButton(onClick = { if (vm.saveTextStyle(styleName, l)) styleName = "" }) { Text("Сохранить") }
                    }
                    val savedStyles = vm.savedTextStyleNames()
                    if (savedStyles.isEmpty()) {
                        Text("Сохранённые комбинации появятся здесь", color = Dim, fontSize = 11.sp)
                    } else {
                        savedStyles.forEach { saved ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(saved, color = Color.White, modifier = Modifier.weight(1f), fontSize = 12.sp)
                                TextButton(onClick = { vm.applyTextStyle(l.id, saved) }) { Text("Применить") }
                            }
                        }
                    }
                }
                SettingsGroup("Материал букв", initiallyExpanded = true) {
                    Text("Готовые фактуры и эффекты заливки", color = Dim, fontSize = 11.sp)
                    val half = (TextMaterialNames.size + 1) / 2
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (rowIdx in 0..1) {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for (i in (rowIdx * half) until minOf(TextMaterialNames.size, (rowIdx + 1) * half)) {
                                    PreviewPill(TextMaterialNames[i], l.textMaterial == i, vm, l.id,
                                        { it.copy(textMaterial = i) }, { x.update("tm") { it.copy(textMaterial = i) } })
                                }
                            }
                        }
                    }
                }
                SettingsGroup("Линии по бокам текста", initiallyExpanded = true) {
                    var manual by remember(l.id) { mutableStateOf(false) }
                    Text("Декоративные разделители вокруг надписи", color = Dim, fontSize = 11.sp)
                    PresetRow {
                        Pill("Без линий", l.textRules <= 0.001f, { x.update("tr") { it.copy(textRules = 0f) } })
                        Pill("Тонкие", abs(l.textRules - 0.35f) < 0.05f, { x.update("tr") { it.copy(textRules = 0.35f) } })
                        Pill("Яркие", abs(l.textRules - 0.8f) < 0.05f, { x.update("tr") { it.copy(textRules = 0.8f) } })
                        Pill("Настроить", manual, { manual = !manual })
                    }
                    if (manual) LabeledSlider("Интенсивность линий", l.textRules, 0f..1f,
                        if (l.textRules <= 0.001f) "Выкл." else "${(l.textRules * 100).toInt()}%") { v ->
                        x.update("tr") { it.copy(textRules = v) }
                    }
                }
            } else {
                ColorRow(l.color) { c -> x.update("c") { it.copy(color = c) } }
            }
        }
        Tool.OUTLINE -> {
            var manual by remember(l.id) { mutableStateOf(false) }
            val gold = android.graphics.Color.rgb(212, 166, 75)
            val none = l.textOutlineWidth <= 0.001f && l.textGlowRadius <= 0.001f
            PresetRow {
                PreviewPill("Нет", none, vm, l.id, { it.copy(textOutlineWidth = 0f, textGlowRadius = 0f) }, { x.update("tp") { it.copy(textOutlineWidth = 0f, textGlowRadius = 0f) } })
                PreviewPill("Чёрная", l.textOutlineColor == android.graphics.Color.BLACK && l.textOutlineWidth > 0f && l.textGlowRadius <= 0.001f, vm, l.id,
                    { it.copy(textOutlineWidth = 0.06f, textOutlineColor = android.graphics.Color.BLACK, textGlowRadius = 0f) }, {
                    x.update("tp") { it.copy(textOutlineWidth = 0.06f, textOutlineColor = android.graphics.Color.BLACK, textGlowRadius = 0f) }
                })
                PreviewPill("Белая", l.textOutlineColor == android.graphics.Color.WHITE && l.textOutlineWidth > 0f && l.textGlowRadius <= 0.001f, vm, l.id,
                    { it.copy(textOutlineWidth = 0.06f, textOutlineColor = android.graphics.Color.WHITE, textGlowRadius = 0f) }, {
                    x.update("tp") { it.copy(textOutlineWidth = 0.06f, textOutlineColor = android.graphics.Color.WHITE, textGlowRadius = 0f) }
                })
                val ice: (Layer) -> Layer = { it.copy(textOutlineWidth = 0.055f, textOutlineColor = android.graphics.Color.CYAN, textGlowRadius = 0.12f, textGlowColor = android.graphics.Color.CYAN) }
                PreviewPill("Ледяной", l.textOutlineColor == android.graphics.Color.CYAN && l.textOutlineWidth > 0f, vm, l.id, ice, { x.update("tp", ice) })
                val goldStyle: (Layer) -> Layer = { it.copy(textOutlineWidth = 0.045f, textOutlineColor = gold, textGlowRadius = 0.04f, textGlowColor = android.graphics.Color.rgb(255, 190, 80)) }
                PreviewPill("Золотой", l.textOutlineColor == gold && l.textOutlineWidth > 0f, vm, l.id, goldStyle, { x.update("tp", goldStyle) })
                val neon: (Layer) -> Layer = { it.copy(textOutlineWidth = 0.03f, textOutlineColor = android.graphics.Color.WHITE, textGlowRadius = 0.25f, textGlowColor = android.graphics.Color.rgb(255, 60, 200)) }
                PreviewPill("Неон", l.textGlowRadius >= 0.2f, vm, l.id, neon, { x.update("tp", neon) })
                Pill("Настроить", manual, { manual = !manual })
            }
            if (manual) {
                LabeledSlider("Толщина обводки", l.textOutlineWidth, 0f..0.18f,
                    if (l.textOutlineWidth <= 0.001f) "Выкл." else "${(l.textOutlineWidth * 100).toInt()}%") { v ->
                    x.update("to") { it.copy(textOutlineWidth = v) }
                }
                if (l.textOutlineWidth > 0.001f) ColorRow(l.textOutlineColor) { c -> x.update("toc") { it.copy(textOutlineColor = c) } }
                LabeledSlider("Свечение", l.textGlowRadius, 0f..0.5f,
                    if (l.textGlowRadius <= 0.001f) "Выкл." else "${(l.textGlowRadius * 100).toInt()}%") { v ->
                    x.update("tg") { it.copy(textGlowRadius = v) }
                }
                if (l.textGlowRadius > 0.001f) ColorRow(l.textGlowColor) { c -> x.update("tgc") { it.copy(textGlowColor = c) } }
            }
        }
        Tool.SHADOW -> ShadowControls(l, vm) { key, f -> x.update(key, f) }
        Tool.MIRROR -> ReflectionControls(l) { key, f -> x.update(key, f) }
        Tool.FRAME -> FrameProps(x, vm)
        Tool.BLEND -> {
            val png = remember(l.path) { hasObjectTransparency(l.path) }
            var showEdgeCompare by remember(l.id) { mutableStateOf(false) }
            var manual by remember(l.id) { mutableStateOf(false) }
            var edgeOpen by remember(l.id) { mutableStateOf(png) }
            var lightOpen by remember(l.id) { mutableStateOf(false) }
            var fadeOpen by remember(l.id) { mutableStateOf(false) }
            val warm = android.graphics.Color.rgb(255, 205, 150)
            val cold = android.graphics.Color.rgb(160, 205, 255)
            fun Layer.cleared() = copy(
                imageFade = 0f, imageFadeBlend = 0f, imageBlur = 0, imageFadeStyle = 0, imageFadeEdges = 15,
                imageEdgeClean = 0f, imageChoke = 0f, imageLightWrap = 0f, imageEdgeRelight = 0f, imageEdgeShade = 0f, imageColorMatch = 0f, imageContactShadow = 0f,
                imageWrapAuto = false, imageWrapColor = android.graphics.Color.WHITE
            )
            val off = l.imageFade <= 0.001f && l.imageEdgeClean <= 0.001f && l.imageChoke <= 0.001f &&
                l.imageLightWrap <= 0.001f && l.imageEdgeRelight <= 0.001f && l.imageEdgeShade <= 0.001f && l.imageColorMatch <= 0.001f && l.imageContactShadow <= 0.001f
            val lit = l.imageLightWrap > 0.001f
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PreviewPill("Выкл.", off, vm, l.id, { it.cleared() }, { x.update("pr") { it.cleared() } })
                if (png) {
                    val cleanEdge: (Layer) -> Layer = { it.cleared().copy(imageEdgeClean = 1f, imageChoke = 0.7f) }
                    PreviewPill("Чистый край", l.imageEdgeClean >= 0.9f && l.imageChoke > 0.001f && !lit && l.imageFade <= 0.001f, vm, l.id, cleanEdge, { x.update("pr", cleanEdge) })
                    val fitBackground: (Layer) -> Layer = { it.cleared().copy(imageEdgeClean = 1f, imageChoke = 0.7f, imageLightWrap = 0.30f, imageEdgeRelight = 0.18f, imageColorMatch = 0.35f, imageContactShadow = 0.12f, imageWrapAuto = true) }
                    val warmLight: (Layer) -> Layer = { it.cleared().copy(imageEdgeClean = 1f, imageChoke = 0.7f, imageLightWrap = 0.28f, imageEdgeRelight = 0.16f, imageWrapColor = warm) }
                    val coldLight: (Layer) -> Layer = { it.cleared().copy(imageEdgeClean = 1f, imageChoke = 0.7f, imageLightWrap = 0.28f, imageEdgeRelight = 0.16f, imageWrapColor = cold) }
                    PreviewPill("Вписать в фон", l.imageWrapAuto && lit, vm, l.id, fitBackground, { x.update("pr", fitBackground) })
                    PreviewPill("Тёплый свет", !l.imageWrapAuto && lit && l.imageWrapColor == warm, vm, l.id, warmLight, { x.update("pr", warmLight) })
                    PreviewPill("Холодный свет", !l.imageWrapAuto && lit && l.imageWrapColor == cold, vm, l.id, coldLight, { x.update("pr", coldLight) })
                }
                val softEdge: (Layer) -> Layer = { it.cleared().copy(imageFade = if (png) 0.12f else 0.18f, imageEdgeClean = if (png) 1f else 0f, imageChoke = if (png) 0.5f else 0f) }
                val cinemaFade: (Layer) -> Layer = { it.cleared().copy(imageFade = if (png) 0.16f else 0.28f, imageFadeStyle = 1, imageEdgeClean = if (png) 1f else 0f, imageChoke = if (png) 0.5f else 0f) }
                PreviewPill("Мягкий край", l.imageFade in 0.05f..0.30f && l.imageFadeStyle == 0, vm, l.id, softEdge, { x.update("pr", softEdge) })
                PreviewPill("Кино", l.imageFade > 0.001f && l.imageFadeStyle == 1, vm, l.id, cinemaFade, { x.update("pr", cinemaFade) })
                Pill("Настроить", manual, { manual = !manual })
            }
            if (png) {
                TextButton(onClick = { showEdgeCompare = true }) { Text("Сравнить до / после") }
                if (showEdgeCompare) EdgeCompareDialog(l) { showEdgeCompare = false }
            }
            if (manual) {
                if (png) {
                    ToolGroupHeader("Край PNG", "Очистка цветной каймы и точность силуэта", edgeOpen) { edgeOpen = !edgeOpen }
                    if (edgeOpen) {
                        LabeledSlider("Очистка каймы", l.imageEdgeClean, 0f..1f,
                            if (l.imageEdgeClean <= 0.001f) "Выкл." else "${(l.imageEdgeClean * 100).toInt()}%") { v ->
                            x.update("edgeclean") { it.copy(imageEdgeClean = v) }
                        }
                        LabeledSlider("Сжатие края", l.imageChoke, 0f..1f,
                            if (l.imageChoke <= 0.001f) "Выкл." else "${(l.imageChoke * 100).toInt()}%") { v ->
                            x.update("choke") { it.copy(imageChoke = v) }
                        }
                    }
                    ToolGroupHeader("Свет и интеграция", "Light Wrap, подсветка и согласование с окружением", lightOpen) { lightOpen = !lightOpen }
                    if (lightOpen) {
                        LabeledSlider("Свет по краю (Light Wrap)", l.imageLightWrap, 0f..0.65f,
                            if (l.imageLightWrap <= 0.001f) "Выкл." else "${(l.imageLightWrap * 100).toInt()}%") { v ->
                            x.update("lightwrap") { it.copy(imageLightWrap = v) }
                        }
                        if (l.imageLightWrap > 0.001f) {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Pill("Цвет по фону", l.imageWrapAuto, {
                                    x.update("wrapauto") { it.copy(imageWrapAuto = !it.imageWrapAuto) }
                                })
                            }
                            if (!l.imageWrapAuto) ColorRow(l.imageWrapColor) { c -> x.update("wrapcolor") { it.copy(imageWrapColor = c) } }
                        }
                        LabeledSlider("Подсветка края", l.imageEdgeRelight, 0f..0.65f,
                            if (l.imageEdgeRelight <= 0.001f) "Выкл." else "${(l.imageEdgeRelight * 100).toInt()}%") { v ->
                            x.update("edgerelight") { it.copy(imageEdgeRelight = v) }
                        }
                        LabeledSlider("Затемнение края", l.imageEdgeShade, 0f..0.65f,
                            if (l.imageEdgeShade <= 0.001f) "Выкл." else "${(l.imageEdgeShade * 100).toInt()}%") { v ->
                            x.update("edgeshade") { it.copy(imageEdgeShade = v) }
                        }
                        LabeledSlider("Согласование цвета с фоном", l.imageColorMatch, 0f..0.65f,
                            if (l.imageColorMatch <= 0.001f) "Выкл." else "${(l.imageColorMatch * 100).toInt()}%") { v ->
                            x.update("colormatch") { it.copy(imageColorMatch = v, imageWrapAuto = if (v > 0f) true else it.imageWrapAuto) }
                        }
                        LabeledSlider("Контактная тень", l.imageContactShadow, 0f..1f,
                            if (l.imageContactShadow <= 0.001f) "Выкл." else "${(l.imageContactShadow * 100).toInt()}%") { v ->
                            x.update("contactshadow") { it.copy(imageContactShadow = v, imageWrapAuto = if (v > 0f) true else it.imageWrapAuto) }
                        }
                    }
                }
                ToolGroupHeader("Мягкое смешивание", "Переход по краям изображения или по контуру PNG", fadeOpen) { fadeOpen = !fadeOpen }
                if (fadeOpen) {
                    LabeledSlider(if (png) "Мягкость контура" else "Ширина перехода", l.imageFade, 0f..(if (png) 0.20f else 0.45f),
                        if (l.imageFade <= 0.001f) "Выкл." else "${(l.imageFade * 100).toInt()}%") { v -> x.update("if") { it.copy(imageFade = v) } }
                    if (l.imageFade > 0.001f) {
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PreviewPill("Ровный край", l.imageFadeStyle == 0, vm, l.id, { it.copy(imageFadeStyle = 0) }, { x.update("ifs") { it.copy(imageFadeStyle = 0) } })
                            PreviewPill("Органический", l.imageFadeStyle == 1, vm, l.id, { it.copy(imageFadeStyle = 1) }, { x.update("ifs") { it.copy(imageFadeStyle = 1) } })
                        }
                        val fadeEdges = listOf(
                            (if (png) "По контуру" else "Все края") to 15, "Слева" to 1, "Справа" to 2,
                            "Сверху" to 4, "Снизу" to 8, "По горизонтали" to 3, "По вертикали" to 12
                        )
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            fadeEdges.forEach { (label, edges) ->
                                val edgeTransform: (Layer) -> Layer = { it.copy(imageFadeEdges = edges) }
                                PreviewPill(label, l.imageFadeEdges == edges, vm, l.id, edgeTransform, { x.update("ife", edgeTransform) })
                            }
                        }
                    }
                }
            }
        }
        Tool.TONE -> {
            Text("Корректируйте изображение ползунками. Изменения сразу видны на холсте.", color = Dim, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Pill("Сбросить", false, {
                    x.update("ig-reset") { it.copy(imgHue = 0f, imgSat = 1f, imgBright = 0f, imgContrast = 1f, imgTemp = 0f, imgColorize = 0f) }
                })
            }
            LabeledSlider("Яркость · светлее или темнее", l.imgBright, -0.6f..0.6f, "${(l.imgBright * 100).toInt()}") { v -> x.update("ib") { it.copy(imgBright = v) } }
            LabeledSlider("Контраст · разница между светом и тенью", l.imgContrast, 0.5f..1.8f, "${(l.imgContrast * 100).toInt()}%") { v -> x.update("ic") { it.copy(imgContrast = v) } }
            LabeledSlider("Насыщенность · интенсивность цветов", l.imgSat, 0f..2.5f, "${(l.imgSat * 100).toInt()}%") { v -> x.update("is") { it.copy(imgSat = v) } }
            LabeledSlider("Оттенок · сдвиг цветового тона", l.imgHue, -180f..180f, "${l.imgHue.toInt()}°") { v -> x.update("ih") { it.copy(imgHue = v) } }
            LabeledSlider("Температура · холоднее или теплее", l.imgTemp, -1f..1f, "${(l.imgTemp * 100).toInt()}") { v -> x.update("it") { it.copy(imgTemp = v) } }
            LabeledSlider("Перекраска · сила одного цвета", l.imgColorize, 0f..1f,
                if (l.imgColorize <= 0.001f) "Выкл." else "${(l.imgColorize * 100).toInt()}%") { v -> x.update("iz") { it.copy(imgColorize = v) } }
            if (l.imgColorize > 0.001f) {
                Text("Цвет перекраски", color = Dim, fontSize = 12.sp)
                ColorRow(l.imgColorizeColor) { c -> x.update("izc") { it.copy(imgColorizeColor = c) } }
            }
        }
        Tool.QUALITY -> {
            var showEnhance by remember { mutableStateOf(false) }
            Text("Нейросетевое увеличение: фото станет чётче для печати 300 dpi. Работает на устройстве.", color = Dim, fontSize = 12.sp)
            Pill("Улучшить качество фото", false, { showEnhance = true })
            if (showEnhance) EnhanceDialog(vm, l) { showEnhance = false }
        }
        Tool.CUTOUT -> {
            var showCut by remember { mutableStateOf(false) }
            Text("Нейросеть найдёт объекты, вы выберете, что оставить, и подправите границу кистью. Работает на устройстве, без интернета.", color = Dim, fontSize = 12.sp)
            Pill("Удалить фон", false, { showCut = true })
            if (showCut) BgRemoveDialog(vm, l) { showCut = false }
        }
        else -> Unit
    }
}

/** Рамка вокруг выбранного объекта: выбор вида и параметры. */
@Composable
fun FrameProps(x: LayerCtx, vm: AppVm) {
    val l = x.layer
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FrameNames.forEachIndexed { i, n ->
            val applyFrame: (Layer) -> Layer = { layer ->
                if (i != 0 && layer.frame == 0) {
                    val text = layer.kind == Kind.TEXT
                    layer.copy(frame = i, framePad = if (text) 0.3f else 0.03f, frameWidth = if (text) 0.05f else 0.012f)
                } else layer.copy(frame = i)
            }
            PreviewPill(if (i == 0) "Без рамки" else n, l.frame == i, vm, l.id, applyFrame, { x.update("fr", applyFrame) })
        }
    }
    if (l.frame != 0) {
        var manual by remember(l.id) { mutableStateOf(false) }
        val gold = android.graphics.Color.rgb(212, 166, 75)
        PresetRow {
            PreviewPill("Тонкая", l.frameWidth < 0.012f, vm, l.id, { it.copy(frameWidth = 0.008f) }, { x.update("fw") { it.copy(frameWidth = 0.008f) } })
            PreviewPill("Средняя", l.frameWidth in 0.012f..0.03f, vm, l.id, { it.copy(frameWidth = 0.02f) }, { x.update("fw") { it.copy(frameWidth = 0.02f) } })
            PreviewPill("Толстая", l.frameWidth > 0.03f, vm, l.id, { it.copy(frameWidth = 0.05f) }, { x.update("fw") { it.copy(frameWidth = 0.05f) } })
            PreviewPill("Белая", l.frameColor == android.graphics.Color.WHITE, vm, l.id, { it.copy(frameColor = android.graphics.Color.WHITE) }, { x.update("fc") { it.copy(frameColor = android.graphics.Color.WHITE) } })
            PreviewPill("Чёрная", l.frameColor == android.graphics.Color.BLACK, vm, l.id, { it.copy(frameColor = android.graphics.Color.BLACK) }, { x.update("fc") { it.copy(frameColor = android.graphics.Color.BLACK) } })
            PreviewPill("Золотая", l.frameColor == gold, vm, l.id, { it.copy(frameColor = gold) }, { x.update("fc") { it.copy(frameColor = gold) } })
            Pill("Настроить", manual, { manual = !manual })
        }
        if (manual) {
            LabeledSlider("Толщина рамки", l.frameWidth, 0.005f..0.15f, "${f1(l.frameWidth * 100)}% (${f1(l.frameWidth * l.frameRef())} мм)") { v ->
                x.update("fw") { it.copy(frameWidth = v) }
            }
            LabeledSlider("Отступ от объекта", l.framePad, 0f..0.6f, "${f1(l.framePad * 100)}% (${f1(l.framePad * l.frameRef())} мм)") { v ->
                x.update("fp") { it.copy(framePad = v) }
            }
            SectionLabel("Цвет рамки")
            ColorRow(l.frameColor) { c -> x.update("fc") { it.copy(frameColor = c) } }
        }
    }
}


@Composable
private fun EdgeCompareDialog(layer: Layer, onDismiss: () -> Unit) {
    val source = remember(layer.path) { Bitmaps.get(layer.path) }
    val processed = remember(layer.path, layer.imageEdgeClean, layer.imageLightWrap, layer.imageEdgeRelight,
        layer.imageEdgeShade, layer.imageWrapColor, layer.imageChoke, layer.imageColorMatch, layer.imageContactShadow) {
        source?.let {
            EdgeIntegration.process(
                layer.path, it, layer.imageEdgeClean, layer.imageLightWrap, layer.imageEdgeRelight,
                layer.imageWrapColor, choke = layer.imageChoke, edgeShade = layer.imageEdgeShade, colorMatch = layer.imageColorMatch
            )
        }
    }
    var split by remember(layer.id) { mutableStateOf(0.5f) }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Сравнение обработки краёв", color = Color.White, fontWeight = FontWeight.SemiBold)
            if (source != null && processed != null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("До", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    Text("После", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                }
                Canvas(
                    Modifier.fillMaxWidth().aspectRatio(source.width.toFloat() / source.height.toFloat())
                        .heightIn(max = 360.dp).clip(RoundedCornerShape(10.dp))
                        .pointerInput(source.width, source.height) {
                            detectDragGestures { change, _ ->
                                split = (change.position.x / size.width).coerceIn(0.02f, 0.98f)
                            }
                        }
                ) {
                    val before = source.asImageBitmap()
                    val after = processed.asImageBitmap()
                    val target = IntSize(size.width.toInt().coerceAtLeast(1), size.height.toInt().coerceAtLeast(1))
                    drawImage(after, dstSize = target)
                    clipRect(left = 0f, top = 0f, right = size.width * split, bottom = size.height) {
                        drawImage(before, dstSize = target)
                    }
                    drawLine(Color.White, Offset(size.width * split, 0f), Offset(size.width * split, size.height), 2.dp.toPx())
                    drawCircle(Color.White, 7.dp.toPx(), Offset(size.width * split, size.height / 2f))
                }
                Text("Перемещайте разделитель пальцем", color = Color.White.copy(alpha = 0.72f), fontSize = 12.sp)
            } else {
                Text("Не удалось открыть изображение для сравнения.", color = Color.White)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text("Готово") }
            }
        }
    }
}
