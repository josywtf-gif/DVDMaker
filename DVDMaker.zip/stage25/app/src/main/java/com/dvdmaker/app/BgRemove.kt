package com.dvdmaker.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Half
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Удаление фона нейросетью (RMBG-1.4, ONNX fp16) прямо на устройстве, без интернета.
 *
 * Файл модели в APK не лежит в исходниках: его кладёт в assets шаг сборки на GitHub
 * (см. .github/workflows/build.yml, путь в APK — [ASSET]). Если модели нет — [available] вернёт false.
 *
 * Вход сети: NCHW 1×3×1024×1024, значения (пиксель/255 − 0.5). Выход: маска переднего плана 0…1.
 */
object BgRemover {
    const val ASSET = "models/bgremove.onnx"
    private const val SIZE = 1024
    /** Предел по длинной стороне результата (как у улучшения качества). */
    private const val MAX_SIDE = 4096

    fun available(ctx: Context): Boolean = try {
        ctx.assets.open(ASSET).close(); true
    } catch (_: Throwable) {
        false
    }

    /** ORT лучше грузить с файла, а не из массива в памяти (модель ≈ 88 МБ): копируем из assets один раз. */
    private fun modelFile(ctx: Context): File {
        val f = File(ctx.noBackupFilesDir, "bgremove.onnx")
        val size = ctx.assets.openFd(ASSET).use { it.length }
        if (!f.exists() || f.length() != size) {
            val tmp = File(f.parentFile, "bgremove.onnx.tmp")
            ctx.assets.open(ASSET).use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
            if (tmp.length() != size) {
                tmp.delete()
                throw IllegalStateException("Файл модели удаления фона скопирован не полностью")
            }
            if (f.exists() && !f.delete()) throw IllegalStateException("Не удалось обновить модель удаления фона")
            if (!tmp.renameTo(f)) {
                tmp.delete()
                throw IllegalStateException("Не удалось подготовить модель удаления фона")
            }
        }
        return f
    }

    /** Маска переднего плана 0…1 размером [w]×[h]: сырая из сети и уточнённая по краям картинки. */
    class Masks(val w: Int, val h: Int, val raw: FloatArray, val refined: FloatArray)

    /** Один проход нейросети. [onProgress] получает 0…100. */
    suspend fun infer(ctx: Context, src: Bitmap, onProgress: (Int) -> Unit): Masks {
        onProgress(2)
        val file = modelFile(ctx)
        currentCoroutineContext().ensureActive()

        // Вписываем изображение в квадрат без искажения пропорций; поля нужны только модели.
        // Маску после inference обрежем обратно до области исходного изображения.
        val fit = min(SIZE.toFloat() / src.width, SIZE.toFloat() / src.height)
        val contentW = (src.width * fit).roundToInt().coerceIn(1, SIZE)
        val contentH = (src.height * fit).roundToInt().coerceIn(1, SIZE)
        val contentLeft = (SIZE - contentW) / 2
        val contentTop = (SIZE - contentH) / 2
        val contentRect = Rect(contentLeft, contentTop, contentLeft + contentW, contentTop + contentH)
        val small = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        Canvas(small).apply {
            drawColor(Color.WHITE)
            drawBitmap(
                src, Rect(0, 0, src.width, src.height), contentRect,
                Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            )
        }
        val pix = IntArray(SIZE * SIZE)
        small.getPixels(pix, 0, SIZE, 0, 0, SIZE, SIZE)
        small.recycle()
        onProgress(8)

        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(min(4, max(2, Runtime.getRuntime().availableProcessors() - 1)))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.BASIC_OPT)
        }
        var mask = FloatArray(0)
        var mw = SIZE
        var mh = SIZE
        try {
            env.createSession(file.absolutePath, opts).use { session ->
                onProgress(20)
                currentCoroutineContext().ensureActive()
                val inName = session.inputNames.first()
                val half = (session.inputInfo[inName]?.info as? ai.onnxruntime.TensorInfo)?.type == OnnxJavaType.FLOAT16
                val plane = SIZE * SIZE
                val shape = longArrayOf(1, 3, SIZE.toLong(), SIZE.toLong())

                val tensor: OnnxTensor = if (half) {
                    val bb = ByteBuffer.allocateDirect(3 * plane * 2).order(ByteOrder.nativeOrder())
                    val sb = bb.asShortBuffer()
                    for (i in 0 until plane) {
                        val c = pix[i]
                        sb.put(i, Half.toHalf((((c shr 16) and 255) / 255f) - 0.5f))
                        sb.put(plane + i, Half.toHalf((((c shr 8) and 255) / 255f) - 0.5f))
                        sb.put(2 * plane + i, Half.toHalf(((c and 255) / 255f) - 0.5f))
                    }
                    OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.FLOAT16)
                } else {
                    val data = FloatArray(3 * plane)
                    for (i in 0 until plane) {
                        val c = pix[i]
                        data[i] = (((c shr 16) and 255) / 255f) - 0.5f
                        data[plane + i] = (((c shr 8) and 255) / 255f) - 0.5f
                        data[2 * plane + i] = ((c and 255) / 255f) - 0.5f
                    }
                    OnnxTensor.createTensor(env, java.nio.FloatBuffer.wrap(data), shape)
                }
                onProgress(30)
                tensor.use { t ->
                    session.run(mapOf(inName to t)).use { res ->
                        onProgress(85)
                        currentCoroutineContext().ensureActive()
                        val out = res.get(0) as OnnxTensor
                        val oshape = out.info.shape
                        if (oshape.size < 2) throw IllegalStateException("Модель вернула маску неверного формата")
                        mh = oshape[oshape.size - 2].toInt()
                        mw = oshape[oshape.size - 1].toInt()
                        if (mw <= 0 || mh <= 0 || mw.toLong() * mh > SIZE.toLong() * SIZE * 4L) {
                            throw IllegalStateException("Модель вернула недопустимый размер маски")
                        }
                        val n = mw * mh
                        val m = FloatArray(n)
                        if (out.info.type == OnnxJavaType.FLOAT16) {
                            val sb = out.byteBuffer.order(ByteOrder.nativeOrder()).asShortBuffer()
                            for (i in 0 until n) m[i] = Half.toFloat(sb.get(i))
                        } else {
                            out.floatBuffer.get(m, 0, n)
                        }
                        for (i in m.indices) if (!m[i].isFinite()) m[i] = 0f
                        mask = m
                    }
                }
            }
        } finally {
            opts.close()
        }

        // Если сеть вернула логиты — сначала переводим их в вероятности.
        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        for (v in mask) { if (v < lo) lo = v; if (v > hi) hi = v }
        if (lo < -0.01f || hi > 1.01f) {
            for (i in mask.indices) mask[i] = 1f / (1f + Math.exp(-mask[i].toDouble()).toFloat())
        }

        // Удаляем letterbox-поля: итоговая маска сохраняет точные пропорции исходного фото.
        val cropLeft = (contentLeft.toFloat() * mw / SIZE).roundToInt().coerceIn(0, mw - 1)
        val cropTop = (contentTop.toFloat() * mh / SIZE).roundToInt().coerceIn(0, mh - 1)
        val cropRight = ((contentLeft + contentW).toFloat() * mw / SIZE).roundToInt().coerceIn(cropLeft + 1, mw)
        val cropBottom = ((contentTop + contentH).toFloat() * mh / SIZE).roundToInt().coerceIn(cropTop + 1, mh)
        val outW = cropRight - cropLeft
        val outH = cropBottom - cropTop
        val cropped = FloatArray(outW * outH)
        for (y in 0 until outH) {
            val from = (cropTop + y) * mw + cropLeft
            mask.copyInto(cropped, y * outW, from, from + outW)
        }
        // Сохраняем абсолютные вероятности модели. Min-max-нормализация здесь вредна:
        // даже слабый шум на фоне растягивается до 0…1, а мягкие волосы становятся ореолом.
        for (i in cropped.indices) cropped[i] = cropped[i].coerceIn(0f, 1f)

        // Guided filter использует только реальные пиксели фотографии, без белых полей модели.
        val guide = FloatArray(outW * outH)
        for (y in 0 until outH) for (x in 0 until outW) {
            val sx = (contentLeft + (x + 0.5f) * contentW / outW).toInt().coerceIn(contentLeft, contentLeft + contentW - 1)
            val sy = (contentTop + (y + 0.5f) * contentH / outH).toInt().coerceIn(contentTop, contentTop + contentH - 1)
            val c = pix[sy * SIZE + sx]
            guide[y * outW + x] = (((c shr 16) and 255) * 0.299f + ((c shr 8) and 255) * 0.587f + (c and 255) * 0.114f) / 255f
        }
        val radius = max(2, (8f * min(outW, outH) / SIZE).roundToInt())
        val guidedMask = guided(guide, cropped, outW, outH, radius, 2e-4f)
        // Смешиваем мягкую модельную альфу с edge-aware результатом: это уменьшает
        // цветовые/яркостные ореолы на контрастных границах, не вымывая тонкие детали.
        val refined = FloatArray(cropped.size) { i ->
            (cropped[i] * 0.65f + guidedMask[i] * 0.35f).coerceIn(0f, 1f)
        }
        onProgress(95)
        return Masks(outW, outH, cropped, refined)
    }

    /** Скользящее среднее по окну (2r+1)² с поправкой на края. */
    internal fun box(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(w * h)
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            val o = y * w
            var s = 0.0
            for (x in 0..min(r, w - 1)) s += src[o + x]
            for (x in 0 until w) {
                val lo = max(0, x - r); val hi = min(w - 1, x + r)
                tmp[o + x] = (s / (hi - lo + 1)).toFloat()
                if (x + r + 1 < w) s += src[o + x + r + 1]
                if (x - r >= 0) s -= src[o + x - r]
            }
        }
        for (x in 0 until w) {
            var s = 0.0
            for (y in 0..min(r, h - 1)) s += tmp[y * w + x]
            for (y in 0 until h) {
                val lo = max(0, y - r); val hi = min(h - 1, y + r)
                out[y * w + x] = (s / (hi - lo + 1)).toFloat()
                if (y + r + 1 < h) s += tmp[(y + r + 1) * w + x]
                if (y - r >= 0) s -= tmp[(y - r) * w + x]
            }
        }
        return out
    }

    private fun guided(guide: FloatArray, p: FloatArray, w: Int, h: Int, r: Int, eps: Float): FloatArray {
        val n = w * h
        val mI = box(guide, w, h, r)
        val mP = box(p, w, h, r)
        val mII = box(FloatArray(n) { guide[it] * guide[it] }, w, h, r)
        val mIP = box(FloatArray(n) { guide[it] * p[it] }, w, h, r)
        val a = FloatArray(n)
        val b = FloatArray(n)
        for (i in 0 until n) {
            val v = mII[i] - mI[i] * mI[i]
            val c = mIP[i] - mI[i] * mP[i]
            a[i] = c / (v + eps)
            b[i] = mP[i] - a[i] * mI[i]
        }
        val mA = box(a, w, h, r)
        val mB = box(b, w, h, r)
        return FloatArray(n) { (mA[it] * guide[it] + mB[it]).coerceIn(0f, 1f) }
    }

    /** Накладывает [mask] (w×h, 0…1, растянута на всю картинку) на [src] в полном размере. Возвращает ARGB_8888. */
    suspend fun applyMask(src: Bitmap, mask: FloatArray, mw: Int, mh: Int, onProgress: (Int) -> Unit): Bitmap {
        var w = src.width
        var h = src.height
        val k = MAX_SIDE.toFloat() / max(w, h)
        val base = if (k < 1f) {
            w = (w * k).roundToInt().coerceAtLeast(1); h = (h * k).roundToInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(src, w, h, true)
        } else src
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val band = 64
        val row = IntArray(w * band)
        var y0 = 0
        while (y0 < h) {
            currentCoroutineContext().ensureActive()
            val bh = min(band, h - y0)
            base.getPixels(row, 0, w, 0, y0, w, bh)
            for (yy in 0 until bh) {
                val fy = ((y0 + yy + 0.5f) * mh / h - 0.5f).coerceIn(0f, mh - 1f)
                val iy = fy.toInt(); val iy2 = min(iy + 1, mh - 1); val ty = fy - iy
                for (x in 0 until w) {
                    val fx = ((x + 0.5f) * mw / w - 0.5f).coerceIn(0f, mw - 1f)
                    val ix = fx.toInt(); val ix2 = min(ix + 1, mw - 1); val tx = fx - ix
                    val a0 = mask[iy * mw + ix] * (1 - tx) + mask[iy * mw + ix2] * tx
                    val a1 = mask[iy2 * mw + ix] * (1 - tx) + mask[iy2 * mw + ix2] * tx
                    val m = a0 * (1 - ty) + a1 * ty
                    val c = row[yy * w + x]
                    val a = (m * (c ushr 24)).roundToInt().coerceIn(0, 255)
                    row[yy * w + x] = (a shl 24) or (c and 0x00FFFFFF)
                }
            }
            out.setPixels(row, 0, w, 0, y0, w, bh)
            y0 += bh
            onProgress((y0 * 100 / h).coerceAtMost(100))
        }
        if (base !== src) base.recycle()
        return out
    }
}

/**
 * Удаление фона: нейросеть строит маску, затем открывается редактор — там можно выбрать, какие объекты оставить,
 * подправить границу кистью и настроить мягкость. «Готово» сохраняет PNG с прозрачным фоном.
 */
@Composable
fun BgRemoveDialog(vm: AppVm, layer: Layer, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var progress by remember { mutableStateOf(0) }
    var stage by remember { mutableStateOf(0) } // 0 вопрос, 1 нейросеть, 2 редактор, 3 сохранение
    var job by remember { mutableStateOf<Job?>(null) }
    var edit by remember { mutableStateOf<BgEdit?>(null) }
    val hasModel = remember { BgRemover.available(ctx) }

    fun fail(t: Throwable) {
        val msg = if (t is OutOfMemoryError) "Не хватило памяти. Закройте другие приложения и попробуйте ещё раз"
        else "Не удалось удалить фон: ${t.message ?: t.javaClass.simpleName}"
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
    }

    fun start() {
        val src = Bitmaps.get(layer.path)
        if (src == null) { onDismiss(); return }
        job = scope.launch {
            stage = 1
            progress = 0
            val res = withContext(Dispatchers.Default) {
                try {
                    BgEdit(BgRemover.infer(ctx.applicationContext, src) { progress = it })
                } catch (t: CancellationException) {
                    throw t
                } catch (t: Throwable) {
                    withContext(Dispatchers.Main) { fail(t) }
                    null
                }
            }
            if (res == null) { stage = 0; return@launch }
            edit = res
            stage = 2
        }
    }

    fun finish(mask: FloatArray) {
        val e = edit ?: return
        val src = Bitmaps.get(layer.path) ?: return
        job = scope.launch {
            stage = 3
            progress = 0
            val newPath = withContext(Dispatchers.Default) {
                try {
                    val out = BgRemover.applyMask(src, mask, e.w, e.h) { progress = it }
                    val p = vm.store.saveBitmap(out, true)
                    out.recycle()
                    p
                } catch (t: CancellationException) {
                    throw t
                } catch (t: Throwable) {
                    withContext(Dispatchers.Main) { fail(t) }
                    null
                }
            }
            if (newPath == null) {
                stage = 2
            } else {
                vm.updateLayer(layer.id) { it.copy(path = newPath) }
                Toast.makeText(ctx, "Фон удалён", Toast.LENGTH_SHORT).show()
                onDismiss()
            }
        }
    }

    when (stage) {
        0 -> AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Card,
            title = { Text("Удалить фон") },
            text = {
                Text(
                    if (hasModel)
                        "Нейросеть найдёт объекты на фото. Потом вы сами выберете, что оставить: нажмите на объект, чтобы убрать или " +
                            "вернуть его, а кистью подправьте границу. Работает на устройстве без интернета, первый шаг занимает " +
                            "от десяти секунд до минуты. Результат — PNG с прозрачным фоном; исходный файл не меняется."
                    else
                        "В этой сборке нет файла нейросети. Положите model_fp16.onnx в папку plugin/ репозитория и соберите приложение заново.",
                    color = Dim, fontSize = 13.sp
                )
            },
            confirmButton = { if (hasModel) TextButton(onClick = { start() }) { Text("Начать") } },
            dismissButton = { TextButton(onClick = onDismiss) { Text(if (hasModel) "Отмена" else "Закрыть", color = Dim) } }
        )
        2 -> edit?.let { e ->
            BgEditor(
                src = Bitmaps.get(layer.path)!!, edit = e,
                onCancel = onDismiss,
                onDone = { mask -> finish(mask) }
            )
        }
        else -> AlertDialog(
            onDismissRequest = { },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
            containerColor = Card,
            title = { Text(if (stage == 1) "Поиск объектов" else "Сохранение") },
            text = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(if (stage == 1) "Нейросеть анализирует фото: $progress%" else "Применяю вырезку: $progress%", color = Amber, fontSize = 14.sp)
                    if (stage == 1 && progress in 30..84) LinearProgressIndicator(color = Violet, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(progress = { progress / 100f }, color = Violet, modifier = Modifier.fillMaxWidth())
                    Text("Не закрывайте приложение.", color = Dim, fontSize = 12.sp)
                }
            },
            confirmButton = { },
            dismissButton = {
                if (stage == 1) TextButton(onClick = { job?.cancel(); stage = 0 }) { Text("Отменить", color = Dim) }
            }
        )
    }
}
