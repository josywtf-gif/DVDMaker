package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.AtomicFile
import androidx.exifinterface.media.ExifInterface
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.max

class Store(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "projects").apply { mkdirs() }
    private val imgDir = File(ctx.filesDir, "img").apply { mkdirs() }
    private val maxImportSide = 4096
    private val maxImportPixels = 10_000_000L

    @Synchronized
    fun loadAll(): List<Project> =
        (dir.listFiles() ?: emptyArray())
            .filter { it.extension == "json" }
            .mapNotNull { f ->
                // AtomicFile восстанавливает резервную копию, если предыдущая запись прервалась.
                runCatching {
                    AtomicFile(f).openRead().bufferedReader().use { reader ->
                        Project.fromJson(JSONObject(reader.readText()))
                    }
                }.getOrNull()
            }
            .sortedByDescending { it.updated }

    /** Атомарное сохранение: при сбое записи остаётся предыдущая целая версия проекта. */
    @Synchronized
    fun save(p: Project): Boolean = runCatching {
        val atomic = AtomicFile(File(dir, "${p.id}.json"))
        val stream = atomic.startWrite()
        try {
            val writer = stream.writer(Charsets.UTF_8)
            writer.write(p.toJson().toString())
            writer.flush()
            atomic.finishWrite(stream)
        } catch (t: Throwable) {
            atomic.failWrite(stream)
            throw t
        }
        true
    }.getOrDefault(false)

    fun delete(p: Project) {
        File(dir, "${p.id}.json").delete()
        val used = loadAll().flatMap { it.imagePaths() }.toSet()
        (imgDir.listFiles() ?: emptyArray()).forEach { if (it.absolutePath !in used) it.delete() }
    }

    /** Сохраняет готовый bitmap (результат подгонки) во внутреннюю папку изображений. */
    fun saveBitmap(bmp: Bitmap, png: Boolean = false, prefix: String = ""): String? = runCatching {
        val f = File(imgDir, prefix + UUID.randomUUID().toString() + if (png) ".png" else ".jpg")
        f.outputStream().use { bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }
        f.absolutePath
    }.getOrNull()

    /** Загружает изображение для проверки: bitmap (до 4096 px по длинной стороне) и реальные размеры в пикселях. */
    fun decodeForCheck(uri: Uri): CheckImage? = runCatching {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        val sample = decodeSample(bounds.outWidth, bounds.outHeight)
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
        bmp = limitImportSize(bmp)
        var tw = bounds.outWidth
        var th = bounds.outHeight
        val orientation = readExifOrientation(cr, uri)
        bmp = applyExifOrientation(bmp, orientation)
        if (swapsExifDimensions(orientation)) { val t = tw; tw = th; th = t }
        CheckImage(bmp, tw, th)
    }.getOrNull()

    fun importImage(uri: Uri): String? = runCatching {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        val sample = decodeSample(bounds.outWidth, bounds.outHeight)
        val orientation = readExifOrientation(cr, uri)
        val type = cr.getType(uri) ?: bounds.outMimeType.orEmpty()
        val isJpeg = type.contains("jpeg", ignoreCase = true) || type.contains("jpg", ignoreCase = true)
        // Не перекодируем обычный JPEG: сохраняем исходные байты и качество без потерь поколения.
        if (isJpeg && orientation == ExifInterface.ORIENTATION_NORMAL &&
            max(bounds.outWidth, bounds.outHeight) <= maxImportSide) {
            val target = File(imgDir, UUID.randomUUID().toString() + ".jpg")
            val temp = File(imgDir, target.name + ".tmp")
            try {
                cr.openInputStream(uri)!!.use { input -> temp.outputStream().use { output -> input.copyTo(output, 1 shl 16) } }
            } catch (t: Throwable) {
                temp.delete()
                throw t
            }
            if (!temp.renameTo(target)) {
                temp.delete()
                throw IllegalStateException("Не удалось сохранить исходное изображение")
            }
            return@runCatching target.absolutePath
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
        try {
            bmp = limitImportSize(bmp)
            bmp = applyExifOrientation(bmp, orientation)
            val png = type.contains("png", ignoreCase = true) || type.contains("webp", ignoreCase = true) ||
                bounds.outMimeType?.contains("png", ignoreCase = true) == true || bmp.hasAlpha()
            val f = File(imgDir, UUID.randomUUID().toString() + if (png) ".png" else ".jpg")
            f.outputStream().use {
                bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it)
            }
            f.absolutePath
        } finally {
            if (!bmp.isRecycled) bmp.recycle()
        }
    }.getOrNull()

    /** Keep decode memory bounded while retaining as many source pixels as possible. */
    private fun decodeSample(width: Int, height: Int): Int {
        var sample = 1
        while (width > 0 && height > 0 &&
            (width / sample).toLong() * (height / sample) > maxImportPixels) sample *= 2
        return sample
    }

    private fun readExifOrientation(cr: android.content.ContentResolver, uri: Uri): Int = runCatching {
        cr.openInputStream(uri)!!.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }
    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

    private fun swapsExifDimensions(orientation: Int): Boolean = orientation == ExifInterface.ORIENTATION_TRANSPOSE ||
        orientation == ExifInterface.ORIENTATION_ROTATE_90 || orientation == ExifInterface.ORIENTATION_TRANSVERSE ||
        orientation == ExifInterface.ORIENTATION_ROTATE_270

    /** Applies all eight EXIF orientations, including mirrored camera images. */
    private fun applyExifOrientation(source: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(270f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(270f)
            else -> return source
        }
        val result = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        if (result !== source) source.recycle()
        return result
    }

    /** Decode near the target size, then resample once to the exact supported long-side limit. */
    private fun limitImportSize(source: Bitmap): Bitmap {
        val longest = max(source.width, source.height)
        if (longest <= maxImportSide) return source
        val scale = maxImportSide.toFloat() / longest
        val result = Bitmap.createScaledBitmap(
            source,
            (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1),
            true
        )
        if (result !== source) source.recycle()
        return result
    }

}
