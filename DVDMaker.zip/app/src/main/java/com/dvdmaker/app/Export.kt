package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.OutputStream

object Exporter {
    const val PNG_DPI = 300
    const val PDF_DPI = 200

    fun safeName(n: String): String =
        n.replace(Regex("[^\\p{L}\\p{N}_ .-]"), "_").trim().ifEmpty { "DVDMaker" }

    fun writePng(p: Project, a4: Boolean, marks: Boolean, out: OutputStream) {
        val bmp = renderSheet(p, PNG_DPI / 25.4f, a4, marks)
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
    }

    fun writePdf(p: Project, a4: Boolean, marks: Boolean, out: OutputStream) {
        val bmp = renderSheet(p, PDF_DPI / 25.4f, a4, marks)
        val (wMm, hMm) = sheetSizeMm(p, a4, marks)
        val wPt = (wMm / 25.4f * 72f).toInt()
        val hPt = (hMm / 25.4f * 72f).toInt()
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(wPt, hPt, 1).create())
        page.canvas.drawBitmap(bmp, null, RectF(0f, 0f, wPt.toFloat(), hPt.toFloat()),
            Paint(Paint.FILTER_BITMAP_FLAG))
        doc.finishPage(page)
        doc.writeTo(out)
        doc.close()
        bmp.recycle()
    }

    fun cacheFile(ctx: Context, p: Project, pdf: Boolean, a4: Boolean, marks: Boolean): File {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, safeName(p.name) + if (pdf) ".pdf" else ".png")
        f.outputStream().use { if (pdf) writePdf(p, a4, marks, it) else writePng(p, a4, marks, it) }
        return f
    }
}
