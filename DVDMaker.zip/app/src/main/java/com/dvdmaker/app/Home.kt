package com.dvdmaker.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(vm: AppVm) {
    var about by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Project?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "DVDMaker",
                        style = TextStyle(brush = BrandBrush, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                    )
                    Text("Обложки для DVD, CD и Blu-ray", color = Dim, fontSize = 13.sp)
                }
                IconButton(onClick = { about = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "О программе", tint = Dim)
                }
            }
        }

        if (vm.update != null) item { UpdateBanner(vm) }

        item { SectionLabel("Новый проект") }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                DiscFormat.values().toList().chunked(2).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEach { f -> FormatCard(f, Modifier.weight(1f)) { vm.create(f) } }
                    }
                }
            }
        }

        item {
            GradientButton("Проверить готовую обложку", onClick = { vm.checker = true },
                modifier = Modifier.fillMaxWidth(), brush = GoldBrush)
        }

        item { SectionLabel("Мои проекты") }
        if (vm.projects.isEmpty()) {
            item {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Пока пусто. Выберите формат выше, чтобы создать первую обложку.",
                        color = Dim, fontSize = 13.sp)
                }
            }
        } else {
            items(vm.projects, key = { it.id }) { p ->
                ProjectRow(p, onOpen = { vm.open(p) }, onDelete = { toDelete = p })
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = Card,
            title = { Text("Удалить проект?") },
            text = { Text("«${p.name}» будет удалён без возможности восстановления.", color = Dim) },
            confirmButton = {
                TextButton(onClick = { vm.delete(p); toDelete = null }) { Text("Удалить", color = Color(0xFFFF8A8A)) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена", color = Dim) } }
        )
    }

    if (about) AboutDialog(vm) { about = false }
}

@Composable
fun FormatCard(f: DiscFormat, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .clip(shape)
            .background(Card)
            .border(BorderStroke(1.dp, Line), shape)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FormatArt(f, Modifier.fillMaxWidth().height(64.dp))
        Text(f.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(f.subtitle, color = Amber, fontSize = 12.sp)
        Text(f.specText, color = Dim, fontSize = 11.sp, lineHeight = 14.sp)
    }
}

@Composable
fun ProjectRow(p: Project, onOpen: () -> Unit, onDelete: () -> Unit) {
    val thumb by produceState<ImageBitmap?>(null, p.id, p.updated) {
        value = withContext(Dispatchers.Default) { renderSheet(p, 1.4f, false, false).asImageBitmap() }
    }
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Card)
            .border(BorderStroke(1.dp, Line), shape)
            .clickable(onClick = onOpen)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.width(120.dp).height(78.dp).clip(RoundedCornerShape(10.dp)).background(Card2),
            contentAlignment = Alignment.Center
        ) {
            thumb?.let {
                Image(it, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(p.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1)
            Text("${p.format.title} · ${p.format.specText}", color = Dim, fontSize = 11.sp, maxLines = 2, lineHeight = 14.sp)
            Text(
                SimpleDateFormat("d MMM yyyy, HH:mm", Locale("ru")).format(Date(p.updated)),
                color = Amber, fontSize = 11.sp
            )
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = Dim)
        }
    }
}

@Composable
fun UpdateBanner(vm: AppVm) {
    val u = vm.update ?: return
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Card)
            .border(BorderStroke(1.5.dp, GoldBrush), shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Доступно обновление", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text("${u.name} — новая версия DVDMaker. Установится поверх текущей, проекты сохранятся.",
            color = Dim, fontSize = 12.sp)
        val pr = vm.progress
        if (pr != null) {
            LinearProgressIndicator(
                progress = { pr },
                modifier = Modifier.fillMaxWidth(),
                color = Amber, trackColor = Line
            )
            Text("Загрузка ${(pr * 100).toInt()}%", color = Dim, fontSize = 12.sp)
        } else {
            GradientButton("Обновить", onClick = { vm.downloadAndInstall() }, brush = GoldBrush)
        }
        vm.updateMsg?.let { Text(it, color = Color(0xFFFF8A8A), fontSize = 12.sp) }
    }
}

@Composable
fun AboutDialog(vm: AppVm, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text("DVDMaker") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Версия ${BuildConfig.VERSION_NAME}", color = Dim)
                if (vm.update != null) UpdateBanner(vm)
                else {
                    if (vm.checking) Text("Проверяем…", color = Amber)
                    vm.updateMsg?.let { Text(it, color = Amber) }
                    GradientButton("Проверить обновления", onClick = { vm.checkUpdate(true) },
                        enabled = !vm.checking)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}
