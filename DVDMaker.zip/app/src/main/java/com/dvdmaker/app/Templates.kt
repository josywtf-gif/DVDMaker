package com.dvdmaker.app

import android.graphics.Color

class Template(val name: String, val make: (DiscFormat) -> Map<PanelId, PanelData>)

private fun tx(
    text: String, y: Float, size: Float, color: Int, font: Int, file: String,
    x: Float = 0.5f, rot: Float = 0f, upper: Boolean = false, spacing: Float = 0f,
    shadow: Boolean = false, box: Float = 0f
) = Layer(
    kind = Kind.TEXT, text = text, x = x, y = y, sizeMm = size, color = color, font = font,
    fontFile = file, rot = rot, upper = upper, spacing = spacing, shadow = shadow, boxMm = box
)

private fun rc(x: Float, y: Float, w: Float, h: Float, color: Int, alpha: Float = 1f) =
    Layer(kind = Kind.RECT, x = x, y = y, widthMm = w, sizeMm = h, color = color, alpha = alpha)

private class St(
    val name: String, val c1: Long, val c2: Long, val ang: Int, val accent: Long, val text: Long,
    val tFile: String, val tSys: Int, val bFile: String, val bSys: Int,
    val upper: Boolean, val sp: Float, val shadow: Boolean, val kind: Int, val ts: Float = 1f
)

private fun build(st: St, f: DiscFormat): Map<PanelId, PanelData> {
    val k = f.frontW / 129.5f
    val fw = f.frontW
    val fh = f.frontH
    val acc = st.accent.toInt()
    val tc = st.text.toInt()
    fun title(y: Float, size: Float) =
        tx("НАЗВАНИЕ", y, size * k * st.ts, tc, st.tSys, st.tFile, upper = st.upper, spacing = st.sp, shadow = st.shadow)
    fun sub(y: Float, size: Float) =
        tx("подзаголовок", y, size * k, acc, st.bSys, st.bFile, upper = true, spacing = 0.15f)

    val frontLayers: List<Layer> = when (st.kind) {
        0 -> listOf(
            rc(0.5f, 0.35f, fw * 0.45f, 0.9f * k, acc), title(0.45f, 16f),
            rc(0.5f, 0.56f, fw * 0.45f, 0.9f * k, acc), sub(0.63f, 5f)
        )
        1 -> listOf(
            rc(0.5f, 0.07f, fw * 0.9f, 1.2f * k, acc),
            rc(0.5f, 0.8f, fw, 42f * k, Color.BLACK, 0.35f),
            title(0.78f, 18f), sub(0.9f, 5f)
        )
        2 -> listOf(
            title(0.16f, 16f), sub(0.26f, 5f), rc(0.5f, 0.31f, fw * 0.3f, 0.9f * k, acc),
            tx("основано на реальных событиях", 0.93f, 3.6f * k, tc, st.bSys, st.bFile, upper = true, spacing = 0.1f)
        )
        else -> {
            val m = 5f * k
            val t = 0.8f * k
            listOf(
                rc(0.5f, m / fh, fw - 2 * m, t, acc), rc(0.5f, 1f - m / fh, fw - 2 * m, t, acc),
                rc(m / fw, 0.5f, t, fh - 2 * m, acc), rc(1f - m / fw, 0.5f, t, fh - 2 * m, acc),
                title(0.45f, 15f), rc(0.5f, 0.55f, fw * 0.3f, 0.6f * k, acc), sub(0.62f, 5f)
            )
        }
    }
    val ss = minOf(f.spineW * 0.55f, 7f) * st.ts
    val spineLayers = listOf(
        tx("НАЗВАНИЕ", 0.5f, ss, tc, st.tSys, st.tFile, rot = 90f, upper = st.upper, spacing = 0.08f)
    )
    val bw = f.backW
    val bk = bw / 129.5f
    val backLayers = listOf(
        tx("О фильме", 0.14f, 7f * bk, acc, st.tSys, st.tFile, upper = st.upper, spacing = st.sp * 0.5f),
        rc(0.5f, 0.22f, bw * 0.25f, 0.7f * bk, acc),
        tx("Здесь можно разместить краткий сюжет, список актёров и другую информацию о диске.",
            0.42f, 3.8f * bk, tc, st.bSys, st.bFile, box = bw * 0.8f),
        tx("Длительность · Формат · Язык", 0.88f, 3.2f * bk, acc, st.bSys, st.bFile, upper = true, spacing = 0.1f)
    )
    fun pd(l: List<Layer>) = PanelData(st.c1.toInt(), st.c2.toInt(), st.ang, l)
    return mapOf(PanelId.FRONT to pd(frontLayers), PanelId.SPINE to pd(spineLayers), PanelId.BACK to pd(backLayers))
}

private val styles = listOf(
    St("Триллер", 0xFF0B0B10, 0xFF3A0A12, 80, 0xFFE11D48, 0xFFFFFFFF, "Oswald.ttf", 1, "Open_Sans.ttf", 0, true, 0.12f, true, 1),
    St("Боевик", 0xFF1A1A1A, 0xFFB45309, 60, 0xFFFBBF24, 0xFFFFFFFF, "Russo_One.ttf", 1, "Rubik.ttf", 0, true, 0.05f, true, 0),
    St("Комедия", 0xFFFDE047, 0xFFF97316, 45, 0xFF7C2D12, 0xFF1F2937, "Lobster.ttf", 5, "Rubik.ttf", 0, false, 0f, false, 0),
    St("Драма", 0xFF1F2937, 0xFF475569, 70, 0xFFE5E7EB, 0xFFFFFFFF, "Playfair_Display.ttf", 4, "PT_Serif.ttf", 4, false, 0.06f, false, 3),
    St("Ужасы", 0xFF000000, 0xFF450A0A, 90, 0xFFDC2626, 0xFFE5E7EB, "Ruslan_Display.ttf", 4, "Philosopher.ttf", 4, false, 0.04f, true, 2),
    St("Фантастика", 0xFF020617, 0xFF1E1B4B, 60, 0xFF22D3EE, 0xFFFFFFFF, "Exo_2.ttf", 2, "Jura.ttf", 0, true, 0.2f, true, 1),
    St("Романтика", 0xFFFBCFE8, 0xFFF472B6, 60, 0xFFBE185D, 0xFF831843, "Pacifico.ttf", 5, "Philosopher.ttf", 4, false, 0f, false, 0),
    St("Документальный", 0xFFE7DDC8, 0xFFC8B68F, 45, 0xFF3F2F1B, 0xFF2B2118, "Merriweather.ttf", 4, "PT_Serif.ttf", 4, true, 0.1f, false, 3),
    St("Мультфильм", 0xFF38BDF8, 0xFF818CF8, 45, 0xFFFACC15, 0xFFFFFFFF, "Pangolin.ttf", 6, "Pangolin.ttf", 6, false, 0f, true, 0),
    St("Музыка", 0xFF111111, 0xFF1F1F1F, 90, 0xFFFFFFFF, 0xFFFFFFFF, "Montserrat.ttf", 1, "Montserrat.ttf", 0, true, 0.3f, false, 2),
    St("Ретро 80-х", 0xFF2D1B69, 0xFFFF4D8D, 90, 0xFFFFE066, 0xFFFFFFFF, "Press_Start_2P.ttf", 1, "Exo_2.ttf", 2, true, 0.02f, true, 1, 0.55f),
    St("Минимализм", 0xFFFFFFFF, 0xFFF3F4F6, 90, 0xFF111827, 0xFF111827, "Raleway.ttf", 3, "Open_Sans.ttf", 3, true, 0.25f, false, 2),
    St("Золото", 0xFF0A0A0A, 0xFF1C1917, 90, 0xFFD4AF37, 0xFFD4AF37, "Cormorant.ttf", 4, "Cormorant.ttf", 4, true, 0.2f, false, 3),
    St("Неон", 0xFF0F172A, 0xFF7C3AED, 45, 0xFFF0ABFC, 0xFFFFFFFF, "Unbounded.ttf", 1, "Manrope.ttf", 0, true, 0.05f, true, 0, 0.8f)
)

val Templates: List<Template> = styles.map { st -> Template(st.name) { f -> build(st, f) } }
