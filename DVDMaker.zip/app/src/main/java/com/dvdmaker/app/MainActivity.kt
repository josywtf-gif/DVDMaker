package com.dvdmaker.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.safeGesturesPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val am = getSystemService(android.app.ActivityManager::class.java)
        Bitmaps.configure(am?.memoryClass ?: 128, am?.isLowRamDevice ?: false)
        Fonts.init(assets)
        SymbolAssets.init(assets)
        BlurayAssets.init(assets)
        DvdMeshAsset.init(assets)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            DVDMakerTheme { Root(vm) }
        }
    }

    override fun onPause() {
        vm.flush()
        super.onPause()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        vm.onMemoryPressure(level)
        RenderMemory.trim(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            ThumbMemory.trim(level)
            FxPainter.trimMemory()
        }
    }
}

@Composable
fun Root(vm: AppVm) {
    LaunchedEffect(Unit) { vm.checkUpdate(false) }
    BackHandler(enabled = vm.checker && vm.current == null) {
        vm.checker = false
    }
    Box(Modifier.fillMaxSize().background(Bg).safeDrawingPadding().safeGesturesPadding().imePadding()) {
        Crossfade(targetState = if (vm.current != null) 1 else if (vm.checker) 2 else 0, animationSpec = tween(durationMillis = 220), label = "screen") { screen ->
            when (screen) {
                1 -> EditorScreen(vm)
                2 -> CheckerScreen(vm)
                else -> HomeScreen(vm)
            }
        }
        if (vm.memoryWarning) {
            Surface(Modifier.align(Alignment.TopCenter).padding(8.dp), color = androidx.compose.ui.graphics.Color(0xFF5B3B16),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("Мало памяти. Закройте другие приложения или включите режим производительности.",
                        color = androidx.compose.ui.graphics.Color.White, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.dismissMemoryWarning() }) { Text("OK") }
                }
            }
        }
    }
}
