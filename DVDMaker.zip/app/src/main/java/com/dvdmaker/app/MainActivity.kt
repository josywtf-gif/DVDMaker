package com.dvdmaker.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            DVDMakerTheme { Root(vm) }
        }
    }

    override fun onPause() {
        vm.flush()
        super.onPause()
    }
}

@Composable
fun Root(vm: AppVm) {
    LaunchedEffect(Unit) { vm.checkUpdate(false) }
    BackHandler(enabled = vm.current != null) { vm.close() }
    Box(Modifier.fillMaxSize().background(Bg).systemBarsPadding().imePadding()) {
        Crossfade(targetState = vm.current != null, label = "screen") { editing ->
            if (editing) EditorScreen(vm) else HomeScreen(vm)
        }
    }
}
