package com.dvdmaker.app

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.Image
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private fun normRot(r: Float): Float = ((r + 180f) % 360f + 360f) % 360f - 180f

private fun f1(v: Float): String = String.format(java.util.Locale.US, "%.1f", v)

private fun Layer.label(): String =
    when (kind) {
        Kind.TEXT -> text.replace("\n", " ").take(12).ifBlank { "Текст" }
        Kind.IMAGE -> "Фото"
        Kind.RECT -> "Фигура"
        Kind.SYMBOL -> "Значок: $text"
    }

@Composable
fun EditorScreen(vm: AppVm) {
    val p = vm.current ?: return
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var showExport by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var guides by remember { mutableStateOf(true) }
    var confirmAutoFit by remember { mutableStateOf(false) }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addImage(uri, false)
    }
    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addImage(uri, true)
    }

    Column(Modifier.fillMaxSize()) {
        // Верхняя панель
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.close() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад", tint = Color.White)
            }
            Column(Modifier.weight(1f).clickable { showRename = true }) {
                Text(p.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
                Text(p.format.title, color = Dim, fontSize = 11.sp, maxLines = 1)
            }
            IconButton(onClick = { vm.undoLast() }, enabled = vm.canUndo) {
                Text("↶", fontSize = 24.sp, color = if (vm.canUndo) Color.White else Line)
            }
            GradientButton("Экспорт", onClick = { showExport = true }, modifier = Modifier.padding(end = 6.dp))
        }

        // Вкладки частей обложки
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PanelId.values().forEach { id ->
                Pill(id.title, selected = !vm.overview && vm.panel == id, onClick = {
                    vm.panel = id; vm.overview = false; vm.selected = null
                })
            }
            Pill("Обзор", selected = vm.overview, onClick = { vm.overview = true; vm.selected = null })
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            if (vm.overview) OverviewCanvas(p) else PanelEditor(vm, p, guides)
            if (!vm.overview && vm.selected != null) {
                Row(Modifier.align(Alignment.TopEnd), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Копия", false, { vm.duplicateSelected() })
                    Pill("✕ Удалить", false, { vm.removeSelected() }, danger = true)
                }
            }
        }

        if (!vm.overview) {
            ToolsPanel(
                vm, p, guides, { guides = !guides },
                onPhoto = { pickPhoto.launch("image/*") },
                onBgPhoto = { pickBg.launch("image/*") }
            )
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GradientButton("Автоподгон", onClick = { confirmAutoFit = true }, modifier = Modifier.weight(1f))
            }
            Text(
                "Так выглядит обложка целиком, без линий на стыках панелей.",
                color = Dim, fontSize = 12.sp, modifier = Modifier.padding(16.dp)
            )
        }
    }

    if (showRename) {
        var name by remember { mutableStateOf(p.name) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            containerColor = Card,
            title = { Text("Название проекта") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, colors = fieldColors()) },
            confirmButton = { TextButton(onClick = { vm.rename(name); showRename = false }) { Text("Готово") } },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Отмена", color = Dim) } }
        )
    }

    if (confirmAutoFit) AlertDialog(
        onDismissRequest = { confirmAutoFit = false }, containerColor = Card,
        title = { Text("Автоматическая подгонка?") },
        text = { Text("Приложение автоматически заполнит стороны добавленными изображениями и аккуратно выровняет элементы. Текущие параметры могут измениться.", color = Dim) },
        confirmButton = { TextButton(onClick = { vm.autoFitAll(); confirmAutoFit = false }) { Text("Да, подогнать") } },
        dismissButton = { TextButton(onClick = { confirmAutoFit = false }) { Text("Отмена", color = Dim) } }
    )
    if (showExport) ExportDialog(vm, p) { showExport = false }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Violet, unfocusedBorderColor = Line,
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    cursorColor = Violet
)

// ---------- Холст ----------

@Composable
fun PanelEditor(vm: AppVm, p: Project, guides: Boolean) {
    val (wMm, hMm) = p.format.size(vm.panel)
    val spine = vm.panel == PanelId.SPINE
    val dw = if (spine) hMm else wMm
    val dh = if (spine) wMm else hMm
    val aspect = dw / dh
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        var cw = maxWidth
        var ch = cw / aspect
        if (ch > maxHeight) {
            ch = maxHeight
            cw = ch * aspect
        }
        Box(
            Modifier.size(cw, ch).shadow(14.dp, RoundedCornerShape(2.dp)),
            contentAlignment = Alignment.Center
        ) {
            val innerW = if (spine) ch else cw
            val innerH = if (spine) cw else ch
            val m = Modifier.requiredSize(innerW, innerH)
                .then(if (spine) Modifier.graphicsLayer(rotationZ = -90f) else Modifier)
            PanelCanvas(
                project = p, panelId = vm.panel, wMm = wMm, hMm = hMm,
                selectedId = vm.selected, guides = guides,
                onSelect = { vm.selected = it },
                onTransform = { id, pan, zoom, rot, w, h -> vm.transform(id, pan, zoom, rot, w, h) },
                modifier = m
            )
        }
    }
}

private fun hitTest(pos: Offset, layers: List<Layer>, w: Float, h: Float, ppm: Float, pad: Float): String? {
    for (l in layers.asReversed()) {
        val (lw, lh) = layerSize(l, ppm)
        val dx = pos.x - l.x * w
        val dy = pos.y - l.y * h
        val r = Math.toRadians(-l.rot.toDouble())
        val lx = (dx * cos(r) - dy * sin(r)).toFloat()
        val ly = (dx * sin(r) + dy * cos(r)).toFloat()
        if (abs(lx) <= lw / 2 + pad && abs(ly) <= lh / 2 + pad) return l.id
    }
    return null
}

@Composable
fun PanelCanvas(
    project: Project,
    panelId: PanelId,
    wMm: Float,
    hMm: Float,
    selectedId: String?,
    guides: Boolean,
    onSelect: (String?) -> Unit,
    onTransform: (String, Offset, Float, Float, Float, Float) -> Unit,
    modifier: Modifier
) {
    val data = project.panel(panelId)
    val dataState by rememberUpdatedState(data)
    val selState by rememberUpdatedState(selectedId)
    val selectCb by rememberUpdatedState(onSelect)
    val transformCb by rememberUpdatedState(onTransform)

    Canvas(
        modifier.pointerInput(wMm, hMm) {
            val pad = 10.dp.toPx()
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val w = size.width.toFloat()
                val h = size.height.toFloat()
                val ppm = w / wMm
                val active: String? = hitTest(down.position, dataState.layers, w, h, ppm, pad)
                if (active != null) selectCb(active)
                var pastSlop = false
                var pan = Offset.Zero
                var zoom = 1f
                var rot = 0f
                val slop = viewConfiguration.touchSlop
                do {
                    val event = awaitPointerEvent()
                    val canceled = event.changes.any { it.isConsumed }
                    if (!canceled) {
                        val zc = event.calculateZoom()
                        val rc = event.calculateRotation()
                        val pc = event.calculatePan()
                        if (!pastSlop) {
                            zoom *= zc
                            rot += rc
                            pan += pc
                            val cs = event.calculateCentroidSize(useCurrent = false)
                            val zm = abs(1 - zoom) * cs
                            val rm = abs(rot * Math.PI.toFloat() * cs / 180f)
                            if (zm > slop || rm > slop || pan.getDistance() > slop) pastSlop = true
                        }
                        if (pastSlop) {
                            val target = active ?: selState
                            if (target != null && (pc != Offset.Zero || zc != 1f || rc != 0f)) {
                                transformCb(target, pc, zc, rc, w, h)
                            }
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    }
                } while (!canceled && event.changes.any { it.pressed })
                if (!pastSlop && active == null) selectCb(null)
            }
        }
    ) {
        val ppm = size.width / wMm
        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            nc.save()
            nc.clipRect(0f, 0f, size.width, size.height)
            drawPanelIn(nc, project, panelId, 0, size.width, size.height, ppm)
            nc.restore()
        }
        if (guides) {
            val inset = minOf(3f * ppm, size.width * 0.15f)
            drawRect(
                color = Color.White.copy(alpha = 0.45f),
                topLeft = Offset(inset, inset),
                size = Size(size.width - inset * 2, size.height - inset * 2),
                style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
            )
        }
        val sel = data.layers.firstOrNull { it.id == selectedId }
        if (sel != null) {
            val (lw, lh) = layerSize(sel, ppm)
            withTransform({
                translate(sel.x * size.width, sel.y * size.height)
                rotate(sel.rot, Offset.Zero)
            }) {
                drawRect(
                    color = Amber,
                    topLeft = Offset(-lw / 2, -lh / 2),
                    size = Size(lw, lh),
                    style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
                )
                for (cx in listOf(-lw / 2, lw / 2)) for (cy in listOf(-lh / 2, lh / 2)) {
                    drawCircle(Amber, 4.dp.toPx(), Offset(cx, cy))
                }
            }
        }
    }
}

@Composable
fun OverviewCanvas(p: Project) {
    val lay = p.format.layout()
    val aspect = lay.w / lay.h
    var scale by remember(p.id) { mutableStateOf(1f) }
    var pan by remember(p.id) { mutableStateOf(Offset.Zero) }
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        var cw = maxWidth
        var ch = cw / aspect
        if (ch > maxHeight) { ch = maxHeight; cw = ch * aspect }
        Canvas(Modifier.size(cw, ch).graphicsLayer {
            scaleX = scale; scaleY = scale; translationX = pan.x; translationY = pan.y
        }.pointerInput(p.id) {
            detectTransformGestures { _, delta, zoom, _ ->
                scale = (scale * zoom).coerceIn(1f, 5f)
                pan = if (scale <= 1f) Offset.Zero else pan + delta
            }
        }.shadow(14.dp, RoundedCornerShape(2.dp)).background(Color.White)) {
            val ppm = size.width / lay.w
            drawIntoCanvas { cv ->
                val nc = cv.nativeCanvas
                for (pl in lay.places) {
                    nc.save(); nc.translate(pl.x * ppm, pl.y * ppm)
                    nc.clipRect(0f, 0f, pl.w * ppm, pl.h * ppm)
                    drawPanelIn(nc, p, pl.id, if (pl.id == PanelId.SPINE && pl.x > 0f) 1 else 0, pl.w * ppm, pl.h * ppm, ppm)
                    nc.restore()
                }
            }
        }
    }
}

// ---------- Инструменты ----------

@Composable
fun ToolsPanel(
    vm: AppVm,
    p: Project,
    guides: Boolean,
    toggleGuides: () -> Unit,
    onPhoto: () -> Unit,
    onBgPhoto: () -> Unit
) {
    val pd = p.panel(vm.panel)
    val sel = pd.layers.firstOrNull { it.id == vm.selected }
    var showAddMenu by remember { mutableStateOf(false) }
    var showSymbols by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            .background(Card)
            .padding(top = 12.dp, start = 12.dp, end = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box {
                Pill("Добавить", false, { showAddMenu = true })
                DropdownMenu(expanded = showAddMenu, onDismissRequest = { showAddMenu = false }) {
                    DropdownMenuItem(text = { Text("Текст") }, onClick = { vm.addText(); showAddMenu = false })
                    DropdownMenuItem(text = { Text("Фигура") }, onClick = { vm.addRect(); showAddMenu = false })
                    DropdownMenuItem(text = { Text("Фото") }, onClick = { onPhoto(); showAddMenu = false })
                    DropdownMenuItem(text = { Text("Фото-фон") }, onClick = { onBgPhoto(); showAddMenu = false })
                    DropdownMenuItem(text = { Text("Спец. символы") }, onClick = { showSymbols = true; showAddMenu = false })
                }
            }
            if (sel != null) {
                Pill("Копия", false, { vm.duplicateSelected() })
                Pill("Выше", false, { vm.moveSelected(true) })
                Pill("Ниже", false, { vm.moveSelected(false) })
                Pill("Удалить", false, { vm.removeSelected() }, danger = true)
            }
        }
        if (pd.layers.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                pd.layers.asReversed().forEach { l ->
                    Pill(l.label(), l.id == vm.selected, { vm.selected = l.id })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when {
                sel == null -> BackgroundProps(vm, p, pd, guides, toggleGuides)
                sel.kind == Kind.TEXT -> TextProps(vm, p, sel)
                sel.kind == Kind.RECT -> RectProps(vm, p, sel)
                sel.kind == Kind.SYMBOL -> SymbolProps(vm, sel)
                else -> ImageProps(vm, p, sel)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
    if (showSymbols) SymbolDialog(onDismiss = { showSymbols = false }) { symbol ->
        vm.addSpecialSymbol(symbol)
        showSymbols = false
    }
}

@Composable
fun BackgroundProps(vm: AppVm, p: Project, pd: PanelData, guides: Boolean, toggleGuides: () -> Unit) {
    if (vm.panel == PanelId.SPINE) {
        Text("Корешок автоматически соединяется с лицевой и задней сторонами. Цвета и изображения смешиваются без ручной настройки.", color = Dim, fontSize = 12.sp)
    } else {
        Text("Фон формируется автоматически. Для оформления используйте фотографии и слои.", color = Dim, fontSize = 12.sp)
    }
    Pill(if (guides) "Безопасная зона: вкл" else "Безопасная зона: выкл", guides, toggleGuides)
}

@Composable
fun TextProps(vm: AppVm, p: Project, l: Layer) {
    val (pw, _) = p.format.size(vm.panel)
    OutlinedTextField(
        value = l.text,
        onValueChange = { t -> vm.updateLayer(l.id, "t${l.id}") { it.copy(text = t) } },
        modifier = Modifier.fillMaxWidth(),
        minLines = 1, maxLines = 3,
        colors = fieldColors(),
        label = { Text("Текст", color = Dim) }
    )
    SectionLabel("Шрифт")
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Fonts.entries.forEach { e ->
            val on = if (e.file.isNotEmpty()) l.fontFile == e.file else (l.fontFile.isEmpty() && l.font == e.sys)
            FontChip(e, on) { vm.updateLayer(l.id) { it.copy(font = e.sys, fontFile = e.file) } }
        }
    }
    LabeledSlider("Размер", l.sizeMm, 1f..80f, "${f1(l.sizeMm)} мм") { v ->
        vm.updateLayer(l.id, "s${l.id}") { it.copy(sizeMm = v) }
    }
    LabeledSlider("Поворот", normRot(l.rot), -180f..180f, "${normRot(l.rot).toInt()}°") { v ->
        vm.updateLayer(l.id, "r${l.id}") { it.copy(rot = v) }
    }
    LabeledSlider("Интервал букв", l.spacing, 0f..0.5f, f1(l.spacing * 100) + "%") { v ->
        vm.updateLayer(l.id, "sp${l.id}") { it.copy(spacing = v) }
    }
    LabeledSlider("Ширина блока (перенос строк)", l.boxMm, 0f..max(pw, 20f),
        if (l.boxMm <= 0f) "авто" else "${f1(l.boxMm)} мм") { v ->
        vm.updateLayer(l.id, "b${l.id}") { it.copy(boxMm = if (v < 2f) 0f else v) }
    }
    if (vm.panel == PanelId.SPINE) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill("Боком ↓", normRot(l.rot) == 90f, { vm.updateLayer(l.id) { it.copy(rot = 90f) } })
            Pill("Боком ↑", normRot(l.rot) == -90f, { vm.updateLayer(l.id) { it.copy(rot = -90f) } })
        }
    }
    SectionLabel("Цвет")
    ColorRow(l.color) { c -> vm.updateLayer(l.id, "c${l.id}") { it.copy(color = c) } }
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Pill("Курсив", l.italic, { vm.updateLayer(l.id) { it.copy(italic = !it.italic) } })
        Pill("ЗАГЛАВНЫЕ", l.upper, { vm.updateLayer(l.id) { it.copy(upper = !it.upper) } })
        Pill("Тень", l.shadow, { vm.updateLayer(l.id) { it.copy(shadow = !it.shadow) } })
        Pill("Слева", l.align == 0, { vm.updateLayer(l.id) { it.copy(align = 0) } })
        Pill("Центр", l.align == 1, { vm.updateLayer(l.id) { it.copy(align = 1) } })
        Pill("Справа", l.align == 2, { vm.updateLayer(l.id) { it.copy(align = 2) } })
    }
}

@Composable
fun ImageProps(vm: AppVm, p: Project, l: Layer) {
    val (pw, ph) = p.format.size(vm.panel)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Pill("Заполнить макет", false, { vm.fillSelected(true) })
        Pill("Вписать целиком", false, { vm.fillSelected(false) })
    }
    LabeledSlider("Размер (ширина)", l.widthMm, 2f..(max(pw, ph) * 2.5f), "${f1(l.widthMm)} мм") { v ->
        vm.updateLayer(l.id, "w${l.id}") { it.copy(widthMm = v) }
    }
    LabeledSlider("Поворот", normRot(l.rot), -180f..180f, "${normRot(l.rot).toInt()}°") { v ->
        vm.updateLayer(l.id, "r${l.id}") { it.copy(rot = v) }
    }
    LabeledSlider("Прозрачность", l.alpha, 0.05f..1f, "${(l.alpha * 100).toInt()}%") { v ->
        vm.updateLayer(l.id, "a${l.id}") { it.copy(alpha = v) }
    }
}

// ---------- Экспорт ----------

@Composable
fun ExportDialog(vm: AppVm, p: Project, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdf by remember { mutableStateOf(false) }
    var a4 by remember { mutableStateOf(false) }
    var marks by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }

    fun save(uri: android.net.Uri, asPdf: Boolean) {
        val proj = vm.current ?: return
        scope.launch {
            busy = true
            val ok = withContext(Dispatchers.Default) {
                runCatching {
                    ctx.contentResolver.openOutputStream(uri)!!.use { os ->
                        if (asPdf) Exporter.writePdf(proj, a4, marks, os) else Exporter.writePng(proj, a4, marks, os)
                    }
                }.isSuccess
            }
            busy = false
            Toast.makeText(ctx, if (ok) "Сохранено" else "Не удалось сохранить", Toast.LENGTH_SHORT).show()
            if (ok) onDismiss()
        }
    }

    val savePng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) save(uri, false)
    }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) save(uri, true)
    }

    val (sw, sh) = sheetSizeMm(p, a4, marks)

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        containerColor = Card,
        title = { Text("Экспорт для печати") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionLabel("Формат файла")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("PNG · 300 dpi", !pdf, { pdf = false })
                    Pill("PDF", pdf, { pdf = true })
                }
                SectionLabel("Лист")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Точный размер", !a4, { a4 = false })
                    Pill("A4", a4, { a4 = true })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Метки реза и сгиба", Modifier.weight(1f))
                    Switch(
                        checked = marks, onCheckedChange = { marks = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = Violet)
                    )
                }
                Text("Размер листа: ${fmt(sw)}×${fmt(sh)} мм. Печатайте в масштабе 100%.", color = Dim, fontSize = 12.sp)
                if (busy) Text("Готовим файл…", color = Amber, fontSize = 13.sp)
            }
        },
        confirmButton = {
            Row {
                TextButton(enabled = !busy, onClick = {
                    val proj = vm.current ?: return@TextButton
                    scope.launch {
                        busy = true
                        val f = withContext(Dispatchers.Default) {
                            runCatching { Exporter.cacheFile(ctx, proj, pdf, a4, marks) }.getOrNull()
                        }
                        busy = false
                        if (f == null) {
                            Toast.makeText(ctx, "Не удалось подготовить файл", Toast.LENGTH_SHORT).show()
                        } else {
                            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
                            val i = Intent(Intent.ACTION_SEND)
                                .setType(if (pdf) "application/pdf" else "image/png")
                                .putExtra(Intent.EXTRA_STREAM, uri)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            ctx.startActivity(Intent.createChooser(i, "Поделиться"))
                        }
                    }
                }) { Text("Поделиться") }
                TextButton(enabled = !busy, onClick = {
                    val n = Exporter.safeName(p.name)
                    if (pdf) savePdf.launch("$n.pdf") else savePng.launch("$n.png")
                }) { Text("Сохранить", fontWeight = FontWeight.Bold) }
            }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Закрыть", color = Dim) } }
    )
}

@Composable
fun RectProps(vm: AppVm, p: Project, l: Layer) {
    val (pw, ph) = p.format.size(vm.panel)
    LabeledSlider("Ширина", l.widthMm, 0.5f..(max(pw, ph) * 1.5f), "${f1(l.widthMm)} мм") { v ->
        vm.updateLayer(l.id, "w${l.id}") { it.copy(widthMm = v) }
    }
    LabeledSlider("Высота", l.sizeMm, 0.3f..(max(pw, ph) * 1.5f), "${f1(l.sizeMm)} мм") { v ->
        vm.updateLayer(l.id, "h${l.id}") { it.copy(sizeMm = v) }
    }
    LabeledSlider("Поворот", normRot(l.rot), -180f..180f, "${normRot(l.rot).toInt()}°") { v ->
        vm.updateLayer(l.id, "r${l.id}") { it.copy(rot = v) }
    }
    LabeledSlider("Прозрачность", l.alpha, 0.05f..1f, "${(l.alpha * 100).toInt()}%") { v ->
        vm.updateLayer(l.id, "a${l.id}") { it.copy(alpha = v) }
    }
    SectionLabel("Цвет")
    ColorRow(l.color) { c -> vm.updateLayer(l.id, "c${l.id}") { it.copy(color = c) } }
}

@Composable
private fun SymbolProps(vm: AppVm, l: Layer) {
    SectionLabel("Цвет значка")
    ColorRow(l.color) { c -> vm.updateLayer(l.id, "sym${l.id}") { it.copy(color = c) } }
    LabeledSlider("Размер", l.widthMm, 4f..120f, "${l.widthMm.toInt()} мм") { v ->
        vm.updateLayer(l.id, "sw${l.id}") { it.copy(widthMm = v) }
    }
}

@Composable
private fun SymbolDialog(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val symbols = listOf(
        "Blu-ray Disc" to "BLURAY", "DVD Video" to "DVD", "Compact Disc" to "CD",
        "Hi-Res Audio" to "HIRES", "Dolby Digital" to "DOLBY", "Dolby Atmos" to "ATMOS",
        "DTS" to "DTS", "DTS-HD" to "DTSHD", "4K Ultra HD" to "4K", "HDR" to "HDR",
        "THX" to "THX", "Stereo" to "STEREO", "16:9" to "169", "1080p" to "1080P", "2160p" to "2160P"
    )
    AlertDialog(onDismissRequest = onDismiss, containerColor = Card,
        title = { Text("Оригинальные значки") },
        text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            symbols.chunked(2).forEach { pair -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { (name, value) -> Pill(name, false, { onPick(value) }) }
            } }
        } },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } })
}
