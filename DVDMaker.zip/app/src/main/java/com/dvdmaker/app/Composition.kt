package com.dvdmaker.app

import kotlin.math.abs
import kotlin.math.max
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Modifier

data class CompositionPlan(
    val name: String,
    val description: String,
    val positions: Map<String, Pair<Float, Float>>,
    val score: Int,
    val freeArea: String
)

/** Анализирует только геометрию слоёв. Расчёт не меняет проект; применение выполняется отдельно пользователем. */
object SmartComposition {
    fun suggest(project: Project, panel: PanelId): List<CompositionPlan> {
        val layers = project.panel(panel).layers.filter { it.visible }
        if (layers.isEmpty()) return emptyList()
        val (w, h) = project.format.size(panel)
        val movable = layers.filter { !it.locked }
        val photos = movable.filter { it.kind == Kind.IMAGE && !(it.widthMm >= w * .96f && imageHeight(it) >= h * .96f) }
        val title = movable.filter { it.kind == Kind.TEXT }.maxByOrNull { it.sizeMm }
        val decor = movable.filter { it.kind == Kind.SYMBOL || it.kind == Kind.RECT }
        val anchors = listOf(
            Triple("Слева", .30f, .50f),
            Triple("По центру", .50f, .50f),
            Triple("Справа", .70f, .50f)
        )
        return anchors.mapIndexed { index, anchor ->
            val pos = LinkedHashMap<String, Pair<Float, Float>>()
            // Фотографии выстраиваются по общей горизонтальной оси с равными интервалами.
            photos.forEachIndexed { i, layer ->
                val count = photos.size
                val x = if (count <= 1) anchor.second else
                    (anchor.second + (i - (count - 1) / 2f) * .17f).coerceIn(.18f, .82f)
                pos[layer.id] = x to (layer.y.coerceIn(.2f, .8f) * .65f + .175f)
            }
            val freeSpot = title?.let { findFreeSpace(layers, pos, it, w, h) }
            title?.let { freeSpot?.let { spot -> pos[it.id] = spot.first to spot.second } }
            decor.forEachIndexed { i, layer ->
                val x = if ((freeSpot?.first ?: .5f) < .5f) .88f else .12f
                val y = if (i % 2 == 0) .82f else .18f
                pos[layer.id] = x to y
            }
            val free = when {
                freeSpot == null -> "Свободная зона не найдена"
                freeSpot.second < .35f -> "Свободная зона сверху"
                freeSpot.second > .65f -> "Свободная зона снизу"
                freeSpot.first < .35f -> "Свободная зона слева"
                else -> "Свободная зона справа"
            }
            val score = balanceScore(layers, pos, w, h)
            CompositionPlan(
                when (index) { 0 -> "Фото слева"; 1 -> "Фото по центру"; else -> "Фото справа" },
                "${if (title != null) "Заголовок размещён в свободной зоне" else "Без заголовка"} · декор вынесен к краям",
                pos, score, free
            )
        }.sortedByDescending { it.score }
    }

    private fun findFreeSpace(
        layers: List<Layer>,
        positions: Map<String, Pair<Float, Float>>,
        title: Layer,
        w: Float,
        h: Float
    ): Pair<Float, Float>? {
        val candidates = listOf(.5f to .16f, .5f to .84f, .16f to .5f, .84f to .5f)
        val titleHalfW = .17f
        val titleHalfH = .07f
        val best = candidates.minByOrNull { candidate ->
            var penalty = 0f
            layers.filter { it.id != title.id }.forEach { layer ->
                val point = positions[layer.id] ?: (layer.x to layer.y)
                val halfW = when (layer.kind) {
                    Kind.IMAGE -> (layer.widthMm / w / 2f).coerceIn(.05f, .35f)
                    Kind.TEXT -> .12f
                    else -> .06f
                }
                val halfH = when (layer.kind) {
                    Kind.IMAGE -> (imageHeight(layer) / h / 2f).coerceIn(.05f, .35f)
                    Kind.TEXT -> .06f
                    else -> .06f
                }
                val dx = abs(candidate.first - point.first)
                val dy = abs(candidate.second - point.second)
                if (dx < titleHalfW + halfW && dy < titleHalfH + halfH) {
                    penalty += (titleHalfW + halfW - dx) * (titleHalfH + halfH - dy) * 100f
                }
            }
            penalty
        } ?: return null
        return best
    }

    private fun imageHeight(l: Layer): Float {
        val bitmap = Bitmaps.get(l.path) ?: return l.widthMm
        return if (bitmap.width > 0) l.widthMm * bitmap.height / bitmap.width else l.widthMm
    }

    private fun balanceScore(layers: List<Layer>, positions: Map<String, Pair<Float, Float>>, w: Float, h: Float): Int {
        var sx = 0f
        var sy = 0f
        var total = 0f
        var overlapPenalty = 0f
        val boxes = ArrayList<Triple<Float, Float, Float>>()
        layers.forEach { l ->
            val p = positions[l.id] ?: (l.x to l.y)
            val weight = when (l.kind) { Kind.IMAGE -> 2f; Kind.TEXT -> 1.5f; else -> .7f }
            sx += p.first * weight; sy += p.second * weight; total += weight
            val radius = (if (l.kind == Kind.IMAGE) .18f else .08f)
            boxes += Triple(p.first, p.second, radius)
        }
        for (i in boxes.indices) for (j in i + 1 until boxes.size) {
            val a = boxes[i]; val b = boxes[j]
            if (abs(a.first - b.first) < a.third + b.third && abs(a.second - b.second) < a.third + b.third)
                overlapPenalty += 12f
        }
        val centerDistance = abs(sx / max(total, .1f) - .5f) + abs(sy / max(total, .1f) - .5f)
        return (100f - centerDistance * 45f - overlapPenalty).toInt().coerceIn(0, 100)
    }
}

@androidx.compose.runtime.Composable
fun SmartCompositionDialog(vm: AppVm, project: Project, onDismiss: () -> Unit) {
    var selected by androidx.compose.runtime.remember { androidx.compose.runtime.mutableIntStateOf(0) }
    val plans = androidx.compose.runtime.remember(project, vm.panel) { SmartComposition.suggest(project, vm.panel) }
    val active = plans.getOrNull(selected)
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { androidx.compose.material3.Text("Умная композиция") },
        text = {
            androidx.compose.foundation.layout.Column(
                modifier = androidx.compose.ui.Modifier.heightIn(max = 430.dp)
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.material3.Text(
                    "Предложения рассчитаны по расположению слоёв. Исходный макет не меняется, пока вы не нажмёте «Применить».",
                    color = Dim, fontSize = 12.sp
                )
                if (plans.isEmpty()) {
                    androidx.compose.material3.Text("На панели пока нет видимых слоёв.", color = Dim)
                } else plans.forEachIndexed { index, plan ->
                    androidx.compose.material3.Surface(
                        onClick = { selected = index },
                        color = if (selected == index) Card.copy(alpha = .95f) else Color.Transparent,
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp, if (selected == index) Violet else Line
                        )
                    ) {
                        androidx.compose.foundation.layout.Column(Modifier.padding(10.dp)) {
                            androidx.compose.material3.Text(plan.name, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                            androidx.compose.material3.Text(plan.description, color = Dim, fontSize = 11.sp)
                            androidx.compose.foundation.Canvas(
                                Modifier.fillMaxWidth().height(58.dp)
                            ) {
                                val sx = size.width
                                val sy = size.height
                                drawRect(Color.White.copy(alpha = .08f), size = size)
                                layersForPreview(project, vm.panel).forEach { layer ->
                                    val point = plan.positions[layer.id] ?: (layer.x to layer.y)
                                    val rw = when (layer.kind) {
                                        Kind.IMAGE -> sx * .20f
                                        Kind.TEXT -> sx * .16f
                                        else -> sx * .07f
                                    }
                                    val rh = when (layer.kind) {
                                        Kind.IMAGE -> sy * .54f
                                        Kind.TEXT -> sy * .16f
                                        else -> sy * .14f
                                    }
                                    val color = when (layer.kind) {
                                        Kind.IMAGE -> Color(0xFF638BC7)
                                        Kind.TEXT -> Color(0xFFFFD36A)
                                        else -> Color(0xFF70C9A1)
                                    }
                                    drawRect(color, androidx.compose.ui.geometry.Offset(point.first * sx - rw / 2, point.second * sy - rh / 2),
                                        androidx.compose.ui.geometry.Size(rw, rh))
                                }
                            }
                            androidx.compose.material3.Text("${plan.freeArea} · баланс ${plan.score}/100", color = Amber, fontSize = 11.sp)
                        }
                    }
                }
                active?.let {
                    androidx.compose.material3.Text("Сравнение: ${it.score}/100 — ${it.freeArea.lowercase()}. Выберите другой вариант выше, чтобы сравнить оценки и расположение.", color = Dim, fontSize = 11.sp)
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(
                enabled = active != null,
                onClick = { active?.let { vm.applyComposition(it.positions) }; onDismiss() }
            ) { androidx.compose.material3.Text("Применить") }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) {
                androidx.compose.material3.Text("Отмена", color = Dim)
            }
        }
    )
}

private fun layersForPreview(project: Project, panel: PanelId): List<Layer> =
    project.panel(panel).layers.filter { it.visible }
