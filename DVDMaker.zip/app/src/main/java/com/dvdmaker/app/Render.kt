package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import androidx.core.graphics.ColorUtils
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

object Fonts {
    val names = listOf("Классика", "Жирный", "Узкий", "Тонкий", "Засечки", "Рукопись", "Casual", "Моно")
    private val fam = listOf(
        "sans-serif-medium", "sans-serif-black", "sans-serif-condensed", "sans-serif-light",
        "serif", "cursive", "casual", "monospace"
    )
    private val cache = HashMap<String, Typeface>()

    fun get(i: Int, italic: Boolean): Typeface = cache.getOrPut("$i-$italic") {
        val base = Typeface.create(fam[i.coerceIn(0, fam.lastIndex)], Typeface.NORMAL)
        Typeface.create(base, if (italic) Typeface.ITALIC else Typeface.NORMAL)
    }
}

object Bitmaps {
    private val cache = object : LruCache<String, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(path: String): Bitmap? {
        cache.get(path)?.let { return it }
        if (path.isEmpty() || !File(path).exists()) return null
        val b = android.graphics.BitmapFactory.decodeFile(path) ?: return null
        cache.put(path, b)
        return b
    }
}

private fun textLayout(l: Layer, ppm: Float): StaticLayout {
    val size = (l.sizeMm * ppm).coerceAtLeast(1f)
    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = l.color
        textSize = size
        typeface = Fonts.get(l.font, l.italic)
        letterSpacing = l.spacing
        if (l.shadow) setShadowLayer(size * 0.08f, 0f, size * 0.05f, 0xB0000000.toInt())
    }
    val raw = if (l.upper) l.text.uppercase() else l.text
    val s = if (raw.isEmpty()) " " else raw
    val width = if (l.boxMm > 0f) {
        (l.boxMm * ppm).toInt().coerceAtLeast(1)
    } else {
        var m = 1f
        for (line in s.split("\n")) m = maxOf(m, tp.measureText(line))
        ceil(m).toInt() + ceil(size * 0.15f).toInt() + 1
    }
    val align = when (l.align) {
        0 -> Layout.Alignment.ALIGN_NORMAL
        2 -> Layout.Alignment.ALIGN_OPPOSITE
        else -> Layout.Alignment.ALIGN_CENTER
    }
    return StaticLayout.Builder.obtain(s, 0, s.length, tp, width)
        .setAlignment(align)
        .setLineSpacing(0f, 1.08f)
        .setIncludePad(false)
        .build()
}

fun layerSize(l: Layer, ppm: Float): Pair<Float, Float> = when (l.kind) {
    Kind.TEXT -> textLayout(l, ppm).let { it.width.toFloat() to it.height.toFloat() }
    Kind.IMAGE -> {
        val b = Bitmaps.get(l.path)
        val w = l.widthMm * ppm
        w to (if (b != null) w * b.height / b.width else w)
    }
}

fun drawLayer(c: Canvas, l: Layer, w: Float, h: Float, ppm: Float) {
    c.save()
    c.translate(l.x * w, l.y * h)
    c.rotate(l.rot)
    when (l.kind) {
        Kind.TEXT -> {
            val sl = textLayout(l, ppm)
            c.translate(-sl.width / 2f, -sl.height / 2f)
            sl.draw(c)
        }
        Kind.IMAGE -> {
            val b = Bitmaps.get(l.path)
            if (b != null) {
                val bw = l.widthMm * ppm
                val bh = bw * b.height / b.width
                val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
                p.alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
                c.drawBitmap(b, null, RectF(-bw / 2, -bh / 2, bw / 2, bh / 2), p)
            }
        }
    }
    c.restore()
}

fun drawPanel(c: Canvas, p: PanelData, w: Float, h: Float, ppm: Float) {
    val bg = Paint()
    if (p.c1 == p.c2) {
        bg.color = p.c1
    } else {
        val rad = Math.toRadians(p.angle.toDouble())
        val dx = cos(rad).toFloat()
        val dy = sin(rad).toFloat()
        val half = (abs(w * dx) + abs(h * dy)) / 2f
        bg.shader = LinearGradient(
            w / 2 - dx * half, h / 2 - dy * half, w / 2 + dx * half, h / 2 + dy * half,
            p.c1, p.c2, Shader.TileMode.CLAMP
        )
    }
    c.drawRect(0f, 0f, w, h, bg)
    for (l in p.layers) drawLayer(c, l, w, h, ppm)
}

fun colorAt(p: PanelData, w: Float, h: Float, x: Float, y: Float): Int {
    if (p.c1 == p.c2) return p.c1
    val rad = Math.toRadians(p.angle.toDouble())
    val dx = cos(rad).toFloat()
    val dy = sin(rad).toFloat()
    val half = (abs(w * dx) + abs(h * dy)) / 2f
    val t = if (half <= 0f) 0f else (((x - w / 2) * dx + (y - h / 2) * dy) / (2 * half) + 0.5f).coerceIn(0f, 1f)
    return ColorUtils.blendARGB(p.c1, p.c2, t)
}

/** Фон корешка всегда подстраивается под соседние части: плавный переход оборот → корешок → лицо. */
fun effectivePanel(p: Project, id: PanelId, instance: Int = 0): PanelData {
    val pd = p.panel(id)
    if (id != PanelId.SPINE) return pd
    val f = p.format
    val back = p.panel(PanelId.BACK)
    val front = p.panel(PanelId.FRONT)
    return if (!f.tray) {
        val l = colorAt(back, f.backW, f.backH, f.backW, f.backH / 2)
        val r = colorAt(front, f.frontW, f.frontH, 0f, f.frontH / 2)
        pd.copy(c1 = l, c2 = r, angle = 0)
    } else {
        val c = if (instance == 0) colorAt(back, f.backW, f.backH, 0f, f.backH / 2)
        else colorAt(back, f.backW, f.backH, f.backW, f.backH / 2)
        pd.copy(c1 = c, c2 = c)
    }
}

fun drawPanelIn(c: Canvas, p: Project, id: PanelId, instance: Int, w: Float, h: Float, ppm: Float) {
    drawPanel(c, effectivePanel(p, id, instance), w, h, ppm)
    if (id == PanelId.SPINE) return
    val f = p.format
    val pd = p.panel(id)
    val fw = minOf(7f * ppm, w * 0.2f)
    fun fade(left: Boolean) {
        val col = colorAt(pd, w, h, if (left) 0f else w, h / 2)
        val x0 = if (left) 0f else w
        val x1 = if (left) fw else w - fw
        val paint = Paint().apply {
            shader = LinearGradient(x0, 0f, x1, 0f, col, col and 0x00FFFFFF, Shader.TileMode.CLAMP)
        }
        c.drawRect(minOf(x0, x1), 0f, maxOf(x0, x1), h, paint)
    }
    if (!f.tray) {
        if (id == PanelId.BACK) fade(false) else fade(true)
    } else if (id == PanelId.BACK) {
        fade(true); fade(false)
    }
}

fun sheetSizeMm(p: Project, a4: Boolean, marks: Boolean): Pair<Float, Float> {
    val lay = p.format.layout()
    if (a4) return 297f to 210f
    val m = if (marks) 8f else 0f
    return (lay.w + 2 * m) to (lay.h + 2 * m)
}

fun renderSheet(p: Project, ppm: Float, a4: Boolean, marks: Boolean): Bitmap {
    val lay = p.format.layout()
    val (sw, sh) = sheetSizeMm(p, a4, marks)
    val bmp = Bitmap.createBitmap((sw * ppm).roundToInt(), (sh * ppm).roundToInt(), Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(Color.WHITE)
    val ox = (sw - lay.w) / 2f
    val oy = (sh - lay.h) / 2f
    for (pl in lay.places) {
        c.save()
        c.translate((ox + pl.x) * ppm, (oy + pl.y) * ppm)
        c.clipRect(0f, 0f, pl.w * ppm, pl.h * ppm)
        drawPanelIn(c, p, pl.id, if (pl.id == PanelId.SPINE && pl.x > 0f) 1 else 0, pl.w * ppm, pl.h * ppm, ppm)
        c.restore()
    }
    if (marks) {
        val mp = Paint().apply {
            color = Color.BLACK
            strokeWidth = maxOf(1f, 0.15f * ppm)
            style = Paint.Style.STROKE
        }
        val gap = 1.5f * ppm
        val len = 4f * ppm
        for (g in lay.groups) {
            val x0 = (ox + g.x) * ppm
            val y0 = (oy + g.y) * ppm
            val x1 = x0 + g.w * ppm
            val y1 = y0 + g.h * ppm
            for ((cx, cy) in listOf(x0 to y0, x1 to y0, x0 to y1, x1 to y1)) {
                val sx = if (cx == x0) -1f else 1f
                val sy = if (cy == y0) -1f else 1f
                c.drawLine(cx + sx * gap, cy, cx + sx * (gap + len), cy, mp)
                c.drawLine(cx, cy + sy * gap, cx, cy + sy * (gap + len), mp)
            }
            for (f in g.folds) {
                val fx = x0 + f * ppm
                c.drawLine(fx, y0 - gap, fx, y0 - gap - len, mp)
                c.drawLine(fx, y1 + gap, fx, y1 + gap + len, mp)
            }
        }
    }
    return bmp
}
