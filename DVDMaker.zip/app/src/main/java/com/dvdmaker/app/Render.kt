package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import androidx.core.graphics.ColorUtils
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

object Fonts {
    class Entry(val name: String, val sys: Int, val file: String)

    private val sysFam = listOf(
        "sans-serif-medium", "sans-serif-black", "sans-serif-condensed", "sans-serif-light",
        "serif", "cursive", "casual", "monospace"
    )
    private val sysNames = listOf("Классика", "Жирный", "Узкий", "Тонкий", "Засечки", "Рукопись", "Casual", "Моно")
    // системные шрифты с кириллицей (cursive/casual без неё — оставлены только как запасные)
    private val shown = listOf(0, 1, 2, 3, 4, 7)

    var entries: List<Entry> = shown.map { Entry(sysNames[it], it, "") }
        private set
    private var assets: android.content.res.AssetManager? = null
    private val cache = HashMap<String, Typeface>()

    fun init(am: android.content.res.AssetManager) {
        assets = am
        val files = runCatching { am.list("fonts")?.toList() }.getOrNull().orEmpty()
            .filter { it.endsWith(".ttf") || it.endsWith(".otf") }.sorted()
        entries = shown.map { Entry(sysNames[it], it, "") } +
            files.map { Entry(it.substringBeforeLast('.').replace('_', ' '), 0, it) }
        cache.clear()
    }

    fun get(sys: Int, file: String, italic: Boolean): Typeface = cache.getOrPut("$sys|$file|$italic") {
        val fromAsset = if (file.isNotEmpty()) runCatching { Typeface.createFromAsset(assets, "fonts/$file") }.getOrNull() else null
        val base = fromAsset ?: Typeface.create(sysFam[sys.coerceIn(0, sysFam.lastIndex)], Typeface.NORMAL)
        Typeface.create(base, if (italic) Typeface.ITALIC else Typeface.NORMAL)
    }
}

object Bitmaps {
    private val cache = object : LruCache<String, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(path: String): Bitmap? {
        cache.get(path)?.let { return it }
        if (path.isEmpty() || !File(path).exists()) return null
        val b = android.graphics.BitmapFactory.decodeFile(path) ?: return null
        cache.put(path, b)
        return b
    }
}

private fun textLayout(l: Layer, ppm: Float): StaticLayout {
    val size = (l.sizeMm * ppm).coerceAtLeast(1f)
    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = l.color
        textSize = size
        typeface = Fonts.get(l.font, l.fontFile, l.italic)
        letterSpacing = l.spacing
        if (l.shadow) setShadowLayer(size * 0.08f, 0f, size * 0.05f, 0xB0000000.toInt())
    }
    val raw = if (l.upper) l.text.uppercase() else l.text
    val s = if (raw.isEmpty()) " " else raw
    val width = if (l.boxMm > 0f) {
        (l.boxMm * ppm).toInt().coerceAtLeast(1)
    } else {
        var m = 1f
        for (line in s.split("\n")) m = maxOf(m, tp.measureText(line))
        ceil(m).toInt() + ceil(size * 0.15f).toInt() + 1
    }
    val align = when (l.align) {
        0 -> Layout.Alignment.ALIGN_NORMAL
        2 -> Layout.Alignment.ALIGN_OPPOSITE
        else -> Layout.Alignment.ALIGN_CENTER
    }
    return StaticLayout.Builder.obtain(s, 0, s.length, tp, width)
        .setAlignment(align)
        .setLineSpacing(0f, 1.08f)
        .setIncludePad(false)
        .build()
}

fun layerSize(l: Layer, ppm: Float): Pair<Float, Float> = when (l.kind) {
    Kind.TEXT -> textLayout(l, ppm).let { it.width.toFloat() to it.height.toFloat() }
    Kind.RECT -> (l.widthMm * ppm) to (l.sizeMm * ppm)
    Kind.SYMBOL -> (l.widthMm * ppm) to (l.widthMm * ppm * 0.42f)
    Kind.IMAGE -> {
        val b = Bitmaps.get(l.path)
        val w = l.widthMm * ppm
        w to (if (b != null) w * b.height / b.width else w)
    }
}

fun drawLayer(c: Canvas, l: Layer, w: Float, h: Float, ppm: Float) {
    c.save()
    c.translate(l.x * w, l.y * h)
    c.rotate(l.rot)
    when (l.kind) {
        Kind.TEXT -> {
            val sl = textLayout(l, ppm)
            c.translate(-sl.width / 2f, -sl.height / 2f)
            sl.draw(c)
        }
        Kind.SYMBOL -> drawSpecialMark(c, l, ppm)
        Kind.RECT -> {
            val rw = l.widthMm * ppm
            val rh = l.sizeMm * ppm
            val rp = Paint(Paint.ANTI_ALIAS_FLAG)
            rp.color = l.color
            rp.alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
            c.drawRect(-rw / 2, -rh / 2, rw / 2, rh / 2, rp)
        }
        Kind.IMAGE -> {
            val b = Bitmaps.get(l.path)
            if (b != null) {
                val bw = l.widthMm * ppm
                val bh = bw * b.height / b.width
                val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
                p.alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
                c.drawBitmap(b, null, RectF(-bw / 2, -bh / 2, bw / 2, bh / 2), p)
            }
        }
    }
    c.restore()
}

/** Прозрачные векторные знаки: цвет задаётся цветом слоя, фон не рисуется. */
private fun drawSpecialMark(c: Canvas, l: Layer, ppm: Float) {
    val w = l.widthMm * ppm
    val h = w * 0.42f
    val sx = w / 300f
    val sy = h / 126f
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = l.color
        alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
        style = Paint.Style.FILL
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC)
    }
    c.save()
    c.scale(sx, sy)
    val key = l.text.uppercase()
    when (key) {
        "BLURAY" -> {
            val p = android.graphics.Path().apply {
                moveTo(12f, 30f); cubicTo(95f, -2f, 240f, 0f, 286f, 43f)
                cubicTo(314f, 70f, 272f, 111f, 185f, 112f)
                cubicTo(240f, 94f, 263f, 69f, 241f, 49f)
                cubicTo(204f, 18f, 91f, 17f, 12f, 30f); close()
            }
            c.drawPath(p, paint)
            val ring = Paint(paint).apply { style = Paint.Style.STROKE; strokeWidth = 13f }
            c.drawOval(48f, 43f, 154f, 70f, ring)
            paint.textSize = 43f
            c.drawText("Blu-ray Disc", 8f, 123f, paint)
        }
        "DVD" -> {
            val ring = Paint(paint).apply { style = Paint.Style.STROKE; strokeWidth = 12f }
            c.drawOval(7f, 8f, 93f, 92f, ring)
            c.drawCircle(50f, 50f, 5f, paint)
            paint.textSize = 66f; c.drawText("DVD", 105f, 76f, paint)
            paint.textSize = 20f; c.drawText("VIDEO", 111f, 105f, paint)
        }
        "CD" -> {
            val ring = Paint(paint).apply { style = Paint.Style.STROKE; strokeWidth = 10f }
            c.drawCircle(54f, 53f, 43f, ring)
            c.drawCircle(54f, 53f, 5f, paint)
            paint.textSize = 76f; c.drawText("CD", 112f, 82f, paint)
        }
        "HIRES" -> { paint.textSize = 58f; c.drawText("Hi-Res", 5f, 69f, paint); paint.textSize = 26f; c.drawText("AUDIO", 10f, 103f, paint) }
        "DOLBY" -> { paint.textSize = 43f; c.drawText("DOLBY", 5f, 59f, paint); paint.textSize = 29f; c.drawText("DIGITAL", 8f, 94f, paint) }
        "ATMOS" -> { paint.textSize = 42f; c.drawText("DOLBY", 5f, 52f, paint); paint.textSize = 37f; c.drawText("ATMOS", 5f, 99f, paint) }
        "DTS", "DTSHD" -> { paint.textSize = 82f; c.drawText(if (key == "DTSHD") "DTS-HD" else "DTS", 5f, 86f, paint) }
        "4K" -> { paint.textSize = 73f; c.drawText("4K", 5f, 79f, paint); paint.textSize = 28f; c.drawText("ULTRA HD", 103f, 77f, paint) }
        "HDR" -> { paint.textSize = 82f; c.drawText("HDR", 5f, 86f, paint) }
        "THX" -> { paint.textSize = 82f; c.drawText("THX", 5f, 86f, paint) }
        "STEREO" -> { paint.textSize = 58f; c.drawText("STEREO", 5f, 76f, paint) }
        "169" -> { paint.textSize = 74f; c.drawText("16:9", 5f, 82f, paint) }
        "1080P", "2160P" -> { paint.textSize = 72f; c.drawText(key.dropLast(1) + "p", 5f, 82f, paint) }
        else -> { paint.textSize = 50f; c.drawText(key, 5f, 75f, paint) }
    }
    c.restore()
}

fun drawPanel(c: Canvas, p: PanelData, w: Float, h: Float, ppm: Float) {
    val bg = Paint()
    if (p.c1 == p.c2) {
        bg.color = p.c1
    } else {
        val rad = Math.toRadians(p.angle.toDouble())
        val dx = cos(rad).toFloat()
        val dy = sin(rad).toFloat()
        val half = (abs(w * dx) + abs(h * dy)) / 2f
        bg.shader = LinearGradient(
            w / 2 - dx * half, h / 2 - dy * half, w / 2 + dx * half, h / 2 + dy * half,
            p.c1, p.c2, Shader.TileMode.CLAMP
        )
    }
    c.drawRect(0f, 0f, w, h, bg)
    for (l in p.layers) {
        if (l.kind == Kind.SYMBOL) {
            val under = samplePanelEdge(p.copy(layers = p.layers.takeWhile { it.id != l.id }), w, h, l.x * w, l.y * h)
            val luminance = (0.299 * Color.red(under) + 0.587 * Color.green(under) + 0.114 * Color.blue(under))
            val autoColor = if (luminance > 145.0) android.graphics.Color.BLACK else android.graphics.Color.WHITE
            drawLayer(c, l.copy(color = autoColor), w, h, ppm)
        } else drawLayer(c, l, w, h, ppm)
    }
}

fun colorAt(p: PanelData, w: Float, h: Float, x: Float, y: Float): Int {
    if (p.c1 == p.c2) return p.c1
    val rad = Math.toRadians(p.angle.toDouble())
    val dx = cos(rad).toFloat()
    val dy = sin(rad).toFloat()
    val half = (abs(w * dx) + abs(h * dy)) / 2f
    val t = if (half <= 0f) 0f else (((x - w / 2) * dx + (y - h / 2) * dy) / (2 * half) + 0.5f).coerceIn(0f, 1f)
    return ColorUtils.blendARGB(p.c1, p.c2, t)
}

/** Цвет фактического содержимого у края панели: учитывает фотографии и фигуры поверх градиента. */
fun samplePanelEdge(p: PanelData, w: Float, h: Float, x: Float, y: Float): Int {
    var result = colorAt(p, w, h, x, y)
    for (layer in p.layers) {
        val dx = x - layer.x * w
        val dy = y - layer.y * h
        val rad = Math.toRadians(-layer.rot.toDouble())
        val lx = (dx * kotlin.math.cos(rad) - dy * kotlin.math.sin(rad)).toFloat()
        val ly = (dx * kotlin.math.sin(rad) + dy * kotlin.math.cos(rad)).toFloat()
        when (layer.kind) {
            Kind.IMAGE -> {
                val bitmap = Bitmaps.get(layer.path) ?: continue
                val iw = layer.widthMm
                val ih = iw * bitmap.height / bitmap.width.toFloat()
                if (kotlin.math.abs(lx) <= iw / 2f && kotlin.math.abs(ly) <= ih / 2f) {
                    val bx = (((lx / iw) + 0.5f) * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
                    val by = (((ly / ih) + 0.5f) * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
                    result = ColorUtils.blendARGB(result, bitmap.getPixel(bx, by), layer.alpha.coerceIn(0f, 1f))
                }
            }
            Kind.RECT -> if (kotlin.math.abs(lx) <= layer.widthMm / 2f && kotlin.math.abs(ly) <= layer.sizeMm / 2f) {
                result = ColorUtils.blendARGB(result, layer.color, layer.alpha.coerceIn(0f, 1f))
            }
            Kind.TEXT, Kind.SYMBOL -> Unit
        }
    }
    return result
}

/** Фон корешка всегда подстраивается под соседние части: плавный переход оборот → корешок → лицо. */
fun effectivePanel(p: Project, id: PanelId, instance: Int = 0): PanelData {
    val pd = p.panel(id)
    if (id != PanelId.SPINE) return pd
    val f = p.format
    val back = p.panel(PanelId.BACK)
    val front = p.panel(PanelId.FRONT)
    return if (!f.tray) {
        val backEdge = samplePanelEdge(back, f.backW, f.backH, f.backW, f.backH / 2)
        val frontEdge = samplePanelEdge(front, f.frontW, f.frontH, 0f, f.frontH / 2)
        val spineTone = colorAt(pd, f.spineW, f.backH, f.spineW / 2f, f.backH / 2f)
        // Края корешка получают точные цвета соседних панелей: на стыке нет цветового скачка.
        pd.copy(c1 = backEdge, c2 = frontEdge, angle = 0)
    } else {
        val edge = if (instance == 0) samplePanelEdge(back, f.backW, f.backH, 0f, f.backH / 2)
        else samplePanelEdge(back, f.backW, f.backH, f.backW, f.backH / 2)
        val spineTone = colorAt(pd, f.spineW, f.backH, f.spineW / 2f, f.backH / 2f)
        pd.copy(c1 = edge, c2 = edge)
    }
}

fun drawPanelIn(c: Canvas, p: Project, id: PanelId, instance: Int, w: Float, h: Float, ppm: Float) {
    // Каждый край соседних панелей окрашен одним и тем же рассчитанным цветом.
    // Поэтому не нужны заметные полосы-фейды поверх изображений.
    drawPanel(c, effectivePanel(p, id, instance), w, h, ppm)
}

fun sheetSizeMm(p: Project, a4: Boolean, marks: Boolean): Pair<Float, Float> {
    val lay = p.format.layout()
    if (a4) return 297f to 210f
    val m = if (marks) 8f else 0f
    return (lay.w + 2 * m) to (lay.h + 2 * m)
}

fun renderSheet(p: Project, ppm: Float, a4: Boolean, marks: Boolean): Bitmap {
    val lay = p.format.layout()
    val (sw, sh) = sheetSizeMm(p, a4, marks)
    val bmp = Bitmap.createBitmap((sw * ppm).roundToInt(), (sh * ppm).roundToInt(), Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(Color.WHITE)
    val ox = (sw - lay.w) / 2f
    val oy = (sh - lay.h) / 2f
    for (pl in lay.places) {
        c.save()
        c.translate((ox + pl.x) * ppm, (oy + pl.y) * ppm)
        c.clipRect(0f, 0f, pl.w * ppm, pl.h * ppm)
        drawPanelIn(c, p, pl.id, if (pl.id == PanelId.SPINE && pl.x > 0f) 1 else 0, pl.w * ppm, pl.h * ppm, ppm)
        c.restore()
    }
    if (marks) {
        val mp = Paint().apply {
            color = Color.BLACK
            strokeWidth = maxOf(1f, 0.15f * ppm)
            style = Paint.Style.STROKE
        }
        val gap = 1.5f * ppm
        val len = 4f * ppm
        for (g in lay.groups) {
            val x0 = (ox + g.x) * ppm
            val y0 = (oy + g.y) * ppm
            val x1 = x0 + g.w * ppm
            val y1 = y0 + g.h * ppm
            for ((cx, cy) in listOf(x0 to y0, x1 to y0, x0 to y1, x1 to y1)) {
                val sx = if (cx == x0) -1f else 1f
                val sy = if (cy == y0) -1f else 1f
                c.drawLine(cx + sx * gap, cy, cx + sx * (gap + len), cy, mp)
                c.drawLine(cx, cy + sy * gap, cx, cy + sy * (gap + len), mp)
            }
            for (f in g.folds) {
                val fx = x0 + f * ppm
                c.drawLine(fx, y0 - gap, fx, y0 - gap - len, mp)
                c.drawLine(fx, y1 + gap, fx, y1 + gap + len, mp)
            }
        }
    }
    return bmp
}
