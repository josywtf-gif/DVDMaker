package com.dvdmaker.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    brush: Brush = BrandBrush
) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (enabled) brush else Brush.linearGradient(listOf(Card2, Card2)))
            .clickable(enabled = enabled, onClick = onClick)
            .heightIn(min = 48.dp)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) Color(0xFF111111) else Dim, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

/** Вкладка в стиле Snapseed: выбранная — жёлтая плашка с чёрным текстом, остальные — белый жирный текст. */
@Composable
fun TabChip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(6.dp))
            .background(if (selected) Violet else Color.Transparent)
            .clickable(onClick = onClick)
            .heightIn(min = 40.dp)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text.uppercase(), color = if (selected) Color(0xFF111111) else Color.White,
            fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 0.5.sp, maxLines = 1)
    }
}

@Composable
fun Pill(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    danger: Boolean = false
) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .heightIn(min = 40.dp)
            .clip(shape)
            .background(if (selected) Violet.copy(alpha = 0.25f) else Card2)
            .border(BorderStroke(1.dp, if (selected) Violet else Line), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            color = if (danger) Color(0xFFFF8A8A) else if (selected) Color.White else Dim
        )
    }
}

/**
 * Состояние «палец на ползунке». Пока count > 0, редактор прячет панель настроек и затемнение,
 * чтобы было видно само изображение (как в Snapseed); text — подпись текущего значения.
 */
class SliderHud {
    var count by mutableIntStateOf(0)
    var text by mutableStateOf("")
}

val LocalSliderHud = compositionLocalOf<SliderHud?> { null }

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onChange: (Float) -> Unit
) {
    val hud = LocalSliderHud.current
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val dragged by source.collectIsDraggedAsState()
    val active = pressed || dragged
    if (hud != null) {
        DisposableEffect(active) {
            if (active) hud.count++
            onDispose { if (active) hud.count-- }
        }
        if (active) SideEffect { hud.text = "$label  ·  $valueText" }
    }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Dim, fontSize = 13.sp)
            Text(valueText, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            interactionSource = source,
            modifier = Modifier.height(34.dp),
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Violet, inactiveTrackColor = Line
            )
        )
    }
}

@Composable
fun Swatch(color: Int, selected: Boolean, size: Dp = 32.dp, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(color))
            .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) Amber else Line), CircleShape)
            .clickable(onClick = onClick)
    )
}

@Composable
fun ColorRow(selected: Int, onPick: (Int) -> Unit) {
    var dialog by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextPalette.forEach { c -> Swatch(c, c == selected) { onPick(c) } }
        Box(
            Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
                .border(BorderStroke(1.dp, Line), CircleShape)
                .clickable { dialog = true },
            contentAlignment = Alignment.Center
        ) { Text("+", color = Color.White, fontWeight = FontWeight.Bold) }
    }
    if (dialog) ColorDialog(selected, { dialog = false }) { onPick(it); dialog = false }
}

@Composable
fun ColorDialog(initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val hsv = remember {
        FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) }
    }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    val argb = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text("Свой цвет") },
        text = {
          androidx.compose.runtime.CompositionLocalProvider(LocalSliderHud provides null) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(12.dp))
                        .background(Color(argb)).border(BorderStroke(1.dp, Line), RoundedCornerShape(12.dp))
                )
                LabeledSlider("Оттенок", h, 0f..360f, "${h.toInt()}°") { h = it }
                LabeledSlider("Насыщенность", s, 0f..1f, "${(s * 100).toInt()}%") { s = it }
                LabeledSlider("Яркость", v, 0f..1f, "${(v * 100).toInt()}%") { v = it }
            }
          }
        },
        confirmButton = { TextButton(onClick = { onPick(argb) }) { Text("Выбрать") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = Dim) } }
    )
}

@Composable
fun FontChip(e: Fonts.Entry, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    val ff = remember(e.file, e.sys) {
        androidx.compose.ui.text.font.FontFamily(Fonts.get(e.sys, e.file, false))
    }
    Box(
        Modifier
            .clip(shape)
            .background(if (selected) Violet.copy(alpha = 0.25f) else Card2)
            .border(BorderStroke(1.dp, if (selected) Violet else Line), shape)
            .clickable(onClick = onClick)
            .heightIn(min = 40.dp)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(e.name, fontFamily = ff, fontSize = 16.sp, color = if (selected) Color.White else Color(0xFFD0D4F0), maxLines = 1)
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp, modifier = modifier)
}

@Composable
fun FormatArt(format: DiscFormat, modifier: Modifier = Modifier, showSafeZone: Boolean = false) {
    androidx.compose.foundation.Canvas(modifier) {
        val lay = format.layout()
        val s = minOf(size.width / lay.w, size.height / lay.h)
        val ox = (size.width - lay.w * s) / 2f
        val oy = (size.height - lay.h * s) / 2f
        val gap = 1f
        for (pl in lay.places) {
            val col = when (pl.id) {
                PanelId.FRONT -> Violet
                PanelId.SPINE -> Amber
                PanelId.BACK -> Color(0xFF3A3F6B)
                PanelId.DISC -> Color(0xFF3A3F6B)
            }
            val left = ox + pl.x * s + gap
            val top = oy + pl.y * s + gap
            val panelW = (pl.w * s - gap * 2).coerceAtLeast(1f)
            val panelH = (pl.h * s - gap * 2).coerceAtLeast(1f)
            drawRoundRect(
                color = col,
                topLeft = androidx.compose.ui.geometry.Offset(left, top),
                size = androidx.compose.ui.geometry.Size(panelW, panelH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f, 3f)
            )
            if (showSafeZone && pl.id != PanelId.SPINE) {
                val inset = minOf(3f * s, panelW * 0.2f, panelH * 0.2f)
                drawRect(
                    color = Color.White.copy(alpha = 0.7f),
                    topLeft = androidx.compose.ui.geometry.Offset(left + inset, top + inset),
                    size = androidx.compose.ui.geometry.Size((panelW - inset * 2).coerceAtLeast(1f), (panelH - inset * 2).coerceAtLeast(1f)),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(4f, 3f)))
                )
            }
        }
    }
}

@Composable
fun SettingsGroup(
    title: String,
    initiallyExpanded: Boolean = false,
    content: @Composable () -> Unit
) {
    var expanded by remember(title) { mutableStateOf(initiallyExpanded) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Card2.copy(alpha = 0.72f))
            .border(BorderStroke(1.dp, Line), RoundedCornerShape(16.dp))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Row(Modifier.fillMaxWidth().clickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically) {
            Text(title, modifier = Modifier.weight(1f), color = Color.White,
                fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(if (expanded) "−" else "+", color = Violet, fontSize = 19.sp,
                fontWeight = FontWeight.Bold)
        }
        if (expanded) content()
    }
}



/** Единое пустое состояние: короткое объяснение и необязательное следующее действие. */
@Composable
fun EmptyState(
    title: String,
    message: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(Card2.copy(alpha = 0.72f))
            .border(BorderStroke(1.dp, Line), RoundedCornerShape(16.dp))
            .padding(horizontal = 20.dp, vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("✦", color = Amber, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(message, color = Dim, fontSize = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (actionLabel != null && onAction != null) {
            GradientButton(actionLabel, onAction, brush = BrandBrush)
        }
    }
}

/** Строка пресетов: горизонтальная прокрутка, последним пунктом обычно идёт «Настроить». */
@Composable
fun PresetRow(content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    androidx.compose.foundation.layout.Row(
        Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp),
        content = content
    )
}
