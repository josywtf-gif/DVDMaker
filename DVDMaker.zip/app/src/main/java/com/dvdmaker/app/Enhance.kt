package com.dvdmaker.app

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Параметры улучшения. scale — во сколько раз увеличить; остальные силы от 0 (выкл). */
class EnhanceOptions(
    val scale: Float = 1f,
    val denoise: Float = 0f,
    val sharpen: Float = 0f,
    val contrast: Float = 0f
)

/**
 * Классическое улучшение без нейросетей и без интернета: увеличение с интерполяцией,
 * мягкое шумоподавление с сохранением краёв, автоматическая коррекция уровней и маска резкости.
 * Новых деталей не «дорисовывает», но заметно улучшает вид и печать небольших картинок.
 */
object Enhancer {
    /** Предел по длинной стороне: больше не помещается в кэш изображений приложения. */
    const val MAX_SIDE = 4096

    /** Во сколько раз увеличить, чтобы получить [targetDpi] (от 1 до 4). */
    fun autoScale(currentDpi: Float, targetDpi: Float = 300f): Float =
        if (currentDpi <= 0f) 1f else (targetDpi / currentDpi).coerceIn(1f, 4f)

    fun enhance(src: Bitmap, o: EnhanceOptions): Bitmap {
        val cap = MAX_SIDE.toFloat() / max(src.width, src.height)
        val f = min(o.scale, cap)
        var work: Bitmap = src
        if (f > 1.02f) work = upscale(src, f)
        val w = work.width
        val h = work.height
        val px = IntArray(w * h)
        work.getPixels(px, 0, w, 0, 0, w, h)
        if (work !== src) work.recycle()
        if (o.denoise > 0.01f) denoise(px, w, h, o.denoise)
        if (o.contrast > 0.01f) autoLevels(px, o.contrast)
        if (o.sharpen > 0.01f) unsharp(px, w, h, o.sharpen)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Увеличение ступенями не более ×2 — так меньше «лесенки», чем одним большим прыжком. */
    private fun upscale(src: Bitmap, f: Float): Bitmap {
        val tw = (src.width * f).roundToInt()
        val th = (src.height * f).roundToInt()
        var cur = src
        while (cur.width < tw) {
            val nw = min(cur.width * 2, tw)
            val nh = if (nw == tw) th else min(cur.height * 2, th)
            val next = Bitmap.createScaledBitmap(cur, nw, nh, true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        return cur
    }

    /** Билатеральный фильтр 3×3: сглаживает шум и артефакты JPEG, не размывая контуры. */
    private fun denoise(px: IntArray, w: Int, h: Int, s: Float) {
        val sig = 8f + 40f * s
        val lut = FloatArray(766) { d -> exp(-(d.toFloat() * d) / (2f * sig * sig * 9f)) }
        val src = px.copyOf()
        for (y in 0 until h) {
            val y0 = if (y > 0) y - 1 else 0
            val y1 = if (y < h - 1) y + 1 else h - 1
            for (x in 0 until w) {
                val x0 = if (x > 0) x - 1 else 0
                val x1 = if (x < w - 1) x + 1 else w - 1
                val c = src[y * w + x]
                val cr = (c shr 16) and 255
                val cg = (c shr 8) and 255
                val cb = c and 255
                var sr = cr.toFloat()
                var sg = cg.toFloat()
                var sb = cb.toFloat()
                var sw = 1f
                for (yy in y0..y1) {
                    for (xx in x0..x1) {
                        if (yy == y && xx == x) continue
                        val n = src[yy * w + xx]
                        val nr = (n shr 16) and 255
                        val ng = (n shr 8) and 255
                        val nb = n and 255
                        val wgt = lut[abs(nr - cr) + abs(ng - cg) + abs(nb - cb)]
                        sr += nr * wgt
                        sg += ng * wgt
                        sb += nb * wgt
                        sw += wgt
                    }
                }
                val r = (sr / sw).roundToInt().coerceIn(0, 255)
                val g = (sg / sw).roundToInt().coerceIn(0, 255)
                val b = (sb / sw).roundToInt().coerceIn(0, 255)
                px[y * w + x] = (c and -0x1000000) or (r shl 16) or (g shl 8) or b
            }
        }
    }

    /** Автоматические уровни: растягивает тональный диапазон по 0,5% / 99,5% яркости. */
    private fun autoLevels(px: IntArray, strength: Float) {
        val hist = IntArray(256)
        var total = 0
        for (c in px) {
            if ((c ushr 24) < 16) continue
            val l = (299 * ((c shr 16) and 255) + 587 * ((c shr 8) and 255) + 114 * (c and 255)) / 1000
            hist[l]++
            total++
        }
        if (total == 0) return
        val cut = (total * 0.005f).toInt()
        var lo = 0
        var acc = 0
        while (lo < 255 && acc + hist[lo] <= cut) { acc += hist[lo]; lo++ }
        var hi = 255
        acc = 0
        while (hi > 0 && acc + hist[hi] <= cut) { acc += hist[hi]; hi-- }
        if (hi - lo < 32) return
        val gain = 255f / (hi - lo)
        val s = strength.coerceIn(0f, 1f)
        val lut = IntArray(256) { v ->
            val t = ((v - lo) * gain).coerceIn(0f, 255f)
            (v + (t - v) * s).roundToInt().coerceIn(0, 255)
        }
        for (i in px.indices) {
            val c = px[i]
            px[i] = (c and -0x1000000) or
                (lut[(c shr 16) and 255] shl 16) or (lut[(c shr 8) and 255] shl 8) or lut[c and 255]
        }
    }

    /** Маска резкости: добавляет разницу между оригиналом и размытой копией. */
    private fun unsharp(px: IntArray, w: Int, h: Int, amount: Float) {
        val r = (max(w, h) / 1000).coerceIn(1, 4)
        val orig = ByteArray(w * h)
        val a = ByteArray(w * h)
        val b = ByteArray(w * h)
        for (shift in intArrayOf(16, 8, 0)) {
            for (i in px.indices) orig[i] = ((px[i] shr shift) and 255).toByte()
            boxBlurH(orig, a, w, h, r)
            boxBlurV(a, b, w, h, r)
            boxBlurH(b, a, w, h, r)
            boxBlurV(a, b, w, h, r)
            val keep = (255 shl shift).inv()
            for (i in px.indices) {
                val o = orig[i].toInt() and 255
                val bl = b[i].toInt() and 255
                val v = (o + amount * (o - bl)).roundToInt().coerceIn(0, 255)
                px[i] = (px[i] and keep) or (v shl shift)
            }
        }
    }

    private fun boxBlurH(src: ByteArray, dst: ByteArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sum = 0
            for (i in -r..r) sum += src[row + i.coerceIn(0, w - 1)].toInt() and 255
            for (x in 0 until w) {
                dst[row + x] = (sum / div).toByte()
                val add = src[row + min(x + r + 1, w - 1)].toInt() and 255
                val sub = src[row + max(x - r, 0)].toInt() and 255
                sum += add - sub
            }
        }
    }

    private fun boxBlurV(src: ByteArray, dst: ByteArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var sum = 0
            for (i in -r..r) sum += src[i.coerceIn(0, h - 1) * w + x].toInt() and 255
            for (y in 0 until h) {
                dst[y * w + x] = (sum / div).toByte()
                val add = src[min(y + r + 1, h - 1) * w + x].toInt() and 255
                val sub = src[max(y - r, 0) * w + x].toInt() and 255
                sum += add - sub
            }
        }
    }
}

/** Диалог улучшения выбранной картинки на макете. */
@Composable
fun EnhanceDialog(vm: AppVm, layer: Layer, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val bmp = Bitmaps.get(layer.path)
    val dpi = if (bmp != null && layer.widthMm > 0f) bmp.width / (layer.widthMm / 25.4f) else 0f
    var scaleMode by remember { mutableStateOf(1) }
    var denoise by remember { mutableStateOf(0.35f) }
    var sharpen by remember { mutableStateOf(0.6f) }
    var contrast by remember { mutableStateOf(0.4f) }
    var busy by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        containerColor = Card,
        title = { Text("Улучшить качество") },
        text = {
            Column(
                Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (bmp != null) Text(
                    "Сейчас: ${bmp.width}×${bmp.height} px, при текущем размере на макете ≈ ${dpi.roundToInt()} dpi.",
                    color = Dim, fontSize = 12.sp
                )
                SectionLabel("Увеличение")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Нет", scaleMode == 0, { scaleMode = 0 })
                    Pill("Авто до 300 dpi", scaleMode == 1, { scaleMode = 1 })
                    Pill("×2", scaleMode == 2, { scaleMode = 2 })
                    Pill("×3", scaleMode == 3, { scaleMode = 3 })
                }
                LabeledSlider("Шумоподавление", denoise, 0f..1f, "${(denoise * 100).toInt()}%") { denoise = it }
                LabeledSlider("Резкость", sharpen, 0f..1.5f, "${(sharpen * 100).toInt()}%") { sharpen = it }
                LabeledSlider("Автоконтраст", contrast, 0f..1f, "${(contrast * 100).toInt()}%") { contrast = it }
                Text(
                    "Это классическое улучшение (интерполяция, шумоподавление, резкость, уровни), не нейросеть: " +
                        "оно не дорисовывает новые детали. Размер картинки на макете не меняется, растёт только число пикселей " +
                        "(до ${Enhancer.MAX_SIDE} px по длинной стороне). Отменить можно кнопкой ↶.",
                    color = Dim, fontSize = 11.sp
                )
                if (busy) Text("Обрабатываем, это может занять несколько секунд…", color = Amber, fontSize = 13.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && bmp != null, onClick = {
                scope.launch {
                    busy = true
                    val newPath = withContext(Dispatchers.Default) {
                        try {
                            val src = Bitmaps.get(layer.path) ?: return@withContext null
                            val sc = when (scaleMode) {
                                0 -> 1f
                                1 -> Enhancer.autoScale(dpi)
                                2 -> 2f
                                else -> 3f
                            }
                            val out = Enhancer.enhance(src, EnhanceOptions(sc, denoise, sharpen, contrast))
                            val p = vm.store.saveBitmap(out, layer.path.endsWith(".png", true))
                            out.recycle()
                            p
                        } catch (t: Throwable) {
                            null
                        }
                    }
                    busy = false
                    if (newPath == null) {
                        Toast.makeText(ctx, "Не удалось улучшить изображение", Toast.LENGTH_SHORT).show()
                    } else {
                        vm.updateLayer(layer.id) { it.copy(path = newPath) }
                        Toast.makeText(ctx, "Готово", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    }
                }
            }) { Text("Улучшить") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Отмена", color = Dim) } }
    )
}
