package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Улучшение картинки только нейросетью Real-ESRGAN (на устройстве, без интернета), см. [NeuralUpscaler]. */
object Enhancer {
    /** Предел по длинной стороне: больше не помещается в кэш изображений приложения. */
    const val MAX_SIDE = 4096

    /** Во сколько раз увеличить, чтобы получить [targetDpi] (от 1 до 4). */
    fun autoScale(currentDpi: Float, targetDpi: Float = 300f): Float =
        if (currentDpi <= 0f) 1f else (targetDpi / currentDpi).coerceIn(1f, 4f)

    /** Реальный коэффициент увеличения с учётом предела [MAX_SIDE]. Если он ≤ 1,02 — улучшать нечего. */
    fun effectiveScale(src: Bitmap, scale: Float): Float = min(scale, MAX_SIDE.toFloat() / max(src.width, src.height))

    fun canEnhance(src: Bitmap, scale: Float): Boolean = effectiveScale(src, scale) > 1.02f

    suspend fun enhance(
        ctx: Context, src: Bitmap, scale: Float, model: NnModel = NnModel.FAST, onProgress: (Int) -> Unit = {}
    ): Bitmap {
        val f = effectiveScale(src, scale)
        return NeuralUpscaler.upscale(
            ctx.applicationContext, src,
            (src.width * f).roundToInt(), (src.height * f).roundToInt(), model, onProgress
        )
    }
}

/**
 * Выбор параметров улучшения: увеличение (авто до 300 dpi, ×2, ×3, ×4) и, если [allowModel], модель.
 * Если разрешение уже ≥300 dpi, перед запуском спрашивает, продолжать ли.
 */
@Composable
fun EnhanceOptionsDialog(
    dpi: Float, allowModel: Boolean, onDismiss: () -> Unit, onConfirm: (Float, NnModel) -> Unit
) {
    val ctx = LocalContext.current
    val enough = dpi >= 300f
    var model by remember { mutableStateOf(NnModel.FAST) }
    var scaleMode by remember { mutableStateOf(if (enough) 1 else 0) }
    var asking by remember { mutableStateOf(false) }
    val needDl = allowModel && model == NnModel.MAX && !ModelStore.has(ctx)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text(if (asking) "Разрешение уже достаточное" else "Улучшить качество") },
        text = {
            if (asking) {
                Text(
                    "Сейчас ≈${dpi.roundToInt()} dpi — это уже не меньше 300. Нейросеть всё равно уберёт артефакты и " +
                        "дорисует детали, но для печати выигрыш будет небольшим, а обработка займёт время. Продолжить?",
                    fontSize = 14.sp
                )
            } else {
                Column(
                    Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (dpi > 0f) Text("Сейчас ≈ ${dpi.roundToInt()} dpi при текущем размере.", color = Dim, fontSize = 12.sp)
                    if (enough) Text("Уже ≥300 dpi: увеличение не обязательно, перед запуском спросим подтверждение.", color = Amber, fontSize = 12.sp)
                    if (allowModel) {
                        SectionLabel("Модель")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            NnModel.values().forEach { m -> Pill(m.title, model == m, { model = m }) }
                        }
                        Text(
                            if (model == NnModel.MAX)
                                "RealESRGAN x4plus: лучшая детализация, но в 10–20 раз медленнее (лучше для небольших картинок). " +
                                    if (ModelStore.has(ctx)) "Модель уже скачана." else "При первом запуске скачается модель ~67 МБ (нужен интернет)."
                            else "Быстрая: встроена в приложение, подходит для большинства обложек.",
                            color = Dim, fontSize = 11.sp
                        )
                    }
                    SectionLabel("Увеличение")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!enough) Pill("Авто до 300 dpi", scaleMode == 0, { scaleMode = 0 })
                        Pill("×2", scaleMode == 1, { scaleMode = 1 })
                        Pill("×3", scaleMode == 2, { scaleMode = 2 })
                        Pill("×4", scaleMode == 3, { scaleMode = 3 })
                    }
                    Text(
                        "Нейросеть работает на устройстве без интернета: увеличивает картинку, убирает артефакты JPEG и дорисовывает " +
                            "правдоподобные мелкие детали. Размер картинки на макете не меняется, растёт только число пикселей " +
                            "(до ${Enhancer.MAX_SIDE} px по длинной стороне).",
                        color = Dim, fontSize = 11.sp
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (enough && !asking) asking = true
                else onConfirm(
                    when (scaleMode) { 0 -> Enhancer.autoScale(dpi); 1 -> 2f; 2 -> 3f; else -> 4f },
                    model
                )
            }) { Text(if (asking) "Продолжить" else if (needDl) "Скачать и улучшить" else "Улучшить") }
        },
        dismissButton = {
            TextButton(onClick = { if (asking) asking = false else onDismiss() }) {
                Text(if (asking) "Назад" else "Отмена", color = Dim)
            }
        }
    )
}

/** Диалог улучшения выбранной картинки на макете. Во время обработки доступна только кнопка «Отменить». */
@Composable
fun EnhanceDialog(vm: AppVm, layer: Layer, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val bmp = Bitmaps.get(layer.path)
    val dpi = if (bmp != null && layer.widthMm > 0f) bmp.width / (layer.widthMm / 25.4f) else 0f
    var phase by remember { mutableStateOf(1) }
    var progress by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }

    if (!busy) {
        EnhanceOptionsDialog(dpi, allowModel = true, onDismiss = onDismiss) { sc, nnModel ->
            val b = bmp
            if (b == null) { onDismiss(); return@EnhanceOptionsDialog }
            if (!Enhancer.canEnhance(b, sc)) {
                Toast.makeText(ctx, "Картинка уже максимального размера (${Enhancer.MAX_SIDE} px)", Toast.LENGTH_LONG).show()
                return@EnhanceOptionsDialog
            }
            job = scope.launch {
                busy = true
                progress = 0
                if (nnModel == NnModel.MAX && !ModelStore.has(ctx)) {
                    phase = 0
                    val ok = withContext(Dispatchers.IO) {
                        try {
                            ModelStore.download(ctx.applicationContext) { progress = it }
                            true
                        } catch (t: CancellationException) {
                            throw t
                        } catch (t: Throwable) {
                            false
                        }
                    }
                    if (!ok) {
                        busy = false
                        Toast.makeText(ctx, "Не удалось скачать модель — проверьте интернет", Toast.LENGTH_LONG).show()
                        return@launch
                    }
                    phase = 1
                    progress = 0
                }
                val newPath = withContext(Dispatchers.Default) {
                    try {
                        val src = Bitmaps.get(layer.path) ?: return@withContext null
                        val out = Enhancer.enhance(ctx, src, sc, nnModel) { progress = it }
                        val p = vm.store.saveBitmap(out, layer.path.endsWith(".png", true))
                        out.recycle()
                        p
                    } catch (t: CancellationException) {
                        throw t
                    } catch (t: Throwable) {
                        null
                    }
                }
                busy = false
                if (newPath == null) {
                    Toast.makeText(ctx, "Не удалось улучшить изображение", Toast.LENGTH_SHORT).show()
                } else {
                    vm.updateLayer(layer.id) { it.copy(path = newPath) }
                    Toast.makeText(ctx, "Готово", Toast.LENGTH_SHORT).show()
                    onDismiss()
                }
            }
        }
    } else {
        AlertDialog(
            onDismissRequest = { },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
            containerColor = Card,
            title = { Text("Улучшение изображения") },
            text = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        if (phase == 0) "Скачиваем модель: $progress%" else "Нейросеть улучшает изображение: $progress%",
                        color = Amber, fontSize = 14.sp
                    )
                    if (phase == 1 && progress <= 0) LinearProgressIndicator(color = Violet, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(progress = { progress / 100f }, color = Violet, modifier = Modifier.fillMaxWidth())
                    Text("Это может занять до нескольких минут. Не закрывайте приложение.", color = Dim, fontSize = 12.sp)
                }
            },
            confirmButton = { },
            dismissButton = { TextButton(onClick = { job?.cancel(); busy = false }) { Text("Отменить", color = Dim) } }
        )
    }
}
