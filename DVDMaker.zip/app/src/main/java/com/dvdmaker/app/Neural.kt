package com.dvdmaker.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Нейросетевой апскейлинг Real-ESRGAN (realesr-general-x4v3, ONNX) прямо на устройстве, без интернета.
 * Модель всегда увеличивает ×4; картинка обрабатывается плитками, чтобы хватило памяти.
 */
object NeuralUpscaler {
    private const val MODEL = "models/realesr-general-x4v3.onnx"
    private const val CORE = 160
    private const val PAD = 10
    private const val SCALE = 4

    /** Предел входа в нейросеть: больше — слишком долго и не хватит памяти. */
    const val MAX_INPUT_PIXELS = 1_000_000

    fun available(ctx: Context): Boolean = try {
        ctx.assets.open(MODEL).close(); true
    } catch (_: Throwable) {
        false
    }

    /**
     * Увеличивает [src] в [factor] раз (1…4) нейросетью: ×4 плитками, затем точное уменьшение до нужного размера.
     * [targetW]×[targetH] — итоговый размер. [onProgress] получает 0…100.
     */
    suspend fun upscale(ctx: Context, src: Bitmap, targetW: Int, targetH: Int, onProgress: (Int) -> Unit): Bitmap {
        // вход ограничиваем по числу пикселей
        var input = src
        val px0 = src.width.toLong() * src.height
        if (px0 > MAX_INPUT_PIXELS) {
            val k = Math.sqrt(MAX_INPUT_PIXELS.toDouble() / px0).toFloat()
            input = Bitmap.createScaledBitmap(
                src, (src.width * k).roundToInt().coerceAtLeast(1), (src.height * k).roundToInt().coerceAtLeast(1), true
            )
        }
        val inW = input.width
        val inH = input.height
        val pix = IntArray(inW * inH)
        input.getPixels(pix, 0, inW, 0, 0, inW, inH)
        if (input !== src) input.recycle()

        val big = Bitmap.createBitmap(inW * SCALE, inH * SCALE, Bitmap.Config.ARGB_8888)
        val env = OrtEnvironment.getEnvironment()
        val bytes = ctx.assets.open(MODEL).use { it.readBytes() }
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(min(4, max(2, Runtime.getRuntime().availableProcessors() - 1)))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        try {
            env.createSession(bytes, opts).use { session ->
                val inName = session.inputNames.first()
                val tilesX = (inW + CORE - 1) / CORE
                val tilesY = (inH + CORE - 1) / CORE
                val total = tilesX * tilesY
                var done = 0
                var last = -1
                for (ty in 0 until tilesY) for (tx in 0 until tilesX) {
                    currentCoroutineContext().ensureActive()
                    val x0 = tx * CORE
                    val y0 = ty * CORE
                    val x1 = min(x0 + CORE, inW)
                    val y1 = min(y0 + CORE, inH)
                    val sx0 = max(0, x0 - PAD)
                    val sy0 = max(0, y0 - PAD)
                    val sx1 = min(inW, x1 + PAD)
                    val sy1 = min(inH, y1 + PAD)
                    val tw = sx1 - sx0
                    val th = sy1 - sy0
                    val plane = tw * th
                    val data = FloatArray(3 * plane)
                    for (y in 0 until th) {
                        val row = (sy0 + y) * inW + sx0
                        for (x in 0 until tw) {
                            val c = pix[row + x]
                            val i = y * tw + x
                            data[i] = ((c shr 16) and 255) / 255f
                            data[plane + i] = ((c shr 8) and 255) / 255f
                            data[2 * plane + i] = (c and 255) / 255f
                        }
                    }
                    OnnxTensor.createTensor(env, FloatBuffer.wrap(data), longArrayOf(1, 3, th.toLong(), tw.toLong())).use { t ->
                        session.run(mapOf(inName to t)).use { res ->
                            val out = res.get(0) as OnnxTensor
                            val fb = out.floatBuffer
                            val ow = tw * SCALE
                            val oh = th * SCALE
                            val oPlane = ow * oh
                            val cx = (x0 - sx0) * SCALE
                            val cy = (y0 - sy0) * SCALE
                            val cw = (x1 - x0) * SCALE
                            val ch = (y1 - y0) * SCALE
                            val buf = IntArray(cw * ch)
                            for (y in 0 until ch) {
                                val rowO = (cy + y) * ow + cx
                                for (x in 0 until cw) {
                                    val o = rowO + x
                                    val r = (fb.get(o) * 255f + 0.5f).toInt().coerceIn(0, 255)
                                    val g = (fb.get(oPlane + o) * 255f + 0.5f).toInt().coerceIn(0, 255)
                                    val b = (fb.get(2 * oPlane + o) * 255f + 0.5f).toInt().coerceIn(0, 255)
                                    buf[y * cw + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
                                }
                            }
                            big.setPixels(buf, 0, cw, x0 * SCALE, y0 * SCALE, cw, ch)
                        }
                    }
                    done++
                    val p = done * 100 / total
                    if (p != last) { last = p; onProgress(p) }
                }
            }
        } finally {
            opts.close()
        }

        var out = shrinkTo(big, targetW, targetH)
        if (src.hasAlpha()) out = withAlpha(out, src)
        return out
    }

    /** Уменьшение до точного размера ступенями ×2 — без «лесенки» от одного большого прыжка. */
    private fun shrinkTo(bmp: Bitmap, tw: Int, th: Int): Bitmap {
        var cur = bmp
        while (cur.width >= tw * 2 && cur.height >= th * 2) {
            val next = Bitmap.createScaledBitmap(cur, max(cur.width / 2, tw), max(cur.height / 2, th), true)
            if (cur !== bmp) cur.recycle()
            cur = next
        }
        if (cur.width != tw || cur.height != th) {
            val next = Bitmap.createScaledBitmap(cur, tw, th, true)
            if (cur !== bmp) cur.recycle()
            cur = next
        }
        if (cur !== bmp) bmp.recycle()
        return cur
    }

    /** Нейросеть не знает про прозрачность: берём альфа-канал из исходника, увеличенного обычным способом. */
    private fun withAlpha(rgb: Bitmap, src: Bitmap): Bitmap {
        val w = rgb.width
        val h = rgb.height
        val a = Bitmap.createScaledBitmap(src, w, h, true)
        val pa = IntArray(w * h)
        a.getPixels(pa, 0, w, 0, 0, w, h)
        if (a !== src) a.recycle()
        val pc = IntArray(w * h)
        rgb.getPixels(pc, 0, w, 0, 0, w, h)
        rgb.recycle()
        for (i in pc.indices) pc[i] = (pa[i] and -0x1000000) or (pc[i] and 0x00FFFFFF)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(pc, 0, w, 0, 0, w, h)
        return out
    }
}
