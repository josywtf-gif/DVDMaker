package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.max

class Store(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "projects").apply { mkdirs() }
    private val imgDir = File(ctx.filesDir, "img").apply { mkdirs() }

    fun loadAll(): List<Project> =
        (dir.listFiles() ?: emptyArray())
            .filter { it.extension == "json" }
            .mapNotNull { f -> runCatching { Project.fromJson(JSONObject(f.readText())) }.getOrNull() }
            .sortedByDescending { it.updated }

    fun save(p: Project): Boolean =
        runCatching { File(dir, "${p.id}.json").writeText(p.toJson().toString()) }.isSuccess

    fun delete(p: Project) {
        File(dir, "${p.id}.json").delete()
        val used = loadAll().flatMap { it.imagePaths() }.toSet()
        (imgDir.listFiles() ?: emptyArray()).forEach { if (it.absolutePath !in used) it.delete() }
    }

    /** Сохраняет готовый bitmap (результат подгонки) во внутреннюю папку изображений. */
    fun saveBitmap(bmp: Bitmap, png: Boolean = false, prefix: String = ""): String? = runCatching {
        val f = File(imgDir, prefix + UUID.randomUUID().toString() + if (png) ".png" else ".jpg")
        f.outputStream().use { bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }
        f.absolutePath
    }.getOrNull()

    /** Загружает изображение для проверки: bitmap (до 4096 px по длинной стороне) и реальные размеры в пикселях. */
    fun decodeForCheck(uri: Uri): CheckImage? = runCatching {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 4096) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
        var tw = bounds.outWidth
        var th = bounds.outHeight
        val orientation = runCatching {
            cr.openInputStream(uri)!!.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val deg = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg != 0f) {
            val m = Matrix().apply { postRotate(deg) }
            val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (r != bmp) bmp.recycle()
            bmp = r
            if (deg == 90f || deg == 270f) { val t = tw; tw = th; th = t }
        }
        CheckImage(bmp, tw, th)
    }.getOrNull()

    fun importImage(uri: Uri): String? = runCatching {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 3000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
        try {
            val orientation = runCatching {
                cr.openInputStream(uri)!!.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                }
            }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) {
                val m = Matrix().apply { postRotate(deg) }
                val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (r != bmp) bmp.recycle()
                bmp = r
            }
            val type = cr.getType(uri) ?: ""
            val png = type.contains("png") || type.contains("webp") || bounds.outMimeType?.contains("png") == true || bmp.hasAlpha()
            val f = File(imgDir, UUID.randomUUID().toString() + if (png) ".png" else ".jpg")
            f.outputStream().use {
                bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 92, it)
            }
            f.absolutePath
        } finally {
            if (!bmp.isRecycled) bmp.recycle()
        }
    }.getOrNull()
}
