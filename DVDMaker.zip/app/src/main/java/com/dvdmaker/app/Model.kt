package com.dvdmaker.app

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class PanelId(val title: String) { FRONT("Лицо"), SPINE("Корешок"), BACK("Оборот"), DISC("Диск") }

/** Печать на самом диске: холст 120×120 мм, печатная зона — кольцо 118 мм снаружи и 22 мм отверстие. */
const val DISC_SIZE_MM = 120f
const val DISC_OUTER_MM = 118f
const val DISC_INNER_MM = 22f

data class Place(val id: PanelId, val x: Float, val y: Float, val w: Float, val h: Float)
data class Group(val x: Float, val y: Float, val w: Float, val h: Float, val folds: List<Float>)
data class SheetLayout(val groups: List<Group>, val places: List<Place>, val w: Float, val h: Float)

fun fmt(v: Float): String = if (v % 1f == 0f) v.toInt().toString() else v.toString()

data class DiscFormat(
    val name: String,
    val title: String,
    val subtitle: String,
    val frontW: Float,
    val frontH: Float,
    val spineW: Float,
    val backW: Float,
    val backH: Float,
    val tray: Boolean,
    /** Просто фото: одна панель без корешка и оборота, размер берётся из открытой картинки. */
    val photo: Boolean = false
) {
    companion object {
        val DVD = DiscFormat("DVD", "DVD", "Стандартный кейс", 129.5f, 183f, 14f, 129.5f, 183f, false)
        val DVD_SLIM = DiscFormat("DVD_SLIM", "DVD Slim", "Тонкий кейс", 129.5f, 183f, 7f, 129.5f, 183f, false)
        val CD = DiscFormat("CD", "CD", "Jewel case", 120f, 120f, 6.5f, 137f, 118f, true)
        val BLURAY = DiscFormat("BLURAY", "Blu-ray", "Стандартный кейс", 129f, 150f, 11f, 129f, 150f, false)
        val PHOTO = photo(150f, 100f)

        /** Фото-формат нужного размера в мм; размер хранится в имени, поэтому сохраняется вместе с проектом. */
        fun photo(wMm: Float, hMm: Float): DiscFormat {
            val w = (wMm * 10f).toInt() / 10f
            val h = (hMm * 10f).toInt() / 10f
            return DiscFormat("PHOTO_${w}x${h}", "Фото", "Размер по картинке", w, h, 0f, w, h, false, true)
        }

        fun values(): List<DiscFormat> = listOf(DVD, DVD_SLIM, CD, BLURAY, PHOTO)

        fun valueOf(s: String): DiscFormat {
            // Форматы, созданные мастером, кодируют размеры в имени проекта.
            // Это сохраняет их совместимость без изменения схемы старых проектов.
            if (s.startsWith("CUSTOM_")) {
                val p = s.removePrefix("CUSTOM_").split("x")
                val w = p.getOrNull(0)?.toFloatOrNull()
                val h = p.getOrNull(1)?.toFloatOrNull()
                val spine = p.getOrNull(2)?.toFloatOrNull()
                if (w != null && h != null && w in 30f..600f && h in 30f..420f) {
                    if (spine == null) return photo(w, h).copy(name = s, title = "Своя обложка", subtitle = "Лицевая сторона")
                    if (spine in 0f..40f && w > spine) {
                        val panelW = (w - spine) / 2f
                        return DiscFormat(s, "Свой размер", "Пользовательский", panelW, h, spine, panelW, h, false)
                    }
                }
            }
            if (s.startsWith("FRONT_")) {
                val base = valueOf(s.removePrefix("FRONT_"))
                return base.copy(name = s, title = "${base.title} · лицо", subtitle = "Лицевая сторона",
                    spineW = 0f, backW = base.frontW, backH = base.frontH, photo = true)
            }
            if (s.startsWith("PHOTO_")) {
                val p = s.removePrefix("PHOTO_").split("x")
                val w = p.getOrNull(0)?.toFloatOrNull()
                val h = p.getOrNull(1)?.toFloatOrNull()
                if (w != null && h != null && w > 0f && h > 0f) return photo(w, h)
            }
            return values().firstOrNull { it.name == s } ?: DVD
        }
    }

    fun size(id: PanelId): Pair<Float, Float> = when (id) {
        PanelId.FRONT -> frontW to frontH
        PanelId.SPINE -> spineW to backH
        PanelId.BACK -> backW to backH
        PanelId.DISC -> DISC_SIZE_MM to DISC_SIZE_MM
    }

    /** Лист для печати на диске: один квадрат 120×120 мм. */
    fun discLayout(): SheetLayout = SheetLayout(
        listOf(Group(0f, 0f, DISC_SIZE_MM, DISC_SIZE_MM, emptyList())),
        listOf(Place(PanelId.DISC, 0f, 0f, DISC_SIZE_MM, DISC_SIZE_MM)),
        DISC_SIZE_MM, DISC_SIZE_MM
    )

    val specText: String
        get() = if (photo) "${fmt(frontW)}×${fmt(frontH)} мм" else if (tray)
            "Лицо ${fmt(frontW)}×${fmt(frontH)} · трей ${fmt(spineW * 2 + backW)}×${fmt(backH)} мм"
        else
            "${fmt(backW + spineW + frontW)}×${fmt(backH)} мм · корешок ${fmt(spineW)} мм"

    fun layout(): SheetLayout {
        if (photo) return SheetLayout(
            listOf(Group(0f, 0f, frontW, frontH, emptyList())),
            listOf(Place(PanelId.FRONT, 0f, 0f, frontW, frontH)), frontW, frontH
        )
        val h = maxOf(frontH, backH)
        if (!tray) {
            val w = backW + spineW + frontW
            val places = listOf(
                Place(PanelId.BACK, 0f, 0f, backW, backH),
                Place(PanelId.SPINE, backW, 0f, spineW, backH),
                Place(PanelId.FRONT, backW + spineW, 0f, frontW, frontH)
            )
            return SheetLayout(listOf(Group(0f, 0f, w, h, listOf(backW, backW + spineW))), places, w, h)
        }
        val trayW = spineW * 2 + backW
        val gap = 8f
        val ty = (h - backH) / 2f
        val fy = (h - frontH) / 2f
        val places = listOf(
            Place(PanelId.SPINE, 0f, ty, spineW, backH),
            Place(PanelId.BACK, spineW, ty, backW, backH),
            Place(PanelId.SPINE, spineW + backW, ty, spineW, backH),
            Place(PanelId.FRONT, trayW + gap, fy, frontW, frontH)
        )
        val groups = listOf(
            Group(0f, ty, trayW, backH, listOf(spineW, spineW + backW)),
            Group(trayW + gap, fy, frontW, frontH, emptyList())
        )
        return SheetLayout(groups, places, trayW + gap + frontW, h)
    }
}

val FrameNames = listOf("Нет", "Линия", "Двойная", "Скруглённая", "Пунктир", "Уголки", "Толстая+тонкая", "Внутренняя", "Овал", "Штрих-пунктир", "Тройная", "Боковые", "Угловая")

enum class Kind { TEXT, IMAGE, RECT, SYMBOL }

data class Layer(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val visible: Boolean = true,
    val locked: Boolean = false,
    val groupId: String = "",
    val kind: Kind = Kind.TEXT,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val rot: Float = 0f,
    val flipX: Boolean = false,
    val flipY: Boolean = false,
    val text: String = "",
    val sizeMm: Float = 10f,
    val color: Int = Color.WHITE,
    val font: Int = 0,
    val fontFile: String = "",
    val italic: Boolean = false,
    val upper: Boolean = false,
    val shadow: Boolean = false,
    val spacing: Float = 0f,
    /** Межстрочный интервал: множитель базовой высоты строки. */
    val lineSpacing: Float = 1.08f,
    /** Независимое масштабирование текста по осям. */
    val textScaleX: Float = 1f,
    val textScaleY: Float = 1f,
    /** Автоматически уменьшать кегль, чтобы текст поместился в заданную ширину блока. */
    val textAutoFit: Boolean = false,
    /** Изгиб одной строки по дуге в градусах; 0 — обычная строка. */
    val textArc: Float = 0f,
    val align: Int = 1,
    val boxMm: Float = 0f,
    val path: String = "",
    val widthMm: Float = 50f,
    val alpha: Float = 1f,
    /** Рамка вокруг объекта: 0 — нет, остальное см. [FrameNames]. */
    val frame: Int = 0,
    val frameColor: Int = Color.WHITE,
    /** Толщина и отступ рамки — доли размера объекта (см. [frameRef]), поэтому рамка растёт и сжимается вместе с ним. */
    val frameWidth: Float = 0.05f,
    val framePad: Float = 0.3f,
    /** Мягкость тени под текстом: 0 — чёткая, 1–3 — всё более размытая. */
    val textBlur: Int = 0,
    /** Сила тени под текстом (по контуру букв), 0–0.85. */
    val textShade: Float = 0f,
    /** Мягкий цветной ореол из размытой копии фото: 0 выкл., 1–3 сила. */
    val imageBlur: Int = 0,
    /** Доля ширины/высоты, на которой альфа плавно затухает у выбранных краёв фото. 0 — выкл. */
    val imageFade: Float = 0f,
    /** Битовая маска краёв: 1 слева, 2 справа, 4 сверху, 8 снизу; 15 — все стороны. */
    val imageFadeEdges: Int = 15,
    /** 0 — плавный линейный переход, 1 — органический неровный край. */
    val imageFadeStyle: Int = 0,
    /** Сила подмешивания цвета фона к переходным краям фотографии. */
    val imageFadeBlend: Float = 0f,
    /** Офлайн-очистка цветной каймы по RGB краевых пикселей PNG; альфа остаётся неизменной. */
    val imageEdgeClean: Float = 0f,
    /** Сила цветового Light Wrap по внутреннему краю PNG (0–1), локально и офлайн. */
    val imageLightWrap: Float = 0f,
    /** Локальная подсветка/затемнение внутреннего края (0–1). */
    val imageEdgeRelight: Float = 0f,
    /** Локальное затемнение внутренней кромки для согласования с тёмным окружением (0–1). */
    val imageEdgeShade: Float = 0f,
    /** Цвет Light Wrap; пользователь может подобрать его под окружение. */
    val imageWrapColor: Int = Color.WHITE,
    /** Авто-режим Light Wrap: цвет и направление света берутся из фона под слоем. */
    val imageWrapAuto: Boolean = false,
    /** Сжатие края PNG-вырезки (0–1): убирает остаточный светлый след по контуру. */
    val imageChoke: Float = 0f,
    /** Согласование цвета краевой зоны объекта с окружением (0–1). */
    val imageColorMatch: Float = 0f,
    /** Мягкая контактная тень под вырезанным PNG (0–1). */
    val imageContactShadow: Float = 0f,
    /** Обводка текста: ширина в долях кегля; 0 — выкл. */
    val textOutlineWidth: Float = 0f,
    val textOutlineColor: Int = Color.BLACK,
    /** Мягкое свечение текста: радиус в долях кегля; 0 — выкл. */
    val textGlowRadius: Float = 0f,
    val textGlowColor: Int = Color.WHITE,
    /** 0 — сплошной цвет, 1 — золото, 2 — серебро, 3 — лёд, 4 — обсидиан, 5 — мороз с трещинами, 6 — камень, 7 — ржавчина, 8 — лава. */
    val textMaterial: Int = 0,
    /** Декоративные линии по бокам текста («— 1982 —»): 0 — выкл., иначе длина линии (0–1). Цвет линий — цвет текста. */
    val textRules: Float = 0f,
    /** Цветокор фото: сдвиг оттенка (градусы), насыщенность, яркость, контраст, температура, перекраска в один цвет. */
    val imgHue: Float = 0f,
    val imgSat: Float = 1f,
    val imgBright: Float = 0f,
    val imgContrast: Float = 1f,
    val imgTemp: Float = 0f,
    val imgColorize: Float = 0f,
    val imgColorizeColor: Int = 0xFF2E6FD0.toInt()
) {
    val hasImageGrade: Boolean
        get() = kotlin.math.abs(imgHue) > 0.5f || kotlin.math.abs(imgSat - 1f) > 0.001f || kotlin.math.abs(imgBright) > 0.001f ||
            kotlin.math.abs(imgContrast - 1f) > 0.001f || kotlin.math.abs(imgTemp) > 0.001f || imgColorize > 0.001f

    /** Опорный размер объекта, мм: кегль у текста, ширина у картинки/значка, меньшая сторона у фигуры. */
    fun frameRef(): Float = when (kind) {
        Kind.TEXT -> sizeMm
        Kind.RECT -> minOf(widthMm, sizeMm)
        else -> widthMm
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("visible", visible); put("locked", locked); put("groupId", groupId); put("kind", kind.name)
        put("x", x.toDouble()); put("y", y.toDouble()); put("rot", rot.toDouble()); put("flipX", flipX); put("flipY", flipY)
        put("text", text); put("sizeMm", sizeMm.toDouble()); put("color", color)
        put("font", font); put("fontFile", fontFile); put("italic", italic); put("upper", upper); put("shadow", shadow)
        put("spacing", spacing.toDouble()); put("lineSpacing", lineSpacing.toDouble()); put("textScaleX", textScaleX.toDouble()); put("textScaleY", textScaleY.toDouble()); put("textAutoFit", textAutoFit); put("textArc", textArc.toDouble()); put("align", align); put("boxMm", boxMm.toDouble())
        put("path", path); put("widthMm", widthMm.toDouble()); put("alpha", alpha.toDouble())
        put("frame", frame); put("frameColor", frameColor)
        put("frameWidth", frameWidth.toDouble()); put("framePad", framePad.toDouble())
        put("textBlur", textBlur); put("textShade", textShade.toDouble()); put("imageBlur", imageBlur)
        put("imageFade", imageFade.toDouble()); put("imageFadeEdges", imageFadeEdges); put("imageFadeStyle", imageFadeStyle); put("imageFadeBlend", imageFadeBlend.toDouble()); put("imageEdgeClean", imageEdgeClean.toDouble()); put("imageLightWrap", imageLightWrap.toDouble()); put("imageEdgeRelight", imageEdgeRelight.toDouble()); put("imageEdgeShade", imageEdgeShade.toDouble()); put("imageWrapColor", imageWrapColor); put("imageWrapAuto", imageWrapAuto); put("imageChoke", imageChoke.toDouble()); put("imageColorMatch", imageColorMatch.toDouble()); put("imageContactShadow", imageContactShadow.toDouble())
        put("textOutlineWidth", textOutlineWidth.toDouble()); put("textOutlineColor", textOutlineColor)
        put("textGlowRadius", textGlowRadius.toDouble()); put("textGlowColor", textGlowColor)
        put("textMaterial", textMaterial); put("textRules", textRules.toDouble())
        put("imgHue", imgHue.toDouble()); put("imgSat", imgSat.toDouble()); put("imgBright", imgBright.toDouble())
        put("imgContrast", imgContrast.toDouble()); put("imgTemp", imgTemp.toDouble())
        put("imgColorize", imgColorize.toDouble()); put("imgColorizeColor", imgColorizeColor)
    }

    companion object {
        fun fromJson(o: JSONObject): Layer = fromJsonRaw(o).let { l ->
            // проекты со старой рамкой в миллиметрах переводим в доли размера
            if (!o.has("frameWidth") && o.has("frameWidthMm")) {
                val ref = l.frameRef().coerceAtLeast(0.1f)
                l.copy(frameWidth = (o.optDouble("frameWidthMm", 0.6).toFloat() / ref).coerceIn(0.005f, 0.15f),
                    framePad = (o.optDouble("framePadMm", 2.0).toFloat() / ref).coerceIn(0f, 0.6f))
            } else l
        }

        private fun fromJsonRaw(o: JSONObject) = Layer(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.optString("name", ""),
            visible = o.optBoolean("visible", true),
            locked = o.optBoolean("locked", false),
            groupId = o.optString("groupId", ""),
            kind = runCatching { Kind.valueOf(o.optString("kind", "TEXT")) }.getOrDefault(Kind.TEXT),
            x = o.optDouble("x", 0.5).toFloat(), y = o.optDouble("y", 0.5).toFloat(),
            rot = o.optDouble("rot", 0.0).toFloat(), flipX = o.optBoolean("flipX", false), flipY = o.optBoolean("flipY", false),
            text = o.optString("text", ""), sizeMm = o.optDouble("sizeMm", 10.0).toFloat(),
            color = o.optInt("color", Color.WHITE), font = o.optInt("font", 0), fontFile = o.optString("fontFile", ""),
            italic = o.optBoolean("italic", false), upper = o.optBoolean("upper", false),
            shadow = o.optBoolean("shadow", false), spacing = o.optDouble("spacing", 0.0).toFloat().coerceIn(0f, 0.5f),
            lineSpacing = o.optDouble("lineSpacing", 1.08).toFloat().coerceIn(0.8f, 2.5f),
            textScaleX = o.optDouble("textScaleX", 1.0).toFloat().coerceIn(0.5f, 2f),
            textScaleY = o.optDouble("textScaleY", 1.0).toFloat().coerceIn(0.5f, 2f),
            textAutoFit = o.optBoolean("textAutoFit", false),
            textArc = o.optDouble("textArc", 0.0).toFloat().coerceIn(-90f, 90f),
            align = o.optInt("align", 1), boxMm = o.optDouble("boxMm", 0.0).toFloat(),
            path = o.optString("path", ""), widthMm = o.optDouble("widthMm", 50.0).toFloat(),
            alpha = o.optDouble("alpha", 1.0).toFloat(),
            frame = o.optInt("frame", 0), frameColor = o.optInt("frameColor", Color.WHITE),
            frameWidth = o.optDouble("frameWidth", 0.05).toFloat(),
            framePad = o.optDouble("framePad", 0.3).toFloat(),
            textBlur = o.optInt("textBlur", 0).coerceIn(0, 3),
            // старые проекты: «блюр без затемнения» рисовал полупрозрачную подложку — сохраняем её вид
            textShade = o.optDouble("textShade", 0.0).toFloat().coerceIn(0f, 0.85f).let { sh ->
                if (sh <= 0f && o.optInt("textBlur", 0) > 0) 0.6f else sh
            },
            imageBlur = o.optInt("imageBlur", 0).coerceIn(0, 3),
            imageFade = o.optDouble("imageFade", 0.0).toFloat().coerceIn(0f, 0.45f),
            imageFadeEdges = o.optInt("imageFadeEdges", 15).coerceIn(1, 15),
            imageFadeStyle = o.optInt("imageFadeStyle", 0).coerceIn(0, 1),
            imageFadeBlend = o.optDouble("imageFadeBlend", 0.0).toFloat().coerceIn(0f, 1f),
            imageEdgeClean = o.optDouble("imageEdgeClean", 0.0).toFloat().coerceIn(0f, 1f),
            imageLightWrap = o.optDouble("imageLightWrap", 0.0).toFloat().coerceIn(0f, 1f),
            imageEdgeRelight = o.optDouble("imageEdgeRelight", 0.0).toFloat().coerceIn(0f, 1f),
            imageEdgeShade = o.optDouble("imageEdgeShade", 0.0).toFloat().coerceIn(0f, 1f),
            imageWrapColor = o.optInt("imageWrapColor", Color.WHITE),
            imageWrapAuto = o.optBoolean("imageWrapAuto", false),
            imageChoke = o.optDouble("imageChoke", 0.0).toFloat().coerceIn(0f, 1f),
            imageColorMatch = o.optDouble("imageColorMatch", 0.0).toFloat().coerceIn(0f, 1f),
            imageContactShadow = o.optDouble("imageContactShadow", 0.0).toFloat().coerceIn(0f, 1f),
            textOutlineWidth = o.optDouble("textOutlineWidth", 0.0).toFloat().coerceIn(0f, 0.18f),
            textOutlineColor = o.optInt("textOutlineColor", Color.BLACK),
            textGlowRadius = o.optDouble("textGlowRadius", 0.0).toFloat().coerceIn(0f, 0.5f),
            textGlowColor = o.optInt("textGlowColor", Color.WHITE),
            textMaterial = o.optInt("textMaterial", 0).coerceIn(0, TextMaterialNames.size - 1),
            textRules = o.optDouble("textRules", 0.0).toFloat().coerceIn(0f, 1f),
            imgHue = o.optDouble("imgHue", 0.0).toFloat().coerceIn(-180f, 180f),
            imgSat = o.optDouble("imgSat", 1.0).toFloat().coerceIn(0f, 2.5f),
            imgBright = o.optDouble("imgBright", 0.0).toFloat().coerceIn(-0.6f, 0.6f),
            imgContrast = o.optDouble("imgContrast", 1.0).toFloat().coerceIn(0.5f, 1.8f),
            imgTemp = o.optDouble("imgTemp", 0.0).toFloat().coerceIn(-1f, 1f),
            imgColorize = o.optDouble("imgColorize", 0.0).toFloat().coerceIn(0f, 1f),
            imgColorizeColor = o.optInt("imgColorizeColor", 0xFF2E6FD0.toInt())
        )
    }
}

data class PanelData(
    val c1: Int,
    val c2: Int,
    val angle: Int = 45,
    val layers: List<Layer> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("c1", c1); put("c2", c2); put("angle", angle)
        put("layers", JSONArray().also { a -> layers.forEach { a.put(it.toJson()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): PanelData {
            val arr = o.optJSONArray("layers") ?: JSONArray()
            val ls = (0 until arr.length()).map { Layer.fromJson(arr.getJSONObject(it)) }
            return PanelData(o.optInt("c1", Color.BLACK), o.optInt("c2", Color.BLACK), o.optInt("angle", 45), ls)
        }
    }
}

data class Project(
    val id: String,
    val name: String,
    val format: DiscFormat,
    val panels: Map<PanelId, PanelData>,
    val updated: Long,
    val foldShadow: Boolean = true,
    /** Общие слои всего разворота: координаты и размеры заданы относительно единого холста. */
    val canvasLayers: List<Layer> = emptyList(),
    /** Атмосфера всего разворота: цветокор, виньетка, снег, зерно. */
    val fx: Fx = Fx(),
    /** Избранный проект (главный экран). */
    val favorite: Boolean = false,
    /** Время последнего открытия (0 — ещё не открывался). */
    val opened: Long = 0L,
    /** Показывать безопасную зону при открытии редактора. */
    val showSafeZone: Boolean = true
) {
    fun panel(id: PanelId): PanelData = panels[id] ?: PanelData(Color.BLACK, Color.BLACK)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("format", format.name); put("updated", updated); put("foldShadow", foldShadow)
        put("favorite", favorite); put("opened", opened); put("showSafeZone", showSafeZone)
        put("panels", JSONObject().also { o -> panels.forEach { (k, v) -> o.put(k.name, v.toJson()) } })
        put("canvasLayers", JSONArray().also { a -> canvasLayers.forEach { a.put(it.toJson()) } })
        put("fx", fx.toJson())
    }

    fun imagePaths(): Set<String> =
        (panels.values.flatMap { it.layers } + canvasLayers).filter { it.kind == Kind.IMAGE }.map { it.path }.toSet()

    companion object {
        fun fromJson(o: JSONObject): Project {
            val po = o.getJSONObject("panels")
            val map = PanelId.values().associateWith { pid ->
                po.optJSONObject(pid.name)?.let { PanelData.fromJson(it) } ?: PanelData(Color.BLACK, Color.BLACK)
            }
            return Project(
                o.getString("id"), o.optString("name", "Проект"),
                DiscFormat.valueOf(o.getString("format")), map, o.optLong("updated", 0L),
                o.optBoolean("foldShadow", true),
                (o.optJSONArray("canvasLayers") ?: JSONArray()).let { a ->
                    (0 until a.length()).mapNotNull { i -> runCatching { Layer.fromJson(a.getJSONObject(i)) }.getOrNull() }
                },
                Fx.fromJson(o.optJSONObject("fx")),
                o.optBoolean("favorite", false), o.optLong("opened", 0L), o.optBoolean("showSafeZone", true)
            )
        }
    }
}

class GradientPreset(val name: String, val c1: Int, val c2: Int, val angle: Int)

val GradientPresets = listOf(
    GradientPreset("Ночь", 0xFF0F0C29.toInt(), 0xFF302B63.toInt(), 60),
    GradientPreset("Закат", 0xFFFF512F.toInt(), 0xFFDD2476.toInt(), 45),
    GradientPreset("Океан", 0xFF2193B0.toInt(), 0xFF6DD5ED.toInt(), 45),
    GradientPreset("Неон", 0xFF8E2DE2.toInt(), 0xFF4A00E0.toInt(), 60),
    GradientPreset("Золото", 0xFFF7971E.toInt(), 0xFFFFD200.toInt(), 45),
    GradientPreset("Лес", 0xFF134E5E.toInt(), 0xFF71B280.toInt(), 60),
    GradientPreset("Мята", 0xFF11998E.toInt(), 0xFF38EF7D.toInt(), 45),
    GradientPreset("Рубин", 0xFFCB2D3E.toInt(), 0xFFEF473A.toInt(), 60),
    GradientPreset("Королевский", 0xFF1A2980.toInt(), 0xFF26D0CE.toInt(), 45),
    GradientPreset("Уголь", 0xFF232526.toInt(), 0xFF414345.toInt(), 80),
    GradientPreset("Чёрный", 0xFF000000.toInt(), 0xFF111111.toInt(), 45),
    GradientPreset("Лёд", 0xFFE0EAFC.toInt(), 0xFFCFDEF3.toInt(), 60),
    GradientPreset("Белый", 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0)
)

val TextPalette = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFB547.toInt(), 0xFFFF4D8D.toInt(),
    0xFF8B6CFF.toInt(), 0xFF38BDF8.toInt(), 0xFF34D399.toInt(), 0xFFEF4444.toInt(),
    0xFFFACC15.toInt(), 0xFFE5E7EB.toInt(), 0xFF9CA3AF.toInt(), 0xFF1F2937.toInt()
)

/** Новый проект: чистые панели без заготовленных названий и заголовков — только фон по умолчанию. */
fun newProject(format: DiscFormat, name: String): Project {
    val pr = GradientPresets[0]
    fun bg() = PanelData(pr.c1, pr.c2, pr.angle)
    return Project(
        UUID.randomUUID().toString(), name, format,
        mapOf(PanelId.FRONT to bg(), PanelId.SPINE to bg(), PanelId.BACK to bg(), PanelId.DISC to bg()),
        System.currentTimeMillis()
    )
}
