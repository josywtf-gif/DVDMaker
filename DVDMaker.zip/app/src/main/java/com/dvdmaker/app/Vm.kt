package com.dvdmaker.app

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

class AppVm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    var projects by mutableStateOf(store.loadAll())
    var current by mutableStateOf<Project?>(null)
    var panel by mutableStateOf(PanelId.FRONT)
    var overview by mutableStateOf(false)
    var selected by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)

    var update by mutableStateOf<UpdateInfo?>(null)
    var checking by mutableStateOf(false)
    var progress by mutableStateOf<Float?>(null)
    var updateMsg by mutableStateOf<String?>(null)

    private val undo = ArrayList<Project>()
    private var lastKey = ""
    private var lastEdit = 0L
    private var saveJob: Job? = null

    fun create(format: DiscFormat) {
        val p = newProject(format, "Новый ${format.title}")
        store.save(p)
        projects = store.loadAll()
        enter(p)
    }

    fun open(p: Project) = enter(p)

    private fun enter(p: Project) {
        current = p; panel = PanelId.FRONT; overview = false; selected = null
        undo.clear(); canUndo = false; lastKey = ""
    }

    fun close() {
        flush()
        current = null
        selected = null
        projects = store.loadAll()
    }

    fun delete(p: Project) {
        store.delete(p)
        projects = store.loadAll()
    }

    fun flush() {
        saveJob?.cancel()
        current?.let { store.save(it) }
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(500)
            current?.let { p -> withContext(Dispatchers.IO) { store.save(p) } }
        }
    }

    fun edit(key: String = "", block: (Project) -> Project) {
        val p = current ?: return
        val now = SystemClock.elapsedRealtime()
        if (key.isEmpty() || key != lastKey || now - lastEdit > 1200) {
            undo.add(p)
            if (undo.size > 40) undo.removeAt(0)
            canUndo = true
        }
        lastKey = key
        lastEdit = now
        current = block(p).copy(updated = System.currentTimeMillis())
        scheduleSave()
    }

    fun undoLast() {
        if (undo.isEmpty()) return
        current = undo.removeAt(undo.lastIndex)
        canUndo = undo.isNotEmpty()
        lastKey = ""
        val p = current
        if (p != null && selected != null &&
            p.panel(panel).layers.none { it.id == selected }) selected = null
        scheduleSave()
    }

    fun rename(name: String) = edit { it.copy(name = name.ifBlank { it.name }) }

    fun updatePanel(id: PanelId, key: String = "", f: (PanelData) -> PanelData) =
        edit(key) { p -> p.copy(panels = p.panels + (id to f(p.panel(id)))) }

    fun updateLayer(layerId: String, key: String = "", f: (Layer) -> Layer) =
        updatePanel(panel, key) { pd ->
            pd.copy(layers = pd.layers.map { if (it.id == layerId) f(it) else it })
        }

    fun addLayer(l: Layer) {
        updatePanel(panel) { it.copy(layers = it.layers + l) }
        selected = l.id
    }

    fun addText() {
        val p = current ?: return
        val (w, h) = p.format.size(panel)
        val spine = panel == PanelId.SPINE
        addLayer(
            Layer(
                kind = Kind.TEXT, text = "Текст",
                sizeMm = if (spine) minOf(w * 0.55f, 7f) else 9f,
                font = 0, rot = if (spine) 90f else 0f
            )
        )
    }

    fun addRect() {
        val p = current ?: return
        val (w, _) = p.format.size(panel)
        addLayer(Layer(kind = Kind.RECT, widthMm = w * 0.6f, sizeMm = 8f, color = 0xFFFFB547.toInt()))
    }

    fun removeSelected() {
        val id = selected ?: return
        updatePanel(panel) { it.copy(layers = it.layers.filter { l -> l.id != id }) }
        selected = null
    }

    fun duplicateSelected() {
        val id = selected ?: return
        val src = current?.panel(panel)?.layers?.firstOrNull { it.id == id } ?: return
        addLayer(src.copy(id = java.util.UUID.randomUUID().toString(),
            x = (src.x + 0.05f).coerceAtMost(0.95f), y = (src.y + 0.05f).coerceAtMost(0.95f)))
    }

    fun moveSelected(up: Boolean) {
        val id = selected ?: return
        updatePanel(panel) { pd ->
            val list = pd.layers.toMutableList()
            val i = list.indexOfFirst { it.id == id }
            val j = if (up) i + 1 else i - 1
            if (i >= 0 && j in list.indices) {
                val t = list[i]; list[i] = list[j]; list[j] = t
            }
            pd.copy(layers = list)
        }
    }

    fun transform(id: String, pan: Offset, zoom: Float, rot: Float, cw: Float, ch: Float) {
        updateLayer(id, "g$id") { l ->
            val nl = l.copy(
                x = (l.x + pan.x / cw).coerceIn(-0.2f, 1.2f),
                y = (l.y + pan.y / ch).coerceIn(-0.2f, 1.2f),
                rot = l.rot + rot
            )
            when (l.kind) {
                Kind.TEXT -> nl.copy(sizeMm = (l.sizeMm * zoom).coerceIn(1f, 120f))
                Kind.IMAGE -> nl.copy(widthMm = (l.widthMm * zoom).coerceIn(2f, 900f))
                Kind.RECT -> nl.copy(
                    widthMm = (l.widthMm * zoom).coerceIn(0.5f, 900f),
                    sizeMm = (l.sizeMm * zoom).coerceIn(0.3f, 900f)
                )
            }
        }
    }

    fun addImage(uri: Uri, asBackground: Boolean) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { store.importImage(uri) } ?: return@launch
            val p = current ?: return@launch
            val (pw, ph) = p.format.size(panel)
            val b = Bitmaps.get(path)
            val aspect = if (b != null) b.width.toFloat() / b.height else 1f
            val w = if (asBackground) max(pw, ph * aspect) else minOf(pw * 0.7f, ph * 0.7f * aspect)
            addLayer(Layer(kind = Kind.IMAGE, path = path, widthMm = w))
        }
    }

    fun fillSelected(cover: Boolean) {
        val id = selected ?: return
        val p = current ?: return
        val l = p.panel(panel).layers.firstOrNull { it.id == id } ?: return
        val b = Bitmaps.get(l.path) ?: return
        val (pw, ph) = p.format.size(panel)
        val aspect = b.width.toFloat() / b.height
        val w = if (cover) max(pw, ph * aspect) else minOf(pw, ph * aspect)
        updateLayer(id) { it.copy(widthMm = w, x = 0.5f, y = 0.5f, rot = 0f) }
    }

    fun checkUpdate(manual: Boolean) {
        if (checking) return
        viewModelScope.launch {
            checking = true
            if (manual) updateMsg = null
            val u = Updater.check()
            update = u
            if (manual) updateMsg = if (u == null) "У вас последняя версия" else null
            checking = false
        }
    }

    fun downloadAndInstall() {
        val u = update ?: return
        if (progress != null) return
        viewModelScope.launch {
            progress = 0f
            updateMsg = null
            val f = Updater.download(getApplication(), u) { progress = it }
            progress = null
            if (f == null) {
                updateMsg = "Не удалось скачать обновление"
            } else if (!Updater.install(getApplication(), f)) {
                updateMsg = "Разрешите установку из этого источника и нажмите «Обновить» ещё раз"
            }
        }
    }
}
