package com.dvdmaker.app

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

class AppVm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    var projects by mutableStateOf(store.loadAll())
    var current by mutableStateOf<Project?>(null)
    var panel by mutableStateOf(PanelId.FRONT)
    var overview by mutableStateOf(false)
    var selected by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)
    var checker by mutableStateOf(false)

    var update by mutableStateOf<UpdateInfo?>(null)
    var checking by mutableStateOf(false)
    var progress by mutableStateOf<Float?>(null)
    var updateMsg by mutableStateOf<String?>(null)

    private val undo = ArrayList<Project>()
    private var lastKey = ""
    private var lastEdit = 0L
    private var saveJob: Job? = null

    fun create(format: DiscFormat) {
        val p = newProject(format, "Новый ${format.title}")
        store.save(p)
        projects = store.loadAll()
        enter(p)
    }

    fun open(p: Project) = enter(p)

    /** Создаёт проект из готового Project (например, после подгонки готовой обложки) и открывает его. */
    fun createFrom(p: Project) {
        store.save(p)
        projects = store.loadAll()
        checker = false
        enter(p)
    }

    fun toggleFoldShadow() = edit { it.copy(foldShadow = !it.foldShadow) }

    /** Диск: берёт фон и главное изображение с лицевой стороны и подгоняет под круг диска. */
    fun discFromFront() {
        val p = current ?: return
        val front = p.panel(PanelId.FRONT)
        val img = front.layers.firstOrNull { it.kind == Kind.IMAGE }
        updatePanel(PanelId.DISC) { d ->
            var nd = d.copy(c1 = front.c1, c2 = front.c2, angle = front.angle)
            if (img != null) {
                val b = Bitmaps.get(img.path)
                val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                val layer = img.copy(
                    id = java.util.UUID.randomUUID().toString(),
                    x = 0.5f, y = 0.5f, rot = 0f, alpha = 1f,
                    widthMm = max(DISC_SIZE_MM, DISC_SIZE_MM * aspect)
                )
                nd = nd.copy(layers = listOf(layer) + nd.layers.filter { it.kind != Kind.IMAGE })
            }
            nd
        }
        selected = null
    }

    private fun enter(p: Project) {
        current = p; panel = PanelId.FRONT; overview = false; selected = null
        undo.clear(); canUndo = false; lastKey = ""
    }

    fun close() {
        flush()
        current = null
        selected = null
        projects = store.loadAll()
    }

    fun delete(p: Project) {
        store.delete(p)
        projects = store.loadAll()
    }

    fun flush() {
        saveJob?.cancel()
        current?.let { store.save(it) }
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(500)
            current?.let { p -> withContext(Dispatchers.IO) { store.save(p) } }
        }
    }

    fun edit(key: String = "", block: (Project) -> Project) {
        val p = current ?: return
        val now = SystemClock.elapsedRealtime()
        if (key.isEmpty() || key != lastKey || now - lastEdit > 1200) {
            undo.add(p)
            if (undo.size > 40) undo.removeAt(0)
            canUndo = true
        }
        lastKey = key
        lastEdit = now
        current = block(p).copy(updated = System.currentTimeMillis())
        scheduleSave()
    }

    fun undoLast() {
        if (undo.isEmpty()) return
        current = undo.removeAt(undo.lastIndex)
        canUndo = undo.isNotEmpty()
        lastKey = ""
        val p = current
        if (p != null && selected != null &&
            p.panel(panel).layers.none { it.id == selected }) selected = null
        scheduleSave()
    }

    fun rename(name: String) = edit { it.copy(name = name.ifBlank { it.name }) }

    fun updatePanel(id: PanelId, key: String = "", f: (PanelData) -> PanelData) =
        edit(key) { p -> p.copy(panels = p.panels + (id to f(p.panel(id)))) }

    fun updateLayer(layerId: String, key: String = "", f: (Layer) -> Layer) =
        updatePanel(panel, key) { pd ->
            pd.copy(layers = pd.layers.map { if (it.id == layerId) f(it) else it })
        }

    fun addLayer(l: Layer) {
        updatePanel(panel) { it.copy(layers = it.layers + l) }
        selected = l.id
    }

    fun addText() {
        val p = current ?: return
        val (w, h) = p.format.size(panel)
        val spine = panel == PanelId.SPINE
        addLayer(
            Layer(
                kind = Kind.TEXT, text = "Текст",
                sizeMm = if (spine) minOf(w * 0.55f, 7f) else 9f,
                font = 0, rot = if (spine) 90f else 0f
            )
        )
    }

    fun addRect() {
        val p = current ?: return
        val (w, _) = p.format.size(panel)
        addLayer(Layer(kind = Kind.RECT, widthMm = w * 0.6f, sizeMm = 8f, color = 0xFFFFB547.toInt()))
    }

    fun removeSelected() {
        val id = selected ?: return
        updatePanel(panel) { it.copy(layers = it.layers.filter { l -> l.id != id }) }
        selected = null
    }

    fun duplicateSelected() {
        val id = selected ?: return
        val src = current?.panel(panel)?.layers?.firstOrNull { it.id == id } ?: return
        addLayer(src.copy(id = java.util.UUID.randomUUID().toString(),
            x = (src.x + 0.05f).coerceAtMost(0.95f), y = (src.y + 0.05f).coerceAtMost(0.95f)))
    }

    fun moveSelected(up: Boolean) {
        val id = selected ?: return
        updatePanel(panel) { pd ->
            val list = pd.layers.toMutableList()
            val i = list.indexOfFirst { it.id == id }
            val j = if (up) i + 1 else i - 1
            if (i >= 0 && j in list.indices) {
                val t = list[i]; list[i] = list[j]; list[j] = t
            }
            pd.copy(layers = list)
        }
    }

    fun transform(id: String, pan: Offset, zoom: Float, rot: Float, cw: Float, ch: Float) {
        updateLayer(id, "g$id") { l ->
            val rawX = (l.x + pan.x / cw).coerceIn(-0.2f, 1.2f)
            val rawY = (l.y + pan.y / ch).coerceIn(-0.2f, 1.2f)
            fun align(v: Float): Float = listOf(0.05f, 0.5f, 0.95f).minByOrNull { kotlin.math.abs(v - it) }
                ?.let { if (kotlin.math.abs(v - it) <= 0.0035f) it else v } ?: v
            val nl = l.copy(
                x = align(rawX),
                y = align(rawY),
                rot = run {
                    val raw = l.rot + rot
                    val snap = listOf(0f, 90f, -90f, 180f, -180f).minByOrNull { kotlin.math.abs((((raw - it + 180f) % 360f + 360f) % 360f) - 180f) }
                    if (snap != null && kotlin.math.abs((((raw - snap + 180f) % 360f + 360f) % 360f) - 180f) <= 1.2f) snap else raw
                }
            )
            when (l.kind) {
                Kind.TEXT -> nl.copy(sizeMm = (l.sizeMm * zoom).coerceIn(1f, 120f))
                Kind.IMAGE -> nl.copy(widthMm = (l.widthMm * zoom).coerceIn(2f, 900f))
                Kind.RECT -> nl.copy(
                    widthMm = (l.widthMm * zoom).coerceIn(0.5f, 900f),
                    sizeMm = (l.sizeMm * zoom).coerceIn(0.3f, 900f)
                )
                Kind.SYMBOL -> nl.copy(widthMm = (l.widthMm * zoom).coerceIn(4f, 900f))
            }
        }
    }

    fun addSpecialSymbol(symbol: String) {
        val p = current ?: return
        val spine = panel == PanelId.SPINE
        addLayer(Layer(kind = Kind.SYMBOL, text = symbol, widthMm = if (spine) 7f else 42f,
            rot = if (spine) 90f else 0f, color = 0xFFFFFFFF.toInt()))
    }

    /** Аккуратно подгоняет уже добавленные изображения и текст, не удаляя слои. */
    fun autoFitAll() {
        val p = current ?: return
        val fallbackImage = p.panels.values.asSequence().flatMap { it.layers.asSequence() }
            .firstOrNull { it.kind == Kind.IMAGE }
        val panels = p.panels.mapValues { (id, data) ->
            val (w, h) = p.format.size(id)
            var firstImage = true
            val sourceLayers = if (data.layers.none { it.kind == Kind.IMAGE } && fallbackImage != null) {
                val b = Bitmaps.get(fallbackImage.path)
                val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                val coverW = max(w, h * aspect)
                data.layers + fallbackImage.copy(id = java.util.UUID.randomUUID().toString(),
                    x = 0.5f, y = 0.5f, widthMm = coverW, rot = 0f)
            } else data.layers
            val fitted = sourceLayers.map { layer ->
                when (layer.kind) {
                    Kind.IMAGE -> {
                        if (!firstImage) layer.copy(x = layer.x.coerceIn(0.05f, 0.95f), y = layer.y.coerceIn(0.05f, 0.95f))
                        else {
                            firstImage = false
                            val b = Bitmaps.get(layer.path)
                            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                            val coverW = max(w, h * aspect)
                            layer.copy(x = 0.5f, y = 0.5f, widthMm = coverW, rot = 0f)
                        }
                    }
                    Kind.TEXT -> layer.copy(
                        x = layer.x.coerceIn(0.08f, 0.92f), y = layer.y.coerceIn(0.08f, 0.92f),
                        rot = run { val r = (((layer.rot + 180f) % 360f + 360f) % 360f) - 180f; if (kotlin.math.abs(r) <= 3.5f) 0f else r }
                    )
                    Kind.RECT, Kind.SYMBOL -> layer.copy(x = layer.x.coerceIn(0.05f, 0.95f), y = layer.y.coerceIn(0.05f, 0.95f))
                }
            }
            data.copy(layers = fitted)
        }
        edit("auto-fit") { it.copy(panels = panels) }
        selected = null
    }

    fun addImage(uri: Uri, asBackground: Boolean) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { store.importImage(uri) } ?: return@launch
            val p = current ?: return@launch
            val (pw, ph) = p.format.size(panel)
            val b = Bitmaps.get(path)
            val aspect = if (b != null) b.width.toFloat() / b.height else 1f
            val w = if (asBackground) max(pw, ph * aspect) else minOf(pw * 0.7f, ph * 0.7f * aspect)
            addLayer(Layer(kind = Kind.IMAGE, path = path, widthMm = w))
        }
    }

    fun fillSelected(cover: Boolean) {
        val id = selected ?: return
        val p = current ?: return
        val l = p.panel(panel).layers.firstOrNull { it.id == id } ?: return
        val b = Bitmaps.get(l.path) ?: return
        val (pw, ph) = p.format.size(panel)
        val aspect = b.width.toFloat() / b.height
        val w = if (cover) max(pw, ph * aspect) else minOf(pw, ph * aspect)
        updateLayer(id) { it.copy(widthMm = w, x = 0.5f, y = 0.5f, rot = 0f) }
    }

    fun checkUpdate(manual: Boolean) {
        if (checking) return
        viewModelScope.launch {
            checking = true
            if (manual) updateMsg = null
            val u = Updater.check()
            update = u
            if (manual) updateMsg = if (u == null) "У вас последняя версия" else null
            checking = false
        }
    }

    fun downloadAndInstall() {
        val u = update ?: return
        if (progress != null) return
        viewModelScope.launch {
            progress = 0f
            updateMsg = null
            val f = Updater.download(getApplication(), u) { progress = it }
            progress = null
            if (f == null) {
                updateMsg = "Не удалось скачать обновление"
            } else if (!Updater.install(getApplication(), f)) {
                updateMsg = "Разрешите установку из этого источника и нажмите «Обновить» ещё раз"
            }
        }
    }
}
