package com.dvdmaker.app

import androidx.compose.foundation.layout.Box
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.Typography
import androidx.compose.material3.Shapes
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Bg = Color(0xFF121212)
val Card = Color(0xFF1E1E1E)
val Card2 = Color(0xFF2A2A2A)
// «Violet» — основной акцент (теперь жёлтый, как в Snapseed); имя сохранено, чтобы не переписывать весь код
val Violet = Color(0xFFF2BE3F)
val Pink = Color(0xFFE8903A)
val Amber = Color(0xFFFFB547)
val Dim = Color(0xFFB0B0B0)
val Line = Color(0xFF3A3A3A)

val BrandBrush = Brush.linearGradient(listOf(Violet, Pink))
val GoldBrush = Brush.linearGradient(listOf(Amber, Pink))

@Composable
fun DVDMakerTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Violet, onPrimary = Color.Black,
        secondary = Amber, onSecondary = Color.Black,
        background = Bg, onBackground = Color(0xFFEDEEFA),
        surface = Card, onSurface = Color(0xFFEDEEFA),
        surfaceVariant = Card2, onSurfaceVariant = Dim,
        outline = Line, error = Color(0xFFFF6B6B)
    )
    val typo = Typography(
        displaySmall = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold),
        headlineSmall = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
        titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
        titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
        titleSmall = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
        bodyLarge = TextStyle(fontSize = 15.sp),
        bodyMedium = TextStyle(fontSize = 14.sp),
        bodySmall = TextStyle(fontSize = 12.sp),
        labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
        labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
        labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium)
    )
    val shapes = Shapes(
        extraSmall = RoundedCornerShape(8.dp),
        small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(16.dp),
        large = RoundedCornerShape(20.dp),
        extraLarge = RoundedCornerShape(24.dp)
    )
    MaterialTheme(colorScheme = scheme, typography = typo, shapes = shapes) {
        CompositionLocalProvider(LocalContentColor provides Color(0xFFEDEEFA)) { content() }
    }
}
