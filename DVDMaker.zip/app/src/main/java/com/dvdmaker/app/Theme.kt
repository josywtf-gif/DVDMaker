package com.dvdmaker.app

import androidx.compose.foundation.layout.Box
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Bg = Color(0xFF0B0D1A)
val Card = Color(0xFF14172B)
val Card2 = Color(0xFF1C2038)
val Violet = Color(0xFF8B6CFF)
val Pink = Color(0xFFFF4D8D)
val Amber = Color(0xFFFFB547)
val Dim = Color(0xFF9AA0C0)
val Line = Color(0xFF2A2F4D)

val BrandBrush = Brush.linearGradient(listOf(Violet, Pink))
val GoldBrush = Brush.linearGradient(listOf(Amber, Pink))

@Composable
fun DVDMakerTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Violet, onPrimary = Color.White,
        secondary = Amber, onSecondary = Color.Black,
        background = Bg, onBackground = Color(0xFFEDEEFA),
        surface = Card, onSurface = Color(0xFFEDEEFA),
        surfaceVariant = Card2, onSurfaceVariant = Dim,
        outline = Line, error = Color(0xFFFF6B6B)
    )
    val typo = Typography(
        titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
        titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
        bodyMedium = TextStyle(fontSize = 14.sp),
        bodySmall = TextStyle(fontSize = 12.sp),
        labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    )
    MaterialTheme(colorScheme = scheme, typography = typo, content = content)
}
