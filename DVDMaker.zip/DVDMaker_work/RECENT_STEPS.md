## 1. 2026-11-18 — Stage 72: resume, дисковые миниатюры, актуальный ObjectOutline и компактная панель Photo Editor
- **Файлы:** `Update.kt`, `Home.kt`, `Outline.kt`, `Editor.kt`, `PhotoEditor.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** APK downloader продолжает `.part` через HTTP Range, не дописывает ответ сервера `200 OK` поверх частичного файла, проверяет размер и SHA-256, если GitHub Release asset публикует digest. Home thumbnail теперь имеет дисковый JPEG-кэш; старое изображение проекта можно показать сразу, новая версия рендерится в фоне. LazyVerticalGrid уже обеспечивает lazy-композицию карточек. ObjectOutline получает fingerprint только актуального `previewBitmap`, `sel.path` больше не влияет на кэш. PhotoEditor использует один компактный ряд инструментов и короткую полупрозрачную панель параметров; редактирование по-прежнему получает bitmap выбранного image-layer отдельно от фона композиции.
- **Проверки:** статическая сверка вызовов/сигнатур и файлов. Сборка/Android-тесты не запускались: Gradle Wrapper, системный Gradle и Android SDK отсутствуют.
- **Ограничения:** resume для APK реализован; отдельного контент/модель загрузчика в перечисленных целевых файлах не найдено. SHA-256 проверяется при наличии digest в GitHub asset metadata; если сервер digest не публикует, применяется проверка полной длины ответа. На устройстве требуется проверить сворачивание/возврат во время загрузки, холодный запуск Home и визуальный размер фото на разных экранах. P1.12 Blur не начинался.

## 1. 2026-11-18 — Переименование инструмента Photo Editor
- **Файл:** `app/src/main/java/com/dvdmaker/app/Tools.kt`.
- **Изменение:** подпись инструмента `IMAGE_EDIT` в панели инструментов изменена с «Редактор фото» на «Редактировать». Поведение и иконка не менялись.
- **Проверка:** совпадение старой подписи в исходниках проверено; автоматическая сборка не запускалась.

## 1. 2026-11-18 — Stage 70: четырёхточечная перспективная ректификация
- **Файлы:** `PhotoEditor.kt`, `ImageOperationRenderer.kt`, `PhotoEditorStage63Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** в полноэкранном редакторе добавлен режим четырёх точек с оранжевыми маркерами, перетаскиванием TL/TR/BR/BL, перспективной сеткой и подтверждением «Выправить». Координаты включены в локальные Undo/Redo и сохраняются как `perspectiveQuad` в stable geometry operation. Ordered Executor применяет гомографию через `Matrix.setPolyToPoly()` к текущему bitmap, выводит выровненный прямоугольник, сохраняет alpha и отклоняет вырожденные/пересекающиеся четырёхугольники и чрезмерные размеры. Preview/Export используют один geometry executor.
- **Проверки:** исходники и связи проверены статически; добавлены Android instrumentation-тесты хранения quad, warp и crossed-corners rejection. Сборка/тесты не запускались: Gradle Wrapper, системный Gradle и Android SDK отсутствуют в среде.
- **Ограничения:** качество на реальных фото, Preview/Export pixel parity, сочетания с crop/rotation/flip и сенсорная проверка на устройстве не подтверждены.

## 1. 2026-11-18 — Stage 68: локальная Undo/Redo история полноэкранного Photo Editor (P1.11)
- **Файлы:** `PhotoEditor.kt`, `PhotoEditorStage63Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** добавлен immutable `PhotoEditorDraftState` и ограниченная история до 50 шагов. Undo/Redo восстанавливают crop, произвольный/четверть-поворот, перспективу по двум осям, flip X/Y, zoom и pan. После Undo новая правка отсекает redo-ветку. Слайдеры фиксируют обновлённые значения, reset — один checkpoint, drag/pinch — один checkpoint после завершения жеста. Все правки остаются локальным preview draft; Save по-прежнему делает один `vm.updateLayer()` commit, Back/Cancel не меняет проект. Добавлены проверки истории, ветвления и ограничения размера.
- **Проверки:** исходники и вызовы сверены статически; тесты и сборка не запускались (нет Gradle Wrapper/системного Gradle/Android SDK).
- **Ограничения:** требуется ручная проверка на устройстве, особенно частых slider callbacks, drag+pinch и отмены выхода; глобальный Undo после Save должен откатывать весь Photo Editor одним шагом.

## 1. 2026-11-18 — Stage 67: зеркалирование, четверть-повороты и сетка перспективы
- **Файлы:** `PhotoEditor.kt`, `PhotoEditorStage63Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** добавлены кнопки поворота −90°/+90° с циклическим переходом в пределах −180…+180°; горизонтальное и вертикальное зеркалирование с preview и сохранением через `Layer.flipX/flipY` (переключатели применяют XOR к исходным значениям слоя); в режиме перспективы поверх фотографии отображается оранжевая рамка и сетка 3×3, использующая те же масштаб, смещение, поворот, зеркала и наклон, что и фото. Существующие произвольный поворот и два независимых ползунка перспективы сохранены; кадрирование остаётся отдельным режимом.
- **Проверки:** добавлены instrumentation-тесты для независимых зеркал и wrap-around четверть-поворота; статически сверены поля `Layer.flipX/flipY`, legacy geometry projection и `ImageOperationRenderer.applyGeometryValues()`.
- **Ограничения:** Gradle Wrapper, системный Gradle и Android SDK отсутствуют в рабочей среде; сборка и Android-тесты не запускались. Preview/final-render parity, перспективная сетка на разных aspect ratio и координаты эффектов после сочетаний требуют проверки на устройстве.
- **Следующий шаг:** собрать `assembleDebug` и `connectedDebugAndroidTest` в Android CI/локальной среде; на устройстве проверить rotate→mirror→perspective→crop и обратный порядок, затем продолжить P1.11 (draft/commit/Undo для всей сессии редактора).

## 1. 2026-11-18 — Stage 66: независимые поворот и кадрирование + двухосевая перспектива
- **Файлы:** `PhotoEditor.kt`, `PhotoEditorStage63Test.kt`, `PROJECT_MAP.md`, `RECENT_STEPS.md`.
- **Изменения:** поворот и перспектива переведены в отдельный режим трансформации; рамка кадрирования и её жесты больше не вращаются вместе с фото. Добавлены два регулятора перспективы: вверх/вниз (`imageTiltX`) и влево/вправо (`imageTiltY`), оба ±65°, с preview через Compose 3D transform и сохранением в существующие поля `Layer`, которые уже исполняются `ImageOperationRenderer` через Android Camera. Добавлен единый commit-helper, сохраняющий crop и geometry раздельно.
- **Проверки:** добавлены instrumentation-тесты независимого хранения crop/rotation/tilt и ограничения перспективы; не запускались. Статическая проверка исходников выполнена.
- **Ограничения:** сборка и визуальная проверка preview-vs-render на устройстве не выполнялись (в среде нет Gradle Wrapper, Gradle и Android SDK).

## 1. 2026-11-18 — Stage 65: оранжевый Photo Editor и актуальный контур объекта
- **Файлы:** `PhotoEditor.kt`, `Components.kt`, `Editor.kt`, `Outline.kt`, `ObjectOutlineStage65Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** Photo Editor приближен к референсу: чёрный холст, оранжевый акцент, оранжевая кнопка сохранения и ползунок, плавающая панель быстрых действий, нижняя панель инструментов; добавлен preview произвольного поворота −180…+180° с синхронным overlay и преобразованием координат жестов; при сохранении угол добавляется к `Layer.rot`. Исправлено устаревание пунктирного контура: cache key `ObjectOutline` учитывает fingerprint фактического bitmap, `Editor.kt` запрашивает контур по текущему preview bitmap/path; непрозрачное изображение использует обычную рамку.
- **Проверки:** исходники/вызовы проверены статически; добавлен Android instrumentation-тест смены alpha-силуэта при одинаковом пути и тест opaque bitmap. Сборка и тесты не запускались: в среде нет Gradle Wrapper, системного Gradle и Android SDK.
- **Ограничения:** визуальная проверка на телефоне/планшете не выполнена; поворот пока не имеет независимых ±90°, flip X/Y и перспективы; P1.10/P1.11 остаются открытыми.
- **Следующий шаг:** запустить `ObjectOutlineStage65Test` и `PhotoEditorStage63Test` на Android, проверить crop после поворота на устройстве и продолжить геометрию P1.10.

## 1. 2026-11-18 — Stage 64: компоновка полноэкранного редактора фото по мобильному референсу
- **Файлы:** `PhotoEditor.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** верхняя панель упрощена до «Вернуть / Фото / Сохранить»; холст сохраняет максимум доступной высоты; под ним добавлена приподнятая панель быстрых действий, отдельная шкала масштаба и нижняя иконная панель. Быстрые действия реально управляют режимом кадрирования/перемещения, масштабом и сбросом. Используются существующие токены `Bg/Card/SurfaceRaised/Violet/Line` и скругления DVDMaker; обработка bitmap, crop handles, жесты и `AppVm.updateLayer()` не менялись.
- **Проверки:** исходник и вызовы сверены статически; автоматическая сборка и Android-тесты не запускались (в архиве нет Gradle Wrapper; системные Gradle/SDK в окружении не подтверждены).
- **Ограничения:** нет визуальной проверки на устройстве и адаптивной проверки на планшете; вращение/зеркало/перспектива не добавлялись — это отдельный P1.10.
- **Следующий шаг:** собрать APK и проверить PhotoEditor на узком телефоне и планшете; затем реализовать атомарный draft/commit P1.11 и геометрию P1.10.

## 1. 2026-11-18 — Stage 63: полноценные crop handles в полноэкранном Photo Editor (P1.9)
- **Файлы:** `PhotoEditor.kt`, `Editor.kt`, `PhotoEditorStage63Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** добавлены восемь интерактивных маркеров; угловые меняют обе оси, боковые — одну; drag внутри рамки перемещает её целиком. Нормализованная область clamp-ится к 0..1 с минимальным размером 5%. Добавлены режимы «Кадр»/«Фото»: в первом редактируется рамка, во втором одним пальцем перемещается фото; pinch доступен в обоих режимах и сохраняет focal point. Overlay и bitmap используют одинаковые fit/scale/offset. «Готово» применяет crop одним `AppVm.updateLayer()` commit; обновляется существующая stable crop operation, а legacy Layer crop-поля конвертируются в stable crop operation с композицией прежней области; исходный файл не меняется.
- **Проверки:** добавлены 8 instrumentation-тестов на геометрию handles, движение рамки, границы/min-size и композицию legacy/stable crop. Исходники проверены статически.
- **Ограничения:** Gradle/Android SDK в текущем окружении отсутствуют, поэтому компиляция и Android runtime-тесты не запускались; визуальная проверка на физическом устройстве не выполнялась. P1.9 ожидает device/CI подтверждения.

## 1. 2026-11-18 — Stage 62: безопасные ресурсы/миграции/Undo-тесты и полноэкранный Photo Editor (P1.4–P1.8)
- **Файлы:** `PhotoEditor.kt`, `Editor.kt`, `ImageOperationRenderer.kt`, `EngineLifecycleStage62Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`, `DEVICE_TEST_STAGE62.md`.
- **Изменения:** P1.4/P1.6/P1.7 дополнены instrumentation-тестами безопасного удаления только неиспользуемых ресурсов, отказа от GC при повреждённом JSON, Undo/Redo для перестановки/отключения/удаления операций и идемпотентной проекции legacy Layer-полей. Для P1.5 существующие save/reopen тесты сохранены; оставлена ручная проверка повторного редактирования UI после открытия. P1.8: `Tool.IMAGE_EDIT` теперь открывает полноэкранный `PhotoEditorScreen`; изображение получает уже исполненный bitmap через общий Ordered Executor и контекст backdrop панели; добавлены one-finger pan, focal-point pinch zoom, clamp к границам изображения, точный zoom через `LabeledSlider`, reset и возврат Back/Close.
- **Проверки:** исходники и сигнатуры проверены; тесты и сборка в этом окружении не запускались (нет Gradle Wrapper, системного Gradle и Android SDK).
- **Ограничения:** P1.4–P1.7 остаются открытыми до прогона новых и существующих instrumentation-тестов; P1.5 дополнительно требует ручной проверки повторного редактирования Enhance/BgRemove/Blur после reopen. P1.8 требует проверки на устройстве/планшете; ручки кадрирования P1.9 и атомарный draft/commit P1.11 ещё не реализованы.

## 1. 2026-11-18 — Stage 60: исправление миниатюр проектов на Home (P1.1)
- **Файлы:** `Home.kt`, `HomeThumbnailStage60Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** установлено, что Home создаёт несколько `renderSheet()` одновременно через `produceState(Dispatchers.Default)`, а `ImageOperationRenderer.executeOrderedBitmapStack()` использует общий latest-preview generation; параллельная карточка могла инвалидировать рендер предыдущей посреди листа, из-за чего часть image layers оставалась незарисованной поверх фона панели. Добавлен `ProjectThumbnailRenderer` с сериализацией только Home thumbnail render, сохраняя `renderSheet()` → `drawLayer()` → Ordered Executor; ключ кэша версионирован `home-thumb-v2` для регенерации старых миниатюр.
- **Проверки:** добавлен Android instrumentation `HomeThumbnailStage60Test` с двумя конкурентно запрошенными проектами и стеком crop → geometry; тест не запускался в текущем окружении.
- **Ограничения:** сборка/инструментальный тест не выполнены здесь; Preview/Export pixel parity и checkpoints отмены Fade/Edge/Geometry остаются блокерами P1.1/P1.3.

## 1. 2026-11-18 — Stage 59: prefix-cache и cooperative preview cancellation (P1.1/P1.3/P2.12)
- **Файлы:** `ImageOperationRenderer.kt`, `Blur.kt`, `Render.kt`, `Components.kt`, `ImagePipelineStage40Test.kt`, `RmbgRealModelDeviceTest.kt`, `RMBG_DEVICE_TEST.md`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** добавлен кэш каждого выполненного префикса с fingerprint-ключом по исходнику и ordered operations; crop/geometry/color-grade префиксы не зависят от backdrop, backdrop входит в ключ после Edge Integration. Кэш сохраняет копии bitmap, чтобы последующий executor не recycle-ил закэшированный префикс. Изменение Blur повторно использует Crop+Geometry. Новая render generation инвалидирует устаревший executor; `Interactive.sliderActive/dragging` вызывают отмену, Gaussian Blur проверяет отмену в циклах. Добавлены тесты prefix reuse, blur cancellation и backdrop parity. Добавлен opt-in тест реального RMBG ONNX и инструкция запуска.
- **Проверки:** статически; тесты/сборка не запускались — отсутствуют `gradlew`, системный `gradle` и Android SDK.
- **Ограничения:** cancellation сейчас проверяется между узлами и внутри Gaussian Blur; тяжёлые Fade/Edge/Geometry не имеют внутренних checkpoints. Проверка Preview/Export pixel parity на полном смешанном стеке ещё не добавлена/не выполнена. Настоящая модель RMBG и фото нужны для `RmbgRealModelDeviceTest`; без них тест assumption-skipped.
- **Статус:** P1.1/P1.3 не закрыты до прохождения Android instrumentation и визуально/побайтного сравнения Preview/Export.

