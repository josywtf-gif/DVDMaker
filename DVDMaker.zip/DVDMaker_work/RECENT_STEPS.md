## Последние 10 завершённых логических шагов

Новые записи добавлять сверху; при превышении 10 удалять самую старую запись снизу.

## 1. 2026-11-18 — Stage 48: пересчёт утерянных ресурсов AI-операций (P1.24)
- **Файлы:** `ImageProcessingPipeline.kt`, `Enhance.kt`, `Tools.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `PROJECT_MAP.md`, `RECENT_STEPS.md`.
- **Изменения:** `missingResourceNodes()`, `isRecoverable()`, `recomputeMissingResults()`; `ResourceRepairBanner` (предупреждение + «Пересчитать результат») в панелях «Качество» и «Удаление фона».
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** повреждённый, но существующий файл не распознаётся (только отсутствие/нулевой размер); утерянная маска удаления фона не восстанавливается автоматически.
- **Следующий шаг:** P1.25 — единая точка записи стека операций.

## 1. 2026-11-18 — Stage 47: относительные пути ресурсов в JSON (P1.23)
- **Файлы:** `Store.kt`, `Model.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `PROJECT_MAP.md`, `RECENT_STEPS.md`.
- **Изменения:** `ResourcePaths.toStored/fromStored`; `Layer.toJson/fromJson` и `ImageOperation.toJson/fromJson` пишут `img:<имя>` для файлов в `img/` и читают как новый, так и старый абсолютный формат с переназначением при переезде каталога данных.
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** старая версия приложения не прочитает `img:`-пути (даунгрейд); другие места сериализации путей не проверены.
- **Следующий шаг:** P1.24 — безопасное поведение при отсутствующем/повреждённом ресурсе операции.

## 1. 2026-11-18 — Stage 46: GC производных файлов с учётом Undo (P1.22)
- **Файлы:** `Store.kt`, `Vm.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** `Store.pruneDerived(extraUsed)` удаляет только `derived-*`/`mask-*` без ссылок и старше 30 мин; `AppVm.protectedPaths()` собирает ресурсы current+Undo+Redo; prune вызывается из `scheduleSave()` не чаще раза в 2 мин; `Store.delete()` принимает `extraUsed`. Добавлены тесты prune и `restoreInPlace` (Stage 45).
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** `imagePaths()` учитывает только `Kind.IMAGE`, поэтому `blur-*`/`spine-*` не очищаются; существующий `Store.delete()` по-прежнему удаляет все неучтённые файлы в `img/`.
- **Следующий шаг:** P1.23 — относительные пути ресурсов.

## 1. 2026-11-18 — Stage 45: чистый результат Real-ESRGAN отдельно от detail/grain (P1.21)
- **Файлы:** `Neural.kt`, `Enhance.kt`, `ImageProcessingPipeline.kt`, `ImageOperationRenderer.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** `NeuralUpscaler.restoreInPlace()` применяет detail/grain к уже готовому результату сети (без инференса); `Enhancer.enhanceKeepingBase()` запускает сеть один раз с `EnhanceOpts.PURE`, сохраняет чистый результат в `assetPath` узла `enhance`; `restoreFromBase()` пересобирает итог из него. Диалог улучшения, «Применить настройки», `replayFollowing()` и `materializeBeforeOperation()` пишут `assetPath`. Формат JSON не менялся (используется существующее поле).
- **Проверки:** статически, баланс скобок в 4 файлах; сборка и тесты не запускались (нет Android SDK). Поведение на устройстве не проверялось.
- **Ограничения:** итог теперь строится постобработкой, а не внутри тайлов сети — визуально может немного отличаться от прежнего; два PNG на один enhance (рост `img/`, см. P1.22).
- **Следующий шаг:** P1.22 — GC производных файлов с учётом Undo-окна; затем Android-тесты для P1.21.

## 1. 2026-11-18 — Анализ недеструктивной системы и обновление IMPROVEMENTS.md
- **Файлы:** `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** P1.1 сжат до остаточных задач с критериями (история реализации осталась в `PROJECT_MAP.md`/`RECENT_STEPS.md`); добавлены P1.21 (AI-результат отдельно от detail/grain), P1.22 (GC производных ресурсов с учётом Undo), P1.23 (относительные пути), P1.24 (отсутствующий resultPath), P1.25 (единая точка записи стека), P1.26 (версия схемы проекта); уточнены P1.4, P1.6, P1.14. Исходный код не менялся.
- **Проверки:** статический разбор `Model.kt`, `Store.kt`, `Vm.kt`, `Enhance.kt`, `Neural.kt`, `ImageProcessingPipeline.kt`; сборка/тесты не запускались (нет Android SDK).
- **Следующий шаг:** P1.21 — вынести detail/grain из инференса `Neural.kt` в отдельные узлы стека.

## 1. 2026-11-18 — Stage 44: исправление обнаружения объектов при удалении фона
- **Файлы:** `app/src/main/java/com/dvdmaker/app/BgRemove.kt`, `app/src/androidTest/java/com/dvdmaker/app/ImagePipelineStage40Test.kt`, `AI_RULES.md`, `PROJECT_MAP.md`, `RECENT_STEPS.md`.
- **Изменения:** preprocessing RMBG-1.4 переведён с letterbox на прямое масштабирование 1024×1024, как в официальном pipeline. Выходная маска после преобразования logits нормализуется min-max в диапазон 0…1 до порогового выделения связных областей; добавлены тесты узкого диапазона маски и вырожденного/некорректного выхода.
- **Проверки:** исходники и регрессионные сценарии проверены статически; Android-сборка и instrumentation tests не запускались (в среде нет Gradle/Android SDK; ONNX-модель в архив не включена, она добавляется CI).
- **Ограничения:** реальное качество сегментации необходимо проверить на устройстве с фактической `model_fp16.onnx` и несколькими портретными/горизонтальными фото.
- **Следующий шаг:** собрать APK через CI и проверить, что редактор показывает найденные объекты, корректно выбирает их и сохраняет прозрачный PNG.

## 1. 2026-11-18 — Stage 43: быстрый предпросмотр при перетаскивании ползунков
- **Файлы:** `Components.kt`, `Render.kt`, `ImageOperationRenderer.kt`, `RECENT_STEPS.md`.
- **Изменения:** `LabeledSlider` сообщает `Interactive.sliderActive()`; пока ползунок удерживается, `executeOrderedBitmapStack()` перед Fade/Edge/Blur уменьшает рабочий bitmap до ≤800 px (AI-узлы по-прежнему получают полноразмерный вход), результат кэшируется с суффиксом `|preview`; после отпускания пересчёт в полном качестве. Экспорт не затрагивается.
- **Проверки:** статически; сборка не выполнялась (нет Android SDK).
- **Следующий шаг:** проверить плавность и перерисовку после отпускания на устройстве.

## 2. 2026-11-18 — Stage 42: Fade по готовой вырезке рисовал прямоугольную маску
- **Файлы:** `app/src/main/java/com/dvdmaker/app/ImageOperationRenderer.kt`, `RECENT_STEPS.md`.
- **Изменения:** в `drawFade()` маска `ObjectMasks` (≤1536 px) рисовалась с `sourceRect` в пикселях полного bitmap; на больших PNG маска покрывала лишь часть кадра, остальное оставалось без растворения. `sourceRect` теперь масштабируется в координаты маски.
- **Проверки:** статически; сборка и запуск не выполнялись (нет Android SDK).
- **Следующий шаг:** проверить «Мягкий край»/«Кино» на большом PNG-вырезке на устройстве.

## 3. 2026-11-18 — Stage 41: порядок Fade/Edge vs вырезка, stale-снимки, кэш executor, цвет Блюр/Размытие
- **Файлы:** `ImageProcessingPipeline.kt`, `ImageOperationRenderer.kt`, `Model.kt`, `Render.kt`, `AI_RULES.md`, `PROJECT_MAP.md`, `RECENT_STEPS.md`.
- **Изменения:** (1) «Вписать в фон»/Fade работали по квадрату: `recordOperation()` замораживал Layer-проекции в стек и дописывал `background-removal` в конец → эффекты шли до вырезки. Теперь проекции не сохраняются в стеке, `Layer.fromJson()` отбрасывает ранее сохранённые снимки (они ещё и перебивали слайдеры), новая вырезка/enhance вставляется через `insertionIndex()` перед Fade/Edge. (2) Тормоза: результат стека с AI/Edge не кэшировался (`ownsCurrent`) и каждый кадр хэшировался SHA-256; кэш всегда, размер до 1/6 heap, `bitmapFingerprint()` мемоизирован и без per-pixel putInt. (3) `drawBlurBitmapObject()` теперь использует `Layer.color`.
- **Проверки:** статический разбор потока UI→Vm→Pipeline→Renderer, баланс скобок в 4 файлах. Сборка/тесты не выполнялись: нет Android SDK; поведение на устройстве не проверялось.
- **Ограничения:** старые проекты, где вырезка уже сохранена ПОСЛЕ Fade/Edge, получают корректный порядок за счёт отбрасывания снимков; пользовательские (не проекционные) Fade/Edge-операции стека не перемещаются. Перерисовка Edge Integration во время перетаскивания по-прежнему зависит от backdrop в ключе кэша.
- **Следующий шаг:** `assembleDebug` + `connectedDebugAndroidTest`; замерить кадр при перетаскивании фото с Light Wrap.

## 4. 2026-11-18 — Stage 40: backdrop snapshot для AI bridge и runtime regression tests
- **Файлы:** `app/src/main/java/com/dvdmaker/app/Render.kt`, `app/src/main/java/com/dvdmaker/app/Enhance.kt`, `app/src/main/java/com/dvdmaker/app/BgRemove.kt`, `app/src/main/java/com/dvdmaker/app/ImageProcessingPipeline.kt`, `app/build.gradle.kts`, `app/src/androidTest/java/com/dvdmaker/app/ImagePipelineStage40Test.kt`, `AI_RULES.md`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** добавлен `materializationBackdrop(project, panelId, layer)`: он анализирует фон панели и только нижние слои, исключая выбранное изображение; использует реальные цвет/направление/силу `BackdropLight`. Enhance и Background Removal получают snapshot перед materialization и передают тот же экземпляр в `replayFollowing()`. `replayFollowing()` прокидывает его в повторную материализацию downstream AI/bitmap prefix. Добавлены Android instrumentation tests: фактический prefix `crop → enhance(cache hit) → fade → blur → edge-integration(with real backdrop) → background-removal`, сохранение порядка/зависимостей, старый JSON/очистка `fadeBlend`, открытие через Store и Undo/Redo.
- **Проверки:** статически сверены все UI-вызовы AI bridge и replay, аргументы `backdrop`, сигнатура `replayFollowing()`, новые тестовые сценарии и зависимости instrumentation runner; выполнены проверки баланса скобок/строк и whitespace; Kotlin parser-oriented проход не выявил `expecting`/syntax ошибок. Целостность итогового ZIP проверена (`testzip=None`).
- **Ограничения:** Android instrumentation tests и assembleDebug не запускались: в окружении отсутствуют Gradle/Gradle Wrapper и Android SDK. Проверки Undo/Redo и открытия старого проекта добавлены как тесты, но пока не исполнены; ONNX runtime на устройстве также не проверен.
- **Следующий шаг:** запустить `connectedDebugAndroidTest`/`assembleDebug` в Android SDK окружении; затем проверить Preview/Export совпадение и полный стек с реальными ONNX-моделями.

