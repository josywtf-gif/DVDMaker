## 1. 2026-11-18 — Stage 63: полноценные crop handles в полноэкранном Photo Editor (P1.9)
- **Файлы:** `PhotoEditor.kt`, `Editor.kt`, `PhotoEditorStage63Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** добавлены восемь интерактивных маркеров; угловые меняют обе оси, боковые — одну; drag внутри рамки перемещает её целиком. Нормализованная область clamp-ится к 0..1 с минимальным размером 5%. Добавлены режимы «Кадр»/«Фото»: в первом редактируется рамка, во втором одним пальцем перемещается фото; pinch доступен в обоих режимах и сохраняет focal point. Overlay и bitmap используют одинаковые fit/scale/offset. «Готово» применяет crop одним `AppVm.updateLayer()` commit; обновляется существующая stable crop operation, а legacy Layer crop-поля конвертируются в stable crop operation с композицией прежней области; исходный файл не меняется.
- **Проверки:** добавлены 8 instrumentation-тестов на геометрию handles, движение рамки, границы/min-size и композицию legacy/stable crop. Исходники проверены статически.
- **Ограничения:** Gradle/Android SDK в текущем окружении отсутствуют, поэтому компиляция и Android runtime-тесты не запускались; визуальная проверка на физическом устройстве не выполнялась. P1.9 ожидает device/CI подтверждения.

## 1. 2026-11-18 — Stage 62: безопасные ресурсы/миграции/Undo-тесты и полноэкранный Photo Editor (P1.4–P1.8)
- **Файлы:** `PhotoEditor.kt`, `Editor.kt`, `ImageOperationRenderer.kt`, `EngineLifecycleStage62Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`, `DEVICE_TEST_STAGE62.md`.
- **Изменения:** P1.4/P1.6/P1.7 дополнены instrumentation-тестами безопасного удаления только неиспользуемых ресурсов, отказа от GC при повреждённом JSON, Undo/Redo для перестановки/отключения/удаления операций и идемпотентной проекции legacy Layer-полей. Для P1.5 существующие save/reopen тесты сохранены; оставлена ручная проверка повторного редактирования UI после открытия. P1.8: `Tool.IMAGE_EDIT` теперь открывает полноэкранный `PhotoEditorScreen`; изображение получает уже исполненный bitmap через общий Ordered Executor и контекст backdrop панели; добавлены one-finger pan, focal-point pinch zoom, clamp к границам изображения, точный zoom через `LabeledSlider`, reset и возврат Back/Close.
- **Проверки:** исходники и сигнатуры проверены; тесты и сборка в этом окружении не запускались (нет Gradle Wrapper, системного Gradle и Android SDK).
- **Ограничения:** P1.4–P1.7 остаются открытыми до прогона новых и существующих instrumentation-тестов; P1.5 дополнительно требует ручной проверки повторного редактирования Enhance/BgRemove/Blur после reopen. P1.8 требует проверки на устройстве/планшете; ручки кадрирования P1.9 и атомарный draft/commit P1.11 ещё не реализованы.

## 1. 2026-11-18 — Stage 60: исправление миниатюр проектов на Home (P1.1)
- **Файлы:** `Home.kt`, `HomeThumbnailStage60Test.kt`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** установлено, что Home создаёт несколько `renderSheet()` одновременно через `produceState(Dispatchers.Default)`, а `ImageOperationRenderer.executeOrderedBitmapStack()` использует общий latest-preview generation; параллельная карточка могла инвалидировать рендер предыдущей посреди листа, из-за чего часть image layers оставалась незарисованной поверх фона панели. Добавлен `ProjectThumbnailRenderer` с сериализацией только Home thumbnail render, сохраняя `renderSheet()` → `drawLayer()` → Ordered Executor; ключ кэша версионирован `home-thumb-v2` для регенерации старых миниатюр.
- **Проверки:** добавлен Android instrumentation `HomeThumbnailStage60Test` с двумя конкурентно запрошенными проектами и стеком crop → geometry; тест не запускался в текущем окружении.
- **Ограничения:** сборка/инструментальный тест не выполнены здесь; Preview/Export pixel parity и checkpoints отмены Fade/Edge/Geometry остаются блокерами P1.1/P1.3.

## 1. 2026-11-18 — Stage 59: prefix-cache и cooperative preview cancellation (P1.1/P1.3/P2.12)
- **Файлы:** `ImageOperationRenderer.kt`, `Blur.kt`, `Render.kt`, `Components.kt`, `ImagePipelineStage40Test.kt`, `RmbgRealModelDeviceTest.kt`, `RMBG_DEVICE_TEST.md`, `PROJECT_MAP.md`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** добавлен кэш каждого выполненного префикса с fingerprint-ключом по исходнику и ordered operations; crop/geometry/color-grade префиксы не зависят от backdrop, backdrop входит в ключ после Edge Integration. Кэш сохраняет копии bitmap, чтобы последующий executor не recycle-ил закэшированный префикс. Изменение Blur повторно использует Crop+Geometry. Новая render generation инвалидирует устаревший executor; `Interactive.sliderActive/dragging` вызывают отмену, Gaussian Blur проверяет отмену в циклах. Добавлены тесты prefix reuse, blur cancellation и backdrop parity. Добавлен opt-in тест реального RMBG ONNX и инструкция запуска.
- **Проверки:** статически; тесты/сборка не запускались — отсутствуют `gradlew`, системный `gradle` и Android SDK.
- **Ограничения:** cancellation сейчас проверяется между узлами и внутри Gaussian Blur; тяжёлые Fade/Edge/Geometry не имеют внутренних checkpoints. Проверка Preview/Export pixel parity на полном смешанном стеке ещё не добавлена/не выполнена. Настоящая модель RMBG и фото нужны для `RmbgRealModelDeviceTest`; без них тест assumption-skipped.
- **Статус:** P1.1/P1.3 не закрыты до прохождения Android instrumentation и визуально/побайтного сравнения Preview/Export.

## 1. 2026-11-18 — Stage 58: экспорт без лишней децимации крупных изображений (P1.3)
- **Файлы:** `Render.kt`, `ImagePipelineStage56Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** `Bitmaps.getFullQuality()` (только при `Interactive.isFullQuality`): если экранный лимит 40 МБ прорядил бы файл (4096×3072 и т.п. после Enhance), он декодируется с лимитом 64 МБ, вне общего кэша; при OOM/ошибке — обычный путь. Экранное поведение и кэш не менялись.
- **Проверки:** статически; тест на 4096×2800 PNG добавлен, не запущен.
- **Ограничения:** пик памяти печатного экспорта на слабых устройствах не измерялся; лимит 4096 px по стороне сохранён (совпадает с лимитом импорта/Enhance).
- **Следующий шаг:** запуск CI-тестов; затем P1.1 — сравнение Preview/Export на смешанном стеке.

## 1. 2026-11-18 — Stage 57: экспорт не зависит от интерактивных упрощений (P1.3)
- **Файлы:** `Render.kt`, `Export.kt`, `ImagePipelineStage56Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** `Interactive.adjusting` и `backdropFor()` учитывают потоковый флаг; `Interactive.withFullQuality {}` оборачивает `renderSheet` в `writePng/writePdf`. Раньше экспорт, запущенный во время удержания ползунка/перетаскивания, мог получить уменьшенное превью (≤800 px) эффектов или устаревший backdrop.
- **Проверки:** статически; новый тест не запускался.
- **Ограничения:** побайтное сравнение Preview/Export не выполнялось; лимит декодирования `Bitmaps` 4096 px не менялся (правило §4 — проверить отдельно).
- **Следующий шаг:** запуск CI-тестов; затем проверка лимита `Bitmaps.get()` для печатного экспорта.

## 1. 2026-11-18 — Stage 56: тест Undo/Redo для стека операций (P1.6)
- **Файлы:** `ImagePipelineStage56Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** разобраны `edit()/undoLast()/redoLast()/protectedPaths()`: снимки `Project` включают стек и пути, код приложения не менялся. Новый тест: отклонённый `commitReplay` не создаёт шаг Undo; commit → undo → redo восстанавливает операции, `path` и `resultPath`.
- **Проверки:** CI-прогон до этого шага: тесты Stage 45–54 зелёные; новый тест не запускался.
- **Ограничения:** тест работает с `AppVm` напрямую, не через UI; история Undo по-прежнему не сохраняется между сессиями.
- **Следующий шаг:** запустить «Android tests DVDMaker»; далее P1.3 — единый replay Preview/Export.

## 1. 2026-11-18 — Stage 55: результаты CI-тестов и исправление `normalizeMaskInPlace`
- **Файлы:** `BgRemove.kt`, `RECENT_STEPS.md`, `IMPROVEMENTS.md`.
- **Изменения:** `connectedDebugAndroidTest` на эмуляторе (API 30): 16 тестов, 15 прошли, упал `rmbgConstantOrInvalidMaskDoesNotCreateFalseObjects`: NaN заменялся нулём до расчёта min/max, и постоянная маска 0.2 превращалась в 0/1 (ложный объект). Диапазон теперь считается только по конечным значениям, не конечные пиксели → 0.
- **Проверки:** CI-запуск до правки (см. выше); после правки тесты не запускались.
- **Ограничения:** тест на реальной `model_fp16.onnx` не добавлялся.
- **Следующий шаг:** повторить запуск «Android tests DVDMaker»; при зелёном — удалить подтверждённые пункты из `IMPROVEMENTS.md`.

## 1. 2026-11-18 — Stage 54: тест восстановления стека после повторного открытия (P1.5)
- **Файлы:** `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** разобраны `Layer/ImageOperation.toJson/fromJson` — потерь порядка, `enabled`, `inputOperationId`, параметров и путей не найдено; добавлен тест save→loadAll смешанного стека enhance→blur(off)→background-removal. Код приложения не менялся.
- **Проверки:** статически; тест не запускался (нет Android SDK).
- **Ограничения:** повторное редактирование из UI после открытия, маски Fade/ObjectMasks и объекты эффектов не проверялись.
- **Следующий шаг:** запустить сборку и `connectedDebugAndroidTest` на CI; по результатам — P1.6 (Undo/Redo и стек).

## 1. 2026-11-18 — Stage 53: ссылки на ресурсы учитывают слои любого типа (P1.4)
- **Файлы:** `Model.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** `Project.imagePaths()` больше не фильтрует `Kind.IMAGE`: ссылки `path/sourcePath/originalPath/enhanceSourcePath` и ресурсы `imageOperations` собираются со всех слоёв, включая общие. Это только расширяет множество «используемых» файлов, поэтому `pruneDerived()`/`Store.delete()` могут лишь удалить меньше. Разобраны пути замены (`recordOperation`) и отключения (`op.copy(enabled=false, resultPath="")`): осиротевшие `derived-*`/`mask-*` подбирает `pruneDerived()`.
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** `blur-*`/`spine-*`/`unified-*` по-прежнему не очищаются; удаление слоя через UI не проверялось на устройстве.
- **Следующий шаг:** P1.5 — восстановление редактирования после повторного открытия проекта.

