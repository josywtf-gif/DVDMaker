## Последние 10 завершённых логических шагов

Новые записи добавлять сверху; при превышении 10 удалять самую старую запись снизу.

## 1. 2026-11-18 — Stage 54: тест восстановления стека после повторного открытия (P1.5)
- **Файлы:** `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** разобраны `Layer/ImageOperation.toJson/fromJson` — потерь порядка, `enabled`, `inputOperationId`, параметров и путей не найдено; добавлен тест save→loadAll смешанного стека enhance→blur(off)→background-removal. Код приложения не менялся.
- **Проверки:** статически; тест не запускался (нет Android SDK).
- **Ограничения:** повторное редактирование из UI после открытия, маски Fade/ObjectMasks и объекты эффектов не проверялись.
- **Следующий шаг:** запустить сборку и `connectedDebugAndroidTest` на CI; по результатам — P1.6 (Undo/Redo и стек).

## 1. 2026-11-18 — Stage 53: ссылки на ресурсы учитывают слои любого типа (P1.4)
- **Файлы:** `Model.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** `Project.imagePaths()` больше не фильтрует `Kind.IMAGE`: ссылки `path/sourcePath/originalPath/enhanceSourcePath` и ресурсы `imageOperations` собираются со всех слоёв, включая общие. Это только расширяет множество «используемых» файлов, поэтому `pruneDerived()`/`Store.delete()` могут лишь удалить меньше. Разобраны пути замены (`recordOperation`) и отключения (`op.copy(enabled=false, resultPath="")`): осиротевшие `derived-*`/`mask-*` подбирает `pruneDerived()`.
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** `blur-*`/`spine-*`/`unified-*` по-прежнему не очищаются; удаление слоя через UI не проверялось на устройстве.
- **Следующий шаг:** P1.5 — восстановление редактирования после повторного открытия проекта.

## 1. 2026-11-18 — Stage 52: очистка временных файлов после сбоя (P1.4/P1.22)
- **Файлы:** `Store.kt`, `Vm.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** `Store.cleanStaleTemp()` удаляет `*.tmp` в `img/` и `dvd-ai-input-*.png` в `cacheDir` старше 30 мин; вызывается один раз при создании `AppVm` в IO. Оригиналы и производные ресурсы не затрагиваются.
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** `.tmp` модели (`Neural.kt`, `BgRemove.kt`) вне `img/` не очищаются; тест добавлен, не запущен.
- **Следующий шаг:** P1.4 — сценарии замены/отключения/удаления операций и ссылки на ресурсы; либо P1.5.

## 1. 2026-11-18 — Stage 51: индикатор «только чтение» (P1.26)
- **Файлы:** `Home.kt`, `Editor.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** карточка проекта и заголовок редактора показывают янтарную пометку для проекта из новой версии схемы; дизайн-токены (`Amber`, `Dim`) не менялись.
- **Проверки:** статически; сборка не запускалась (нет Android SDK), на устройстве не проверялось.
- **Ограничения:** редактор по-прежнему молча игнорирует правки (без тоста); дублирование read-only проекта даёт тоже read-only копию.
- **Следующий шаг:** P1.4 — временные файлы (`*.tmp` в `img/`, `dvd-ai-input-*.png`).

## 1. 2026-11-18 — Stage 50: версия схемы проекта (P1.26)
- **Файлы:** `Model.kt`, `Store.kt`, `Vm.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `PROJECT_MAP.md`, `RECENT_STEPS.md`.
- **Изменения:** `Project.schemaVersion`/`readOnly`, `Project.migrate()` (таблица миграций, идемпотентно, на копии JSON), старые проекты без поля читаются как версия 0 → 1; проект новее приложения: `Store.save()` отказывает, `AppVm.edit()` игнорирует правки. Добавлен тест версий N-1/N/N+1.
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** UI не сообщает о режиме «только чтение»; пользователь не видит причину отказа правок.
- **Следующий шаг:** индикатор read-only в редакторе/на главном экране, затем P1.4 (временные файлы).

## 1. 2026-11-18 — Stage 49: единая точка фиксации стека операций (P1.25)
- **Файлы:** `ImageProcessingPipeline.kt`, `Vm.kt`, `Enhance.kt`, `BgRemove.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `PROJECT_MAP.md`, `RECENT_STEPS.md`.
- **Изменения:** `ImageProcessingPipeline.commitReplay()` + `AppVm.commitReplay()` (стек и `path` одним шагом, проверка зависимостей, false при ошибке); переведены Enhance (2 места), BgRemove, `ResourceRepairBanner`, Gaussian Blur. При отказе показывается ошибка, диалог не закрывается / BgRemove возвращается на stage 2.
- **Проверки:** статически, grep коммитов `copy(imageOperations`; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** транзитные `layer.copy(imageOperations=…)` для входа replay оставлены; тест добавлен, не запущен.
- **Следующий шаг:** P1.26 — версия схемы проекта.

## 1. 2026-11-18 — Stage 48: пересчёт утерянных ресурсов AI-операций (P1.24)
- **Файлы:** `ImageProcessingPipeline.kt`, `Enhance.kt`, `Tools.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `PROJECT_MAP.md`, `RECENT_STEPS.md`.
- **Изменения:** `missingResourceNodes()`, `isRecoverable()`, `recomputeMissingResults()`; `ResourceRepairBanner` (предупреждение + «Пересчитать результат») в панелях «Качество» и «Удаление фона».
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** повреждённый, но существующий файл не распознаётся (только отсутствие/нулевой размер); утерянная маска удаления фона не восстанавливается автоматически.
- **Следующий шаг:** P1.25 — единая точка записи стека операций.

## 1. 2026-11-18 — Stage 47: относительные пути ресурсов в JSON (P1.23)
- **Файлы:** `Store.kt`, `Model.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `PROJECT_MAP.md`, `RECENT_STEPS.md`.
- **Изменения:** `ResourcePaths.toStored/fromStored`; `Layer.toJson/fromJson` и `ImageOperation.toJson/fromJson` пишут `img:<имя>` для файлов в `img/` и читают как новый, так и старый абсолютный формат с переназначением при переезде каталога данных.
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** старая версия приложения не прочитает `img:`-пути (даунгрейд); другие места сериализации путей не проверены.
- **Следующий шаг:** P1.24 — безопасное поведение при отсутствующем/повреждённом ресурсе операции.

## 1. 2026-11-18 — Stage 46: GC производных файлов с учётом Undo (P1.22)
- **Файлы:** `Store.kt`, `Vm.kt`, `ImagePipelineStage45Test.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** `Store.pruneDerived(extraUsed)` удаляет только `derived-*`/`mask-*` без ссылок и старше 30 мин; `AppVm.protectedPaths()` собирает ресурсы current+Undo+Redo; prune вызывается из `scheduleSave()` не чаще раза в 2 мин; `Store.delete()` принимает `extraUsed`. Добавлены тесты prune и `restoreInPlace` (Stage 45).
- **Проверки:** статически; сборка и тесты не запускались (нет Android SDK).
- **Ограничения:** `imagePaths()` учитывает только `Kind.IMAGE`, поэтому `blur-*`/`spine-*` не очищаются; существующий `Store.delete()` по-прежнему удаляет все неучтённые файлы в `img/`.
- **Следующий шаг:** P1.23 — относительные пути ресурсов.

## 1. 2026-11-18 — Stage 45: чистый результат Real-ESRGAN отдельно от detail/grain (P1.21)
- **Файлы:** `Neural.kt`, `Enhance.kt`, `ImageProcessingPipeline.kt`, `ImageOperationRenderer.kt`, `IMPROVEMENTS.md`, `RECENT_STEPS.md`.
- **Изменения:** `NeuralUpscaler.restoreInPlace()` применяет detail/grain к уже готовому результату сети (без инференса); `Enhancer.enhanceKeepingBase()` запускает сеть один раз с `EnhanceOpts.PURE`, сохраняет чистый результат в `assetPath` узла `enhance`; `restoreFromBase()` пересобирает итог из него. Диалог улучшения, «Применить настройки», `replayFollowing()` и `materializeBeforeOperation()` пишут `assetPath`. Формат JSON не менялся (используется существующее поле).
- **Проверки:** статически, баланс скобок в 4 файлах; сборка и тесты не запускались (нет Android SDK). Поведение на устройстве не проверялось.
- **Ограничения:** итог теперь строится постобработкой, а не внутри тайлов сети — визуально может немного отличаться от прежнего; два PNG на один enhance (рост `img/`, см. P1.22).
- **Следующий шаг:** P1.22 — GC производных файлов с учётом Undo-окна; затем Android-тесты для P1.21.
