# Stage 62 — проверки на Android-устройстве

Из корня репозитория, при подключённом устройстве/эмуляторе (`adb devices`):

```bash
# Новые проверки P1.4, P1.6, P1.7 и математики жестов P1.8
gradle :app:connectedDebugAndroidTest \
  -Pandroid.testInstrumentationRunnerArguments.class=com.dvdmaker.app.EngineLifecycleStage62Test

# Сохранение/повторное открытие стека и ресурсов (P1.4/P1.5/P1.7/P1.22)
gradle :app:connectedDebugAndroidTest \
  -Pandroid.testInstrumentationRunnerArguments.class=com.dvdmaker.app.ImagePipelineStage45Test

# Старые JSON, восстановление проекта и backdrop/materialization (P1.5/P1.7/P1.1)
gradle :app:connectedDebugAndroidTest \
  -Pandroid.testInstrumentationRunnerArguments.class=com.dvdmaker.app.ImagePipelineStage40Test

# Все instrumentation-тесты
gradle :app:connectedDebugAndroidTest
```

## Ручной сценарий P1.5 после reopen

1. Открыть проект со стеком Enhance → Background Removal → Blur → Fade.
2. Закрыть проект через Home, затем снова открыть тот же проект.
3. Открыть «Качество» и изменить Detail/Grain; применить настройки.
4. Открыть «Удаление фона» и изменить параметры/маску, если модель RMBG установлена.
5. Открыть «Размытие», изменить уровень, отключить и включить операцию.
6. Перезапустить приложение, повторно открыть проект и проверить сохранение параметров/порядка.
7. Проверить Undo/Redo после каждого подтверждённого изменения.

## Ручной сценарий P1.8

1. Выбрать фото-слой и нажать «Редактор».
2. Проверить, что полноэкранный режим использует изображение после Ordered Executor (crop/geometry/effects), а не необработанный sourcePath.
3. Перемещать фото одним пальцем; при масштабе 100% изображение не должно открывать пустые полосы.
4. Pinch в центре и у краёв; точка между пальцами должна оставаться визуальным фокусом.
5. Проверить zoom ползунком и сброс; затем закрыть кнопкой и системным Back.
6. Убедиться, что возврат сохраняет выбранный слой и положение основного редактора.
7. Повторить на узком телефоне и планшете/широком экране.

История Undo/Redo сейчас хранится в памяти текущей сессии и намеренно не восстанавливается после перезапуска; проверка P1.5 относится к состоянию проекта и стека операций.
