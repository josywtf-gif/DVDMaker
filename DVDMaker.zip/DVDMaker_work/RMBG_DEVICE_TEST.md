# RMBG-1.4: проверка реального инференса на Android

Тест не подменяет ONNX-модель. `ImagePipelineStage40Test` проверяет логику Ordered Executor с заранее материализованным Enhance-результатом, поэтому не требует `model_fp16.onnx`. Для проверки самого RMBG нужен настоящий файл модели.

## Подготовка

1. Собрать debug APK обычным проектным CI-процессом. Модель должна попасть в assets как `models/bgremove.onnx` (см. `.github/workflows/build.yml`; исходный файл поставляется через `plugin/model_fp16.onnx` или `.github/plugin/model_fp16.onnx`).
2. Установить приложение и подключить Android-устройство с включённой USB debugging.
3. Подготовить обычное JPEG-фото с объектом на фоне. Не использовать персональные/конфиденциальные снимки.
4. Передать фото в каталог external files приложения:

```bash
adb shell mkdir -p /sdcard/Android/data/com.dvdmaker.app/files
adb push ./rmbg-test-input.jpg /sdcard/Android/data/com.dvdmaker.app/files/rmbg-test-input.jpg
```

## Запуск

```bash
gradle :app:connectedDebugAndroidTest \
  -Pandroid.testInstrumentationRunnerArguments.class=com.dvdmaker.app.RmbgRealModelDeviceTest \
  --no-daemon
```

Тест `realModelRunsOnSuppliedPhotoAndProducesNormalizedMask`:
- проверяет наличие настоящей модели через `BgRemover.available()`;
- запускает `BgRemover.infer()` на переданном фото;
- проверяет размер и диапазон `raw/refined` масок;
- применяет маску и сохраняет `rmbg-test-output.png` в external files приложения.

Если модель или фото отсутствуют, тест будет **assumption-skipped**, а не falsely green. Забрать результат:

```bash
adb pull /sdcard/Android/data/com.dvdmaker.app/files/rmbg-test-output.png ./rmbg-test-output.png
```

## Модель-независимые проверки

```bash
gradle :app:connectedDebugAndroidTest \
  -Pandroid.testInstrumentationRunnerArguments.class=com.dvdmaker.app.ImagePipelineStage40Test \
  --no-daemon
```

`mixedCropEnhanceFadeBlurPrefixMaterializesAtBackgroundRemoval` использует синтетический source и заранее сохранённый результат Enhance с корректным fingerprint. Это проверяет материализацию префикса без фиктивной ONNX-модели и без вызова инференса.
