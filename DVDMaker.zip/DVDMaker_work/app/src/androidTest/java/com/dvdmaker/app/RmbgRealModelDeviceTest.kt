package com.dvdmaker.app

import android.app.Application
import android.graphics.BitmapFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/** Opt-in device test: requires the real RMBG model and rmbg-test-input.jpg in app external files. */
@RunWith(AndroidJUnit4::class)
class RmbgRealModelDeviceTest {
    @Test
    fun realModelRunsOnSuppliedPhotoAndProducesNormalizedMask() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Application>()
        assumeTrue("RMBG model is not packaged in this build", BgRemover.available(context))
        val externalDir = context.getExternalFilesDir(null) ?: context.filesDir
        val input = File(externalDir, "rmbg-test-input.jpg")
        assumeTrue("Push a real photo to ${input.absolutePath}", input.isFile && input.length() > 0L)
        val bitmap = BitmapFactory.decodeFile(input.absolutePath)
            ?: throw AssertionError("Could not decode test photo")
        try {
            val masks = BgRemover.infer(context, bitmap) {}
            assertEquals(bitmap.width, masks.w)
            assertEquals(bitmap.height, masks.h)
            assertTrue(masks.raw.isNotEmpty())
            assertTrue(masks.refined.isNotEmpty())
            assertTrue(masks.raw.all { it.isFinite() && it in 0f..1f })
            assertTrue(masks.refined.all { it.isFinite() && it in 0f..1f })
            val cutout = BgRemover.applyMask(bitmap, masks.refined, masks.w, masks.h) {}
            try {
                val output = File(externalDir, "rmbg-test-output.png")
                output.outputStream().use { stream ->
                    check(cutout.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, stream))
                }
                assertTrue(output.isFile && output.length() > 0L)
            } finally {
                cutout.recycle()
            }
        } finally {
            bitmap.recycle()
        }
    }
}
