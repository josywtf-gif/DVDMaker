package com.dvdmaker.app

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import java.io.File
import java.util.UUID
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EngineLifecycleStage62Test {
    private val app = ApplicationProvider.getApplicationContext<Application>()
    private fun onMain(block: () -> Unit) = InstrumentationRegistry.getInstrumentation().runOnMainSync(block)

    private fun projectWithLayer(name: String, layer: Layer): Project {
        val base = newProject(DiscFormat.values().first(), name)
        return base.copy(panels = base.panels + (PanelId.FRONT to base.panel(PanelId.FRONT).copy(layers = listOf(layer))))
    }

    @Test
    fun deletingProjectRemovesOnlyUnreferencedImages() {
        val store = Store(app)
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val onlyA = File(img, "orig-stage62-a-${UUID.randomUUID()}.png").apply { writeText("a") }
        val shared = File(img, "derived-stage62-shared-${UUID.randomUUID()}.png").apply { writeText("b") }
        val a = projectWithLayer("delete-a", Layer(kind = Kind.IMAGE, path = onlyA.path, sourcePath = onlyA.path))
        val b = projectWithLayer("delete-b", Layer(kind = Kind.IMAGE, path = shared.path,
            imageOperations = listOf(ImageOperation(type = ImageOperationType.ENHANCE, resultPath = shared.path))))
        try {
            assertTrue(store.save(a)); assertTrue(store.save(b))
            store.delete(a)
            assertFalse("resource referenced only by deleted project is removed", onlyA.exists())
            assertTrue("other project's operation resource remains", shared.exists())
        } finally {
            store.delete(b)
            onlyA.delete(); shared.delete()
        }
    }

    @Test
    fun deleteSkipsResourceCleanupWhenAnyRemainingProjectCannotBeParsed() {
        val store = Store(app)
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val resource = File(img, "derived-stage62-protected-${UUID.randomUUID()}.png").apply { writeText("keep") }
        val project = projectWithLayer("delete-corrupt-guard", Layer(kind = Kind.IMAGE, path = resource.path))
        val corrupt = File(app.filesDir, "projects/stage62-corrupt-${UUID.randomUUID()}.json")
        try {
            assertTrue(store.save(project))
            corrupt.parentFile?.mkdirs()
            corrupt.writeText("{not-json")
            store.delete(project)
            assertTrue("unknown references force conservative no-op", resource.exists())
        } finally {
            corrupt.delete(); resource.delete()
        }
    }

    @Test
    fun undoRedoRestoresReorderDisableAndDeleteOfOperationStack() {
        val ops = listOf(
            ImageOperation(type = ImageOperationType.CROP, parameters = "{\"left\":0.1}"),
            ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR, parameters = "{\"level\":2}"),
            ImageOperation(type = ImageOperationType.FADE, parameters = "{\"fade\":0.2}")
        )
        val layer = Layer(kind = Kind.IMAGE, path = "stage62-path.png", sourcePath = "source.png", imageOperations = ops)
        val project = projectWithLayer("undo-ops-${UUID.randomUUID()}", layer)
        lateinit var vm: AppVm
        onMain { vm = AppVm(app); vm.current = project; vm.panel = PanelId.FRONT }
        fun currentLayer(): Layer = vm.current!!.panel(PanelId.FRONT).layers.single()
        fun mutate(key: String, f: (Layer) -> Layer) = onMain {
            vm.edit(key) { p ->
                val data = p.panel(PanelId.FRONT)
                p.copy(panels = p.panels + (PanelId.FRONT to data.copy(layers = data.layers.map { if (it.id == layer.id) f(it) else it })))
            }
        }

        mutate("stage62-reorder") { it.copy(imageOperations = listOf(ops[2], ops[1], ops[0])) }
        assertEquals(listOf(ops[2].id, ops[1].id, ops[0].id), currentLayer().imageOperations.map { it.id })
        onMain { vm.undoLast() }
        assertEquals(ops.map { it.id }, currentLayer().imageOperations.map { it.id })
        onMain { vm.redoLast() }
        assertEquals(listOf(ops[2].id, ops[1].id, ops[0].id), currentLayer().imageOperations.map { it.id })

        mutate("stage62-disable") { it.copy(imageOperations = it.imageOperations.map { op -> if (op.id == ops[1].id) op.copy(enabled = false) else op }) }
        assertFalse(currentLayer().imageOperations[1].enabled)
        onMain { vm.undoLast() }
        assertTrue(currentLayer().imageOperations[1].enabled)
        onMain { vm.redoLast() }
        assertFalse(currentLayer().imageOperations[1].enabled)

        mutate("stage62-delete") { it.copy(imageOperations = it.imageOperations.filterNot { op -> op.id == ops[2].id }) }
        assertEquals(2, currentLayer().imageOperations.size)
        onMain { vm.undoLast() }
        assertEquals(3, currentLayer().imageOperations.size)
        onMain { vm.redoLast() }
        assertEquals(2, currentLayer().imageOperations.size)
        onMain { vm.flush() }
        vm.store.delete(project)
    }

    @Test
    fun fullscreenPhotoTransformPreservesPinchFocusAndClampsPan() {
        val viewport = IntSize(400, 400)
        val focused = transformPhotoViewport(
            currentScale = 1f, currentOffset = Offset.Zero,
            centroid = Offset(300f, 200f), pan = Offset.Zero, zoomChange = 2f,
            viewport = viewport, imageWidth = 400, imageHeight = 400
        )
        assertEquals(2f, focused.scale, 0.001f)
        assertEquals(-100f, focused.offset.x, 0.01f)
        assertEquals(0f, focused.offset.y, 0.01f)

        val panned = transformPhotoViewport(
            currentScale = focused.scale, currentOffset = focused.offset,
            centroid = Offset(200f, 200f), pan = Offset(1000f, -1000f), zoomChange = 1f,
            viewport = viewport, imageWidth = 400, imageHeight = 400
        )
        assertEquals(200f, panned.offset.x, 0.01f)
        assertEquals(-200f, panned.offset.y, 0.01f)

        val fitImage = transformPhotoViewport(
            currentScale = 1f, currentOffset = Offset.Zero,
            centroid = Offset(200f, 200f), pan = Offset(80f, 60f), zoomChange = 1f,
            viewport = viewport, imageWidth = 800, imageHeight = 200
        )
        assertEquals("fit image cannot be dragged into empty space", Offset.Zero, fitImage.offset)
    }

    @Test
    fun schemaZeroLegacyLayerFieldsRemainEditableAndMigrationIsIdempotent() {
        val base = newProject(DiscFormat.values().first(), "legacy-layer-${UUID.randomUUID()}")
        val layerJson = Layer(kind = Kind.IMAGE, path = "legacy-photo.png", sourcePath = "legacy-photo.png",
            rot = 17f, cropLeft = 0.12f, cropTop = 0.08f, cropRight = 0.91f, cropBottom = 0.88f,
            imgHue = 24f, imgSat = 1.2f).toJson().apply { remove("imageOperations") }
        val json = base.toJson()
        json.remove("schemaVersion")
        json.getJSONObject("panels").getJSONObject(PanelId.FRONT.name)
            .put("layers", org.json.JSONArray().put(layerJson))

        val migrated = Project.fromJson(json)
        assertFalse("migration must operate on a copy, not mutate the source JSON", json.has("schemaVersion"))
        val layer = migrated.panel(PanelId.FRONT).layers.single()
        assertEquals(17f, layer.rot, 0.001f)
        assertEquals(0.12f, layer.cropLeft, 0.001f)
        assertEquals(24f, layer.imgHue, 0.001f)
        val types = ImageProcessingPipeline.renderPlan(layer).orderedOperations.map { it.type }
        assertTrue(types.contains(ImageOperationType.GEOMETRY))
        assertTrue(types.contains(ImageOperationType.CROP))
        assertTrue(types.contains(ImageOperationType.COLOR_GRADE))

        val once = migrated.toJson().toString()
        val twice = Project.fromJson(JSONObject(once)).toJson().toString()
        assertEquals("migration and legacy projection must be stable", once, twice)
        assertEquals("schema-zero becomes current schema", Project.CURRENT_SCHEMA_VERSION, migrated.schemaVersion)
    }
}
