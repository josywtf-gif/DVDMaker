package com.dvdmaker.app

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ImagePipelineStage56Test {
    private val app = ApplicationProvider.getApplicationContext<Application>()

    private fun onMain(block: () -> Unit) = InstrumentationRegistry.getInstrumentation().runOnMainSync(block)

    @Test
    fun undoRedoRestoresOperationStackAndPathTogether() {
        val a = ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR, resultPath = "a.png")
        val b = ImageOperation(type = ImageOperationType.ENHANCE, resultPath = "b.png", inputOperationId = a.id)
        val layer = Layer(kind = Kind.IMAGE, path = "old.png", sourcePath = "src.png", imageOperations = listOf(a))
        val base = newProject(DiscFormat.values().first(), "undo-stack-test")
        val project = base.copy(panels = base.panels + (PanelId.FRONT to base.panel(PanelId.FRONT).copy(layers = listOf(layer))))
        lateinit var vm: AppVm
        onMain {
            vm = AppVm(app)
            vm.current = project
            vm.panel = PanelId.FRONT
        }
        fun front() = vm.current!!.panel(PanelId.FRONT).layers.single()

        var committed = false
        var rejected = true
        onMain {
            val broken = ImageProcessingPipeline.ReplayResult("x.png", listOf(a, b.copy(inputOperationId = "missing")))
            rejected = !vm.commitReplay(layer.id, broken)
        }
        assertTrue("broken chain must be rejected", rejected)
        assertFalse("rejected commit must not create an Undo step", vm.canUndo)
        assertEquals("old.png", front().path)

        onMain { committed = vm.commitReplay(layer.id, ImageProcessingPipeline.ReplayResult("new.png", listOf(a, b))) }
        assertTrue(committed)
        assertEquals("new.png", front().path)
        assertEquals(listOf(a.id, b.id), front().imageOperations.map { it.id })
        assertTrue(vm.canUndo)

        onMain { vm.undoLast() }
        assertEquals("old.png", front().path)
        assertEquals(listOf(a.id), front().imageOperations.map { it.id })
        assertEquals("Undo must restore resource links, not only the stack", "a.png", front().imageOperations.single().resultPath)
        assertTrue(vm.canRedo)

        onMain { vm.redoLast() }
        assertEquals("new.png", front().path)
        assertEquals(listOf(a.id, b.id), front().imageOperations.map { it.id })
    }

    @Test
    fun exportIgnoresInteractivePreviewSimplifications() {
        onMain { Interactive.sliderActive(true) }
        try {
            assertTrue("preview mode is on while a slider is held", Interactive.adjusting)
            Interactive.withFullQuality {
                assertFalse("export must render in full quality", Interactive.adjusting)
                assertTrue(Interactive.isFullQuality)
            }
            assertTrue("flag restored after export", Interactive.adjusting)
            assertFalse(Interactive.isFullQuality)
        } finally {
            onMain { Interactive.sliderActive(false) }
        }
    }
}
