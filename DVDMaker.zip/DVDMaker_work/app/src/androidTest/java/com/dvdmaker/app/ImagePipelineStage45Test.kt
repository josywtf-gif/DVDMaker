package com.dvdmaker.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ImagePipelineStage45Test {
    private val app = ApplicationProvider.getApplicationContext<Application>()

    @Test
    fun pruneDerivedKeepsProtectedAndRecentFilesAndNeverTouchesOriginals() {
        val store = Store(app)
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val old = System.currentTimeMillis() - 2 * 60 * 60_000L
        fun file(name: String, aged: Boolean) = File(img, name).apply {
            writeText("x"); if (aged) setLastModified(old)
        }
        val orphan = file("derived-orphan-test.png", true)
        val undoOnly = file("derived-undo-test.png", true)
        val fresh = file("derived-fresh-test.png", false)
        val original = file("orig-test.jpg", true)
        val removed = store.pruneDerived(setOf(undoOnly.absolutePath))
        assertTrue(removed >= 1)
        assertFalse(orphan.exists())
        assertTrue("Undo-referenced file must survive", undoOnly.exists())
        assertTrue("Recent file may belong to a running operation", fresh.exists())
        assertTrue("Originals are never pruned", original.exists())
        listOf(undoOnly, fresh, original).forEach { it.delete() }
    }

    @Test
    fun restoreInPlaceReturnsLostTextureWithoutChangingAlpha() {
        val src = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
        for (y in 0 until 16) for (x in 0 until 16) src.setPixel(x, y, if ((x + y) % 2 == 0) Color.WHITE else Color.BLACK)
        val base = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.argb(200, 128, 128, 128)) }
        assertTrue(NeuralUpscaler.restoreInPlace(src, base, EnhanceOpts(1f, 0f, false)))
        val p = base.getPixel(2, 2)
        assertTrue("alpha preserved", Color.alpha(p) == 200)
        assertTrue("texture returned", Color.red(p) != 128 || Color.red(base.getPixel(6, 2)) != 128)
        assertTrue("pure opts are a no-op", NeuralUpscaler.restoreInPlace(src, base, EnhanceOpts.PURE))
    }

    @Test
    fun resourcePathsAreStoredRelativeAndLegacyAbsolutePathsStillResolve() {
        Store(app)
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val file = File(img, "derived-path-test.png").apply { writeText("x") }
        val op = ImageOperation(type = ImageOperationType.ENHANCE, assetPath = file.path, resultPath = file.path)
        val json = op.toJson()
        assertTrue(json.getString("resultPath") == "img:derived-path-test.png")
        assertTrue(ImageOperation.fromJson(json).resultPath == file.path)
        // Старый проект с абсолютным путём из другого каталога данных.
        val legacy = org.json.JSONObject(json.toString()).put("resultPath", "/old/data/img/derived-path-test.png")
        assertTrue(ImageOperation.fromJson(legacy).resultPath == file.path)
        // Путь вне img и несуществующий legacy-путь остаются без изменений.
        assertTrue(ResourcePaths.fromStored("/somewhere/else/a.png") == "/somewhere/else/a.png")
        file.delete()
    }

    @Test
    fun missingResultNodesAreDetectedWithoutLosingParameters() {
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val present = File(img, "derived-present-test.png").apply { writeText("x") }
        val lostEnhance = ImageOperation(
            type = ImageOperationType.ENHANCE, parameters = """{"scale":2.0}""",
            resultPath = File(img, "derived-lost-test.png").path
        )
        val maskless = ImageOperation(
            type = ImageOperationType.BACKGROUND_REMOVAL, resultPath = present.path,
            assetPath = File(img, "mask-lost-test.png").path
        )
        val fine = ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR, resultPath = File(img, "derived-gone.png").path)
        val layer = Layer(kind = Kind.IMAGE, sourcePath = "missing-source.png", imageOperations = listOf(lostEnhance, maskless, fine))
        val missing = ImageProcessingPipeline.missingResourceNodes(layer)
        assertTrue(missing.map { it.id } == listOf(lostEnhance.id, maskless.id))
        assertTrue(ImageProcessingPipeline.isRecoverable(lostEnhance))
        assertFalse("mask is lost: needs user action", ImageProcessingPipeline.isRecoverable(maskless))
        assertTrue(layer.imageOperations.first().parameters.contains("\"scale\""))
        present.delete()
    }
}
