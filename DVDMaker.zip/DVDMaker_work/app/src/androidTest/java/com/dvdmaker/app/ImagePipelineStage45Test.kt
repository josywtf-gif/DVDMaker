package com.dvdmaker.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import java.io.File
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ImagePipelineStage45Test {
    private val app = ApplicationProvider.getApplicationContext<Application>()

    @Test
    fun pruneDerivedKeepsProtectedAndRecentFilesAndNeverTouchesOriginals() {
        val store = Store(app)
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val old = System.currentTimeMillis() - 2 * 60 * 60_000L
        fun file(name: String, aged: Boolean) = File(img, name).apply {
            writeText("x"); if (aged) setLastModified(old)
        }
        val orphan = file("derived-orphan-test.png", true)
        val undoOnly = file("derived-undo-test.png", true)
        val fresh = file("derived-fresh-test.png", false)
        val original = file("orig-test.jpg", true)
        val removed = store.pruneDerived(setOf(undoOnly.absolutePath))
        assertTrue(removed >= 1)
        assertFalse(orphan.exists())
        assertTrue("Undo-referenced file must survive", undoOnly.exists())
        assertTrue("Recent file may belong to a running operation", fresh.exists())
        assertTrue("Originals are never pruned", original.exists())
        listOf(undoOnly, fresh, original).forEach { it.delete() }
    }

    @Test
    fun restoreInPlaceReturnsLostTextureWithoutChangingAlpha() {
        val src = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
        for (y in 0 until 16) for (x in 0 until 16) src.setPixel(x, y, if ((x + y) % 2 == 0) Color.WHITE else Color.BLACK)
        val base = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.argb(200, 128, 128, 128)) }
        assertTrue(NeuralUpscaler.restoreInPlace(src, base, EnhanceOpts(1f, 0f, false)))
        val p = base.getPixel(2, 2)
        assertTrue("alpha preserved", Color.alpha(p) == 200)
        assertTrue("texture returned", Color.red(p) != 128 || Color.red(base.getPixel(6, 2)) != 128)
        assertTrue("pure opts are a no-op", NeuralUpscaler.restoreInPlace(src, base, EnhanceOpts.PURE))
    }

    @Test
    fun resourcePathsAreStoredRelativeAndLegacyAbsolutePathsStillResolve() {
        Store(app)
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val file = File(img, "derived-path-test.png").apply { writeText("x") }
        val op = ImageOperation(type = ImageOperationType.ENHANCE, assetPath = file.path, resultPath = file.path)
        val json = op.toJson()
        assertTrue(json.getString("resultPath") == "img:derived-path-test.png")
        assertTrue(ImageOperation.fromJson(json).resultPath == file.path)
        // Старый проект с абсолютным путём из другого каталога данных.
        val legacy = org.json.JSONObject(json.toString()).put("resultPath", "/old/data/img/derived-path-test.png")
        assertTrue(ImageOperation.fromJson(legacy).resultPath == file.path)
        // Путь вне img и несуществующий legacy-путь остаются без изменений.
        assertTrue(ResourcePaths.fromStored("/somewhere/else/a.png") == "/somewhere/else/a.png")
        file.delete()
    }

    @Test
    fun missingResultNodesAreDetectedWithoutLosingParameters() {
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val present = File(img, "derived-present-test.png").apply { writeText("x") }
        val lostEnhance = ImageOperation(
            type = ImageOperationType.ENHANCE, parameters = """{"scale":2.0}""",
            resultPath = File(img, "derived-lost-test.png").path
        )
        val maskless = ImageOperation(
            type = ImageOperationType.BACKGROUND_REMOVAL, resultPath = present.path,
            assetPath = File(img, "mask-lost-test.png").path
        )
        val fine = ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR, resultPath = File(img, "derived-gone.png").path)
        val layer = Layer(kind = Kind.IMAGE, sourcePath = "missing-source.png", imageOperations = listOf(lostEnhance, maskless, fine))
        val missing = ImageProcessingPipeline.missingResourceNodes(layer)
        assertTrue(missing.map { it.id } == listOf(lostEnhance.id, maskless.id))
        assertTrue(ImageProcessingPipeline.isRecoverable(lostEnhance))
        assertFalse("mask is lost: needs user action", ImageProcessingPipeline.isRecoverable(maskless))
        assertTrue(layer.imageOperations.first().parameters.contains("\"scale\""))
        present.delete()
    }

    @Test
    fun commitReplayWritesStackAndPathTogetherAndRejectsBrokenDependencies() {
        val a = ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR, resultPath = "a.png")
        val b = ImageOperation(type = ImageOperationType.ENHANCE, resultPath = "b.png", inputOperationId = a.id)
        val layer = Layer(kind = Kind.IMAGE, path = "old.png", sourcePath = "src.png")
        val ok = ImageProcessingPipeline.commitReplay(
            layer, ImageProcessingPipeline.ReplayResult("new.png", listOf(a, b))
        ) { it.copy(enhanceDetail = 0.5f) }
        assertTrue(ok != null && ok.path == "new.png" && ok.imageOperations == listOf(a, b) && ok.enhanceDetail == 0.5f)
        val broken = b.copy(inputOperationId = "missing-id")
        assertTrue(
            ImageProcessingPipeline.commitReplay(layer, ImageProcessingPipeline.ReplayResult("x.png", listOf(a, broken))) == null
        )
    }

    @Test
    fun projectSchemaVersionsMigrateIdempotentlyAndFutureIsReadOnly() {
        val json = newProject(DiscFormat.values().first(), "schema-test").toJson()
        json.remove("schemaVersion")
        val legacy = Project.fromJson(json)
        assertTrue(legacy.schemaVersion == Project.CURRENT_SCHEMA_VERSION && !legacy.readOnly)
        val once = legacy.toJson().toString()
        assertTrue("re-migration must not change JSON", Project.fromJson(JSONObject(once)).toJson().toString() == once)
        val current = Project.fromJson(JSONObject(once))
        assertTrue(current.toJson().getInt("schemaVersion") == Project.CURRENT_SCHEMA_VERSION)
        val future = Project.fromJson(JSONObject(once).put("schemaVersion", Project.CURRENT_SCHEMA_VERSION + 1))
        assertTrue(future.readOnly)
        assertFalse("future project must not be overwritten", Store(app).save(future))
    }

    @Test
    fun cleanStaleTempRemovesOnlyOldTempFiles() {
        val store = Store(app)
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val old = System.currentTimeMillis() - 2 * 60 * 60_000L
        val oldTmp = File(img, "x-old.png.tmp").apply { writeText("x"); setLastModified(old) }
        val freshTmp = File(img, "x-fresh.png.tmp").apply { writeText("x") }
        val oldAi = File(app.cacheDir, "dvd-ai-input-old.png").apply { writeText("x"); setLastModified(old) }
        val keep = File(img, "orig-keep-test.png").apply { writeText("x"); setLastModified(old) }
        assertTrue(store.cleanStaleTemp() >= 2)
        assertFalse(oldTmp.exists()); assertFalse(oldAi.exists())
        assertTrue(freshTmp.exists()); assertTrue(keep.exists())
        freshTmp.delete(); keep.delete()
    }

    @Test
    fun imagePathsCoverOperationResourcesOfEveryLayerKind() {
        val op = ImageOperation(type = ImageOperationType.ENHANCE, assetPath = "/x/derived-base.png", resultPath = "/x/derived-res.png")
        val image = Layer(kind = Kind.IMAGE, path = "/x/derived-res.png", sourcePath = "/x/src.jpg", imageOperations = listOf(op))
        val other = Layer(kind = Kind.TEXT, path = "/x/mask-other.png")
        val project = newProject(DiscFormat.values().first(), "paths-test").let {
            it.copy(canvasLayers = listOf(image, other))
        }
        val paths = project.imagePaths()
        assertTrue(paths.containsAll(listOf("/x/derived-base.png", "/x/derived-res.png", "/x/src.jpg", "/x/mask-other.png")))
    }

    @Test
    fun mixedStackSurvivesSaveAndReopenWithOrderEnabledParamsAndResources() {
        val store = Store(app)
        val img = File(app.filesDir, "img").apply { mkdirs() }
        val enhanceBase = File(img, "derived-reopen-base.png").apply { writeText("x") }
        val enhanceRes = File(img, "derived-reopen-res.png").apply { writeText("x") }
        val mask = File(img, "mask-reopen.png").apply { writeText("x") }
        val bgRes = File(img, "derived-reopen-bg.png").apply { writeText("x") }
        val enhance = ImageOperation(
            type = ImageOperationType.ENHANCE, parameters = """{"scale":2.0,"inputFingerprint":"fp1"}""",
            assetPath = enhanceBase.path, resultPath = enhanceRes.path
        )
        val blur = ImageOperation(
            type = ImageOperationType.GAUSSIAN_BLUR, enabled = false, parameters = """{"level":2}""",
            inputOperationId = enhance.id
        )
        val bg = ImageOperation(
            type = ImageOperationType.BACKGROUND_REMOVAL, assetPath = mask.path, resultPath = bgRes.path,
            inputOperationId = blur.id
        )
        val layer = Layer(
            kind = Kind.IMAGE, path = bgRes.path, sourcePath = "/x/src.jpg", enhanceSourcePath = "/x/src.jpg",
            enhanceScale = 2f, enhanceDetail = 0.3f, enhanceGrain = 0.7f,
            imageOperations = listOf(enhance, blur, bg)
        )
        val project = newProject(DiscFormat.values().first(), "reopen-test").let { it.copy(canvasLayers = listOf(layer)) }
        try {
            assertTrue(store.save(project))
            val reopened = store.loadAll().first { it.id == project.id }.canvasLayers.single()
            assertTrue(reopened.imageOperations.map { it.id } == listOf(enhance.id, blur.id, bg.id))
            assertTrue(reopened.imageOperations.map { it.enabled } == listOf(true, false, true))
            assertTrue(reopened.imageOperations.map { it.inputOperationId } == listOf("", enhance.id, blur.id))
            assertTrue(reopened.imageOperations[0].parameters.contains("fp1"))
            assertTrue(reopened.imageOperations[0].assetPath == enhanceBase.path)
            assertTrue(reopened.imageOperations[2].assetPath == mask.path && reopened.imageOperations[2].resultPath == bgRes.path)
            assertTrue(reopened.path == bgRes.path && reopened.enhanceDetail == 0.3f && reopened.enhanceGrain == 0.7f)
            assertTrue("Reopen must not report lost resources", ImageProcessingPipeline.missingResourceNodes(reopened).isEmpty())
        } finally {
            store.delete(project)
            listOf(enhanceBase, enhanceRes, mask, bgRes).forEach { it.delete() }
        }
    }
}
