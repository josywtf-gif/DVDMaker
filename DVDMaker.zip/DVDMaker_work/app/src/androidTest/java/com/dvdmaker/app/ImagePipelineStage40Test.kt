package com.dvdmaker.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import java.io.File
import kotlinx.coroutines.runBlocking
import java.util.UUID
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ImagePipelineStage40Test {
    @Test
    fun mixedOperationPlanPreservesSerializedOrderAndDependencies() {
        val crop = ImageOperation(type = ImageOperationType.CROP, parameters = JSONObject()
            .put("left", 0.1).put("top", 0.1).put("right", 0.9).put("bottom", 0.9).toString())
        val enhance = ImageOperation(type = ImageOperationType.ENHANCE, inputOperationId = crop.id)
        val fade = ImageOperation(type = ImageOperationType.FADE, inputOperationId = enhance.id)
        val blur = ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR, inputOperationId = fade.id)
        val remove = ImageOperation(type = ImageOperationType.BACKGROUND_REMOVAL, inputOperationId = blur.id)
        val layer = Layer(kind = Kind.IMAGE, sourcePath = "missing-test-source.png",
            imageOperations = listOf(crop, enhance, fade, blur, remove))

        val plan = ImageProcessingPipeline.renderPlan(layer)
        assertEquals(listOf(
            ImageOperationType.CROP, ImageOperationType.ENHANCE, ImageOperationType.FADE,
            ImageOperationType.GAUSSIAN_BLUR, ImageOperationType.BACKGROUND_REMOVAL
        ), plan.orderedOperations.map { it.type })
        assertTrue("all explicit input links should remain valid", plan.execution.all { it.dependencyValid })
        assertEquals("crop", plan.execution.first().operation.type)
        assertEquals("background-removal", plan.execution.last().operation.type)
    }

    @Test
    fun mixedCropEnhanceFadeBlurPrefixMaterializesAtBackgroundRemoval() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val store = Store(context)
        val source = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888).apply {
            val pixels = IntArray(16) { i ->
                val alpha = when (i) { 6 -> 128; 10 -> 0; else -> 255 }
                Color.argb(alpha, i * 11, 255 - i * 9, i * 7)
            }
            setPixels(pixels, 0, 4, 0, 0, 4, 4)
        }
        val sourcePath = store.saveBitmap(source, png = true, prefix = "stage40-source-")!!
        val cropRaster = Bitmap.createBitmap(source, 1, 1, 2, 2)
        val enhancedPath = store.saveBitmap(cropRaster, png = true, prefix = "stage40-enhanced-")!!
        val crop = ImageOperation(type = ImageOperationType.CROP, parameters = JSONObject()
            .put("left", 0.25).put("top", 0.25).put("right", 0.75).put("bottom", 0.75).toString())
        val enhance = ImageOperation(type = ImageOperationType.ENHANCE,
            parameters = JSONObject().put("inputFingerprint", ImageOperationRenderer.bitmapFingerprint(cropRaster)).toString(),
            resultPath = enhancedPath, inputOperationId = crop.id)
        val fade = ImageOperation(type = ImageOperationType.FADE,
            parameters = JSONObject().put("fade", 0.15).put("fadeStyle", 0).put("fadeEdges", 15).toString(),
            inputOperationId = enhance.id)
        val blur = ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR,
            parameters = JSONObject().put("sigmaFrac", 0.02).toString(), inputOperationId = fade.id)
        val edge = ImageOperation(type = ImageOperationType.EDGE_INTEGRATION,
            parameters = JSONObject().put("edgeClean", 0.0).put("lightWrap", 0.6)
                .put("wrapAuto", true).put("wrapColor", Color.WHITE).toString(),
            inputOperationId = blur.id)
        val remove = ImageOperation(type = ImageOperationType.BACKGROUND_REMOVAL,
            inputOperationId = edge.id)
        val layer = Layer(kind = Kind.IMAGE, path = sourcePath, sourcePath = sourcePath,
            imageLightWrap = 0.6f, imageWrapAuto = true,
            imageOperations = listOf(crop, enhance, fade, blur, edge, remove))
        val lower = Layer(kind = Kind.RECT, name = "Backdrop", color = Color.WHITE)
        val project = Project("stage40-prefix-${UUID.randomUUID()}", "Prefix backdrop", DiscFormat.DVD,
            mapOf(PanelId.FRONT to PanelData(Color.BLACK, Color.WHITE, layers = listOf(lower, layer))), 1L)
        val backdrop = materializationBackdrop(project, PanelId.FRONT, layer)
            ?: throw AssertionError("real lower-layer backdrop must be available")
        val materialized = ImageOperationRenderer.materializeBeforeOperation(
            context, store, layer, ImageOperationType.BACKGROUND_REMOVAL, backdrop = backdrop
        ) ?: throw AssertionError("mixed operation prefix must materialize")
        try {
            assertEquals(2, materialized.bitmap.width)
            assertEquals(2, materialized.bitmap.height)
            assertTrue(materialized.fingerprint.isNotBlank())
            assertTrue(materialized.operations[3].resultPath.isNotBlank())
        } finally {
            materialized.close()
            source.recycle()
            cropRaster.recycle()
            File(sourcePath).delete()
            File(enhancedPath).delete()
        }
    }

    @Test
    fun backdropSnapshotUsesLowerPanelLayersForLightWrap() {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val store = Store(context)
        val lower = Layer(kind = Kind.RECT, name = "Backdrop", color = Color.WHITE)
        val source = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.GRAY) }
        val sourcePath = store.saveBitmap(source, png = true, prefix = "stage40-backdrop-")!!
        val selected = Layer(kind = Kind.IMAGE, path = sourcePath, sourcePath = sourcePath,
            imageLightWrap = 0.6f, imageWrapAuto = true)
        val project = Project("stage40-backdrop-${UUID.randomUUID()}", "Backdrop", DiscFormat.DVD,
            mapOf(PanelId.FRONT to PanelData(Color.BLACK, Color.WHITE, layers = listOf(lower, selected))), 1L)
        try {
            assertNotNull(materializationBackdrop(project, PanelId.FRONT, selected))
        } finally {
            source.recycle()
            File(sourcePath).delete()
        }
    }

    @Test
    fun oldProjectJsonLoadsWithSafeDefaultsAndCanBeReopened() {
        val oldJson = JSONObject().apply {
            put("id", "legacy-stage40")
            put("name", "Legacy project")
            put("format", "DVD")
            put("updated", 1L)
            put("panels", JSONObject().put("FRONT", JSONObject().put("c1", -1).put("c2", -1)
                .put("layers", org.json.JSONArray().put(JSONObject().put("id", "legacy-image")
                    .put("kind", "IMAGE").put("path", "missing.png").put("widthMm", 80.0)))))
        }
        val project = Project.fromJson(oldJson)
        val context = ApplicationProvider.getApplicationContext<Application>()
        val store = Store(context)
        assertTrue(store.save(project))
        val loaded = store.loadAll().first { it.id == project.id }
        assertEquals("legacy-stage40", loaded.id)
        assertEquals(1, project.panel(PanelId.FRONT).layers.size)
        val reopened = Project.fromJson(loaded.toJson())
        assertEquals(project.panel(PanelId.FRONT).layers.first().id,
            reopened.panel(PanelId.FRONT).layers.first().id)
        assertTrue(reopened.panel(PanelId.FRONT).layers.first().imageOperations.isEmpty())
        val legacyFade = ImageOperation.fromJson(JSONObject().put("type", ImageOperationType.FADE)
            .put("parameters", JSONObject().put("fade", 0.2).put("fadeBlend", 7).toString()))
        assertTrue(JSONObject(legacyFade.parameters).has("fadeBlend").not())
        store.delete(project)
    }

    @Test
    fun undoRedoRestoresProjectStateAfterOpen() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = AppVm(app)
        val operation = ImageOperation(type = ImageOperationType.ENHANCE, resultPath = "before.png")
        val layer = Layer(kind = Kind.IMAGE, path = "source.png", sourcePath = "source.png",
            imageOperations = listOf(operation))
        val project = Project(
            id = "undo-redo-stage40-${UUID.randomUUID()}", name = "Undo test", format = DiscFormat.DVD,
            panels = mapOf(PanelId.FRONT to PanelData(android.graphics.Color.BLACK,
                android.graphics.Color.BLACK, layers = listOf(layer))), updated = 1L
        )
        vm.open(project)
        assertNotNull(vm.current)
        vm.updateLayer(layer.id, "stage40-test") {
            it.copy(path = "after.png", imageOperations = listOf(operation.copy(resultPath = "after.png")))
        }
        assertEquals("after.png", vm.current!!.panel(PanelId.FRONT).layers.first().path)
        vm.undoLast()
        assertEquals("source.png", vm.current!!.panel(PanelId.FRONT).layers.first().path)
        assertEquals("before.png", vm.current!!.panel(PanelId.FRONT).layers.first().imageOperations.first().resultPath)
        vm.redoLast()
        assertEquals("after.png", vm.current!!.panel(PanelId.FRONT).layers.first().path)
        assertEquals("after.png", vm.current!!.panel(PanelId.FRONT).layers.first().imageOperations.first().resultPath)
        assertTrue(vm.flush())
        val reopened = vm.store.loadAll().first { it.id == vm.current!!.id }
        assertEquals("after.png", reopened.panel(PanelId.FRONT).layers.first().imageOperations.first().resultPath)
        vm.store.delete(vm.current!!)
    }
}
