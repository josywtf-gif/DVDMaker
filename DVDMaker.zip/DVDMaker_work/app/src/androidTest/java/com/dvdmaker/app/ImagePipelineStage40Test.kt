package com.dvdmaker.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.RectF
import android.graphics.Paint
import java.util.concurrent.CancellationException
import java.io.File
import kotlinx.coroutines.runBlocking
import java.util.UUID
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ImagePipelineStage40Test {
    @Test
    fun rmbgOutputIsMinMaxNormalizedBeforeObjectDetection() {
        // RMBG may return a valid foreground mask in a narrow absolute range.
        val raw = FloatArray(40 * 40) { 0.12f }
        for (y in 10 until 30) for (x in 10 until 30) raw[y * 40 + x] = 0.18f
        BgRemover.normalizeMaskInPlace(raw)
        assertEquals(0f, raw[0], 1e-5f)
        assertEquals(1f, raw[20 * 40 + 20], 1e-5f)
        val edit = BgEdit(BgRemover.Masks(40, 40, raw, raw.copyOf()))
        assertEquals("foreground component should be detected", 1, edit.objects.size)
        assertTrue(edit.objects.first().area >= 24)
    }

    @Test
    fun rmbgConstantOrInvalidMaskDoesNotCreateFalseObjects() {
        val raw = FloatArray(32 * 32) { 0.2f }
        raw[0] = Float.NaN
        BgRemover.normalizeMaskInPlace(raw)
        assertTrue(raw.all { it == 0f })
        assertTrue(BgEdit(BgRemover.Masks(32, 32, raw, raw.copyOf())).objects.isEmpty())
    }
    @Test
    fun mixedOperationPlanPreservesSerializedOrderAndDependencies() {
        val crop = ImageOperation(type = ImageOperationType.CROP, parameters = JSONObject()
            .put("left", 0.1).put("top", 0.1).put("right", 0.9).put("bottom", 0.9).toString())
        val enhance = ImageOperation(type = ImageOperationType.ENHANCE, inputOperationId = crop.id)
        val fade = ImageOperation(type = ImageOperationType.FADE, inputOperationId = enhance.id)
        val blur = ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR, inputOperationId = fade.id)
        val remove = ImageOperation(type = ImageOperationType.BACKGROUND_REMOVAL, inputOperationId = blur.id)
        val layer = Layer(kind = Kind.IMAGE, sourcePath = "missing-test-source.png",
            imageOperations = listOf(crop, enhance, fade, blur, remove))

        val plan = ImageProcessingPipeline.renderPlan(layer)
        assertEquals(listOf(
            ImageOperationType.CROP, ImageOperationType.ENHANCE, ImageOperationType.FADE,
            ImageOperationType.GAUSSIAN_BLUR, ImageOperationType.BACKGROUND_REMOVAL
        ), plan.orderedOperations.map { it.type })
        assertTrue("all explicit input links should remain valid", plan.execution.all { it.dependencyValid })
        assertEquals("crop", plan.execution.first().operation.type)
        assertEquals("background-removal", plan.execution.last().operation.type)
    }

    @Test
    fun mixedCropEnhanceFadeBlurPrefixMaterializesAtBackgroundRemoval() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val store = Store(context)
        val source = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888).apply {
            val pixels = IntArray(16) { i ->
                val alpha = when (i) { 6 -> 128; 10 -> 0; else -> 255 }
                Color.argb(alpha, i * 11, 255 - i * 9, i * 7)
            }
            setPixels(pixels, 0, 4, 0, 0, 4, 4)
        }
        val sourcePath = store.saveBitmap(source, png = true, prefix = "stage40-source-")!!
        val cropRaster = Bitmap.createBitmap(source, 1, 1, 2, 2)
        val enhancedPath = store.saveBitmap(cropRaster, png = true, prefix = "stage40-enhanced-")!!
        val crop = ImageOperation(type = ImageOperationType.CROP, parameters = JSONObject()
            .put("left", 0.25).put("top", 0.25).put("right", 0.75).put("bottom", 0.75).toString())
        val enhance = ImageOperation(type = ImageOperationType.ENHANCE,
            parameters = JSONObject().put("inputFingerprint", ImageOperationRenderer.bitmapFingerprint(cropRaster)).toString(),
            resultPath = enhancedPath, inputOperationId = crop.id)
        val fade = ImageOperation(type = ImageOperationType.FADE,
            parameters = JSONObject().put("fade", 0.15).put("fadeStyle", 0).put("fadeEdges", 15).toString(),
            inputOperationId = enhance.id)
        val blur = ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR,
            parameters = JSONObject().put("sigmaFrac", 0.02).toString(), inputOperationId = fade.id)
        val edge = ImageOperation(type = ImageOperationType.EDGE_INTEGRATION,
            parameters = JSONObject().put("edgeClean", 0.0).put("lightWrap", 0.6)
                .put("wrapAuto", true).put("wrapColor", Color.WHITE).toString(),
            inputOperationId = blur.id)
        val remove = ImageOperation(type = ImageOperationType.BACKGROUND_REMOVAL,
            inputOperationId = edge.id)
        val layer = Layer(kind = Kind.IMAGE, path = sourcePath, sourcePath = sourcePath,
            imageLightWrap = 0.6f, imageWrapAuto = true,
            imageOperations = listOf(crop, enhance, fade, blur, edge, remove))
        val lower = Layer(kind = Kind.RECT, name = "Backdrop", color = Color.WHITE)
        val project = Project("stage40-prefix-${UUID.randomUUID()}", "Prefix backdrop", DiscFormat.DVD,
            mapOf(PanelId.FRONT to PanelData(Color.BLACK, Color.WHITE, layers = listOf(lower, layer))), 1L)
        val backdrop = materializationBackdrop(project, PanelId.FRONT, layer)
            ?: throw AssertionError("real lower-layer backdrop must be available")
        val materialized = ImageOperationRenderer.materializeBeforeOperation(
            context, store, layer, ImageOperationType.BACKGROUND_REMOVAL, backdrop = backdrop
        ) ?: throw AssertionError("mixed operation prefix must materialize")
        try {
            assertEquals(2, materialized.bitmap.width)
            assertEquals(2, materialized.bitmap.height)
            assertTrue(materialized.fingerprint.isNotBlank())
            assertTrue(materialized.operations[3].resultPath.isNotBlank())
        } finally {
            materialized.close()
            source.recycle()
            cropRaster.recycle()
            File(sourcePath).delete()
            File(enhancedPath).delete()
        }
    }

    @Test
    fun backdropSnapshotUsesLowerPanelLayersForLightWrap() {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val store = Store(context)
        val lower = Layer(kind = Kind.RECT, name = "Backdrop", color = Color.WHITE)
        val source = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.GRAY) }
        val sourcePath = store.saveBitmap(source, png = true, prefix = "stage40-backdrop-")!!
        val selected = Layer(kind = Kind.IMAGE, path = sourcePath, sourcePath = sourcePath,
            imageLightWrap = 0.6f, imageWrapAuto = true)
        val project = Project("stage40-backdrop-${UUID.randomUUID()}", "Backdrop", DiscFormat.DVD,
            mapOf(PanelId.FRONT to PanelData(Color.BLACK, Color.WHITE, layers = listOf(lower, selected))), 1L)
        try {
            assertNotNull(materializationBackdrop(project, PanelId.FRONT, selected))
        } finally {
            source.recycle()
            File(sourcePath).delete()
        }
    }

    @Test
    fun changingBlurReusesCropAndGeometryPrefix() {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val store = Store(context)
        val source = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888).apply {
            val px = IntArray(48 * 48) { i -> Color.rgb(i % 255, (i / 48) % 255, (i * 7) % 255) }
            setPixels(px, 0, 48, 0, 0, 48, 48)
        }
        val path = store.saveBitmap(source, png = true, prefix = "stage40-prefix-cache-")!!
        val crop = ImageOperation(type = ImageOperationType.CROP, parameters = JSONObject()
            .put("left", 0.1).put("top", 0.1).put("right", 0.9).put("bottom", 0.9).toString())
        val geometry = ImageOperation(type = ImageOperationType.GEOMETRY,
            parameters = JSONObject().put("rotation", 0).toString(), inputOperationId = crop.id)
        val blur = ImageOperation(type = ImageOperationType.GAUSSIAN_BLUR,
            parameters = JSONObject().put("sigmaFrac", 0.01).toString(), inputOperationId = geometry.id)
        val layer = Layer(kind = Kind.IMAGE, path = path, sourcePath = path,
            imageOperations = listOf(crop, geometry, blur))
        val target = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
        try {
            ImageOperationRenderer.resetPrefixCacheStatsForTest()
            ImageOperationRenderer.drawImageLayer(Canvas(target), layer, 1f,
                renderPlan = ImageProcessingPipeline.renderPlan(layer))
            val changedBlur = blur.copy(parameters = JSONObject().put("sigmaFrac", 0.03).toString())
            val changedLayer = layer.copy(imageOperations = listOf(crop, geometry, changedBlur))
            ImageOperationRenderer.drawImageLayer(Canvas(target), changedLayer, 1f,
                renderPlan = ImageProcessingPipeline.renderPlan(changedLayer))
            assertTrue("crop and geometry prefixes should be reused", ImageOperationRenderer.prefixCacheHitsForTest() >= 2)
        } finally {
            target.recycle()
            source.recycle()
            File(path).delete()
            ImageOperationRenderer.trimMemory()
        }
    }

    @Test
    fun blurCooperativelyStopsWhenSuperseded() {
        val source = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLUE) }
        try {
            var cancelled = false
            try {
                Blur.gaussianPreserveAlpha(source, 0.04f, isCancelled = { true })
            } catch (_: CancellationException) {
                cancelled = true
            }
            assertTrue("blur must stop when its render generation is obsolete", cancelled)
        } finally {
            source.recycle()
        }
    }

    @Test
    fun materializationBackdropMatchesCanonicalPreviewAnalysis() {
        val source = Bitmap.createBitmap(12, 12, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.GRAY) }
        val context = ApplicationProvider.getApplicationContext<Application>()
        val path = Store(context).saveBitmap(source, true, "stage40-bd-match-")!!
        val lower = Layer(kind = Kind.RECT, name = "Backdrop", color = Color.WHITE)
        val selected = Layer(kind = Kind.IMAGE, path = path, sourcePath = path,
            imageLightWrap = 0.6f, imageWrapAuto = true)
        val project = Project("stage40-bd-match-${UUID.randomUUID()}", "Backdrop parity", DiscFormat.DVD,
            mapOf(PanelId.FRONT to PanelData(Color.BLACK, Color.WHITE, layers = listOf(lower, selected))), 1L)
        try {
            val materialized = materializationBackdrop(project, PanelId.FRONT, selected)!!
            val panel = project.panel(PanelId.FRONT)
            val (widthMm, heightMm) = project.format.size(PanelId.FRONT)
            val width = 800f // обычный экранный preview; analyzeBackdrop сводит обе стороны к общей 96 px выборке
            val height = width * heightMm / widthMm
            val previewEquivalent = analyzeBackdrop(panel.copy(layers = panel.layers.take(1)), selected,
                width, height, width / widthMm)!!
            assertEquals(materialized.color, previewEquivalent.color)
            assertEquals(materialized.lx, previewEquivalent.lx, 1e-5f)
            assertEquals(materialized.ly, previewEquivalent.ly, 1e-5f)
            assertEquals(materialized.amount, previewEquivalent.amount, 1e-5f)
            assertEquals(materialized.strength, previewEquivalent.strength, 1e-5f)
        } finally {
            source.recycle()
            File(path).delete()
        }
    }

    @Test
    fun oldProjectJsonLoadsWithSafeDefaultsAndCanBeReopened() {
        val oldJson = JSONObject().apply {
            put("id", "legacy-stage40")
            put("name", "Legacy project")
            put("format", "DVD")
            put("updated", 1L)
            put("panels", JSONObject().put("FRONT", JSONObject().put("c1", -1).put("c2", -1)
                .put("layers", org.json.JSONArray().put(JSONObject().put("id", "legacy-image")
                    .put("kind", "IMAGE").put("path", "missing.png").put("widthMm", 80.0)))))
        }
        val project = Project.fromJson(oldJson)
        val context = ApplicationProvider.getApplicationContext<Application>()
        val store = Store(context)
        assertTrue(store.save(project))
        val loaded = store.loadAll().first { it.id == project.id }
        assertEquals("legacy-stage40", loaded.id)
        assertEquals(1, project.panel(PanelId.FRONT).layers.size)
        val reopened = Project.fromJson(loaded.toJson())
        assertEquals(project.panel(PanelId.FRONT).layers.first().id,
            reopened.panel(PanelId.FRONT).layers.first().id)
        assertTrue(reopened.panel(PanelId.FRONT).layers.first().imageOperations.isEmpty())
        val legacyFade = ImageOperation.fromJson(JSONObject().put("type", ImageOperationType.FADE)
            .put("parameters", JSONObject().put("fade", 0.2).put("fadeBlend", 7).toString()))
        assertTrue(JSONObject(legacyFade.parameters).has("fadeBlend").not())
        store.delete(project)
    }

    @Test
    fun undoRedoRestoresProjectStateAfterOpen() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = AppVm(app)
        val operation = ImageOperation(type = ImageOperationType.ENHANCE, resultPath = "before.png")
        val layer = Layer(kind = Kind.IMAGE, path = "source.png", sourcePath = "source.png",
            imageOperations = listOf(operation))
        val project = Project(
            id = "undo-redo-stage40-${UUID.randomUUID()}", name = "Undo test", format = DiscFormat.DVD,
            panels = mapOf(PanelId.FRONT to PanelData(android.graphics.Color.BLACK,
                android.graphics.Color.BLACK, layers = listOf(layer))), updated = 1L
        )
        vm.open(project)
        assertNotNull(vm.current)
        vm.updateLayer(layer.id, "stage40-test") {
            it.copy(path = "after.png", imageOperations = listOf(operation.copy(resultPath = "after.png")))
        }
        assertEquals("after.png", vm.current!!.panel(PanelId.FRONT).layers.first().path)
        vm.undoLast()
        assertEquals("source.png", vm.current!!.panel(PanelId.FRONT).layers.first().path)
        assertEquals("before.png", vm.current!!.panel(PanelId.FRONT).layers.first().imageOperations.first().resultPath)
        vm.redoLast()
        assertEquals("after.png", vm.current!!.panel(PanelId.FRONT).layers.first().path)
        assertEquals("after.png", vm.current!!.panel(PanelId.FRONT).layers.first().imageOperations.first().resultPath)
        assertTrue(vm.flush())
        val reopened = vm.store.loadAll().first { it.id == vm.current!!.id }
        assertEquals("after.png", reopened.panel(PanelId.FRONT).layers.first().imageOperations.first().resultPath)
        vm.store.delete(vm.current!!)
    }
}
