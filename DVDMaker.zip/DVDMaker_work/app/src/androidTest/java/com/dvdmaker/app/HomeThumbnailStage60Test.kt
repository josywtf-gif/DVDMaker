package com.dvdmaker.app

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class HomeThumbnailStage60Test {
    @Test
    fun concurrentHomeThumbnailsRenderWholeOrderedImageLayers() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Application>()
        val store = Store(context)

        fun project(color: Int, name: String): Project {
            val source = Bitmap.createBitmap(96, 64, Bitmap.Config.ARGB_8888).apply { eraseColor(color) }
            val path = store.saveBitmap(source, png = true, prefix = "stage60-thumb-")!!
            source.recycle()
            val crop = ImageOperation(
                type = ImageOperationType.CROP,
                parameters = JSONObject().put("left", 0.12).put("top", 0.08)
                    .put("right", 0.88).put("bottom", 0.92).toString()
            )
            val geometry = ImageOperation(
                type = ImageOperationType.GEOMETRY,
                parameters = JSONObject().put("rotation", 13.0).toString(),
                inputOperationId = crop.id
            )
            val image = Layer(
                kind = Kind.IMAGE, path = path, sourcePath = path, originalPath = path,
                x = 0.5f, y = 0.5f, widthMm = 82f,
                imageOperations = listOf(crop, geometry)
            )
            val panels = PanelId.values().associateWith { id ->
                PanelData(Color.WHITE, Color.WHITE,
                    layers = if (id == PanelId.FRONT) listOf(image) else emptyList())
            }
            return Project(UUID.randomUUID().toString(), name, DiscFormat.BLURAY, panels, System.currentTimeMillis())
        }

        fun containsDominant(bitmap: Bitmap, color: Int): Boolean {
            val pixels = IntArray(bitmap.width * bitmap.height)
            bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
            val r = Color.red(color); val g = Color.green(color); val b = Color.blue(color)
            return pixels.count {
                Color.red(it) > r - 25 && Color.red(it) < r + 25 &&
                    Color.green(it) > g - 25 && Color.green(it) < g + 25 &&
                    Color.blue(it) > b - 25 && Color.blue(it) < b + 25
            } > 20
        }

        val red = project(Color.rgb(220, 25, 35), "red")
        val green = project(Color.rgb(20, 190, 65), "green")
        val first = async(Dispatchers.Default) { ProjectThumbnailRenderer.render(red) }
        val second = async(Dispatchers.Default) { ProjectThumbnailRenderer.render(green) }
        val redThumb = first.await()
        val greenThumb = second.await()
        try {
            assertTrue("red project image must be fully present in thumbnail", containsDominant(redThumb, Color.rgb(220, 25, 35)))
            assertTrue("green project image must be fully present in thumbnail", containsDominant(greenThumb, Color.rgb(20, 190, 65)))
            assertNotEquals(ProjectThumbnailRenderer.cacheKey(red), ProjectThumbnailRenderer.cacheKey(green))
        } finally {
            redThumb.recycle()
            greenThumb.recycle()
        }
    }
}
