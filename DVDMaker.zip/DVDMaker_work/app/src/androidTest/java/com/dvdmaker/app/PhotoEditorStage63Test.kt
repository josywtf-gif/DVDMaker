package com.dvdmaker.app

import androidx.test.ext.junit.runners.AndroidJUnit4
import android.graphics.Bitmap
import android.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PhotoEditorStage63Test {
    @Test
    fun cornerHandleChangesBothAxes() {
        val next = updateCropSelection(CropSelection(0.1f, 0.1f, 0.9f, 0.9f), CropHandle.TOP_LEFT, 0.1f, 0.2f)
        assertEquals(0.2f, next.left, 0.0001f)
        assertEquals(0.3f, next.top, 0.0001f)
        assertEquals(0.9f, next.right, 0.0001f)
        assertEquals(0.9f, next.bottom, 0.0001f)
    }

    @Test
    fun sideHandleChangesOnlyItsOwnAxis() {
        val initial = CropSelection(0.1f, 0.1f, 0.9f, 0.9f)
        val next = updateCropSelection(initial, CropHandle.RIGHT, -0.2f, 0.15f)
        assertEquals(0.1f, next.left, 0.0001f)
        assertEquals(0.1f, next.top, 0.0001f)
        assertEquals(0.7f, next.right, 0.0001f)
        assertEquals(0.9f, next.bottom, 0.0001f)
    }

    @Test
    fun draggingInsideFrameMovesWholeSelectionAndPreservesSize() {
        val initial = CropSelection(0.2f, 0.15f, 0.8f, 0.85f)
        val next = updateCropSelection(initial, CropHandle.MOVE, 0.1f, -0.05f)
        assertEquals(0.3f, next.left, 0.0001f)
        assertEquals(0.1f, next.top, 0.0001f)
        assertEquals(initial.width, next.width, 0.0001f)
        assertEquals(initial.height, next.height, 0.0001f)
    }

    @Test
    fun cropCannotEscapePhotoOrBecomeSmallerThanMinimum() {
        val initial = CropSelection(0.1f, 0.1f, 0.9f, 0.9f)
        val outside = updateCropSelection(initial, CropHandle.BOTTOM_RIGHT, 5f, 5f)
        assertEquals(1f, outside.right, 0.0001f)
        assertEquals(1f, outside.bottom, 0.0001f)
        val tooSmall = updateCropSelection(initial, CropHandle.TOP_LEFT, 5f, 5f)
        assertTrue(tooSmall.width >= 0.05f)
        assertTrue(tooSmall.height >= 0.05f)
        assertTrue(tooSmall.left >= 0f && tooSmall.top >= 0f)
        assertTrue(tooSmall.right <= 1f && tooSmall.bottom <= 1f)
    }


    @Test
    fun everySideHandleChangesOnlyItsOwnAxis() {
        val initial = CropSelection(0.1f, 0.1f, 0.9f, 0.9f)
        val top = updateCropSelection(initial, CropHandle.TOP, 0.2f, 0.1f)
        val bottom = updateCropSelection(initial, CropHandle.BOTTOM, 0.2f, -0.1f)
        val left = updateCropSelection(initial, CropHandle.LEFT, 0.1f, 0.2f)
        assertEquals(initial.left, top.left, 0.0001f)
        assertEquals(initial.right, top.right, 0.0001f)
        assertEquals(initial.top, top.top, 0.0001f)
        assertEquals(initial.bottom, bottom.bottom, 0.0001f)
        assertEquals(initial.top, left.top, 0.0001f)
        assertEquals(initial.bottom, left.bottom, 0.0001f)
    }

    @Test
    fun movingFrameAtPhotoEdgeStaysInsideAndPinchClampsViewport() {
        val moved = updateCropSelection(CropSelection(0.2f, 0.2f, 0.8f, 0.8f), CropHandle.MOVE, 2f, 2f)
        assertEquals(0.4f, moved.left, 0.0001f)
        assertEquals(1f, moved.right, 0.0001f)
        assertEquals(0.4f, moved.top, 0.0001f)
        assertEquals(1f, moved.bottom, 0.0001f)

        val viewport = IntSize(1000, 800)
        val transformed = transformPhotoViewport(1f, Offset.Zero, Offset(500f, 400f), Offset(900f, -900f),
            2f, viewport, 1000, 1000)
        assertEquals(2f, transformed.scale, 0.0001f)
        assertTrue(transformed.offset.x in -300f..300f)
        assertTrue(transformed.offset.y in -400f..400f)
    }

    @Test
    fun applyingSelectionComposesWithLegacyCropWithoutDoubleCropping() {
        val layer = Layer(kind = Kind.IMAGE, cropLeft = 0.2f, cropTop = 0.1f, cropRight = 0.8f, cropBottom = 0.9f)
        val updated = applyCropSelection(layer, CropSelection(0.25f, 0.25f, 0.75f, 0.75f))
        val cropOperation = updated.imageOperations.single { it.type == ImageOperationType.CROP }
        val params = JSONObject(cropOperation.parameters)
        assertEquals(0.35, params.getDouble("left"), 0.0001)
        assertEquals(0.3, params.getDouble("top"), 0.0001)
        assertEquals(0.65, params.getDouble("right"), 0.0001)
        assertEquals(0.7, params.getDouble("bottom"), 0.0001)
        assertEquals("legacy Layer fields are retained for backwards compatibility", 0.2f, updated.cropLeft, 0.0001f)
    }

    @Test
    fun applyingSelectionUpdatesExistingStableCropOperation() {
        val operation = ImageOperation(type = ImageOperationType.CROP,
            parameters = "{\"left\":0.2,\"top\":0.1,\"right\":0.8,\"bottom\":0.9}")
        val layer = Layer(kind = Kind.IMAGE, imageOperations = listOf(operation))
        val updated = applyCropSelection(layer, CropSelection(0.25f, 0.25f, 0.75f, 0.75f))
        val params = JSONObject(updated.imageOperations.single().parameters)
        assertEquals(0.35, params.getDouble("left"), 0.0001)
        assertEquals(0.3, params.getDouble("top"), 0.0001)
        assertEquals(0.65, params.getDouble("right"), 0.0001)
        assertEquals(0.7, params.getDouble("bottom"), 0.0001)
    }
    @Test
    fun cropRotationAndTwoPerspectiveAxesAreStoredIndependently() {
        val original = Layer(kind = Kind.IMAGE, rot = 5f, imageTiltX = 2f, imageTiltY = -3f)
        val updated = applyPhotoEditorEdits(
            original,
            CropSelection(0.1f, 0.2f, 0.9f, 0.8f),
            rotationDelta = 30f,
            perspectiveVertical = 12f,
            perspectiveHorizontal = -18f
        )
        assertEquals(35f, updated.rot, 0.0001f)
        assertEquals(14f, updated.imageTiltX, 0.0001f)
        assertEquals(-21f, updated.imageTiltY, 0.0001f)
        val crop = JSONObject(updated.imageOperations.single { it.type == ImageOperationType.CROP }.parameters)
        assertEquals(0.1, crop.getDouble("left"), 0.0001)
        assertEquals(0.2, crop.getDouble("top"), 0.0001)
        assertTrue(!crop.has("rotation") && !crop.has("tiltX") && !crop.has("tiltY"))
        val geometry = JSONObject(updated.legacyImageOperations().single { it.type == ImageOperationType.GEOMETRY }.parameters)
        assertEquals(35.0, geometry.getDouble("rotation"), 0.0001)
        assertEquals(14.0, geometry.getDouble("tiltX"), 0.0001)
        assertEquals(-21.0, geometry.getDouble("tiltY"), 0.0001)
    }

    @Test
    fun perspectiveAxesClampToRendererCameraRange() {
        val updated = applyPhotoEditorEdits(
            Layer(kind = Kind.IMAGE), CropSelection(), 0f, 90f, -90f
        )
        assertEquals(65f, updated.imageTiltX, 0.0001f)
        assertEquals(-65f, updated.imageTiltY, 0.0001f)
    }

    @Test
    fun photoEditorStoresHorizontalAndVerticalMirrorsIndependently() {
        val original = Layer(kind = Kind.IMAGE, flipX = true, flipY = false)
        val updated = applyPhotoEditorEdits(
            original, CropSelection(), 0f, 0f, 0f,
            mirrorHorizontal = true, mirrorVertical = true
        )
        assertTrue(!updated.flipX)
        assertTrue(updated.flipY)
        val geometry = JSONObject(updated.legacyImageOperations().single { it.type == ImageOperationType.GEOMETRY }.parameters)
        assertTrue(!geometry.optBoolean("flipX", false))
        assertTrue(geometry.optBoolean("flipY", false))
    }

    @Test
    fun quarterTurnButtonsWrapWithinSliderRange() {
        assertEquals(90f, stepPhotoRotation(0f, 90f), 0.0001f)
        assertEquals(180f, stepPhotoRotation(90f, 90f), 0.0001f)
        assertEquals(-180f, stepPhotoRotation(-90f, -90f), 0.0001f)
    }

    @Test
    fun photoEditorHistorySupportsUndoRedoAndDropsRedoAfterNewEdit() {
        val initial = PhotoEditorDraftState()
        val rotated = initial.copy(rotation = 90f)
        val mirrored = rotated.copy(mirrorHorizontal = true)

        val first = appendPhotoEditorHistory(listOf(initial), 0, rotated)
        assertEquals(1, first.second)
        assertEquals(rotated, first.first[first.second])

        val second = appendPhotoEditorHistory(first.first, first.second, mirrored)
        assertEquals(2, second.second)
        // Undo moves to the previous checkpoint; redo restores the next one.
        val undoCursor = second.second - 1
        assertEquals(rotated, second.first[undoCursor])
        assertEquals(mirrored, second.first[undoCursor + 1])

        val replacement = rotated.copy(perspectiveVertical = 15f)
        val branched = appendPhotoEditorHistory(second.first, undoCursor, replacement)
        assertEquals(1, branched.second)
        assertEquals(2, branched.first.size)
        assertEquals(replacement, branched.first.last())
    }

    @Test
    fun photoEditorHistoryIsBounded() {
        var history = listOf(PhotoEditorDraftState())
        var cursor = 0
        repeat(80) { index ->
            val next = appendPhotoEditorHistory(history, cursor, PhotoEditorDraftState(rotation = index.toFloat()), limit = 50)
            history = next.first
            cursor = next.second
        }
        assertEquals(51, history.size)
        assertEquals(79f, history.last().rotation, 0.0001f)
    }


    @Test
    fun fourPointPerspectiveIsStoredAsGeometryOperationAndUndoStateCarriesQuad() {
        val layer = Layer(kind = Kind.IMAGE)
        val quad = listOf(Offset(0.08f, 0.16f), Offset(0.92f, 0.04f), Offset(0.98f, 0.88f), Offset(0.03f, 0.96f))
        val updated = applyPerspectiveQuad(layer, quad)
        val geometry = updated.imageOperations.single { it.type == ImageOperationType.GEOMETRY }
        val stored = JSONObject(geometry.parameters).getJSONArray("perspectiveQuad")
        assertEquals(8, stored.length())
        assertEquals(0.08, stored.getDouble(0), 0.0001)
        assertEquals(0.96, stored.getDouble(7), 0.0001)
        val invalid = applyPerspectiveQuad(layer, listOf(Offset(-0.1f, 0f), quad[1], quad[2], quad[3]))
        assertTrue(invalid.imageOperations.isEmpty())
    }

    @Test
    fun perspectiveWarpRectifiesQuadAndRejectsCrossedCorners() {
        val source = Bitmap.createBitmap(240, 180, Bitmap.Config.ARGB_8888)
        source.eraseColor(Color.WHITE)
        val quad = floatArrayOf(0.1f, 0.15f, 0.9f, 0.05f, 0.95f, 0.88f, 0.04f, 0.94f)
        val warped = ImageOperationRenderer.perspectiveWarpBitmap(source, quad)
        assertTrue(warped != null)
        assertTrue(warped!!.width > 100 && warped.height > 100)
        val crossed = ImageOperationRenderer.perspectiveWarpBitmap(source,
            floatArrayOf(0.1f, 0.1f, 0.9f, 0.9f, 0.9f, 0.1f, 0.1f, 0.9f))
        assertEquals(null, crossed)
        warped.recycle()
        source.recycle()
    }
}
