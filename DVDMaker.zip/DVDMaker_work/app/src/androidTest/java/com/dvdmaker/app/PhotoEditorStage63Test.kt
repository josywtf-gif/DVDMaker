package com.dvdmaker.app

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PhotoEditorStage63Test {
    @Test
    fun cornerHandleChangesBothAxes() {
        val next = updateCropSelection(CropSelection(0.1f, 0.1f, 0.9f, 0.9f), CropHandle.TOP_LEFT, 0.1f, 0.2f)
        assertEquals(0.2f, next.left, 0.0001f)
        assertEquals(0.3f, next.top, 0.0001f)
        assertEquals(0.9f, next.right, 0.0001f)
        assertEquals(0.9f, next.bottom, 0.0001f)
    }

    @Test
    fun sideHandleChangesOnlyItsOwnAxis() {
        val initial = CropSelection(0.1f, 0.1f, 0.9f, 0.9f)
        val next = updateCropSelection(initial, CropHandle.RIGHT, -0.2f, 0.15f)
        assertEquals(0.1f, next.left, 0.0001f)
        assertEquals(0.1f, next.top, 0.0001f)
        assertEquals(0.7f, next.right, 0.0001f)
        assertEquals(0.9f, next.bottom, 0.0001f)
    }

    @Test
    fun draggingInsideFrameMovesWholeSelectionAndPreservesSize() {
        val initial = CropSelection(0.2f, 0.15f, 0.8f, 0.85f)
        val next = updateCropSelection(initial, CropHandle.MOVE, 0.1f, -0.05f)
        assertEquals(0.3f, next.left, 0.0001f)
        assertEquals(0.1f, next.top, 0.0001f)
        assertEquals(initial.width, next.width, 0.0001f)
        assertEquals(initial.height, next.height, 0.0001f)
    }

    @Test
    fun cropCannotEscapePhotoOrBecomeSmallerThanMinimum() {
        val initial = CropSelection(0.1f, 0.1f, 0.9f, 0.9f)
        val outside = updateCropSelection(initial, CropHandle.BOTTOM_RIGHT, 5f, 5f)
        assertEquals(1f, outside.right, 0.0001f)
        assertEquals(1f, outside.bottom, 0.0001f)
        val tooSmall = updateCropSelection(initial, CropHandle.TOP_LEFT, 5f, 5f)
        assertTrue(tooSmall.width >= 0.05f)
        assertTrue(tooSmall.height >= 0.05f)
        assertTrue(tooSmall.left >= 0f && tooSmall.top >= 0f)
        assertTrue(tooSmall.right <= 1f && tooSmall.bottom <= 1f)
    }


    @Test
    fun everySideHandleChangesOnlyItsOwnAxis() {
        val initial = CropSelection(0.1f, 0.1f, 0.9f, 0.9f)
        val top = updateCropSelection(initial, CropHandle.TOP, 0.2f, 0.1f)
        val bottom = updateCropSelection(initial, CropHandle.BOTTOM, 0.2f, -0.1f)
        val left = updateCropSelection(initial, CropHandle.LEFT, 0.1f, 0.2f)
        assertEquals(initial.left, top.left, 0.0001f)
        assertEquals(initial.right, top.right, 0.0001f)
        assertEquals(initial.top, top.top, 0.0001f)
        assertEquals(initial.bottom, bottom.bottom, 0.0001f)
        assertEquals(initial.top, left.top, 0.0001f)
        assertEquals(initial.bottom, left.bottom, 0.0001f)
    }

    @Test
    fun movingFrameAtPhotoEdgeStaysInsideAndPinchClampsViewport() {
        val moved = updateCropSelection(CropSelection(0.2f, 0.2f, 0.8f, 0.8f), CropHandle.MOVE, 2f, 2f)
        assertEquals(0.4f, moved.left, 0.0001f)
        assertEquals(1f, moved.right, 0.0001f)
        assertEquals(0.4f, moved.top, 0.0001f)
        assertEquals(1f, moved.bottom, 0.0001f)

        val viewport = IntSize(1000, 800)
        val transformed = transformPhotoViewport(1f, Offset.Zero, Offset(500f, 400f), Offset(900f, -900f),
            2f, viewport, 1000, 1000)
        assertEquals(2f, transformed.scale, 0.0001f)
        assertTrue(transformed.offset.x in -300f..300f)
        assertTrue(transformed.offset.y in -400f..400f)
    }

    @Test
    fun applyingSelectionComposesWithLegacyCropWithoutDoubleCropping() {
        val layer = Layer(kind = Kind.IMAGE, cropLeft = 0.2f, cropTop = 0.1f, cropRight = 0.8f, cropBottom = 0.9f)
        val updated = applyCropSelection(layer, CropSelection(0.25f, 0.25f, 0.75f, 0.75f))
        val cropOperation = updated.imageOperations.single { it.type == ImageOperationType.CROP }
        val params = JSONObject(cropOperation.parameters)
        assertEquals(0.35, params.getDouble("left"), 0.0001)
        assertEquals(0.3, params.getDouble("top"), 0.0001)
        assertEquals(0.65, params.getDouble("right"), 0.0001)
        assertEquals(0.7, params.getDouble("bottom"), 0.0001)
        assertEquals("legacy Layer fields are retained for backwards compatibility", 0.2f, updated.cropLeft, 0.0001f)
    }

    @Test
    fun applyingSelectionUpdatesExistingStableCropOperation() {
        val operation = ImageOperation(type = ImageOperationType.CROP,
            parameters = "{\"left\":0.2,\"top\":0.1,\"right\":0.8,\"bottom\":0.9}")
        val layer = Layer(kind = Kind.IMAGE, imageOperations = listOf(operation))
        val updated = applyCropSelection(layer, CropSelection(0.25f, 0.25f, 0.75f, 0.75f))
        val params = JSONObject(updated.imageOperations.single().parameters)
        assertEquals(0.35, params.getDouble("left"), 0.0001)
        assertEquals(0.3, params.getDouble("top"), 0.0001)
        assertEquals(0.65, params.getDouble("right"), 0.0001)
        assertEquals(0.7, params.getDouble("bottom"), 0.0001)
    }
}
