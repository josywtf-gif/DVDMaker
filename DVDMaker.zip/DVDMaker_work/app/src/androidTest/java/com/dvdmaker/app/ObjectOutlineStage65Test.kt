package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ObjectOutlineStage65Test {
    @Test
    fun samePathUsesFreshContourAfterCropOrReplayChangesBitmap() {
        val first = Bitmap.createBitmap(40, 40, Bitmap.Config.ARGB_8888)
        val second = Bitmap.createBitmap(40, 40, Bitmap.Config.ARGB_8888)
        val circle = IntArray(40 * 40)
        val bar = IntArray(40 * 40)
        for (y in 0 until 40) for (x in 0 until 40) {
            if ((x - 20) * (x - 20) + (y - 20) * (y - 20) <= 12 * 12) circle[y * 40 + x] = AndroidColor.WHITE
            if (x in 5..34 && y in 16..23) bar[y * 40 + x] = AndroidColor.WHITE
        }
        first.setPixels(circle, 0, 40, 0, 0, 40, 40)
        second.setPixels(bar, 0, 40, 0, 0, 40, 40)

        val oldContour = ObjectOutline.get(first)
        val currentContour = ObjectOutline.get(second)

        assertNotNull(oldContour)
        assertNotNull(currentContour)
        assertNotEquals(oldContour!!.first().toList(), currentContour!!.first().toList())
        first.recycle()
        second.recycle()
    }


    @Test
    fun cropCoordinatesAreNormalizedToVisibleImageRegion() {
        val bitmap = Bitmap.createBitmap(40, 40, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(40 * 40)
        for (y in 10..29) for (x in 10..29) pixels[y * 40 + x] = AndroidColor.WHITE
        bitmap.setPixels(pixels, 0, 40, 0, 0, 40, 40)

        val cropped = ObjectOutline.get(bitmap, 0.25f, 0.25f, 0.75f, 0.75f)
        assertNotNull(cropped)
        val xs = cropped!!.flatMap { poly -> poly.indices.filter { it % 2 == 0 }.map { poly[it] } }
        assertTrue(xs.minOrNull()!! >= -0.55f)
        assertTrue(xs.maxOrNull()!! <= 0.55f)
        bitmap.recycle()
    }

    @Test
    fun opaqueBitmapDoesNotProduceObjectSilhouette() {
        val bitmap = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(AndroidColor.WHITE)
        assertEqualsNull(ObjectOutline.get(bitmap))
        bitmap.recycle()
    }

    private fun assertEqualsNull(value: Any?) {
        org.junit.Assert.assertNull(value)
    }
}
