package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.OutputStream

object Exporter {
    const val PNG_DPI = 300
    const val PDF_DPI = 200

    fun safeName(n: String): String =
        n.replace(Regex("[^\\p{L}\\p{N}_ .-]"), "_").trim().ifEmpty { "DVDMaker" }

    fun writePng(p: Project, a4: Boolean, marks: Boolean, out: OutputStream, disc: Boolean = false) {
        val bmp = Interactive.withFullQuality { renderSheet(p, PNG_DPI / 25.4f, a4, marks, disc) }
        try { bmp.compress(Bitmap.CompressFormat.PNG, 100, out) } finally { bmp.recycle() }
    }

    fun writePdf(p: Project, a4: Boolean, marks: Boolean, out: OutputStream, disc: Boolean = false) {
        val bmp = Interactive.withFullQuality { renderSheet(p, PDF_DPI / 25.4f, a4, marks, disc) }
        val (wMm, hMm) = sheetSizeMm(p, a4, marks, disc)
        val wPt = (wMm / 25.4f * 72f).toInt()
        val hPt = (hMm / 25.4f * 72f).toInt()
        val doc = PdfDocument()
        try {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(wPt, hPt, 1).create())
            page.canvas.drawBitmap(bmp, null, RectF(0f, 0f, wPt.toFloat(), hPt.toFloat()),
                Paint(Paint.FILTER_BITMAP_FLAG))
            doc.finishPage(page)
            doc.writeTo(out)
        } finally {
            doc.close()
            bmp.recycle()
        }
    }

    fun cacheFile(ctx: Context, p: Project, pdf: Boolean, a4: Boolean, marks: Boolean, disc: Boolean = false): File {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, safeName(p.name) + (if (disc) "-диск" else "") + if (pdf) ".pdf" else ".png")
        f.outputStream().use { if (pdf) writePdf(p, a4, marks, it, disc) else writePng(p, a4, marks, it, disc) }
        return f
    }
}
