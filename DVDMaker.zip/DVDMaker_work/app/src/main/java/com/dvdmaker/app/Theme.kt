package com.dvdmaker.app

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.LocalContentColor
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Базовые цвета приложения. Сохраняем прежние значения, чтобы редизайн не менял характер бренда.
val Bg = Color(0xFF121212)
val Card = Color(0xFF1E1E1E)
val Card2 = Color(0xFF2A2A2A)
val Violet = Color(0xFFF2BE3F) // Историческое имя; фактически основной золотистый акцент.
val Pink = Color(0xFFE8903A)
val Amber = Color(0xFFFFB547)
val Dim = Color(0xFFB0B0B0)
val Line = Color(0xFF3A3A3A)
val TextPrimary = Color(0xFFEDEEFA)
val TextOnAccent = Color(0xFF111111)
val Danger = Color(0xFFFF8A8A)
val Success = Color(0xFF72C99A)
val SurfaceRaised = Color(0xFF242424)

// Общие размеры для карточек, полей, кнопок и групп настроек.
val RadiusSmall: Dp = 10.dp
val RadiusMedium: Dp = 14.dp
val RadiusLarge: Dp = 18.dp
val RadiusExtraLarge: Dp = 22.dp
val ControlHeight: Dp = 44.dp
val PrimaryControlHeight: Dp = 48.dp
val ContentSpacing: Dp = 12.dp
val CompactSpacing: Dp = 8.dp

val BrandBrush = Brush.linearGradient(listOf(Violet, Pink))
val GoldBrush = Brush.linearGradient(listOf(Amber, Pink))

@Composable
fun DVDMakerTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Violet,
        onPrimary = TextOnAccent,
        secondary = Amber,
        onSecondary = TextOnAccent,
        background = Bg,
        onBackground = TextPrimary,
        surface = Card,
        onSurface = TextPrimary,
        surfaceVariant = Card2,
        onSurfaceVariant = Dim,
        outline = Line,
        error = Color(0xFFFF6B6B)
    )
    val typo = Typography(
        displaySmall = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold),
        headlineSmall = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
        titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
        titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
        titleSmall = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
        bodyLarge = TextStyle(fontSize = 15.sp),
        bodyMedium = TextStyle(fontSize = 14.sp),
        bodySmall = TextStyle(fontSize = 12.sp),
        labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold),
        labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
        labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium)
    )
    val shapes = Shapes(
        extraSmall = RoundedCornerShape(8.dp),
        small = RoundedCornerShape(RadiusSmall),
        medium = RoundedCornerShape(RadiusMedium),
        large = RoundedCornerShape(RadiusLarge),
        extraLarge = RoundedCornerShape(RadiusExtraLarge)
    )
    MaterialTheme(colorScheme = scheme, typography = typo, shapes = shapes) {
        CompositionLocalProvider(LocalContentColor provides TextPrimary) { content() }
    }
}
