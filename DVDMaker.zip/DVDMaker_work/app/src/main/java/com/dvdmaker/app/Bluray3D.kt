package com.dvdmaker.app

import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Реальный кейс Blu-ray: текстуры из фотографий (рамка лицо/оборот, бок с выемкой, шарнирный бок, крышка и лоток изнутри). */
object BlurayAssets {
    var front: Bitmap? = null
    var back: Bitmap? = null
    var side: Bitmap? = null
    var hinge: Bitmap? = null
    var door: Bitmap? = null
    var tray: Bitmap? = null

    fun init(am: AssetManager) {
        fun ld(n: String): Bitmap? = runCatching { am.open("bluray/$n").use { BitmapFactory.decodeStream(it) } }.getOrNull()
        front = ld("shell_front.png"); back = ld("shell_back.png"); side = ld("side_open.png")
        hinge = ld("hinge_side.png"); door = ld("inner_door.png"); tray = ld("inner_tray.png")
    }
}

class BlurayTex(
    val front: Bitmap, val back: Bitmap, val spine: Bitmap, val side: Bitmap,
    val door: Bitmap, val tray: Bitmap, val shadow: Bitmap
)

/** Вставляет обложку проекта в «окно» пластикового кейса и накрывает её рамкой с бликом плёнки. */
private fun shellWithCover(shell: Bitmap, cover: Bitmap, l: Float, t: Float, r: Float, b: Float): Bitmap {
    val w = shell.width; val h = shell.height
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    val pad = 5f
    val win = RectF(l * w, t * h, r * w, b * h)
    val dst = RectF(win.left - pad, win.top - pad, win.right + pad, win.bottom + pad)
    val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    c.drawBitmap(cover, null, dst, bp)
    // лёгкая голубая тонировка плёнки поверх вкладыша
    c.drawRect(dst, Paint().apply { color = 0x1C2878E6 })
    // мягкий блик на плёнке
    c.save()
    c.clipRect(win)
    c.drawRect(win, Paint().apply {
        shader = LinearGradient(
            win.left, win.top, win.right, win.bottom,
            intArrayOf(0x40FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x22FFFFFF),
            floatArrayOf(0f, 0.34f, 0.62f, 1f), Shader.TileMode.CLAMP
        )
    })
    c.restore()
    c.drawBitmap(shell, 0f, 0f, bp)
    return out
}

/** Бок со стороны шарнира: пластик, а внутри — корешок обложки проекта (вкладыш 150 мм в корпусе 171 мм). */
private fun spineWithInsert(hinge: Bitmap, spinePanel: Bitmap): Bitmap {
    val sw = 128; val sh = 1600
    val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    val whole = RectF(0f, 0f, sw.toFloat(), sh.toFloat())
    c.drawBitmap(hinge, null, whole, bp)
    val reg = RectF(sw * 0.09f, sh * 0.0614f, sw * 0.91f, sh * 0.9386f)
    c.drawBitmap(spinePanel, null, reg, bp)
    c.drawRect(reg, Paint().apply { color = 0x1C2878E6 })
    // пластик поверх вкладыша: видны рёбра и блики
    c.drawBitmap(hinge, null, whole, Paint(bp).apply { alpha = 95 })
    return out
}

private fun softShadow(): Bitmap {
    val s = 160
    val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
    Canvas(bmp).drawCircle(
        s / 2f, s / 2f, s / 2f,
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                s / 2f, s / 2f, s / 2f,
                intArrayOf(0x66000000, 0x4D000000, 0x00000000), floatArrayOf(0f, 0.78f, 1f), Shader.TileMode.CLAMP
            )
        }
    )
    return bmp
}

/** Собирает текстуры реального кейса; null, если файлов нет (тогда используется простая модель). */
fun composeBlurayTextures(front: Bitmap, back: Bitmap, spine: Bitmap): BlurayTex? {
    val sf = BlurayAssets.front ?: return null
    val sb = BlurayAssets.back ?: return null
    val sd = BlurayAssets.side ?: return null
    val hg = BlurayAssets.hinge ?: return null
    val dr = BlurayAssets.door ?: return null
    val tr = BlurayAssets.tray ?: return null
    return BlurayTex(
        front = shellWithCover(sf, front, 0.0263f, 0.1021f, 0.9338f, 0.9531f),
        back = shellWithCover(sb, back, 0.0662f, 0.1021f, 0.9737f, 0.9531f),
        spine = spineWithInsert(hg, spine),
        side = sd, door = dr, tray = tr, shadow = softShadow()
    )
}

internal interface SceneRender {
    fun render(out: Bitmap, yawDeg: Float, pitchDeg: Float, slide: Float)
}

/** Одна грань: 4 угла xyz (лево-верх, право-верх, право-низ, лево-низ как на текстуре), нормаль наружу. */
private class BQ(
    val p: FloatArray,
    val tex: Bitmap?,
    val u0: Float = 0f, val v0: Float = 0f, val u1: Float = 1f, val v1: Float = 1f,
    val color: Int = 0,
    val twoSided: Boolean = false,
    val n: FloatArray,
    val gloss: Boolean = false,
    val dim: Float = 0.3f,
    val outline: Boolean = false,
    val round: Boolean = false
)

/** Кейс Blu-ray в 3D: прозрачный синий пластик, обложка внутри, выемка сбоку, крышка открывается на шарнире, диск лежит на ступице. */
private const val ARC_N = 6

internal class BlurayScene(val p: Project, val tex: CaseTextures) : SceneRender {
    private val bl = tex.bl!!
    private val W = 135f
    private val H = 171f
    private val D = 11f
    private val zp = D / 2f - 3.5f          // плоскость разъёма крышки и лотка
    private val zf = -D / 2f + 1.6f         // дно лотка
    private val vOut = D / 2f - zp          // толщина крышки
    private val vIn = vOut - 1.6f           // внутренняя сторона крышки (от плоскости разъёма)
    private val r = 4.5f                    // скругление углов (фаской)
    private val xh = -W / 2f                // ось шарнира
    private val camera = 1100f
    private val maxOpenDeg = 180f
    private val discCx = (0.495f - 0.5f) * W
    private val discCy = (0.543f - 0.5f) * H
    private val discR = DISC_SIZE_MM / 2f
    private val plastic = 0xFF1673E8.toInt()

    private class P(val x: Float, val y: Float, val z: Float)

    private fun faces(theta: Float): List<BQ> {
        val c = cos(theta); val s = sin(theta)
        fun dp(u: Float, y: Float, v: Float) = floatArrayOf(xh + u * c - v * s, y, zp + u * s + v * c)
        fun dn(nu: Float, ny: Float, nv: Float) = floatArrayOf(nu * c - nv * s, ny, nu * s + nv * c)
        fun q(a: FloatArray, b: FloatArray, cc: FloatArray, d: FloatArray) = a + b + cc + d
        fun pt(x: Float, y: Float, z: Float) = floatArrayOf(x, y, z)
        val x = W / 2f; val y = H / 2f; val z = D / 2f
        val yi = y - r; val xi = x - r
        val list = ArrayList<BQ>()
        val sideSplit = (z - zp) / D       // доля толщины на стороне крышки

        // ----- корпус (лоток и шарнир остаются на месте) -----
        list += BQ(q(pt(x, -y, -z), pt(-x, -y, -z), pt(-x, y, -z), pt(x, y, -z)), bl.back, n = floatArrayOf(0f, 0f, -1f), gloss = true, dim = 0.28f, round = true)
        list += BQ(q(pt(-x, -yi, -z), pt(-x, -yi, z), pt(-x, yi, z), pt(-x, yi, -z)), bl.spine, v0 = r / H, v1 = 1f - r / H, n = floatArrayOf(-1f, 0f, 0f), dim = 0.4f)
        list += BQ(q(pt(x, -yi, zp), pt(x, -yi, -z), pt(x, yi, -z), pt(x, yi, zp)), bl.side, u0 = sideSplit, u1 = 1f, v0 = r / H, v1 = 1f - r / H, twoSided = true, n = floatArrayOf(1f, 0f, 0f), dim = 0.5f)
        list += BQ(q(pt(-x + r, -y, -z), pt(xi, -y, -z), pt(xi, -y, zp), pt(-x + r, -y, zp)), null, color = plastic, twoSided = true, n = floatArrayOf(0f, -1f, 0f), dim = 0.8f, outline = true)
        list += BQ(q(pt(-x + r, y, -z), pt(xi, y, -z), pt(xi, y, zp), pt(-x + r, y, zp)), null, color = plastic, twoSided = true, n = floatArrayOf(0f, 1f, 0f), dim = 0.8f, outline = true)
        // скруглённые углы: дуги из нескольких сегментов
        fun arcs(cxc: Float, cyc: Float, a0: Int, z0: Float, z1: Float, pt3: (Float, Float, Float) -> FloatArray, nrm: (Float, Float) -> FloatArray) {
            for (i in 0 until ARC_N) {
                val t0 = Math.toRadians((a0 + 90.0 * i / ARC_N)).toFloat()
                val t1 = Math.toRadians((a0 + 90.0 * (i + 1) / ARC_N)).toFloat()
                val tm = (t0 + t1) / 2f
                val ax = cxc + r * cos(t0); val ay = cyc + r * sin(t0)
                val bx = cxc + r * cos(t1); val by = cyc + r * sin(t1)
                list += BQ(q(pt3(ax, ay, z0), pt3(bx, by, z0), pt3(bx, by, z1), pt3(ax, ay, z1)), null, color = plastic, twoSided = true, n = nrm(cos(tm), sin(tm)), dim = 0.8f, outline = false)
            }
        }
        val bp3: (Float, Float, Float) -> FloatArray = { px, py, pz -> pt(px, py, pz) }
        val bn: (Float, Float) -> FloatArray = { nx, ny -> floatArrayOf(nx, ny, 0f) }
        arcs(xi, -yi, -90, -z, zp, bp3, bn)
        arcs(xi, yi, 0, -z, zp, bp3, bn)
        arcs(-x + r, -yi, 180, -z, z, bp3, bn)
        arcs(-x + r, yi, 90, -z, z, bp3, bn)

        // ----- крышка (поворачивается вокруг шарнира) -----
        list += BQ(q(dp(0f, -y, vOut), dp(W, -y, vOut), dp(W, y, vOut), dp(0f, y, vOut)), bl.front, n = dn(0f, 0f, 1f), gloss = true, dim = 0.28f, round = true)
        list += BQ(q(dp(W, -yi, vOut), dp(W, -yi, 0f), dp(W, yi, 0f), dp(W, yi, vOut)), bl.side, u0 = 0f, u1 = sideSplit, v0 = r / H, v1 = 1f - r / H, twoSided = true, n = dn(1f, 0f, 0f), dim = 0.5f)
        list += BQ(q(dp(r, -y, vOut), dp(W - r, -y, vOut), dp(W - r, -y, 0f), dp(r, -y, 0f)), null, color = plastic, twoSided = true, n = dn(0f, -1f, 0f), dim = 0.8f, outline = true)
        list += BQ(q(dp(r, y, vOut), dp(W - r, y, vOut), dp(W - r, y, 0f), dp(r, y, 0f)), null, color = plastic, twoSided = true, n = dn(0f, 1f, 0f), dim = 0.8f, outline = true)
        val lp3: (Float, Float, Float) -> FloatArray = { u, yy, v -> dp(u, yy, v) }
        val ln: (Float, Float) -> FloatArray = { nu, ny -> dn(nu, ny, 0f) }
        arcs(W - r, -yi, -90, 0f, vOut, lp3, ln)
        arcs(W - r, yi, 0, 0f, vOut, lp3, ln)

        // ----- внутренности (видны, когда кейс открыт) -----
        if (theta > 0.03f) {
            list += BQ(q(pt(-x, -y, zf), pt(x, -y, zf), pt(x, y, zf), pt(-x, y, zf)), bl.tray, n = floatArrayOf(0f, 0f, 1f), dim = 0.22f)
            list += BQ(q(dp(W, -y, vIn), dp(0f, -y, vIn), dp(0f, y, vIn), dp(W, y, vIn)), bl.door, n = dn(0f, 0f, -1f), dim = 0.22f)
            // тень диска на дне лотка и сам диск на ступице
            val sr = discR + 8f
            val sx = discCx + 2.2f; val sy = discCy + 3.2f; val zs = zf + 0.5f
            list += BQ(q(pt(sx - sr, sy - sr, zs), pt(sx + sr, sy - sr, zs), pt(sx + sr, sy + sr, zs), pt(sx - sr, sy + sr, zs)), bl.shadow, n = floatArrayOf(0f, 0f, 1f), dim = 0f)
            val zd = zf + 2.4f
            list += BQ(q(pt(discCx - discR, discCy - discR, zd), pt(discCx + discR, discCy - discR, zd), pt(discCx + discR, discCy + discR, zd), pt(discCx - discR, discCy + discR, zd)), tex.disc, n = floatArrayOf(0f, 0f, 1f), dim = 0.12f)
        }
        return list
    }

    override fun render(out: Bitmap, yawDeg: Float, pitchDeg: Float, slide: Float) {
        out.eraseColor(Color.TRANSPARENT)
        val cv = Canvas(out)
        val vw = out.width.toFloat(); val vh = out.height.toFloat()
        val yaw = Math.toRadians(yawDeg.toDouble()); val pitch = Math.toRadians(pitchDeg.toDouble())
        val cy = cos(yaw).toFloat(); val sy = sin(yaw).toFloat()
        val cp = cos(pitch).toFloat(); val sp = sin(pitch).toFloat()
        val open = slide.coerceIn(0f, 1f)
        val theta = Math.toRadians((open * maxOpenDeg).toDouble()).toFloat()

        // габариты при текущем угле открытия: подгон масштаба и центровка
        val minX = min(-W / 2f, xh + W * cos(theta))
        val maxX = W / 2f
        val zMax = max(D / 2f, zp + W * sin(theta) + vOut * abs(cos(theta)))
        val zMin = -D / 2f
        val spanX = maxX - minX; val spanZ = zMax - zMin
        val radius = 0.5f * sqrt(spanX * spanX + H * H + spanZ * spanZ)
        val scale = min(vw, vh) * 0.47f / radius
        val shiftX = -(minX + maxX) / 2f
        val shiftZ = -(zMin + zMax) / 2f

        fun proj(x0: Float, y0: Float, z0: Float): P {
            val x = x0 + shiftX; val zz = z0 + shiftZ
            val x1 = x * cy + zz * sy
            val z1 = -x * sy + zz * cy
            val y2 = y0 * cp + z1 * sp
            val z2 = -y0 * sp + z1 * cp
            val k = camera / (camera - z2)
            return P(vw / 2f + x1 * k * scale, vh / 2f + y2 * k * scale, z2)
        }
        fun area(q: Array<P>): Float {
            var s = 0f
            for (i in 0 until 4) { val a = q[i]; val b = q[(i + 1) % 4]; s += a.x * b.y - b.x * a.y }
            return s / 2f
        }
        fun flat(q: Array<P>) = FloatArray(8) { if (it % 2 == 0) q[it / 2].x else q[it / 2].y }
        fun pathOf(q: Array<P>) = Path().apply { moveTo(q[0].x, q[0].y); for (i in 1..3) lineTo(q[i].x, q[i].y); close() }

        val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

        // тень на «полу»
        run {
            val b = proj(0f, H / 2f, 0f)
            val rx = spanX * 0.55f * scale
            val oy = b.y + 6f * scale * 0.6f
            val sh = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(vw / 2f, oy, rx, intArrayOf(0x55000000, 0x00000000), null, Shader.TileMode.CLAMP)
            }
            cv.save(); cv.scale(1f, 0.16f, vw / 2f, oy)
            cv.drawCircle(vw / 2f, oy, rx, sh)
            cv.restore()
        }

        fun roundedPath(q: Array<P>): Path {
            val ru = r / W; val rv = r / H
            fun bi(u: Float, v: Float): Pair<Float, Float> {
                val x = (1 - v) * ((1 - u) * q[0].x + u * q[1].x) + v * ((1 - u) * q[3].x + u * q[2].x)
                val y = (1 - v) * ((1 - u) * q[0].y + u * q[1].y) + v * ((1 - u) * q[3].y + u * q[2].y)
                return x to y
            }
            val path = Path()
            var first = true
            // углы по часовой: лево-верх, право-верх, право-низ, лево-низ
            val corners = arrayOf(
                floatArrayOf(ru, rv, 180f), floatArrayOf(1f - ru, rv, 270f),
                floatArrayOf(1f - ru, 1f - rv, 0f), floatArrayOf(ru, 1f - rv, 90f)
            )
            for (c in corners) {
                for (i in 0..ARC_N) {
                    val a = Math.toRadians((c[2] + 90.0 * i / ARC_N)).toFloat()
                    val (px, py) = bi(c[0] + ru * cos(a), c[1] + rv * sin(a))
                    if (first) { path.moveTo(px, py); first = false } else path.lineTo(px, py)
                }
            }
            path.close()
            return path
        }

        class Item(val f: BQ, val q: Array<P>, val a: Float, val depth: Float)
        val items = ArrayList<Item>()
        for (f in faces(theta)) {
            val q = Array(4) { proj(f.p[it * 3], f.p[it * 3 + 1], f.p[it * 3 + 2]) }
            val a = area(q)
            val seen = if (f.twoSided) abs(a) > 0.5f else a > 0.5f
            if (!seen) continue
            items += Item(f, q, a, q.sumOf { it.z.toDouble() }.toFloat())
        }
        items.sortBy { it.depth }

        for (item in items) {
            val f = item.f; val q = item.q
            val pa = if (f.round) roundedPath(q) else pathOf(q)
            if (f.tex != null) {
                val bmp = f.tex
                val x0 = bmp.width * f.u0; val x1 = bmp.width * f.u1
                val y0 = bmp.height * f.v0; val y1 = bmp.height * f.v1
                val m = Matrix()
                m.setPolyToPoly(floatArrayOf(x0, y0, x1, y0, x1, y1, x0, y1), 0, flat(q), 0, 4)
                cv.save(); cv.clipPath(pa); cv.concat(m); cv.drawBitmap(bmp, 0f, 0f, bp); cv.restore()
            } else {
                cv.drawPath(pa, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = f.color })
            }

            // освещение от грани: чем больше повёрнута к лампе, тем светлее
            var nx = f.n[0]; var ny = f.n[1]; var nz = f.n[2]
            var rx = nx * cy + nz * sy
            var rz1 = -nx * sy + nz * cy
            var ry = ny * cp + rz1 * sp
            var rz = -ny * sp + rz1 * cp
            if (f.twoSided && rz < 0f) { rx = -rx; ry = -ry; rz = -rz }
            val lit = (-0.35f * rx - 0.5f * ry + 0.8f * rz).coerceIn(-1f, 1f)
            val shade = ((1f - (0.62f + 0.38f * lit)) * f.dim).coerceIn(0f, 0.7f)
            if (shade > 0.01f && f.dim > 0f) {
                cv.save(); cv.clipPath(pa)
                cv.drawPath(pa, Paint().apply { color = Color.argb((shade * 255).roundToInt(), 0, 0, 0) })
                cv.restore()
            }

            // подвижный блик на плёнке: смещается вместе с поворотом кейса
            if (f.gloss && rz > 0.05f) {
                val b = RectF(); pa.computeBounds(b, true)
                val t = (0.5f + 0.55f * sin(yaw + pitch * 0.6).toFloat()).coerceIn(-0.2f, 1.2f)
                val cx = b.left + b.width() * t
                val half = b.width() * 0.30f
                cv.save(); cv.clipPath(pa)
                cv.drawRect(b, Paint().apply {
                    shader = LinearGradient(
                        cx - half, b.top, cx + half, b.bottom,
                        intArrayOf(0x00FFFFFF, (0x30 * rz).roundToInt().coerceIn(0, 255) shl 24 or 0xFFFFFF, 0x00FFFFFF),
                        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
                    )
                })
                cv.restore()
            }
            if (f.outline) {
                cv.drawPath(pa, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = 1.2f; color = 0x44FFFFFF
                })
            }
        }
    }
}
