package com.dvdmaker.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
private fun coverFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Violet, unfocusedBorderColor = Line,
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    cursorColor = Violet
)

/** Окно «Оформление»: выбор стиля и текстов — название, подзаголовок, описание. Всё расставляется и подгоняется автоматически. */
@Composable
fun TemplateDialog(vm: AppVm, p: Project, onDismiss: () -> Unit) {
    var style by remember { mutableIntStateOf(0) }
    var title by remember { mutableStateOf(Templates.existingText(p, "tpl-title") ?: p.name) }
    var sub by remember { mutableStateOf(Templates.existingText(p, "tpl-sub") ?: "") }
    var synopsis by remember { mutableStateOf(Templates.existingText(p, "tpl-synopsis") ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text("Оформление обложки") },
        text = {
            Column(
                Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Название, подзаголовок с линиями, описание на обороте, текст на корешке и атмосфера (виньетка, цветокор, снег) ставятся одним нажатием. Потом всё можно править на вкладке «Обзор».",
                    color = Dim, fontSize = 12.sp
                )
                SectionLabel("Стиль")
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Templates.styles.forEachIndexed { i, st -> Pill(st.name, style == i, { style = i }) }
                }
                Text(Templates.styles[style].note, color = Dim, fontSize = 12.sp)
                OutlinedTextField(title, { title = it }, label = { Text("Название", color = Dim) },
                    modifier = Modifier.fillMaxWidth(), maxLines = 2, colors = coverFieldColors())
                OutlinedTextField(sub, { sub = it }, label = { Text("Подзаголовок или год (1982)", color = Dim) },
                    modifier = Modifier.fillMaxWidth(), singleLine = true, colors = coverFieldColors())
                OutlinedTextField(synopsis, { synopsis = it }, label = { Text("Описание для оборота", color = Dim) },
                    modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 8, colors = coverFieldColors())
                Text("Ранее созданные этим окном надписи будут заменены. Остальные слои не затрагиваются.", color = Dim, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.applyTemplate(style, title, sub, synopsis); onDismiss() }) { Text("Применить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена", color = Dim) } }
    )
}

/** Настройки атмосферы всего разворота: цветокор, тонировка, виньетка, снег, зерно. Видны на вкладке «Обзор» и в экспорте. */
@Composable
fun FxControls(vm: AppVm, p: Project) {
    val fx = p.fx
    fun pct(v: Float) = "${(v * 100).roundToInt()}%"
    var manual by remember { mutableStateOf(false) }
    var advanced by remember { mutableStateOf(false) }
    var presetName by remember { mutableStateOf("Мой стиль") }
    var savedNames by remember { mutableStateOf(vm.savedFxPresetNames()) }
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill("Холодный триллер", false, { vm.updateFx("preset") { Templates.fxOf(0) } })
            Pill("Тёплое золото", false, { vm.updateFx("preset") { Templates.fxOf(1) } })
            Pill("Неон", false, { vm.updateFx("preset") { Templates.fxOf(2) } })
            Pill("Огонь", false, { vm.updateFx("preset") { Templates.fxOf(3) } })
            Pill("Плёнка", false, { vm.updateFx("preset") { Fx(vignette = 0.35f, contrast = 1.06f, grain = 0.3f) } })
            Pill("Метель", false, { vm.updateFx("preset") { it.copy(snow = 0.6f, snowWind = 0.5f) } })
            Pill("Выключить всё", !fx.active, { vm.updateFx("preset") { Fx() } })
            Pill("Настроить", manual, { manual = !manual })
        }
        if (savedNames.isNotEmpty()) {
            Text("Мои пресеты", color = Dim, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                savedNames.forEach { name -> Pill(name, false, { vm.applyFxPreset(name) }) }
            }
        }
        if (manual) Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        LabeledSlider("Виньетка", fx.vignette, 0f..1f, if (fx.vignette <= 0.001f) "Выкл." else pct(fx.vignette)) { v ->
            vm.updateFx("vig") { it.copy(vignette = v) }
        }
        LabeledSlider("Тонировка", fx.tintAmount, 0f..0.6f, if (fx.tintAmount <= 0.001f) "Выкл." else pct(fx.tintAmount / 0.6f)) { v ->
            vm.updateFx("tint") { it.copy(tintAmount = v) }
        }
        if (fx.tintAmount > 0.001f) {
            Text("Цвет тонировки", color = Dim, fontSize = 12.sp)
            ColorRow(fx.tint) { c -> vm.updateFx("tintc") { it.copy(tint = c) } }
        }
        LabeledSlider("Контраст", fx.contrast, 0.7f..1.5f, pct(fx.contrast)) { v ->
            vm.updateFx("contrast") { it.copy(contrast = v) }
        }
        LabeledSlider("Яркость", fx.brightness, -1f..1f, pct(fx.brightness)) { v ->
            vm.updateFx("brightness") { it.copy(brightness = v) }
        }
        LabeledSlider("Экспозиция", fx.exposure, -2f..2f, String.format("%.1f EV", fx.exposure)) { v ->
            vm.updateFx("exposure") { it.copy(exposure = v) }
        }
        LabeledSlider("Температура", fx.temperature, -1f..1f, (fx.temperature * 100).roundToInt().toString()) { v ->
            vm.updateFx("temperature") { it.copy(temperature = v) }
        }
        LabeledSlider("Оттенок", fx.hue, -180f..180f, "${fx.hue.roundToInt()}°") { v ->
            vm.updateFx("hue") { it.copy(hue = v) }
        }
        LabeledSlider("Насыщенность", fx.saturation, 0f..1.6f, pct(fx.saturation)) { v ->
            vm.updateFx("sat") { it.copy(saturation = v) }
        }
        Pill(if (advanced) "Скрыть расширенные" else "Расширенные настройки", advanced, { advanced = !advanced })
        if (advanced) {
            SectionLabel("HSL · отдельные цветовые каналы")
            LabeledSlider("Красный · оттенок", fx.redHue, -100f..100f, fx.redHue.roundToInt().toString()) { v -> vm.updateFx("hsl-rh") { it.copy(redHue = v) } }
            LabeledSlider("Красный · насыщенность", fx.redSat, 0f..2f, pct(fx.redSat)) { v -> vm.updateFx("hsl-rs") { it.copy(redSat = v) } }
            LabeledSlider("Красный · яркость", fx.redLum, -1f..1f, pct(fx.redLum)) { v -> vm.updateFx("hsl-rl") { it.copy(redLum = v) } }
            LabeledSlider("Зелёный · оттенок", fx.greenHue, -100f..100f, fx.greenHue.roundToInt().toString()) { v -> vm.updateFx("hsl-gh") { it.copy(greenHue = v) } }
            LabeledSlider("Зелёный · насыщенность", fx.greenSat, 0f..2f, pct(fx.greenSat)) { v -> vm.updateFx("hsl-gs") { it.copy(greenSat = v) } }
            LabeledSlider("Зелёный · яркость", fx.greenLum, -1f..1f, pct(fx.greenLum)) { v -> vm.updateFx("hsl-gl") { it.copy(greenLum = v) } }
            LabeledSlider("Синий · оттенок", fx.blueHue, -100f..100f, fx.blueHue.roundToInt().toString()) { v -> vm.updateFx("hsl-bh") { it.copy(blueHue = v) } }
            LabeledSlider("Синий · насыщенность", fx.blueSat, 0f..2f, pct(fx.blueSat)) { v -> vm.updateFx("hsl-bs") { it.copy(blueSat = v) } }
            LabeledSlider("Синий · яркость", fx.blueLum, -1f..1f, pct(fx.blueLum)) { v -> vm.updateFx("hsl-bl") { it.copy(blueLum = v) } }
            SectionLabel("Кривая и LUT")
            LabeledSlider("Гамма кривой", fx.curveGamma, 0.5f..2f, String.format("%.2f", fx.curveGamma)) { v -> vm.updateFx("curve") { it.copy(curveGamma = v) } }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Без LUT", "Teal", "Matte", "Cinema", "Vintage").forEachIndexed { i, name ->
                    Pill(name, fx.lut == i, { vm.updateFx("lut") { it.copy(lut = i) } })
                }
            }
            SectionLabel("Градиентная тонировка")
            LabeledSlider("Интенсивность градиента", fx.gradientAmount, 0f..1f, pct(fx.gradientAmount)) { v ->
                vm.updateFx("gradient") { it.copy(gradientAmount = v) }
            }
            Text("Верхний цвет градиента", color = Dim, fontSize = 12.sp)
            ColorRow(fx.gradientTop) { c -> vm.updateFx("gradient-top") { it.copy(gradientTop = c) } }
            Text("Нижний цвет градиента", color = Dim, fontSize = 12.sp)
            ColorRow(fx.gradientBottom) { c -> vm.updateFx("gradient-bottom") { it.copy(gradientBottom = c) } }
            OutlinedTextField(presetName, { presetName = it }, label = { Text("Имя собственного пресета") },
                modifier = Modifier.fillMaxWidth(), singleLine = true, colors = coverFieldColors())
            Pill("Сохранить настройки", false, {
                if (vm.saveFxPreset(presetName)) savedNames = vm.savedFxPresetNames()
            })
        }
        LabeledSlider("Плёночное зерно", fx.grain, 0f..1f, if (fx.grain <= 0.001f) "Выкл." else pct(fx.grain)) { v ->
            vm.updateFx("grain") { it.copy(grain = v) }
        }
        LabeledSlider("Снегопад", fx.snow, 0f..1f, if (fx.snow <= 0.001f) "Выкл." else pct(fx.snow)) { v ->
            vm.updateFx("snow") { it.copy(snow = v) }
        }
        if (fx.snow > 0.001f) {
            LabeledSlider("Наклон снега (ветер)", fx.snowWind, 0f..1f, pct(fx.snowWind)) { v ->
                vm.updateFx("wind") { it.copy(snowWind = v) }
            }
            Pill("Другой узор снега", false, { vm.updateFx("seed") { it.copy(snowSeed = it.snowSeed + 1) } })
        }
        }
    }
}
