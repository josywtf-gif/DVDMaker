package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.util.LruCache
import org.json.JSONObject

/**
 * Единая точка доступа к изображению слоя и его недеструктивным операциям.
 *
 * `Layer.path` — текущий отображаемый результат (может быть производным файлом),
 * `sourcePath` — рабочий исходник для повторной обработки, `originalPath` —
 * неизменяемый файл импорта. Все визуальные параметры остаются в Layer и JSON;
 * этот класс не записывает результат поверх исходников.
 */
object ImageProcessingPipeline {
    /** Execution stage of a serialized operation. Order is always taken from the operation list. */
    private enum class ExecutionStage { BITMAP, CANVAS, BACKDROP, LEGACY, UNKNOWN }

    private data class PlannedOperation(
        val operation: ImageOperation,
        val stage: ExecutionStage,
        val dependencyValid: Boolean
    )

    /** Effective ordered stack: persisted operations followed by missing Layer compatibility projections. */
    private fun effectiveOperations(layer: Layer): List<ImageOperation> {
        val storedTypes = layer.imageOperations.mapTo(mutableSetOf()) { it.type }
        return layer.imageOperations + layer.legacyImageOperations().filterNot { it.type in storedTypes }
    }

    /**
     * Builds a non-mutating execution plan and validates every explicit dependency.
     * Render-stage operations are classified separately so bitmap replay can stop
     * safely without silently moving later bitmap operations ahead of them.
     */
    private fun executionPlan(operations: List<ImageOperation>): List<PlannedOperation> {
        var previousOperationId = ""
        val ambiguousIds = operations.asSequence()
            .filterNot { it.type.startsWith(ImageOperationType.LEGACY_PREFIX) }
            .filter { it.id.isNotBlank() }
            .groupingBy { it.id }
            .eachCount()
            .filterValues { it > 1 }
            .keys
        return operations.map { operation ->
            // recordOperation() deliberately links stable operations to the previous
            // non-legacy node. Legacy snapshots are compatibility/render adapters,
            // not dependency-chain anchors; counting them here would reject valid
            // chains whenever a legacy.* snapshot sits between two stable records.
            val isLegacySnapshot = operation.type.startsWith(ImageOperationType.LEGACY_PREFIX)
            val dependencyValid = isLegacySnapshot || (
                operation.id !in ambiguousIds && operation.inputOperationId !in ambiguousIds &&
                    (operation.inputOperationId.isBlank() || operation.inputOperationId == previousOperationId)
                )
            val stage = when {
                // Transitional legacy snapshots mirror Layer fields; they are kept
                // in JSON for compatibility but are not executable nodes in the
                // operation chain and must never become replay barriers.
                isLegacySnapshot -> ExecutionStage.LEGACY
                operation.schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION -> ExecutionStage.UNKNOWN
                operation.type == ImageOperationType.BACKGROUND_REMOVAL ||
                    operation.type == ImageOperationType.GAUSSIAN_BLUR ||
                    operation.type == ImageOperationType.ENHANCE -> ExecutionStage.BITMAP
                operation.type == ImageOperationType.FADE ||
                    operation.type == ImageOperationType.OPACITY ||
                    operation.type == ImageOperationType.COLOR_GRADE ||
                    operation.type == ImageOperationType.CROP ||
                    operation.type == ImageOperationType.GEOMETRY -> ExecutionStage.CANVAS
                operation.type == ImageOperationType.EDGE_INTEGRATION -> ExecutionStage.BACKDROP
                else -> ExecutionStage.UNKNOWN
            }
            if (!isLegacySnapshot) previousOperationId = operation.id
            PlannedOperation(operation, stage, dependencyValid)
        }
    }

    private val blurCache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun trimMemory(level: Int) {
        when {
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> blurCache.evictAll()
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND -> blurCache.trimToSize(6 * 1024 * 1024)
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> blurCache.trimToSize(12 * 1024 * 1024)
        }
    }

    fun previewPath(layer: Layer): String {
        if (layer.path.isNotBlank() && java.io.File(layer.path).exists()) return layer.path
        layer.imageOperations.lastOrNull { it.enabled && it.resultPath.isNotBlank() && java.io.File(it.resultPath).exists() }
            ?.let { return it.resultPath }
        return layer.sourcePath.ifBlank { layer.originalPath }
    }

    /** Рабочий источник для операций, которые пересчитывают изображение заново. */
    fun editSourcePath(layer: Layer): String = layer.sourcePath.ifBlank {
        layer.enhanceSourcePath.ifBlank { layer.path.ifBlank { layer.originalPath } }
    }

    fun previewBitmap(layer: Layer): Bitmap? = Bitmaps.get(previewPath(layer))

    fun editSourceBitmap(layer: Layer): Bitmap? = Bitmaps.get(editSourcePath(layer))

    /** Фиксирует производный результат отдельным файлом; никогда не перезаписывает исходник. */
    fun commitDerived(store: Store, bitmap: Bitmap, preferPng: Boolean): String? =
        store.saveBitmap(bitmap, png = preferPng, prefix = "derived-")

    /** Возвращает параметры legacy-семейства; старые поля Layer остаются источником совместимости. */
    private fun legacyParams(layer: Layer, family: String): JSONObject {
        val type = ImageOperationType.LEGACY_PREFIX + family
        // Layer fields remain the compatibility source of truth while their editors
        // still write those fields. Prefer a fresh projection to avoid stale snapshots.
        val snapshot = layer.legacyImageOperations().firstOrNull { it.type == type }
        if (snapshot != null) return runCatching { JSONObject(snapshot.parameters) }.getOrDefault(JSONObject())
        val stored = layer.imageOperations.lastOrNull { it.type == type }
        return stored?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) } ?: JSONObject()
    }

    /** Возвращает материализованную legacy-операцию для общего renderer-executor. */
    fun legacyOperation(layer: Layer, family: String): ImageOperation? {
        // A persisted stable operation (including enabled=false) is authoritative.
        // Resolve it before projecting Layer compatibility fields; otherwise a
        // disabled stable Fade could be shadowed by a freshly projected legacy copy.
        if (family == "image-effects") {
            layer.imageOperations.lastOrNull { it.type == ImageOperationType.FADE }?.let { return it }
            layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.FADE }?.let { return it }
        }
        return layer.imageOperations.lastOrNull { it.type == ImageOperationType.LEGACY_PREFIX + family }
            ?: layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.LEGACY_PREFIX + family }
    }

    /** Параметры непрозрачности фото; старые Layer-поля остаются совместимым источником. */
    fun imageOpacity(layer: Layer): Float {
        val stored = layer.imageOperations.lastOrNull { it.type == ImageOperationType.OPACITY }
        if (stored?.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION) {
            if (!stored.enabled) return 1f
            val params = runCatching { JSONObject(stored.parameters) }.getOrDefault(JSONObject())
            return params.optDouble("value", layer.alpha.toDouble()).toFloat().coerceIn(0f, 1f)
        }
        val projected = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.OPACITY }
        val params = (projected ?: stored)?.takeIf {
            it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION
        }?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: legacyParams(layer, "opacity")
        return params.optDouble("value", layer.alpha.toDouble()).toFloat().coerceIn(0f, 1f)
    }

    /** Параметры визуальных эффектов фото, централизованно читаемые из legacy-операции. */
    data class ImageEffects(
        val blur: Int,
        val fade: Float,
        val fadeEdges: Int,
        val fadeStyle: Int
    )

    fun imageEffects(layer: Layer): ImageEffects {
        val p = legacyParams(layer, "image-effects")
        val blurParams = legacyParams(layer, "blur")
        return ImageEffects(
            blur = blurParams.optInt("level", layer.imageBlur).coerceIn(0, 3),
            fade = p.optDouble("fade", layer.imageFade.toDouble()).toFloat().coerceIn(0f, 0.45f),
            fadeEdges = p.optInt("fadeEdges", layer.imageFadeEdges).coerceIn(1, 15),
            fadeStyle = p.optInt("fadeStyle", layer.imageFadeStyle).coerceIn(0, 1)
        )
    }

    /** Геометрия фото, централизованно проецируемая из совместимых полей Layer. */
    data class ImageGeometry(
        val rotation: Float,
        val flipX: Boolean,
        val flipY: Boolean,
        val tiltX: Float,
        val tiltY: Float
    )

    fun imageGeometry(layer: Layer): ImageGeometry {
        val stored = layer.imageOperations.lastOrNull { it.type == ImageOperationType.GEOMETRY }
        if (stored?.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION && !stored.enabled) {
            return ImageGeometry(0f, false, false, 0f, 0f)
        }
        val projected = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.GEOMETRY }
        // A future schema is preserved verbatim; render using compatible Layer fields
        // rather than interpreting parameters whose meaning may have changed.
        val operation = stored?.takeIf { it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION } ?: projected
        val p = operation
            ?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: legacyParams(layer, "geometry")
        return ImageGeometry(
            rotation = p.optDouble("rotation", layer.rot.toDouble()).toFloat(),
            flipX = p.optBoolean("flipX", layer.flipX),
            flipY = p.optBoolean("flipY", layer.flipY),
            tiltX = p.optDouble("tiltX", layer.imageTiltX.toDouble()).toFloat().coerceIn(-65f, 65f),
            tiltY = p.optDouble("tiltY", layer.imageTiltY.toDouble()).toFloat().coerceIn(-65f, 65f)
        )
    }

    /** Нормализованные границы кадрирования; стабильная операция имеет приоритет над legacy-полями. */
    fun cropFractions(layer: Layer): RectFValues {
        val stored = layer.imageOperations.lastOrNull { it.type == ImageOperationType.CROP }
        if (stored?.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION && !stored.enabled) {
            return RectFValues(0f, 0f, 1f, 1f)
        }
        val projected = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.CROP }
        val operation = stored?.takeIf { it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION } ?: projected
        val p = operation
            ?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: legacyParams(layer, "crop")
        val left = p.optDouble("left", layer.cropLeft.toDouble()).toFloat().coerceIn(0f, 0.8f)
        val top = p.optDouble("top", layer.cropTop.toDouble()).toFloat().coerceIn(0f, 0.8f)
        val right = p.optDouble("right", layer.cropRight.toDouble()).toFloat().coerceIn(0.2f, 1f)
        val bottom = p.optDouble("bottom", layer.cropBottom.toDouble()).toFloat().coerceIn(0.2f, 1f)
        return RectFValues(left, top, right, bottom)
    }

    data class RectFValues(val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val width: Float get() = (right - left).coerceAtLeast(0.05f)
        val height: Float get() = (bottom - top).coerceAtLeast(0.05f)
    }

    fun cropRect(layer: Layer, bitmap: Bitmap): Rect = cropRect(cropFractions(layer), bitmap)

    /** Crop a bitmap from an already-resolved render snapshot. */
    fun cropRect(crop: RectFValues, bitmap: Bitmap): Rect {
        val width = bitmap.width.coerceAtLeast(1)
        val height = bitmap.height.coerceAtLeast(1)
        val left = (crop.left * width).toInt().coerceIn(0, width - 1)
        val top = (crop.top * height).toInt().coerceIn(0, height - 1)
        val right = (crop.right * width).toInt().coerceIn(left + 1, width)
        val bottom = (crop.bottom * height).toInt().coerceIn(top + 1, height)
        return Rect(left, top, right, bottom)
    }

    data class ImageEdgeSettings(
        val edgeClean: Float,
        val lightWrap: Float,
        val edgeRelight: Float,
        val edgeShade: Float,
        val wrapColor: Int,
        val wrapAuto: Boolean,
        val choke: Float,
        val colorMatch: Float,
        val contactShadow: Float
    )

    /**
     * Immutable snapshot consumed by the shared preview/export renderer.
     * The serialized operation list is retained in its original order; this snapshot
     * resolves each render family once so geometry, crop, grade, opacity and edge
     * integration cannot observe different Layer/legacy projections in one draw.
     * `dependencyChainValid` is diagnostic for render-stage ordering; bitmap replay
     * remains stricter and refuses to cross a render-stage boundary.
     */
    data class OperationExecutionInfo(
        val operation: ImageOperation,
        val stage: String,
        val dependencyValid: Boolean,
        val blocksBitmapReplay: Boolean
    )

    data class ImageRenderPlan(
        val sourcePath: String,
        val orderedOperations: List<ImageOperation>,
        val execution: List<OperationExecutionInfo>,
        val firstBitmapReplayBarrierId: String?,
        val geometry: ImageGeometry,
        val crop: RectFValues,
        val opacity: Float,
        val gradedLayer: Layer,
        val edgeSettings: ImageEdgeSettings,
        val fadeOperation: ImageOperation?,
        val blurLevel: Int,
        val dependencyChainValid: Boolean,
        val containsUnknownOperation: Boolean
    )

    /** Immutable pre-operation source used by the ordered renderer. */
    fun operationSourcePath(layer: Layer): String {
        val candidates = listOf(layer.sourcePath, layer.originalPath, layer.path).filter { it.isNotBlank() }
        return candidates.firstOrNull { java.io.File(it).isFile } ?: candidates.firstOrNull().orEmpty()
    }

    /** Crop operations are cumulative: each crop addresses the output of its predecessor. */
    private fun orderedCrop(operations: List<ImageOperation>, layer: Layer): RectFValues {
        var result = RectFValues(0f, 0f, 1f, 1f)
        var found = false
        var changedSinceMaterializedResult = false
        val hasStableCrop = operations.any { it.type == ImageOperationType.CROP }
        for (step in executionPlan(operations)) {
            val operation = step.operation
            val isLegacyCrop = operation.type == ImageOperationType.LEGACY_PREFIX + "crop" && !hasStableCrop
            if (step.stage == ExecutionStage.LEGACY && !isLegacyCrop) continue
            if (!step.dependencyValid) break
            if (!operation.enabled) continue
            if (operation.schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION || step.stage == ExecutionStage.UNKNOWN) break
            when (operation.type) {
                ImageOperationType.CROP, ImageOperationType.LEGACY_PREFIX + "crop" -> {
                    val params = runCatching { JSONObject(operation.parameters) }.getOrDefault(JSONObject())
                    val left = params.optDouble("left", 0.0).toFloat().coerceIn(0f, 0.8f)
                    val top = params.optDouble("top", 0.0).toFloat().coerceIn(0f, 0.8f)
                    val right = params.optDouble("right", 1.0).toFloat().coerceIn(0.2f, 1f)
                    val bottom = params.optDouble("bottom", 1.0).toFloat().coerceIn(0.2f, 1f)
                    val old = result
                    result = RectFValues(
                        (old.left + old.width * left).coerceIn(0f, 0.95f),
                        (old.top + old.height * top).coerceIn(0f, 0.95f),
                        (old.left + old.width * right).coerceIn(0.05f, 1f),
                        (old.top + old.height * bottom).coerceIn(0.05f, 1f)
                    )
                    found = true
                    if (left > 0f || top > 0f || right < 1f || bottom < 1f) {
                        changedSinceMaterializedResult = true
                    }
                }
                ImageOperationType.ENHANCE, ImageOperationType.BACKGROUND_REMOVAL -> {
                    if (changedSinceMaterializedResult || operation.resultPath.isBlank() || !java.io.File(operation.resultPath).isFile) break
                    changedSinceMaterializedResult = false
                }
                ImageOperationType.GAUSSIAN_BLUR -> {
                    if (changedSinceMaterializedResult || operation.resultPath.isBlank() || !java.io.File(operation.resultPath).isFile) {
                        changedSinceMaterializedResult = true
                    }
                }
                ImageOperationType.GEOMETRY, ImageOperationType.OPACITY, ImageOperationType.COLOR_GRADE,
                ImageOperationType.FADE, ImageOperationType.EDGE_INTEGRATION -> changedSinceMaterializedResult = true
            }
        }
        return if (found) result else cropFractions(layer)
    }

    /** Resolve one consistent render snapshot for both preview and export. */
    fun renderPlan(layer: Layer): ImageRenderPlan {
        // Resolve exactly the same effective list used by bitmap replay. This includes
        // compatibility projections not yet materialized into JSON, in their effective
        // order, so diagnostics cannot silently omit a Canvas/backdrop barrier.
        val operations = effectiveOperations(layer)
        val planned = executionPlan(operations)
        val stable = planned.filter { it.stage != ExecutionStage.LEGACY }
        val blurHasMaterializedResult = operations.any {
            it.type == ImageOperationType.GAUSSIAN_BLUR && it.enabled &&
                it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION &&
                it.resultPath.isNotBlank() && java.io.File(it.resultPath).isFile
        }
        val blurLevel = if (blurHasMaterializedResult) 0 else imageEffects(layer).blur
        val fade = planned.lastOrNull {
            it.stage != ExecutionStage.LEGACY && it.operation.type == ImageOperationType.FADE
        }?.operation ?: legacyOperation(layer, "image-effects")
        val execution = planned.map { step ->
            OperationExecutionInfo(
                operation = step.operation,
                stage = step.stage.name.lowercase(),
                dependencyValid = step.dependencyValid,
                blocksBitmapReplay = step.operation.enabled &&
                    step.stage != ExecutionStage.BITMAP && step.stage != ExecutionStage.LEGACY
            )
        }
        return ImageRenderPlan(
            sourcePath = operationSourcePath(layer),
            orderedOperations = operations.toList(),
            execution = execution,
            firstBitmapReplayBarrierId = execution.firstOrNull { it.blocksBitmapReplay }?.operation?.id,
            geometry = imageGeometry(layer),
            crop = orderedCrop(operations, layer),
            opacity = imageOpacity(layer),
            gradedLayer = imageGrade(layer),
            edgeSettings = imageEdgeSettings(layer),
            fadeOperation = fade,
            blurLevel = blurLevel,
            dependencyChainValid = planned.all { it.dependencyValid },
            containsUnknownOperation = stable.any { it.stage == ExecutionStage.UNKNOWN }
        )
    }

    /** Stable edge-integration operation; legacy Layer fields remain the migration/fallback source. */
    fun imageEdgeSettings(layer: Layer): ImageEdgeSettings {
        val stored = layer.imageOperations.lastOrNull { it.type == ImageOperationType.EDGE_INTEGRATION }
        if (stored?.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION && !stored.enabled) {
            return ImageEdgeSettings(0f, 0f, 0f, 0f, android.graphics.Color.WHITE, false, 0f, 0f, 0f)
        }
        val projected = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.EDGE_INTEGRATION }
        // Do not interpret a future schema: keep rendering from compatible Layer fields.
        val operation = stored?.takeIf { it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION } ?: projected
        val p = operation?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: if (stored == null) legacyParams(layer, "edge-integration") else null
        return ImageEdgeSettings(
            edgeClean = (p?.optDouble("edgeClean", layer.imageEdgeClean.toDouble()) ?: layer.imageEdgeClean.toDouble()).toFloat().coerceIn(0f, 1f),
            lightWrap = (p?.optDouble("lightWrap", layer.imageLightWrap.toDouble()) ?: layer.imageLightWrap.toDouble()).toFloat().coerceIn(0f, 1f),
            edgeRelight = (p?.optDouble("edgeRelight", layer.imageEdgeRelight.toDouble()) ?: layer.imageEdgeRelight.toDouble()).toFloat().coerceIn(0f, 1f),
            edgeShade = (p?.optDouble("edgeShade", layer.imageEdgeShade.toDouble()) ?: layer.imageEdgeShade.toDouble()).toFloat().coerceIn(0f, 1f),
            wrapColor = p?.optInt("wrapColor", layer.imageWrapColor) ?: layer.imageWrapColor,
            wrapAuto = p?.optBoolean("wrapAuto", layer.imageWrapAuto) ?: layer.imageWrapAuto,
            choke = (p?.optDouble("choke", layer.imageChoke.toDouble()) ?: layer.imageChoke.toDouble()).toFloat().coerceIn(0f, 1f),
            colorMatch = (p?.optDouble("colorMatch", layer.imageColorMatch.toDouble()) ?: layer.imageColorMatch.toDouble()).toFloat().coerceIn(0f, 1f),
            contactShadow = (p?.optDouble("contactShadow", layer.imageContactShadow.toDouble()) ?: layer.imageContactShadow.toDouble()).toFloat().coerceIn(0f, 1f)
        )
    }

    /** Исполняемый этап edge-integration для preview/export; не изменяет исходный bitmap. */
    fun prepareLayerBitmap(
        layer: Layer,
        source: Bitmap,
        environmentColor: Int,
        lightX: Float = 0f,
        lightY: Float = 0f,
        lightAmount: Float = 0f,
        lightStrength: Float = 1f,
        renderPlan: ImageRenderPlan? = null
    ): Bitmap {
        // Keep every derived cache/resource in this draw pass keyed to the exact
        // source selected by ImageRenderPlan. Re-resolving previewPath(layer) here
        // could observe a different Layer/cache state than the bitmap loaded by the
        // renderer a few lines earlier.
        val sourcePath = renderPlan?.sourcePath ?: previewPath(layer)
        val edge = renderPlan?.edgeSettings ?: imageEdgeSettings(layer)
        val wrapColor = if (edge.wrapAuto) environmentColor else edge.wrapColor
        val integrated = EdgeIntegration.process(
            sourcePath, source, edge.edgeClean, edge.lightWrap * lightStrength,
            edge.edgeRelight * lightStrength, wrapColor, lightX, lightY, lightAmount,
            edge.choke, edge.edgeShade, edge.colorMatch, environmentColor
        )
        // Once the explicit replay operation exists, its result already contains Blur;
        // do not apply the compatibility Layer.imageBlur a second time in Canvas.
        // A migrated legacy Blur may have a stable operation record but no
        // materialized bitmap yet. Keep the render-time compatibility fallback
        // until replay has produced an actual result file.
        val hasReplayBlur = layer.imageOperations.any {
            it.type == ImageOperationType.GAUSSIAN_BLUR && it.enabled &&
                it.resultPath.isNotBlank() && java.io.File(it.resultPath).exists()
        }
        val blurLevel = renderPlan?.blurLevel ?: if (hasReplayBlur) 0 else imageEffects(layer).blur
        if (blurLevel <= 0) return integrated
        val sigma = when (blurLevel) {
            1 -> 0.006f
            2 -> 0.012f
            else -> 0.022f
        }
        val key = "$sourcePath|${integrated.generationId}|${integrated.width}x${integrated.height}|$blurLevel"
        blurCache.get(key)?.let { return it }
        val blurred = Blur.gaussianPreserveAlpha(integrated, sigma)
        if (blurred !== integrated) blurCache.put(key, blurred)
        return blurred
    }


    /** Сохраняет редактируемую alpha-маску отдельно от результата; PNG не теряет значения маски. */
    fun saveMask(store: Store, mask: FloatArray, width: Int, height: Int): String? {
        if (width <= 0 || height <= 0 || mask.size != width * height) return null
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(mask.size) { i ->
            val alpha = (mask[i].coerceIn(0f, 1f) * 255f).toInt().coerceIn(0, 255)
            (alpha shl 24) or 0x00FFFFFF
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        return try { store.saveBitmap(bitmap, png = true, prefix = "mask-") } finally { bitmap.recycle() }
    }

    /** Читает сохранённую маску для повторного открытия/пересчёта операции. */
    fun loadMask(path: String): Pair<FloatArray, Pair<Int, Int>>? {
        if (path.isBlank()) return null
        val bitmap = Bitmaps.get(path) ?: return null
        val w = bitmap.width; val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        return FloatArray(pixels.size) { i -> ((pixels[i] ushr 24) and 255) / 255f } to (w to h)
    }

    /** Добавляет/заменяет операцию того же типа, сохраняя её параметры и ресурсы в модели проекта. */
    fun recordOperation(layer: Layer, operation: ImageOperation, replaceType: Boolean = true): Layer {
        // Materialize the current legacy Layer settings in the in-memory stack as well
        // as during JSON serialization, so subsequent edits retain their ordering.
        val existingTypes = layer.imageOperations.mapTo(mutableSetOf()) { it.type }
        val base = layer.imageOperations + layer.legacyImageOperations().filterNot { it.type in existingTypes }
        if (!replaceType) {
            val dependency = base.lastOrNull { !it.type.startsWith(ImageOperationType.LEGACY_PREFIX) }?.id.orEmpty()
            return layer.copy(imageOperations = base + operation.copy(
                inputOperationId = operation.inputOperationId.ifBlank { dependency }
            ))
        }
        val index = base.indexOfFirst { it.type == operation.type }
        val next = base.toMutableList()
        if (index >= 0) {
            val dependency = next.subList(0, index).lastOrNull { !it.type.startsWith(ImageOperationType.LEGACY_PREFIX) }?.id.orEmpty()
            next[index] = operation.copy(
                id = next[index].id,
                inputOperationId = operation.inputOperationId.ifBlank { dependency }
            )
        } else {
            val dependency = base.lastOrNull { !it.type.startsWith(ImageOperationType.LEGACY_PREFIX) }?.id.orEmpty()
            next.add(operation.copy(inputOperationId = operation.inputOperationId.ifBlank { dependency }))
        }
        return layer.copy(imageOperations = next)
    }

    /**
     * Исходник непосредственно перед bitmap-операцией.
     *
     * Это только path-only адаптер и он не выполняет materialization. Если префикс
     * содержит render-stage/неизвестный узел, возвращает пустой путь; AI UI должен
     * использовать `ImageOperationRenderer.materializeBeforeOperation()`.
     */
    fun pathBeforeOperation(layer: Layer, type: String): String {
        // Match recordOperation(): stable records keep their order and missing Layer
        // snapshots are materialized at the end of the effective operation list.
        val operations = effectiveOperations(layer)
        val targetIndex = operations.indexOfFirst { it.type == type }
        // If this is a new operation, its input is after every operation already
        // recorded on the layer; do not silently place it before a render-stage node.
        val preceding = if (targetIndex >= 0) operations.take(targetIndex) else operations

        var currentPath = layer.sourcePath.ifBlank { layer.originalPath.ifBlank { layer.path } }
        val planned = executionPlan(operations)
        for (step in planned.take(preceding.size)) {
            val op = step.operation
            if (!step.dependencyValid) return ""
            if (step.stage == ExecutionStage.LEGACY || !op.enabled) continue
            // Until the shared Canvas/backdrop executor exists, an enabled
            // non-bitmap stage is a hard barrier for operations that need a bitmap.
            if (step.stage != ExecutionStage.BITMAP) return ""
            if (op.resultPath.isBlank() || !java.io.File(op.resultPath).isFile) return ""
            currentPath = op.resultPath
        }

        if (targetIndex >= 0 && !planned[targetIndex].dependencyValid) return ""
        return currentPath.takeIf { it.isNotBlank() && java.io.File(it).isFile }.orEmpty()
    }

    fun bitmapBeforeOperation(layer: Layer, type: String): Bitmap? =
        pathBeforeOperation(layer, type).takeIf { it.isNotBlank() }?.let { Bitmaps.get(it) }


    data class ReplayResult(val path: String, val operations: List<ImageOperation>)

    /** Пересчитывает операции после изменённой операции из её нового результата. */
    suspend fun replayFollowing(
        context: Context,
        store: Store,
        operations: List<ImageOperation>,
        changedType: String,
        changedResultPath: String,
        onProgress: (Int) -> Unit = {},
        baseLayer: Layer? = null,
        backdrop: BackdropLight? = null
    ): ReplayResult? {
        val changedIndex = operations.indexOfFirst { it.type == changedType }
        if (changedIndex < 0) return ReplayResult(changedResultPath, operations)
        val plan = executionPlan(operations)
        val changedParams = runCatching { JSONObject(plan[changedIndex].operation.parameters) }.getOrDefault(JSONObject())
        val changedInputFingerprint = changedParams.optString("inputFingerprint", "")
        // A fingerprint proves that the changed AI node received the fully materialized
        // prefix. For legacy bitmap-only operations, keep the previous strict path check.
        for (i in 0..changedIndex) {
            val step = plan[i]
            if (!step.dependencyValid) return null
            if (i < changedIndex && step.operation.enabled && step.stage != ExecutionStage.LEGACY) {
                when (step.stage) {
                    ExecutionStage.BITMAP -> {
                        val path = step.operation.resultPath
                        if (path.isBlank() || !java.io.File(path).isFile) return null
                    }
                    ExecutionStage.CANVAS, ExecutionStage.BACKDROP -> if (changedInputFingerprint.isBlank() || baseLayer == null) return null
                    else -> return null
                }
            }
        }
        if (plan[changedIndex].stage != ExecutionStage.BITMAP) return null
        var current = Bitmaps.get(changedResultPath) ?: return null
        var currentPath = changedResultPath
        var ownsCurrent = false
        val generatedPaths = mutableListOf<String>()
        val heldMaterializations = mutableListOf<ImageOperationRenderer.MaterializedInput>()
        val updated = operations.toMutableList()
        var needsOrderedMaterialization = false

        fun abortReplay(): ReplayResult? {
            generatedPaths.forEach { runCatching { java.io.File(it).delete() } }
            heldMaterializations.forEach { runCatching { it.close() } }
            if (ownsCurrent && !current.isRecycled) current.recycle()
            return null
        }

        for (i in changedIndex + 1 until updated.size) {
            val step = plan[i]
            val originalOperation = step.operation
            if (step.stage == ExecutionStage.LEGACY) continue
            if (!step.dependencyValid) return abortReplay()
            if (!originalOperation.enabled) continue
            if (step.stage == ExecutionStage.CANVAS || step.stage == ExecutionStage.BACKDROP) {
                if (baseLayer == null) return abortReplay()
                needsOrderedMaterialization = true
                continue
            }
            if (step.stage != ExecutionStage.BITMAP) return abortReplay()

            val op = updated[i]
            var aiInputFingerprint = ""
            var materialized: ImageOperationRenderer.MaterializedInput? = null
            var next: Bitmap? = null
            try {
                val inputBitmap: Bitmap
                if (needsOrderedMaterialization) {
                    val prefixLayer = baseLayer!!.copy(imageOperations = updated.toList())
                    materialized = ImageOperationRenderer.materializeBeforeOperation(
                        context, store, prefixLayer, op.type, backdrop = backdrop, onProgress = onProgress
                    ) ?: return abortReplay()
                    heldMaterializations += materialized
                    materialized.operations.forEachIndexed { index, updatedOperation ->
                        if (index < updated.size) updated[index] = updatedOperation
                    }
                    inputBitmap = materialized.bitmap
                    aiInputFingerprint = materialized.fingerprint
                } else if (op.type == ImageOperationType.ENHANCE || op.type == ImageOperationType.BACKGROUND_REMOVAL) {
                    val fileInput = ImageOperationRenderer.materializePng(context, current) ?: return abortReplay()
                    materialized = ImageOperationRenderer.MaterializedInput(
                        fileInput.first.absolutePath, fileInput.second,
                        ImageOperationRenderer.bitmapFingerprint(fileInput.second), updated.toList()
                    )
                    heldMaterializations += materialized
                    inputBitmap = materialized.bitmap
                    aiInputFingerprint = materialized.fingerprint
                } else {
                    inputBitmap = current
                }

                val params = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
                next = when (op.type) {
                    ImageOperationType.BACKGROUND_REMOVAL -> {
                        val mask = loadMask(op.assetPath) ?: return abortReplay()
                        BgRemover.applyMask(inputBitmap, mask.first, mask.second.first, mask.second.second) { onProgress(it) }
                    }
                    ImageOperationType.ENHANCE -> {
                        val scale = params.optDouble("scale", 1.0).toFloat().coerceIn(1f, 4f)
                        val detail = params.optDouble("detail", 0.45).toFloat().coerceIn(0f, 1f)
                        val grain = params.optDouble("grain", 0.6).toFloat().coerceIn(0f, 1f)
                        Enhancer.enhance(context, inputBitmap, scale, EnhanceOpts(detail, grain)) { onProgress(it) }
                    }
                    ImageOperationType.GAUSSIAN_BLUR -> {
                        if (aiInputFingerprint.isBlank()) aiInputFingerprint = ImageOperationRenderer.bitmapFingerprint(inputBitmap)
                        val sigma = params.optDouble("sigmaFrac", 0.012).toFloat().coerceIn(0.001f, 0.12f)
                        val blurred = Blur.gaussianPreserveAlpha(inputBitmap, sigma)
                        if (blurred === inputBitmap && materialized != null) {
                            inputBitmap.copy(Bitmap.Config.ARGB_8888, true)
                        } else blurred
                    }
                    else -> null
                } ?: return abortReplay()
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                next?.takeIf { it !== current && !it.isRecycled }?.recycle()
                abortReplay()
                throw cancelled
            } catch (_: Throwable) {
                next?.takeIf { it !== current && !it.isRecycled }?.recycle()
                return abortReplay()
            } finally {
                materialized?.releaseInput()
            }

            val output = next ?: return abortReplay()
            val path = try {
                commitDerived(store, output, true)
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                if (output !== current && !output.isRecycled) output.recycle()
                abortReplay()
                throw cancelled
            } catch (_: Throwable) {
                if (output !== current && !output.isRecycled) output.recycle()
                return abortReplay()
            } ?: run {
                if (output !== current && !output.isRecycled) output.recycle()
                return abortReplay()
            }
            generatedPaths += path
            val previousCurrent = current
            if (ownsCurrent && previousCurrent !== output && !previousCurrent.isRecycled) previousCurrent.recycle()
            current = output
            ownsCurrent = output !== previousCurrent
            currentPath = path
            val updatedParams = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
            if (aiInputFingerprint.isNotBlank()) updatedParams.put("inputFingerprint", aiInputFingerprint)
            updated[i] = op.copy(resultPath = path, parameters = updatedParams.toString())
            needsOrderedMaterialization = false
        }
        heldMaterializations.forEach { it.commitGenerated(); it.close() }
        return ReplayResult(currentPath, updated)
    }

    private fun blurSigmaForLevel(level: Int): Float = when (level.coerceIn(1, 3)) {
        1 -> 0.006f
        2 -> 0.012f
        else -> 0.022f
    }

    /** Текущий уровень отдельной операции; legacy imageBlur используется только до миграции. */
    fun gaussianBlurEditable(layer: Layer): Boolean = layer.imageOperations
        .lastOrNull { it.type == ImageOperationType.GAUSSIAN_BLUR }
        ?.schemaVersion?.let { it == ImageOperation.CURRENT_SCHEMA_VERSION } ?: true

    fun gaussianBlurLevel(layer: Layer): Int {
        val op = layer.imageOperations.lastOrNull { it.type == ImageOperationType.GAUSSIAN_BLUR }
            ?: return layer.imageBlur.coerceIn(0, 3)
        if (!op.enabled || op.schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION) return 0
        val params = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
        return params.optInt("level", when {
            params.optDouble("sigmaFrac", 0.012) < 0.009 -> 1
            params.optDouble("sigmaFrac", 0.012) < 0.017 -> 2
            else -> 3
        }).coerceIn(1, 3)
    }

    /** Создаёт редактируемую операцию Gaussian Blur с сохранённым уровнем и sigma. */
    fun gaussianBlurOperation(level: Int, resultPath: String = "") : ImageOperation {
        val safeLevel = level.coerceIn(1, 3)
        return ImageOperation(
            type = ImageOperationType.GAUSSIAN_BLUR,
            parameters = JSONObject().put("level", safeLevel)
                .put("sigmaFrac", blurSigmaForLevel(safeLevel).toDouble()).toString(),
            resultPath = resultPath
        )
    }

    /**
     * Включает, меняет или отключает Gaussian Blur в стеке.
     * Пересчёт всегда начинается с изображения непосредственно перед операцией;
     * legacy Layer.imageBlur мигрирует в операцию при первом изменении.
     */
    suspend fun setGaussianBlur(
        context: Context,
        store: Store,
        layer: Layer,
        level: Int,
        onProgress: (Int) -> Unit = {}
    ): ReplayResult? {
        val type = ImageOperationType.GAUSSIAN_BLUR
        val existingIndex = layer.imageOperations.indexOfFirst { it.type == type }
        if (existingIndex >= 0 && layer.imageOperations[existingIndex].schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION) return null
        val cleanOperations = layer.imageOperations.filterNot {
            it.type == ImageOperationType.LEGACY_PREFIX + "blur"
        }
        val cleanLayer = layer.copy(imageBlur = 0, imageOperations = cleanOperations)
        if (level <= 0) {
            if (existingIndex < 0) return ReplayResult(previewPath(layer), cleanOperations)
            val inputPath = pathBeforeOperation(cleanLayer, type)
            if (inputPath.isBlank()) return null
            val updated = cleanOperations.map { op ->
                if (op.type == type) op.copy(enabled = false, resultPath = "") else op
            }
            return replayFollowing(context, store, updated, type, inputPath, onProgress)
        }

        val inputPath = pathBeforeOperation(cleanLayer, type)
        if (inputPath.isBlank()) return null
        val source = Bitmaps.get(inputPath) ?: return null
        val operation = gaussianBlurOperation(level)
        val recorded = recordOperation(cleanLayer, operation, replaceType = true).imageOperations
        val recordedOperationId = recorded.firstOrNull { it.type == type }?.id ?: operation.id
        onProgress(10)
        val sigma = blurSigmaForLevel(level)
        val blurred = try {
            Blur.gaussianPreserveAlpha(source, sigma)
        } catch (t: Throwable) {
            return null
        }
        val resultPath = try {
            commitDerived(store, blurred, preferPng = true)
        } finally {
            if (blurred !== source && !blurred.isRecycled) blurred.recycle()
        } ?: return null
        val withResult = recorded.map { op ->
            if (op.id == recordedOperationId) op.copy(resultPath = resultPath, enabled = true) else op
        }
        onProgress(100)
        return replayFollowing(context, store, withResult, type, resultPath, onProgress)
    }

    /** Параметры AI-улучшения сохраняются отдельно от производного bitmap-кэша. */
    fun enhanceOperation(scale: Float, detail: Float, grain: Float, resultPath: String, inputFingerprint: String = "") = ImageOperation(
        type = ImageOperationType.ENHANCE,
        parameters = JSONObject().put("scale", scale.toDouble()).put("detail", detail.toDouble())
            .put("grain", grain.toDouble()).put("inputFingerprint", inputFingerprint).toString(),
        resultPath = resultPath
    )

    /** Последний активный кэшированный результат операции, если он ещё существует. */
    fun operationPreviewPath(layer: Layer): String = layer.imageOperations.lastOrNull { it.enabled && it.resultPath.isNotBlank() && java.io.File(it.resultPath).exists() }?.resultPath
        ?: previewPath(layer)

    /** Параметры стабильной color-grade; старые legacy.color-grade и поля Layer остаются совместимыми. */
    fun imageGrade(layer: Layer): Layer {
        val stored = layer.imageOperations.lastOrNull { it.type == ImageOperationType.COLOR_GRADE }
        if (stored?.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION && !stored.enabled) {
            return layer.copy(
                imgHue = 0f, imgSat = 1f, imgBright = 0f, imgContrast = 1f,
                imgTemp = 0f, imgColorize = 0f
            )
        }
        val projected = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.COLOR_GRADE }
        val operation = stored?.takeIf { it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION } ?: projected ?: stored
        val params = operation
            ?.takeIf { it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION }
            ?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: legacyParams(layer, "color-grade")
        return layer.copy(
            imgHue = params.optDouble("hue", layer.imgHue.toDouble()).toFloat().coerceIn(-180f, 180f),
            imgSat = params.optDouble("saturation", layer.imgSat.toDouble()).toFloat().coerceIn(0f, 2.5f),
            imgBright = params.optDouble("brightness", layer.imgBright.toDouble()).toFloat().coerceIn(-0.6f, 0.6f),
            imgContrast = params.optDouble("contrast", layer.imgContrast.toDouble()).toFloat().coerceIn(0.5f, 1.8f),
            imgTemp = params.optDouble("temperature", layer.imgTemp.toDouble()).toFloat().coerceIn(-1f, 1f),
            imgColorize = params.optDouble("colorize", layer.imgColorize.toDouble()).toFloat().coerceIn(0f, 1f),
            imgColorizeColor = params.optInt("colorizeColor", layer.imgColorizeColor)
        )
    }

    /** Общая настройка краски для основного изображения и его отражения. */
    fun imagePaint(layer: Layer, alpha: Int = 255): Paint = imagePaintResolved(imageGrade(layer), alpha)

    /** Paint factory for a pre-resolved render snapshot; avoids re-reading Layer fields mid-draw. */
    fun imagePaintResolved(graded: Layer, alpha: Int = 255): Paint {
        return Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
            this.alpha = alpha.coerceIn(0, 255)
            if (graded.hasImageGrade) colorFilter = ColorMatrixColorFilter(FxPainter.imageMatrix(graded))
        }
    }
}
