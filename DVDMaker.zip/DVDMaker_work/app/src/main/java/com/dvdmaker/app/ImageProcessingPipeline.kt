package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.util.LruCache
import org.json.JSONObject

/**
 * Единая точка доступа к изображению слоя и его недеструктивным операциям.
 *
 * `Layer.path` — текущий отображаемый результат (может быть производным файлом),
 * `sourcePath` — рабочий исходник для повторной обработки, `originalPath` —
 * неизменяемый файл импорта. Все визуальные параметры остаются в Layer и JSON;
 * этот класс не записывает результат поверх исходников.
 */
object ImageProcessingPipeline {
    private val blurCache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun trimMemory(level: Int) {
        when {
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE -> blurCache.evictAll()
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND -> blurCache.trimToSize(6 * 1024 * 1024)
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> blurCache.trimToSize(12 * 1024 * 1024)
        }
    }

    fun previewPath(layer: Layer): String {
        if (layer.path.isNotBlank() && java.io.File(layer.path).exists()) return layer.path
        layer.imageOperations.lastOrNull { it.enabled && it.resultPath.isNotBlank() && java.io.File(it.resultPath).exists() }
            ?.let { return it.resultPath }
        return layer.sourcePath.ifBlank { layer.originalPath }
    }

    /** Рабочий источник для операций, которые пересчитывают изображение заново. */
    fun editSourcePath(layer: Layer): String = layer.sourcePath.ifBlank {
        layer.enhanceSourcePath.ifBlank { layer.path.ifBlank { layer.originalPath } }
    }

    fun previewBitmap(layer: Layer): Bitmap? = Bitmaps.get(previewPath(layer))

    fun editSourceBitmap(layer: Layer): Bitmap? = Bitmaps.get(editSourcePath(layer))

    /** Фиксирует производный результат отдельным файлом; никогда не перезаписывает исходник. */
    fun commitDerived(store: Store, bitmap: Bitmap, preferPng: Boolean): String? =
        store.saveBitmap(bitmap, png = preferPng, prefix = "derived-")

    /** Возвращает параметры legacy-семейства; старые поля Layer остаются источником совместимости. */
    private fun legacyParams(layer: Layer, family: String): JSONObject {
        val type = ImageOperationType.LEGACY_PREFIX + family
        // Layer fields remain the compatibility source of truth while their editors
        // still write those fields. Prefer a fresh projection to avoid stale snapshots.
        val snapshot = layer.legacyImageOperations().firstOrNull { it.type == type }
        if (snapshot != null) return runCatching { JSONObject(snapshot.parameters) }.getOrDefault(JSONObject())
        val stored = layer.imageOperations.lastOrNull { it.type == type }
        return stored?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) } ?: JSONObject()
    }

    /** Возвращает материализованную legacy-операцию для общего renderer-executor. */
    fun legacyOperation(layer: Layer, family: String): ImageOperation? {
        // Fade has a stable operation identifier for newly serialized projects;
        // retain the legacy family lookup for already-saved project JSON.
        if (family == "image-effects") {
            layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.FADE }?.let { return it }
            layer.imageOperations.lastOrNull { it.type == ImageOperationType.FADE }?.let { return it }
        }
        return layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.LEGACY_PREFIX + family }
            ?: layer.imageOperations.lastOrNull { it.type == ImageOperationType.LEGACY_PREFIX + family }
    }

    /** Параметры непрозрачности фото; старые Layer-поля остаются совместимым источником. */
    fun imageOpacity(layer: Layer): Float {
        val stable = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.OPACITY }
            ?: layer.imageOperations.lastOrNull { it.type == ImageOperationType.OPACITY }
        val params = stable?.takeIf { it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION }
            ?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: legacyParams(layer, "opacity")
        return params.optDouble("value", layer.alpha.toDouble()).toFloat().coerceIn(0f, 1f)
    }

    /** Параметры визуальных эффектов фото, централизованно читаемые из legacy-операции. */
    data class ImageEffects(
        val blur: Int,
        val fade: Float,
        val fadeEdges: Int,
        val fadeStyle: Int,
        val fadeBlend: Float
    )

    fun imageEffects(layer: Layer): ImageEffects {
        val p = legacyParams(layer, "image-effects")
        val blurParams = legacyParams(layer, "blur")
        return ImageEffects(
            blur = blurParams.optInt("level", layer.imageBlur).coerceIn(0, 3),
            fade = p.optDouble("fade", layer.imageFade.toDouble()).toFloat().coerceIn(0f, 0.45f),
            fadeEdges = p.optInt("fadeEdges", layer.imageFadeEdges).coerceIn(1, 15),
            fadeStyle = p.optInt("fadeStyle", layer.imageFadeStyle).coerceIn(0, 1),
            fadeBlend = p.optDouble("fadeBlend", layer.imageFadeBlend.toDouble()).toFloat().coerceIn(0f, 1f)
        )
    }

    /** Геометрия фото, централизованно проецируемая из совместимых полей Layer. */
    data class ImageGeometry(
        val rotation: Float,
        val flipX: Boolean,
        val flipY: Boolean,
        val tiltX: Float,
        val tiltY: Float
    )

    fun imageGeometry(layer: Layer): ImageGeometry {
        val projected = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.GEOMETRY }
        val stored = layer.imageOperations.lastOrNull { it.type == ImageOperationType.GEOMETRY }
        // A future schema is preserved verbatim; render using compatible Layer fields
        // rather than interpreting parameters whose meaning may have changed.
        val operation = projected ?: stored?.takeIf {
            it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION
        }
        val p = operation
            ?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: legacyParams(layer, "geometry")
        return ImageGeometry(
            rotation = p.optDouble("rotation", layer.rot.toDouble()).toFloat(),
            flipX = p.optBoolean("flipX", layer.flipX),
            flipY = p.optBoolean("flipY", layer.flipY),
            tiltX = p.optDouble("tiltX", layer.imageTiltX.toDouble()).toFloat().coerceIn(-65f, 65f),
            tiltY = p.optDouble("tiltY", layer.imageTiltY.toDouble()).toFloat().coerceIn(-65f, 65f)
        )
    }

    /** Нормализованные границы кадрирования; стабильная операция имеет приоритет над legacy-полями. */
    fun cropFractions(layer: Layer): RectFValues {
        val projected = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.CROP }
        val stored = layer.imageOperations.lastOrNull { it.type == ImageOperationType.CROP }
        val operation = projected ?: stored?.takeIf {
            it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION
        }
        val p = operation
            ?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: legacyParams(layer, "crop")
        val left = p.optDouble("left", layer.cropLeft.toDouble()).toFloat().coerceIn(0f, 0.8f)
        val top = p.optDouble("top", layer.cropTop.toDouble()).toFloat().coerceIn(0f, 0.8f)
        val right = p.optDouble("right", layer.cropRight.toDouble()).toFloat().coerceIn(0.2f, 1f)
        val bottom = p.optDouble("bottom", layer.cropBottom.toDouble()).toFloat().coerceIn(0.2f, 1f)
        return RectFValues(left, top, right, bottom)
    }

    data class RectFValues(val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val width: Float get() = (right - left).coerceAtLeast(0.05f)
        val height: Float get() = (bottom - top).coerceAtLeast(0.05f)
    }

    fun cropRect(layer: Layer, bitmap: Bitmap): Rect {
        val crop = cropFractions(layer)
        val left = (crop.left * bitmap.width).toInt().coerceIn(0, bitmap.width - 2)
        val top = (crop.top * bitmap.height).toInt().coerceIn(0, bitmap.height - 2)
        val right = (crop.right * bitmap.width).toInt().coerceIn(left + 1, bitmap.width)
        val bottom = (crop.bottom * bitmap.height).toInt().coerceIn(top + 1, bitmap.height)
        return Rect(left, top, right, bottom)
    }

    data class ImageEdgeSettings(
        val edgeClean: Float,
        val lightWrap: Float,
        val edgeRelight: Float,
        val edgeShade: Float,
        val wrapColor: Int,
        val wrapAuto: Boolean,
        val choke: Float,
        val colorMatch: Float,
        val contactShadow: Float
    )

    /** Stable edge-integration operation; legacy Layer fields remain the migration/fallback source. */
    fun imageEdgeSettings(layer: Layer): ImageEdgeSettings {
        val projected = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.EDGE_INTEGRATION }
        val stored = layer.imageOperations.lastOrNull { it.type == ImageOperationType.EDGE_INTEGRATION }
        // Do not interpret a future schema: keep rendering from compatible Layer fields.
        val operation = projected ?: stored?.takeIf {
            it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION
        }
        val p = operation?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: if (stored == null) legacyParams(layer, "edge-integration") else null
        return ImageEdgeSettings(
            edgeClean = (p?.optDouble("edgeClean", layer.imageEdgeClean.toDouble()) ?: layer.imageEdgeClean.toDouble()).toFloat().coerceIn(0f, 1f),
            lightWrap = (p?.optDouble("lightWrap", layer.imageLightWrap.toDouble()) ?: layer.imageLightWrap.toDouble()).toFloat().coerceIn(0f, 1f),
            edgeRelight = (p?.optDouble("edgeRelight", layer.imageEdgeRelight.toDouble()) ?: layer.imageEdgeRelight.toDouble()).toFloat().coerceIn(0f, 1f),
            edgeShade = (p?.optDouble("edgeShade", layer.imageEdgeShade.toDouble()) ?: layer.imageEdgeShade.toDouble()).toFloat().coerceIn(0f, 1f),
            wrapColor = p?.optInt("wrapColor", layer.imageWrapColor) ?: layer.imageWrapColor,
            wrapAuto = p?.optBoolean("wrapAuto", layer.imageWrapAuto) ?: layer.imageWrapAuto,
            choke = (p?.optDouble("choke", layer.imageChoke.toDouble()) ?: layer.imageChoke.toDouble()).toFloat().coerceIn(0f, 1f),
            colorMatch = (p?.optDouble("colorMatch", layer.imageColorMatch.toDouble()) ?: layer.imageColorMatch.toDouble()).toFloat().coerceIn(0f, 1f),
            contactShadow = (p?.optDouble("contactShadow", layer.imageContactShadow.toDouble()) ?: layer.imageContactShadow.toDouble()).toFloat().coerceIn(0f, 1f)
        )
    }

    /** Исполняемый этап edge-integration для preview/export; не изменяет исходный bitmap. */
    fun prepareLayerBitmap(
        layer: Layer,
        source: Bitmap,
        environmentColor: Int,
        lightX: Float = 0f,
        lightY: Float = 0f,
        lightAmount: Float = 0f,
        lightStrength: Float = 1f
    ): Bitmap {
        val edge = imageEdgeSettings(layer)
        val wrapColor = if (edge.wrapAuto) environmentColor else edge.wrapColor
        val integrated = EdgeIntegration.process(
            previewPath(layer), source, edge.edgeClean, edge.lightWrap * lightStrength,
            edge.edgeRelight * lightStrength, wrapColor, lightX, lightY, lightAmount,
            edge.choke, edge.edgeShade, edge.colorMatch, environmentColor
        )
        // Once the explicit replay operation exists, its result already contains Blur;
        // do not apply the compatibility Layer.imageBlur a second time in Canvas.
        val hasReplayBlur = layer.imageOperations.any {
            it.type == ImageOperationType.GAUSSIAN_BLUR && it.enabled
        }
        val blurLevel = if (hasReplayBlur) 0 else imageEffects(layer).blur
        if (blurLevel <= 0) return integrated
        val sigma = when (blurLevel) {
            1 -> 0.006f
            2 -> 0.012f
            else -> 0.022f
        }
        val key = "${previewPath(layer)}|${integrated.generationId}|${integrated.width}x${integrated.height}|$blurLevel"
        blurCache.get(key)?.let { return it }
        val blurred = Blur.gaussianPreserveAlpha(integrated, sigma)
        if (blurred !== integrated) blurCache.put(key, blurred)
        return blurred
    }


    /** Сохраняет редактируемую alpha-маску отдельно от результата; PNG не теряет значения маски. */
    fun saveMask(store: Store, mask: FloatArray, width: Int, height: Int): String? {
        if (width <= 0 || height <= 0 || mask.size != width * height) return null
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(mask.size) { i ->
            val alpha = (mask[i].coerceIn(0f, 1f) * 255f).toInt().coerceIn(0, 255)
            (alpha shl 24) or 0x00FFFFFF
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        return try { store.saveBitmap(bitmap, png = true, prefix = "mask-") } finally { bitmap.recycle() }
    }

    /** Читает сохранённую маску для повторного открытия/пересчёта операции. */
    fun loadMask(path: String): Pair<FloatArray, Pair<Int, Int>>? {
        if (path.isBlank()) return null
        val bitmap = Bitmaps.get(path) ?: return null
        val w = bitmap.width; val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        return FloatArray(pixels.size) { i -> ((pixels[i] ushr 24) and 255) / 255f } to (w to h)
    }

    /** Добавляет/заменяет операцию того же типа, сохраняя её параметры и ресурсы в модели проекта. */
    fun recordOperation(layer: Layer, operation: ImageOperation, replaceType: Boolean = true): Layer {
        // Materialize the current legacy Layer settings in the in-memory stack as well
        // as during JSON serialization, so subsequent edits retain their ordering.
        val existingTypes = layer.imageOperations.mapTo(mutableSetOf()) { it.type }
        val base = layer.imageOperations + layer.legacyImageOperations().filterNot { it.type in existingTypes }
        if (!replaceType) {
            val dependency = base.lastOrNull { !it.type.startsWith(ImageOperationType.LEGACY_PREFIX) }?.id.orEmpty()
            return layer.copy(imageOperations = base + operation.copy(
                inputOperationId = operation.inputOperationId.ifBlank { dependency }
            ))
        }
        val index = base.indexOfFirst { it.type == operation.type }
        val next = base.toMutableList()
        if (index >= 0) {
            val dependency = next.subList(0, index).lastOrNull { !it.type.startsWith(ImageOperationType.LEGACY_PREFIX) }?.id.orEmpty()
            next[index] = operation.copy(
                id = next[index].id,
                inputOperationId = operation.inputOperationId.ifBlank { dependency }
            )
        } else {
            val dependency = base.lastOrNull { !it.type.startsWith(ImageOperationType.LEGACY_PREFIX) }?.id.orEmpty()
            next.add(operation.copy(inputOperationId = operation.inputOperationId.ifBlank { dependency }))
        }
        return layer.copy(imageOperations = next)
    }

    /** Исходник непосредственно перед операцией; позволяет повторно открыть редактор маски. */
    fun pathBeforeOperation(layer: Layer, type: String): String {
        val index = layer.imageOperations.indexOfFirst { it.type == type }
        return if (index < 0) previewPath(layer) else
            layer.imageOperations.take(index).lastOrNull { it.enabled && it.resultPath.isNotBlank() && java.io.File(it.resultPath).exists() }?.resultPath
                ?: layer.sourcePath.ifBlank { layer.originalPath.ifBlank { layer.path } }
    }

    fun bitmapBeforeOperation(layer: Layer, type: String): Bitmap? = Bitmaps.get(pathBeforeOperation(layer, type))


    data class ReplayResult(val path: String, val operations: List<ImageOperation>)

    /** Пересчитывает операции после изменённой операции из её нового результата. */
    suspend fun replayFollowing(
        context: Context,
        store: Store,
        operations: List<ImageOperation>,
        changedType: String,
        changedResultPath: String,
        onProgress: (Int) -> Unit = {}
    ): ReplayResult? {
        val changedIndex = operations.indexOfFirst { it.type == changedType }
        if (changedIndex < 0) return ReplayResult(changedResultPath, operations)
        var current = Bitmaps.get(changedResultPath) ?: return null
        var currentPath = changedResultPath
        val updated = operations.toMutableList()
        for (i in changedIndex + 1 until updated.size) {
            val op = updated[i]
            if (!op.enabled) continue
            // Replay is strictly ordered. An enabled operation that this bitmap
            // executor cannot interpret is a barrier: applying a later bitmap op
            // to `current` would silently move it before this operation. Preserve
            // the remaining records and cached resources for a capable renderer.
            if (op.schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION) break
            val next = when (op.type) {
                ImageOperationType.BACKGROUND_REMOVAL -> {
                    val mask = loadMask(op.assetPath) ?: return null
                    BgRemover.applyMask(current, mask.first, mask.second.first, mask.second.second) { onProgress(it) }
                }
                ImageOperationType.GAUSSIAN_BLUR -> {
                    val params = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
                    val sigma = params.optDouble("sigmaFrac", 0.012).toFloat().coerceIn(0.001f, 0.12f)
                    Blur.gaussianPreserveAlpha(current, sigma)
                }
                ImageOperationType.ENHANCE -> {
                    val params = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
                    val scale = params.optDouble("scale", 1.0).toFloat().coerceIn(1f, 4f)
                    val detail = params.optDouble("detail", 0.45).toFloat().coerceIn(0f, 1f)
                    val grain = params.optDouble("grain", 0.6).toFloat().coerceIn(0f, 1f)
                    Enhancer.enhance(context, current, scale, EnhanceOpts(detail, grain)) { onProgress(it) }
                }
                else -> null // Render-stage and unknown operations stop bitmap replay.
            } ?: break
            val path = commitDerived(store, next, true) ?: run { next.recycle(); return null }
            if (current !== Bitmaps.get(changedResultPath)) current.recycle()
            current = next
            currentPath = path
            updated[i] = op.copy(resultPath = path)
        }
        return ReplayResult(currentPath, updated)
    }

    private fun blurSigmaForLevel(level: Int): Float = when (level.coerceIn(1, 3)) {
        1 -> 0.006f
        2 -> 0.012f
        else -> 0.022f
    }

    /** Текущий уровень отдельной операции; legacy imageBlur используется только до миграции. */
    fun gaussianBlurEditable(layer: Layer): Boolean = layer.imageOperations
        .lastOrNull { it.type == ImageOperationType.GAUSSIAN_BLUR }
        ?.schemaVersion?.let { it == ImageOperation.CURRENT_SCHEMA_VERSION } ?: true

    fun gaussianBlurLevel(layer: Layer): Int {
        val op = layer.imageOperations.lastOrNull { it.type == ImageOperationType.GAUSSIAN_BLUR }
            ?: return layer.imageBlur.coerceIn(0, 3)
        if (!op.enabled || op.schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION) return 0
        val params = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
        return params.optInt("level", when {
            params.optDouble("sigmaFrac", 0.012) < 0.009 -> 1
            params.optDouble("sigmaFrac", 0.012) < 0.017 -> 2
            else -> 3
        }).coerceIn(1, 3)
    }

    /** Создаёт редактируемую операцию Gaussian Blur с сохранённым уровнем и sigma. */
    fun gaussianBlurOperation(level: Int, resultPath: String = "") : ImageOperation {
        val safeLevel = level.coerceIn(1, 3)
        return ImageOperation(
            type = ImageOperationType.GAUSSIAN_BLUR,
            parameters = JSONObject().put("level", safeLevel)
                .put("sigmaFrac", blurSigmaForLevel(safeLevel).toDouble()).toString(),
            resultPath = resultPath
        )
    }

    /**
     * Включает, меняет или отключает Gaussian Blur в стеке.
     * Пересчёт всегда начинается с изображения непосредственно перед операцией;
     * legacy Layer.imageBlur мигрирует в операцию при первом изменении.
     */
    suspend fun setGaussianBlur(
        context: Context,
        store: Store,
        layer: Layer,
        level: Int,
        onProgress: (Int) -> Unit = {}
    ): ReplayResult? {
        val type = ImageOperationType.GAUSSIAN_BLUR
        val existingIndex = layer.imageOperations.indexOfFirst { it.type == type }
        if (existingIndex >= 0 && layer.imageOperations[existingIndex].schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION) return null
        val cleanOperations = layer.imageOperations.filterNot {
            it.type == ImageOperationType.LEGACY_PREFIX + "blur"
        }
        if (level <= 0) {
            if (existingIndex < 0) return ReplayResult(previewPath(layer), cleanOperations)
            val inputPath = pathBeforeOperation(layer, type)
            val updated = cleanOperations.map { op ->
                if (op.type == type) op.copy(enabled = false, resultPath = "") else op
            }
            return replayFollowing(context, store, updated, type, inputPath, onProgress)
        }

        val inputPath = if (existingIndex >= 0) pathBeforeOperation(layer, type) else previewPath(layer)
        val source = Bitmaps.get(inputPath) ?: return null
        val operation = gaussianBlurOperation(level)
        val cleanLayer = layer.copy(imageBlur = 0, imageOperations = cleanOperations)
        val recorded = recordOperation(cleanLayer, operation, replaceType = true).imageOperations
        val recordedOperationId = recorded.firstOrNull { it.type == type }?.id ?: operation.id
        onProgress(10)
        val sigma = blurSigmaForLevel(level)
        val blurred = try {
            Blur.gaussianPreserveAlpha(source, sigma)
        } catch (t: Throwable) {
            return null
        }
        val resultPath = try {
            commitDerived(store, blurred, preferPng = true)
        } finally {
            if (blurred !== source && !blurred.isRecycled) blurred.recycle()
        } ?: return null
        val withResult = recorded.map { op ->
            if (op.id == recordedOperationId) op.copy(resultPath = resultPath, enabled = true) else op
        }
        onProgress(100)
        return replayFollowing(context, store, withResult, type, resultPath, onProgress)
    }

    /** Параметры AI-улучшения сохраняются отдельно от производного bitmap-кэша. */
    fun enhanceOperation(scale: Float, detail: Float, grain: Float, resultPath: String) = ImageOperation(
        type = ImageOperationType.ENHANCE,
        parameters = JSONObject().put("scale", scale.toDouble()).put("detail", detail.toDouble()).put("grain", grain.toDouble()).toString(),
        resultPath = resultPath
    )

    /** Последний активный кэшированный результат операции, если он ещё существует. */
    fun operationPreviewPath(layer: Layer): String = layer.imageOperations.lastOrNull { it.enabled && it.resultPath.isNotBlank() && java.io.File(it.resultPath).exists() }?.resultPath
        ?: previewPath(layer)

    /** Параметры стабильной color-grade; старые legacy.color-grade и поля Layer остаются совместимыми. */
    fun imageGrade(layer: Layer): Layer {
        val projected = layer.legacyImageOperations().firstOrNull { it.type == ImageOperationType.COLOR_GRADE }
        val stored = layer.imageOperations.lastOrNull { it.type == ImageOperationType.COLOR_GRADE }
        val operation = projected ?: stored
        val params = operation
            ?.takeIf { it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION }
            ?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }
            ?: legacyParams(layer, "color-grade")
        return layer.copy(
            imgHue = params.optDouble("hue", layer.imgHue.toDouble()).toFloat().coerceIn(-180f, 180f),
            imgSat = params.optDouble("saturation", layer.imgSat.toDouble()).toFloat().coerceIn(0f, 2.5f),
            imgBright = params.optDouble("brightness", layer.imgBright.toDouble()).toFloat().coerceIn(-0.6f, 0.6f),
            imgContrast = params.optDouble("contrast", layer.imgContrast.toDouble()).toFloat().coerceIn(0.5f, 1.8f),
            imgTemp = params.optDouble("temperature", layer.imgTemp.toDouble()).toFloat().coerceIn(-1f, 1f),
            imgColorize = params.optDouble("colorize", layer.imgColorize.toDouble()).toFloat().coerceIn(0f, 1f),
            imgColorizeColor = params.optInt("colorizeColor", layer.imgColorizeColor)
        )
    }

    /** Общая настройка краски для основного изображения и его отражения. */
    fun imagePaint(layer: Layer, alpha: Int = 255): Paint {
        val graded = imageGrade(layer)
        return Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
            this.alpha = alpha.coerceIn(0, 255)
            if (graded.hasImageGrade) colorFilter = ColorMatrixColorFilter(FxPainter.imageMatrix(graded))
        }
    }
}
