package com.dvdmaker.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(val versionCode: Int, val name: String, val url: String, val sha256: String? = null)

object Updater {
    suspend fun check(): UpdateInfo? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = URL("https://api.github.com/repos/${BuildConfig.GITHUB_REPO}/releases/latest")
                .openConnection() as HttpURLConnection
            conn.setRequestProperty("Accept", "application/vnd.github+json")
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            if (conn.responseCode != 200) return@runCatching null
            val o = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val tag = o.optString("tag_name", "")
            val code = tag.filter { it.isDigit() }.toIntOrNull() ?: return@runCatching null
            val assets = o.optJSONArray("assets") ?: return@runCatching null
            var url: String? = null
            var digest: String? = null
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) {
                    url = a.optString("browser_download_url")
                    digest = a.optString("digest").removePrefix("sha256:").takeIf { it.matches(Regex("[0-9a-fA-F]{64}")) }
                    break
                }
            }
            if (url == null || code <= BuildConfig.VERSION_CODE) null
            else UpdateInfo(code, o.optString("name", tag), url, digest)
        }.getOrNull()
    }

    suspend fun download(ctx: Context, info: UpdateInfo, onProgress: (Float) -> Unit): File? =
        withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(ctx.filesDir, "updates").apply { mkdirs() }
                val out = File(dir, "DVDMaker-${info.versionCode}.apk")
                val part = File(dir, "DVDMaker-${info.versionCode}.apk.part")
                if (out.isFile && out.length() > 0L && verifySha256(out, info.sha256)) return@runCatching out

                var offset = part.takeIf { it.isFile }?.length() ?: 0L
                var conn = (URL(info.url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 30000
                    if (offset > 0L) setRequestProperty("Range", "bytes=$offset-")
                }
                conn.connect()
                // A server may ignore Range and return the full body. Never append it to a partial file.
                if (offset > 0L && conn.responseCode != HttpURLConnection.HTTP_PARTIAL) {
                    conn.disconnect()
                    part.delete()
                    offset = 0L
                    conn = (URL(info.url).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15000
                        readTimeout = 30000
                    }
                    conn.connect()
                }
                val total = conn.getHeaderField("Content-Range")
                    ?.substringAfterLast('/')?.toLongOrNull()
                    ?: conn.contentLengthLong.takeIf { it > 0L }?.plus(offset)
                if (conn.responseCode !in 200..299) throw java.io.IOException("HTTP ${conn.responseCode}")
                conn.inputStream.use { input ->
                    java.io.FileOutputStream(part, offset > 0L).use { output ->
                            val buf = ByteArray(64 * 1024)
                            var downloaded = offset
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                output.write(buf, 0, n)
                                downloaded += n
                                if (total != null && total > 0L) onProgress((downloaded.toFloat() / total).coerceIn(0f, 1f))
                            }
                        output.fd.sync()
                    }
                }
                if (total != null && part.length() != total) throw java.io.IOException("Неполная загрузка: ${part.length()} / $total")
                if (!verifySha256(part, info.sha256)) throw java.io.IOException("SHA-256 APK не совпадает")
                if (out.exists()) out.delete()
                if (!part.renameTo(out)) {
                    part.copyTo(out, overwrite = true)
                    part.delete()
                }
                onProgress(1f)
                out
            }.getOrNull()
        }

    private fun verifySha256(file: File, expected: String?): Boolean {
        if (!file.isFile || file.length() == 0L) return false
        if (expected.isNullOrBlank()) return true
        val digest = java.security.MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }.equals(expected, ignoreCase = true)
    }

    /** Возвращает false, если нужно сначала выдать разрешение на установку. */
    fun install(ctx: Context, apk: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return true
    }
}
