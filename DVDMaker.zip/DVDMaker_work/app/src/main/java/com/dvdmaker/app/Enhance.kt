package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Улучшение картинки только нейросетью Real-ESRGAN (на устройстве, без интернета), см. [NeuralUpscaler]. */
object Enhancer {
    /** Предел по длинной стороне: больше не помещается в кэш изображений приложения. */
    const val MAX_SIDE = 4096

    /** Во сколько раз увеличить, чтобы получить [targetDpi] (от 1 до 4). */
    fun autoScale(currentDpi: Float, targetDpi: Float = 300f): Float =
        if (currentDpi <= 0f) 1f else (targetDpi / currentDpi).coerceIn(1f, 4f)

    /** Реальный коэффициент увеличения с учётом предела [MAX_SIDE]. Если он ≤ 1,02 — улучшать нечего. */
    fun effectiveScale(src: Bitmap, scale: Float): Float = min(scale, MAX_SIDE.toFloat() / max(src.width, src.height))

    fun canEnhance(src: Bitmap, scale: Float): Boolean = effectiveScale(src, scale) > 1.02f

    suspend fun enhance(ctx: Context, src: Bitmap, scale: Float, opts: EnhanceOpts = EnhanceOpts.PORTRAIT, onProgress: (Int) -> Unit = {}): Bitmap {
        val f = effectiveScale(src, scale)
        return NeuralUpscaler.upscale(
            ctx.applicationContext, src,
            (src.width * f).roundToInt(), (src.height * f).roundToInt(), opts, onProgress
        )
    }
}

/**
 * Выбор увеличения (авто до 300 dpi, ×2, ×3, ×4).
 * Если разрешение уже ≥300 dpi, перед запуском спрашивает, продолжать ли.
 */
@Composable
fun EnhanceOptionsDialog(dpi: Float, onDismiss: () -> Unit, onConfirm: (Float, EnhanceOpts) -> Unit) {
    val enough = dpi >= 300f
    var scaleMode by remember { mutableStateOf(if (enough) 1 else 0) }
    var asking by remember { mutableStateOf(false) }
    var preset by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf(EnhanceOpts.PORTRAIT.detail) }
    var grain by remember { mutableStateOf(EnhanceOpts.PORTRAIT.grain) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text(if (asking) "Разрешение уже достаточное" else "Улучшить качество") },
        text = {
            if (asking) {
                Text(
                    "Сейчас ≈${dpi.roundToInt()} dpi — это уже не меньше 300. Нейросеть всё равно уберёт артефакты и " +
                        "дорисует детали, но для печати выигрыш будет небольшим, а обработка займёт время. Продолжить?",
                    fontSize = 14.sp
                )
            } else {
                Column(
                    Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (dpi > 0f) Text("Сейчас ≈ ${dpi.roundToInt()} dpi при текущем размере.", color = Dim, fontSize = 12.sp)
                    if (enough) Text("Уже ≥300 dpi: увеличение не обязательно, перед запуском спросим подтверждение.", color = Amber, fontSize = 12.sp)
                    SectionLabel("Увеличение")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!enough) Pill("Авто до 300 dpi", scaleMode == 0, { scaleMode = 0 })
                        Pill("×2", scaleMode == 1, { scaleMode = 1 })
                        Pill("×3", scaleMode == 2, { scaleMode = 2 })
                        Pill("×4", scaleMode == 3, { scaleMode = 3 })
                    }
                    SectionLabel("Текстура кожи и деталей")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Pill("Портрет", preset == 0, { preset = 0 })
                        Pill("Баланс", preset == 1, { preset = 1 })
                        Pill("Чистый ИИ", preset == 2, { preset = 2 })
                        Pill("Настроить", preset == 3, { preset = 3 })
                    }
                    Text(
                        when (preset) {
                            0 -> "Возвращает поры и зерно, на лицах сильнее: кожа не «пластилиновая»."
                            1 -> "Лёгкий возврат текстуры, картинка чище."
                            2 -> "Только нейросеть, без возврата текстуры: максимально гладко."
                            else -> "Ручная настройка."
                        },
                        color = Dim, fontSize = 11.sp
                    )
                    if (preset == 3) {
                        Text("Возврат детали: ${(detail * 100).roundToInt()}%", fontSize = 12.sp)
                        Slider(value = detail, onValueChange = { detail = it }, valueRange = 0f..1f)
                        Text("Зерно: ${(grain * 100).roundToInt()}%", fontSize = 12.sp)
                        Slider(value = grain, onValueChange = { grain = it }, valueRange = 0f..1f)
                    }
                    Text(
                        "Нейросеть работает на устройстве без интернета: увеличивает картинку, убирает артефакты JPEG и дорисовывает " +
                            "правдоподобные мелкие детали. Размер картинки на макете не меняется, растёт только число пикселей " +
                            "(до ${Enhancer.MAX_SIDE} px по длинной стороне).",
                        color = Dim, fontSize = 11.sp
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (enough && !asking) asking = true
                else onConfirm(
                    when (scaleMode) { 0 -> Enhancer.autoScale(dpi); 1 -> 2f; 2 -> 3f; else -> 4f },
                    when (preset) {
                        0 -> EnhanceOpts.PORTRAIT
                        1 -> EnhanceOpts.BALANCE
                        2 -> EnhanceOpts.PURE
                        else -> EnhanceOpts(detail, grain)
                    }
                )
            }) { Text(if (asking) "Продолжить" else "Улучшить") }
        },
        dismissButton = {
            TextButton(onClick = { if (asking) asking = false else onDismiss() }) {
                Text(if (asking) "Назад" else "Отмена", color = Dim)
            }
        }
    )
}

/** Диалог улучшения выбранной картинки на макете. Во время обработки доступна только кнопка «Отменить». */
@Composable
fun EnhanceDialog(vm: AppVm, layer: Layer, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val previewSource = ImageProcessingPipeline.bitmapBeforeOperation(layer, ImageOperationType.ENHANCE)
        ?: Bitmaps.get(ImageProcessingPipeline.editSourcePath(layer))
    val dpi = if (previewSource != null && layer.widthMm > 0f) previewSource.width / (layer.widthMm / 25.4f) else 0f
    var progress by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }

    if (!busy) {
        EnhanceOptionsDialog(dpi, onDismiss = onDismiss) { sc, eo ->
            val editSourcePath = ImageProcessingPipeline.editSourcePath(layer)
            job = scope.launch {
                busy = true
                progress = 0
                val projectSnapshot = vm.current
                val panelSnapshot = vm.panel
                val replay = withContext(Dispatchers.Default) {
                    var materialized: ImageOperationRenderer.MaterializedInput? = null
                    var output: Bitmap? = null
                    try {
                        val backdrop = materializationBackdrop(projectSnapshot, panelSnapshot, layer)
                        val input = ImageOperationRenderer.materializeBeforeOperation(
                            ctx, vm.store, layer, ImageOperationType.ENHANCE,
                            backdrop = backdrop
                        ) { progress = it } ?: return@withContext null
                        materialized = input
                        val src = input.bitmap
                        if (!Enhancer.canEnhance(src, sc)) return@withContext null
                        val enhanced = Enhancer.enhance(ctx, src, sc, eo) { progress = it }
                        output = enhanced
                        val resultPath = ImageProcessingPipeline.commitDerived(vm.store, enhanced, true)
                            ?: return@withContext null
                        val baseLayer = layer.copy(imageOperations = input.operations)
                        val operation = ImageProcessingPipeline.enhanceOperation(
                            sc, eo.detail, eo.grain, resultPath, input.fingerprint
                        )
                        val operations = ImageProcessingPipeline.recordOperation(baseLayer, operation).imageOperations
                        val replayed = ImageProcessingPipeline.replayFollowing(
                            ctx, vm.store, operations, ImageOperationType.ENHANCE, resultPath,
                            onProgress = { progress = it }, baseLayer = baseLayer.copy(imageOperations = operations),
                            backdrop = backdrop
                        )
                        if (replayed != null) input.commitGenerated() else java.io.File(resultPath).delete()
                        replayed
                    } catch (t: CancellationException) {
                        throw t
                    } catch (_: Throwable) {
                        null
                    } finally {
                        output?.takeIf { !it.isRecycled }?.recycle()
                        materialized?.close()
                    }
                }
                busy = false
                if (replay == null) {
                    Toast.makeText(ctx, "Не удалось улучшить изображение", Toast.LENGTH_SHORT).show()
                } else {
                    vm.updateLayer(layer.id) { current ->
                        current.copy(imageOperations = replay.operations, path = replay.path, enhanceSourcePath = editSourcePath,
                            enhanceScale = sc, enhanceDetail = eo.detail, enhanceGrain = eo.grain)
                    }
                    Toast.makeText(ctx, "Готово", Toast.LENGTH_SHORT).show()
                    onDismiss()
                }
            }
        }
    } else {
        AlertDialog(
            onDismissRequest = { },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
            containerColor = Card,
            title = { Text("Улучшение изображения") },
            text = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Нейросеть улучшает изображение: $progress%", color = Amber, fontSize = 14.sp)
                    if (progress <= 0) LinearProgressIndicator(color = Violet, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(progress = { progress / 100f }, color = Violet, modifier = Modifier.fillMaxWidth())
                    Text("Это может занять до нескольких минут. Не закрывайте приложение.", color = Dim, fontSize = 12.sp)
                }
            },
            confirmButton = { },
            dismissButton = { TextButton(onClick = { job?.cancel(); busy = false }) { Text("Отменить", color = Dim) } }
        )
    }
}


/** Ручная повторная настройка деталей и зерна уже улучшенного изображения из сохранённого оригинала. */
@Composable
fun EnhanceAdjustControls(vm: AppVm, layer: Layer) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var detail by remember(layer.id) { mutableStateOf(layer.enhanceDetail) }
    var grain by remember(layer.id) { mutableStateOf(layer.enhanceGrain) }
    var busy by remember(layer.id) { mutableStateOf(false) }
    var progress by remember(layer.id) { mutableStateOf(0) }
    Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(5.dp)) {
        Text("Возврат деталей: ${(detail * 100).roundToInt()}%", fontSize = 12.sp)
        Slider(value = detail, onValueChange = { detail = it }, valueRange = 0f..1f, enabled = !busy)
        Text("Зерно: ${(grain * 100).roundToInt()}%", fontSize = 12.sp)
        Slider(value = grain, onValueChange = { grain = it }, valueRange = 0f..1f, enabled = !busy)
        if (busy) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
        TextButton(enabled = !busy && (layer.sourcePath.isNotBlank() || layer.enhanceSourcePath.isNotBlank()), onClick = {
            val sourcePath = ImageProcessingPipeline.editSourcePath(layer)
            scope.launch {
                busy = true
                val projectSnapshot = vm.current
                val panelSnapshot = vm.panel
                val replay = withContext(Dispatchers.Default) {
                    var materialized: ImageOperationRenderer.MaterializedInput? = null
                    var output: Bitmap? = null
                    try {
                        val backdrop = materializationBackdrop(projectSnapshot, panelSnapshot, layer)
                        val input = ImageOperationRenderer.materializeBeforeOperation(
                            ctx, vm.store, layer, ImageOperationType.ENHANCE,
                            backdrop = backdrop
                        ) { progress = it } ?: return@withContext null
                        materialized = input
                        val enhanced = Enhancer.enhance(ctx, input.bitmap, layer.enhanceScale, EnhanceOpts(detail, grain)) { progress = it }
                        output = enhanced
                        val saved = ImageProcessingPipeline.commitDerived(vm.store, enhanced, true) ?: return@withContext null
                        val baseLayer = layer.copy(imageOperations = input.operations)
                        val operation = ImageProcessingPipeline.enhanceOperation(
                            layer.enhanceScale, detail, grain, saved, input.fingerprint
                        )
                        val operations = ImageProcessingPipeline.recordOperation(baseLayer, operation).imageOperations
                        val replayed = ImageProcessingPipeline.replayFollowing(
                            ctx, vm.store, operations, ImageOperationType.ENHANCE, saved,
                            onProgress = { progress = it }, baseLayer = baseLayer.copy(imageOperations = operations),
                            backdrop = backdrop
                        )
                        if (replayed != null) input.commitGenerated() else java.io.File(saved).delete()
                        replayed
                    } catch (t: CancellationException) { throw t }
                    catch (_: Throwable) { null }
                    finally {
                        output?.takeIf { !it.isRecycled }?.recycle()
                        materialized?.close()
                    }
                }
                busy = false
                if (replay == null) Toast.makeText(ctx, "Не удалось применить настройки", Toast.LENGTH_SHORT).show()
                else vm.updateLayer(layer.id) { current ->
                    current.copy(imageOperations = replay.operations, path = replay.path, enhanceSourcePath = sourcePath,
                        enhanceDetail = detail, enhanceGrain = grain)
                }
            }
        }) { Text(if (busy) "Обработка… $progress%" else "Применить настройки") }
    }
}
