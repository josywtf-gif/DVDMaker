package com.dvdmaker.app

import android.graphics.Bitmap
import android.util.LruCache

/**
 * Контур вырезанного PNG-объекта (marching squares по альфа-каналу уменьшенной копии).
 * Отрезки склеиваются в непрерывные ломаные — иначе пунктир «сбрасывался» бы на каждом отрезке
 * и линия выглядела сплошной. Каждая ломаная — [x0, y0, x1, y1, ...] в долях картинки, от -0.5 до 0.5
 * относительно центра; замкнутая ломаная повторяет первую точку в конце.
 */
object ObjectOutline {
    private val cache = LruCache<String, List<FloatArray>>(64)
    private val EMPTY: List<FloatArray> = emptyList()

    fun get(src: Bitmap): List<FloatArray>? {
        // The same resource path may now resolve to a newly cropped/replayed bitmap.
        // Include the exact bitmap fingerprint so an old silhouette can never survive a new render.
        val cacheKey = ImageOperationRenderer.bitmapFingerprint(src)
        cache.get(cacheKey)?.let { return it.ifEmpty { null } }
        val k = minOf(1f, 220f / maxOf(src.width, src.height))
        val sw = (src.width * k).toInt().coerceAtLeast(2)
        val sh = (src.height * k).toInt().coerceAtLeast(2)
        val small = if (k < 1f) Bitmap.createScaledBitmap(src, sw, sh, true) else src
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (small !== src) small.recycle()
        // Сетка с пустой рамкой в 1 пиксель, чтобы контур всегда замыкался.
        val gw = sw + 2
        val gh = sh + 2
        val g = FloatArray(gw * gh)
        for (y in 0 until sh) for (x in 0 until sw) g[(y + 1) * gw + x + 1] = (px[y * sw + x] ushr 24) / 255f
        // Opaque photos should use the normal rectangular selection, not a contour
        // around the padded bitmap bounds.
        if (px.none { (it ushr 24) < 250 }) {
            cache.put(cacheKey, EMPTY)
            return null
        }
        val t = 0.5f
        fun lerp(a: Float, b: Float): Float = if (a == b) 0.5f else ((t - a) / (b - a)).coerceIn(0f, 1f)

        // Точки контура лежат на рёбрах сетки. Номер ребра: горизонтальное (x,y)-(x+1,y) = 2*(y*gw+x),
        // вертикальное (x,y)-(x,y+1) = 2*(y*gw+x)+1. Так соседние клетки дают одну и ту же точку.
        val pointX = HashMap<Int, Float>()
        val pointY = HashMap<Int, Float>()
        val adj = HashMap<Int, IntArray>() // у каждой точки ровно две соседние (по одной на отрезок)
        fun addSeg(ea: Int, ax: Float, ay: Float, eb: Int, bx: Float, by: Float) {
            pointX[ea] = ax; pointY[ea] = ay; pointX[eb] = bx; pointY[eb] = by
            val a = adj.getOrPut(ea) { intArrayOf(-1, -1) }
            val b = adj.getOrPut(eb) { intArrayOf(-1, -1) }
            if (a[0] < 0) a[0] = eb else a[1] = eb
            if (b[0] < 0) b[0] = ea else b[1] = ea
        }
        for (y in 0 until gh - 1) for (x in 0 until gw - 1) {
            val tl = g[y * gw + x]; val tr = g[y * gw + x + 1]
            val br = g[(y + 1) * gw + x + 1]; val bl = g[(y + 1) * gw + x]
            val idx = (if (tl >= t) 1 else 0) or (if (tr >= t) 2 else 0) or (if (br >= t) 4 else 0) or (if (bl >= t) 8 else 0)
            if (idx == 0 || idx == 15) continue
            val eT = 2 * (y * gw + x); val eB = 2 * ((y + 1) * gw + x)
            val eL = 2 * (y * gw + x) + 1; val eR = 2 * (y * gw + x + 1) + 1
            val topX = x + lerp(tl, tr); val topY = y.toFloat()
            val rightX = (x + 1).toFloat(); val rightY = y + lerp(tr, br)
            val botX = x + lerp(bl, br); val botY = (y + 1).toFloat()
            val leftX = x.toFloat(); val leftY = y + lerp(tl, bl)
            when (idx) {
                1, 14 -> addSeg(eL, leftX, leftY, eT, topX, topY)
                2, 13 -> addSeg(eT, topX, topY, eR, rightX, rightY)
                3, 12 -> addSeg(eL, leftX, leftY, eR, rightX, rightY)
                4, 11 -> addSeg(eR, rightX, rightY, eB, botX, botY)
                5 -> { addSeg(eL, leftX, leftY, eT, topX, topY); addSeg(eR, rightX, rightY, eB, botX, botY) }
                6, 9 -> addSeg(eT, topX, topY, eB, botX, botY)
                7, 8 -> addSeg(eL, leftX, leftY, eB, botX, botY)
                10 -> { addSeg(eT, topX, topY, eR, rightX, rightY); addSeg(eL, leftX, leftY, eB, botX, botY) }
            }
        }

        // Обход: из любой непосещённой точки идём по соседям, пока не вернёмся (или не упрёмся в конец).
        val visited = HashSet<Int>()
        val loops = ArrayList<FloatArray>()
        for (start in adj.keys) {
            if (start in visited) continue
            val pts = ArrayList<Float>()
            fun emit(e: Int) {
                pts.add((pointX[e]!! - 0.5f) / sw - 0.5f); pts.add((pointY[e]!! - 0.5f) / sh - 0.5f)
            }
            var prev = -1
            var cur = start
            while (true) {
                visited.add(cur); emit(cur)
                val n = adj[cur]!!
                val next = if (n[0] != prev) n[0] else n[1]
                if (next < 0) break
                if (next == start) { emit(start); break }       // контур замкнулся
                if (next in visited) break
                prev = cur; cur = next
            }
            if (pts.size >= 12) loops.add(pts.toFloatArray()) // мелкий «мусор» (< 6 точек) не рисуем
        }
        cache.put(cacheKey, if (loops.isEmpty()) EMPTY else loops)
        return loops.ifEmpty { null }
    }
}
