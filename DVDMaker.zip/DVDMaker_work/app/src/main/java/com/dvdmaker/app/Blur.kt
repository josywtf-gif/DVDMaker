package com.dvdmaker.app

import android.graphics.Bitmap
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import java.util.concurrent.CancellationException

/** Качественное гауссово размытие: три прохода box-blur на уменьшенной копии, плавное увеличение и микро-дизеринг (без «квадратиков» и бандинга). */
object Blur {
    fun gaussian(src: Bitmap, sigmaFrac: Float = 0.03f, workSide: Int = 560): Bitmap {
        val w = src.width
        val h = src.height
        val k = min(1f, workSide / max(w, h).toFloat())
        val ww = (w * k).roundToInt().coerceAtLeast(2)
        val hh = (h * k).roundToInt().coerceAtLeast(2)
        val small = scaleSmooth(src, ww, hh)
        val px = IntArray(ww * hh)
        small.getPixels(px, 0, ww, 0, 0, ww, hh)
        if (small !== src) small.recycle()
        blurPixels(px, ww, hh, sigmaFrac * max(ww, hh))
        val blurred = Bitmap.createBitmap(ww, hh, Bitmap.Config.ARGB_8888)
        blurred.setPixels(px, 0, ww, 0, 0, ww, hh)
        var big = scaleSmooth(blurred, w, h)
        if (big !== blurred) blurred.recycle()
        if (!big.isMutable || big.config != Bitmap.Config.ARGB_8888) {
            val c = big.copy(Bitmap.Config.ARGB_8888, true)
            big.recycle()
            big = c
        }
        dither(big)
        return big
    }

    /**
     * Гауссово размытие RGBA с сохранением прозрачности.
     * RGB размывается в premultiplied-alpha пространстве, поэтому по краям PNG
     * не появляются тёмные/светлые ореолы. Исходный bitmap не изменяется.
     */
    fun gaussianPreserveAlpha(src: Bitmap, sigmaFrac: Float, workSide: Int = 1600, isCancelled: () -> Boolean = { Thread.currentThread().isInterrupted }): Bitmap {
        if (sigmaFrac <= 0f || src.width < 2 || src.height < 2) return src
        val w = src.width
        val h = src.height
        val scale = min(1f, workSide.coerceAtLeast(2) / max(w, h).toFloat())
        val sw = (w * scale).roundToInt().coerceAtLeast(2)
        val sh = (h * scale).roundToInt().coerceAtLeast(2)
        val work = if (sw == w && sh == h) src else Bitmap.createScaledBitmap(src, sw, sh, true)
        val count = sw * sh
        val pixels = IntArray(count)
        work.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        if (work !== src) work.recycle()

        val alpha = IntArray(count)
        val red = IntArray(count)
        val green = IntArray(count)
        val blue = IntArray(count)
        for (i in 0 until count) {
            if ((i and 0x3FFF) == 0 && isCancelled()) throw CancellationException("Blur superseded")
            val p = pixels[i]
            val a = p ushr 24
            alpha[i] = a
            red[i] = (((p shr 16) and 255) * a + 127) / 255
            green[i] = (((p shr 8) and 255) * a + 127) / 255
            blue[i] = ((p and 255) * a + 127) / 255
        }
        val sigma = sigmaFrac * max(sw, sh)
        blurChannel(alpha, sw, sh, sigma, isCancelled)
        blurChannel(red, sw, sh, sigma, isCancelled)
        blurChannel(green, sw, sh, sigma, isCancelled)
        blurChannel(blue, sw, sh, sigma, isCancelled)
        for (i in 0 until count) {
            if ((i and 0x3FFF) == 0 && isCancelled()) throw CancellationException("Blur superseded")
            val a = alpha[i].coerceIn(0, 255)
            if (a == 0) {
                pixels[i] = 0
            } else {
                val r = (red[i] * 255f / a).roundToInt().coerceIn(0, 255)
                val g = (green[i] * 255f / a).roundToInt().coerceIn(0, 255)
                val b = (blue[i] * 255f / a).roundToInt().coerceIn(0, 255)
                pixels[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val small = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        small.setHasAlpha(true)
        small.density = src.density
        small.setPixels(pixels, 0, sw, 0, 0, sw, sh)
        if (sw == w && sh == h) return small
        return try {
            Bitmap.createScaledBitmap(small, w, h, true).also { if (it !== small) it.density = src.density }
        } finally {
            small.recycle()
        }
    }

    private fun blurChannel(values: IntArray, w: Int, h: Int, sigma: Float, isCancelled: () -> Boolean) {
        val tmp = IntArray(values.size)
        for (box in boxesForGauss(sigma.coerceAtLeast(0.5f), 3)) {
            val radius = (box - 1) / 2
            val divisor = radius * 2 + 1
            for (y in 0 until h) {
                if (isCancelled()) throw CancellationException("Blur superseded")
                val row = y * w
                var sum = 0
                for (i in -radius..radius) sum += values[row + i.coerceIn(0, w - 1)]
                for (x in 0 until w) {
                    tmp[row + x] = sum / divisor
                    sum += values[row + (x + radius + 1).coerceAtMost(w - 1)]
                    sum -= values[row + (x - radius).coerceAtLeast(0)]
                }
            }
            for (x in 0 until w) {
                if (isCancelled()) throw CancellationException("Blur superseded")
                var sum = 0
                for (i in -radius..radius) sum += tmp[i.coerceIn(0, h - 1) * w + x]
                for (y in 0 until h) {
                    values[y * w + x] = sum / divisor
                    sum += tmp[(y + radius + 1).coerceAtMost(h - 1) * w + x]
                    sum -= tmp[(y - radius).coerceAtLeast(0) * w + x]
                }
            }
        }
    }

    /** Масштаб ступенями ×2 с билинейной фильтрацией: без алиасинга при уменьшении и без блочности при увеличении. */
    fun scaleSmooth(src: Bitmap, tw: Int, th: Int): Bitmap {
        var cur = src
        fun step(nw: Int, nh: Int) {
            val n = Bitmap.createScaledBitmap(cur, nw.coerceAtLeast(1), nh.coerceAtLeast(1), true)
            if (n !== cur) {
                if (cur !== src) cur.recycle()
                cur = n
            }
        }
        while (cur.width / 2 >= tw && cur.height / 2 >= th) step(cur.width / 2, cur.height / 2)
        while (cur.width * 2 <= tw && cur.height * 2 <= th) step(cur.width * 2, cur.height * 2)
        if (cur.width != tw || cur.height != th) step(tw, th)
        return cur
    }

    private fun dither(b: Bitmap) {
        val w = b.width
        val h = b.height
        val row = IntArray(w)
        var seed = 12345
        for (y in 0 until h) {
            b.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                seed = seed * 1103515245 + 12345
                val n = ((seed ushr 16) % 3) - 1
                val p = row[x]
                val r = (((p shr 16) and 255) + n).coerceIn(0, 255)
                val g = (((p shr 8) and 255) + n).coerceIn(0, 255)
                val bl = ((p and 255) + n).coerceIn(0, 255)
                row[x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
            }
            b.setPixels(row, 0, w, 0, y, w, 1)
        }
    }

    fun blurPixels(px: IntArray, w: Int, h: Int, sigma: Float) {
        val tmp = IntArray(px.size)
        for (box in boxesForGauss(sigma.coerceAtLeast(0.5f), 3)) {
            val r = (box - 1) / 2
            boxH(px, tmp, w, h, r)
            boxV(tmp, px, w, h, r)
        }
    }

    private fun boxesForGauss(sigma: Float, n: Int): IntArray {
        val wIdeal = sqrt(12f * sigma * sigma / n + 1f)
        var wl = floor(wIdeal).toInt()
        if (wl % 2 == 0) wl--
        if (wl < 1) wl = 1
        val wu = wl + 2
        val mIdeal = (12f * sigma * sigma - n * wl * wl - 4f * n * wl - 3f * n) / (-4f * wl - 4f)
        val m = mIdeal.roundToInt()
        return IntArray(n) { if (it < m) wl else wu }
    }

    private fun boxH(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val p = src[row + i.coerceIn(0, w - 1)]
                sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (x in 0 until w) {
                dst[row + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val a = src[row + min(x + r + 1, w - 1)]
                val d = src[row + max(x - r, 0)]
                sr += ((a shr 16) and 255) - ((d shr 16) and 255)
                sg += ((a shr 8) and 255) - ((d shr 8) and 255)
                sb += (a and 255) - (d and 255)
            }
        }
    }

    private fun boxV(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val p = src[i.coerceIn(0, h - 1) * w + x]
                sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (y in 0 until h) {
                dst[y * w + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val a = src[min(y + r + 1, h - 1) * w + x]
                val d = src[max(y - r, 0) * w + x]
                sr += ((a shr 16) and 255) - ((d shr 16) and 255)
                sg += ((a shr 8) and 255) - ((d shr 8) and 255)
                sb += (a and 255) - (d and 255)
            }
        }
    }
}
