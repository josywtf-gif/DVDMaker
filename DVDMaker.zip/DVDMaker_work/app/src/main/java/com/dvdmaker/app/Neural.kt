package com.dvdmaker.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.media.FaceDetector
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.nio.FloatBuffer
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Нейросетевой апскейлинг Real-ESRGAN (realesr-general-x4v3, ONNX) прямо на устройстве, без интернета.
 * Модель всегда увеличивает ×4; картинка обрабатывается плитками, чтобы хватило памяти.
 */
object NeuralUpscaler {
    private const val MODEL = "models/realesr-general-x4v3.onnx"
    private const val SCALE = 4
    private const val CORE = 160
    private const val PAD = 20
    private const val GRAIN = 0.02f

    fun available(ctx: Context): Boolean = try {
        ctx.assets.open(MODEL).close(); true
    } catch (_: Throwable) {
        false
    }

    /** Keep the multi-megabyte ONNX model on disk instead of duplicating it in a large byte array. */
    @Synchronized
    private fun modelFile(ctx: Context): File {
        val target = File(ctx.noBackupFilesDir, "realesr-general-x4v3.onnx")
        val expectedSize = ctx.assets.openFd(MODEL).use { it.length }
        if (target.exists() && target.length() == expectedSize) return target
        val temp = File(target.parentFile, target.name + ".tmp")
        ctx.assets.open(MODEL).use { input -> temp.outputStream().use { output -> input.copyTo(output, 1 shl 16) } }
        if (temp.length() != expectedSize) {
            temp.delete()
            throw IllegalStateException("Файл модели улучшения скопирован не полностью")
        }
        if (target.exists() && !target.delete()) throw IllegalStateException("Не удалось обновить файл модели")
        if (!temp.renameTo(target)) {
            temp.delete()
            throw IllegalStateException("Не удалось подготовить файл модели")
        }
        return target
    }

    /**
     * Увеличивает [src] нейросетью ×4 плитками и сразу собирает результат в [targetW]×[targetH].
     * Полный промежуточный bitmap ×4 не создаётся. [onProgress] получает 0…100.
     */
    suspend fun upscale(ctx: Context, src: Bitmap, targetW: Int, targetH: Int, enh: EnhanceOpts, onProgress: (Int) -> Unit): Bitmap {
        require(targetW > 0 && targetH > 0) { "Недопустимый размер результата" }
        require(max(targetW, targetH) <= Enhancer.MAX_SIDE) { "Размер результата превышает ${Enhancer.MAX_SIDE} px" }

        // Не уменьшаем исходник до 1 Мп: каждый фрагмент проходит сеть отдельно,
        // а его центральная часть сразу рисуется в финальный bitmap нужного размера.
        // Поэтому промежуточное полное изображение ×4 не создаётся.
        val inW = src.width
        val inH = src.height
        val output = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        val restoring = enh.detail > 0f || enh.grain > 0f
        val faces = if (restoring && enh.faceAware) FaceMask.detect(src) else FaceMask.EMPTY
        val grainComp = (SCALE * inW.toFloat() / targetW).coerceIn(1f, 3f)
        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            val cores = Runtime.getRuntime().availableProcessors()
            setIntraOpNumThreads(min(2, max(1, cores - 1)))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        var outputReady = false
        try {
            env.createSession(modelFile(ctx.applicationContext).absolutePath, opts).use { session ->
                val inName = session.inputNames.first()
                val tilesX = (inW + CORE - 1) / CORE
                val tilesY = (inH + CORE - 1) / CORE
                val total = tilesX * tilesY
                var done = 0
                var last = -1
                for (ty in 0 until tilesY) for (tx in 0 until tilesX) {
                    currentCoroutineContext().ensureActive()
                    val x0 = tx * CORE
                    val y0 = ty * CORE
                    val x1 = min(x0 + CORE, inW)
                    val y1 = min(y0 + CORE, inH)
                    val sx0 = max(0, x0 - PAD)
                    val sy0 = max(0, y0 - PAD)
                    val sx1 = min(inW, x1 + PAD)
                    val sy1 = min(inH, y1 + PAD)
                    val tw = sx1 - sx0
                    val th = sy1 - sy0
                    val tilePixels = IntArray(tw * th)
                    src.getPixels(tilePixels, 0, tw, sx0, sy0, tw, th)
                    val plane = tw * th
                    val data = FloatArray(3 * plane)
                    for (i in 0 until plane) {
                        val c = tilePixels[i]
                        data[i] = ((c shr 16) and 255) / 255f
                        data[plane + i] = ((c shr 8) and 255) / 255f
                        data[2 * plane + i] = (c and 255) / 255f
                    }
                    OnnxTensor.createTensor(env, FloatBuffer.wrap(data), longArrayOf(1, 3, th.toLong(), tw.toLong())).use { tensor ->
                        session.run(mapOf(inName to tensor)).use { result ->
                            val out = result.get(0) as OnnxTensor
                            val shape = out.info.shape
                            val ow = tw * SCALE
                            val oh = th * SCALE
                            if (shape.size < 4 || shape[2] != oh.toLong() || shape[3] != ow.toLong()) {
                                throw IllegalStateException("Модель улучшения вернула неожиданный размер плитки")
                            }
                            val fb = out.floatBuffer
                            val oPlane = ow * oh
                            val cx = (x0 - sx0) * SCALE
                            val cy = (y0 - sy0) * SCALE
                            val cw = (x1 - x0) * SCALE
                            val ch = (y1 - y0) * SCALE
                            val sw = x1 - x0
                            val sh = y1 - y0
                            var resR = FloatArray(0)
                            var resG = FloatArray(0)
                            var resB = FloatArray(0)
                            var gMap = FloatArray(0)
                            if (restoring) {
                                // Что сеть «сгладила»: исходник минус усреднённый до исходного размера результат сети.
                                // Эта текстура (поры, зерно) возвращается с весом detail, на лицах сильнее.
                                resR = FloatArray(sw * sh)
                                resG = FloatArray(sw * sh)
                                resB = FloatArray(sw * sh)
                                gMap = FloatArray(sw * sh)
                                val inv = 1f / (SCALE * SCALE)
                                for (j in 0 until sh) for (i in 0 until sw) {
                                    val bx = (x0 - sx0 + i) * SCALE
                                    val by = (y0 - sy0 + j) * SCALE
                                    var ar = 0f
                                    var ag = 0f
                                    var ab = 0f
                                    for (v in 0 until SCALE) {
                                        val rowI = (by + v) * ow + bx
                                        for (u in 0 until SCALE) {
                                            val ii = rowI + u
                                            ar += fb.get(ii)
                                            ag += fb.get(oPlane + ii)
                                            ab += fb.get(2 * oPlane + ii)
                                        }
                                    }
                                    val c = tilePixels[(y0 - sy0 + j) * tw + (x0 - sx0 + i)]
                                    val fw = if (faces.isEmpty()) 0f else faces.weight(x0 + i + 0.5f, y0 + j + 0.5f)
                                    val kd = (enh.detail * (1f + 0.8f * fw)).coerceAtMost(1f)
                                    val idx = j * sw + i
                                    resR[idx] = (((c shr 16) and 255) / 255f - ar * inv) * kd
                                    resG[idx] = (((c shr 8) and 255) / 255f - ag * inv) * kd
                                    resB[idx] = ((c and 255) / 255f - ab * inv) * kd
                                    gMap[idx] = enh.grain * (0.5f + 0.5f * fw)
                                }
                            }
                            val xi0 = IntArray(cw)
                            val xi1 = IntArray(cw)
                            val xt = FloatArray(cw)
                            if (restoring) for (x in 0 until cw) {
                                val fx = ((x + 0.5f) / SCALE - 0.5f).coerceIn(0f, (sw - 1).toFloat())
                                xi0[x] = fx.toInt()
                                xi1[x] = min(xi0[x] + 1, sw - 1)
                                xt[x] = fx - xi0[x]
                            }
                            val rng = Rng((0x2545F491 xor (tx * 73856093) xor (ty * 19349663)) or 1)
                            val pixels = IntArray(cw * ch)
                            for (y in 0 until ch) {
                                val row = (cy + y) * ow + cx
                                var yr0 = 0
                                var yr1 = 0
                                var yt = 0f
                                if (restoring) {
                                    val fy = ((y + 0.5f) / SCALE - 0.5f).coerceIn(0f, (sh - 1).toFloat())
                                    yr0 = fy.toInt()
                                    yr1 = min(yr0 + 1, sh - 1)
                                    yt = fy - yr0
                                }
                                for (x in 0 until cw) {
                                    val i = row + x
                                    var rf = fb.get(i)
                                    var gf = fb.get(oPlane + i)
                                    var bf = fb.get(2 * oPlane + i)
                                    if (restoring) {
                                        val p00 = yr0 * sw + xi0[x]
                                        val p01 = yr0 * sw + xi1[x]
                                        val p10 = yr1 * sw + xi0[x]
                                        val p11 = yr1 * sw + xi1[x]
                                        val txx = xt[x]
                                        val w00 = (1f - txx) * (1f - yt)
                                        val w01 = txx * (1f - yt)
                                        val w10 = (1f - txx) * yt
                                        val w11 = txx * yt
                                        rf += resR[p00] * w00 + resR[p01] * w01 + resR[p10] * w10 + resR[p11] * w11
                                        gf += resG[p00] * w00 + resG[p01] * w01 + resG[p10] * w10 + resG[p11] * w11
                                        bf += resB[p00] * w00 + resB[p01] * w01 + resB[p10] * w10 + resB[p11] * w11
                                        val gk = gMap[p00] * w00 + gMap[p01] * w01 + gMap[p10] * w10 + gMap[p11] * w11
                                        if (gk > 0f) {
                                            val lum = (0.3f * rf + 0.59f * gf + 0.11f * bf).coerceIn(0f, 1f)
                                            val tone = (4f * lum * (1f - lum)).coerceIn(0.3f, 1f)
                                            val n = (rng.next() + rng.next() - 1f) * 2.45f * gk * GRAIN * grainComp * tone
                                            rf += n
                                            gf += n
                                            bf += n
                                        }
                                    }
                                    val r = (rf * 255f + 0.5f).toInt().coerceIn(0, 255)
                                    val g = (gf * 255f + 0.5f).toInt().coerceIn(0, 255)
                                    val b = (bf * 255f + 0.5f).toInt().coerceIn(0, 255)
                                    pixels[y * cw + x] = (255 shl 24) or (r shl 16) or (g shl 8) or b
                                }
                            }
                            val tile = Bitmap.createBitmap(pixels, cw, ch, Bitmap.Config.ARGB_8888)
                            try {
                                val dst = RectF(
                                    x0.toFloat() * targetW / inW,
                                    y0.toFloat() * targetH / inH,
                                    x1.toFloat() * targetW / inW,
                                    y1.toFloat() * targetH / inH
                                )
                                canvas.drawBitmap(tile, null, dst, paint)
                            } finally {
                                tile.recycle()
                            }
                        }
                    }
                    done++
                    val progress = done * 92 / total
                    if (progress != last) { last = progress; onProgress(progress) }
                }
            }

            // Real-ESRGAN не восстанавливает альфу. Сохраняем прозрачность исходника,
            // масштабируя её отдельно полосами, не создавая ещё один полный IntArray.
            if (src.hasAlpha()) {
                // Билинейно интерполируем только альфа-канал из двух строк исходника:
                // дополнительный bitmap размером с результат не нужен.
                val srcA = IntArray(src.width)
                val srcB = IntArray(src.width)
                val dst = IntArray(targetW)
                var cachedA = -1
                var cachedB = -1
                for (y in 0 until targetH) {
                    currentCoroutineContext().ensureActive()
                    val fy = ((y + 0.5f) * src.height / targetH - 0.5f).coerceIn(0f, (src.height - 1).toFloat())
                    val y0 = fy.toInt()
                    val y1 = min(y0 + 1, src.height - 1)
                    val ty = fy - y0
                    if (cachedA != y0) {
                        src.getPixels(srcA, 0, src.width, 0, y0, src.width, 1)
                        cachedA = y0
                    }
                    if (cachedB != y1) {
                        src.getPixels(srcB, 0, src.width, 0, y1, src.width, 1)
                        cachedB = y1
                    }
                    output.getPixels(dst, 0, targetW, 0, y, targetW, 1)
                    for (x in 0 until targetW) {
                        val fx = ((x + 0.5f) * src.width / targetW - 0.5f).coerceIn(0f, (src.width - 1).toFloat())
                        val x0 = fx.toInt()
                        val x1 = min(x0 + 1, src.width - 1)
                        val tx = fx - x0
                        val a0 = ((srcA[x0] ushr 24) * (1f - tx) + (srcA[x1] ushr 24) * tx)
                        val a1 = ((srcB[x0] ushr 24) * (1f - tx) + (srcB[x1] ushr 24) * tx)
                        val a = (a0 * (1f - ty) + a1 * ty + 0.5f).toInt().coerceIn(0, 255)
                        dst[x] = (a shl 24) or (dst[x] and 0x00FFFFFF)
                    }
                    output.setPixels(dst, 0, targetW, 0, y, targetW, 1)
                    onProgress(92 + (y + 1) * 8 / targetH)
                }
            } else onProgress(100)
            outputReady = true
            return output
        } finally {
            opts.close()
            if (!outputReady && !output.isRecycled) output.recycle()
        }
    }


    /**
     * Постобработка чистого результата сети [base] (изменяется на месте): возвращает текстуру,
     * которую сеть «сгладила» (исходник [src] минус усреднённый результат), и зерно. Нейросеть
     * не запускается, поэтому смена detail/grain дёшева и не требует повторного инференса.
     * Возвращает false, если [base] нельзя менять или [src] слишком велик — тогда [base] остаётся как есть.
     */
    fun restoreInPlace(src: Bitmap, base: Bitmap, enh: EnhanceOpts): Boolean {
        if (enh.detail <= 0f && enh.grain <= 0f) return true
        if (!base.isMutable || base.config != Bitmap.Config.ARGB_8888) return false
        val sw = src.width
        val sh = src.height
        val bw = base.width
        val bh = base.height
        if (sw <= 0 || sh <= 0 || bw < sw || bh < sh || sw.toLong() * sh > 8_000_000L) return false
        val faces = if (enh.faceAware) FaceMask.detect(src) else FaceMask.EMPTY
        val n = sw * sh
        val resR = FloatArray(n)
        val resG = FloatArray(n)
        val resB = FloatArray(n)
        val cnt = IntArray(n)
        val xMap = IntArray(bw) { x -> min(sw - 1, (x.toLong() * sw / bw).toInt()) }
        val row = IntArray(bw)
        for (y in 0 until bh) {
            base.getPixels(row, 0, bw, 0, y, bw, 1)
            val rowOff = min(sh - 1, (y.toLong() * sh / bh).toInt()) * sw
            for (x in 0 until bw) {
                val idx = rowOff + xMap[x]
                val c = row[x]
                resR[idx] += ((c shr 16) and 255) / 255f
                resG[idx] += ((c shr 8) and 255) / 255f
                resB[idx] += (c and 255) / 255f
                cnt[idx]++
            }
        }
        val gMap = FloatArray(n)
        val srcRow = IntArray(sw)
        for (j in 0 until sh) {
            src.getPixels(srcRow, 0, sw, 0, j, sw, 1)
            for (i in 0 until sw) {
                val idx = j * sw + i
                val inv = 1f / cnt[idx].coerceAtLeast(1)
                val c = srcRow[i]
                val fw = if (faces.isEmpty()) 0f else faces.weight(i + 0.5f, j + 0.5f)
                val kd = (enh.detail * (1f + 0.8f * fw)).coerceAtMost(1f)
                resR[idx] = (((c shr 16) and 255) / 255f - resR[idx] * inv) * kd
                resG[idx] = (((c shr 8) and 255) / 255f - resG[idx] * inv) * kd
                resB[idx] = ((c and 255) / 255f - resB[idx] * inv) * kd
                gMap[idx] = enh.grain * (0.5f + 0.5f * fw)
            }
        }
        val xi0 = IntArray(bw)
        val xi1 = IntArray(bw)
        val xt = FloatArray(bw)
        for (x in 0 until bw) {
            val fx = ((x + 0.5f) * sw / bw - 0.5f).coerceIn(0f, (sw - 1).toFloat())
            xi0[x] = fx.toInt()
            xi1[x] = min(xi0[x] + 1, sw - 1)
            xt[x] = fx - xi0[x]
        }
        val grainComp = (SCALE * sw.toFloat() / bw).coerceIn(1f, 3f)
        for (y in 0 until bh) {
            base.getPixels(row, 0, bw, 0, y, bw, 1)
            val fy = ((y + 0.5f) * sh / bh - 0.5f).coerceIn(0f, (sh - 1).toFloat())
            val y0 = fy.toInt()
            val y1 = min(y0 + 1, sh - 1)
            val yt = fy - y0
            val rng = Rng((0x2545F491 xor (y * 19349663)) or 1)
            for (x in 0 until bw) {
                val c = row[x]
                var rf = ((c shr 16) and 255) / 255f
                var gf = ((c shr 8) and 255) / 255f
                var bf = (c and 255) / 255f
                val p00 = y0 * sw + xi0[x]
                val p01 = y0 * sw + xi1[x]
                val p10 = y1 * sw + xi0[x]
                val p11 = y1 * sw + xi1[x]
                val t = xt[x]
                val w00 = (1f - t) * (1f - yt)
                val w01 = t * (1f - yt)
                val w10 = (1f - t) * yt
                val w11 = t * yt
                rf += resR[p00] * w00 + resR[p01] * w01 + resR[p10] * w10 + resR[p11] * w11
                gf += resG[p00] * w00 + resG[p01] * w01 + resG[p10] * w10 + resG[p11] * w11
                bf += resB[p00] * w00 + resB[p01] * w01 + resB[p10] * w10 + resB[p11] * w11
                val gk = gMap[p00] * w00 + gMap[p01] * w01 + gMap[p10] * w10 + gMap[p11] * w11
                if (gk > 0f) {
                    val lum = (0.3f * rf + 0.59f * gf + 0.11f * bf).coerceIn(0f, 1f)
                    val tone = (4f * lum * (1f - lum)).coerceIn(0.3f, 1f)
                    val noise = (rng.next() + rng.next() - 1f) * 2.45f * gk * GRAIN * grainComp * tone
                    rf += noise
                    gf += noise
                    bf += noise
                }
                val r = (rf * 255f + 0.5f).toInt().coerceIn(0, 255)
                val g = (gf * 255f + 0.5f).toInt().coerceIn(0, 255)
                val b = (bf * 255f + 0.5f).toInt().coerceIn(0, 255)
                row[x] = (c and 0xFF000000.toInt()) or (r shl 16) or (g shl 8) or b
            }
            base.setPixels(row, 0, bw, 0, y, bw, 1)
        }
        return true
    }
}

/** Настройки возврата текстуры после нейросети: [detail] — доля вернувшейся детали, [grain] — зерно, оба 0…1. */
data class EnhanceOpts(val detail: Float = 0.45f, val grain: Float = 0.6f, val faceAware: Boolean = true) {
    companion object {
        val PORTRAIT = EnhanceOpts(0.45f, 0.6f)
        val BALANCE = EnhanceOpts(0.3f, 0.35f)
        val PURE = EnhanceOpts(0f, 0f, false)
    }
}

private class Rng(var s: Int) {
    fun next(): Float {
        s = s xor (s shl 13)
        s = s xor (s ushr 17)
        s = s xor (s shl 5)
        return (s ushr 8) / 16777216f
    }
}

/** Эллипсы лиц в пикселях исходника (встроенный [FaceDetector], без интернета). */
class FaceMask private constructor(private val faces: List<FloatArray>) {
    fun isEmpty(): Boolean = faces.isEmpty()

    /** 1 внутри лица, плавно до 0 к краю. */
    fun weight(x: Float, y: Float): Float {
        var w = 0f
        for (f in faces) {
            val dx = (x - f[0]) / f[2]
            val dy = (y - f[1]) / f[3]
            val d = dx * dx + dy * dy
            if (d < 1.5f) w = max(w, (1.5f - d).coerceIn(0f, 1f))
        }
        return w
    }

    companion object {
        val EMPTY = FaceMask(emptyList())

        fun detect(src: Bitmap): FaceMask = try {
            val sc = min(1f, 1024f / max(src.width, src.height))
            val w = ((src.width * sc).toInt() and 1.inv()).coerceAtLeast(2)
            val h = (src.height * sc).toInt().coerceAtLeast(2)
            val scaled = Bitmap.createScaledBitmap(src, w, h, true)
            val bmp = scaled.copy(Bitmap.Config.RGB_565, false)
            if (scaled !== src) scaled.recycle()
            val maxFaces = 8
            val arr = arrayOfNulls<FaceDetector.Face>(maxFaces)
            val n = FaceDetector(w, h, maxFaces).findFaces(bmp, arr)
            bmp.recycle()
            val k = src.width.toFloat() / w
            val list = ArrayList<FloatArray>()
            for (i in 0 until n) {
                val f = arr[i] ?: continue
                if (f.confidence() < 0.4f) continue
                val p = PointF()
                f.getMidPoint(p)
                val e = f.eyesDistance()
                list.add(floatArrayOf(p.x * k, (p.y + e * 0.5f) * k, e * 1.4f * k, e * 1.9f * k))
            }
            if (list.isEmpty()) EMPTY else FaceMask(list)
        } catch (_: Throwable) {
            EMPTY
        }
    }
}

