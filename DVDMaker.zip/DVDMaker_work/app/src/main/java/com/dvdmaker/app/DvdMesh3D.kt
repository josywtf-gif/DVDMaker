package com.dvdmaker.app

import android.content.res.AssetManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Меш кейса DVD (модель «DVD Case» by seppel, CC BY-SA 3.0). Координаты исходной модели: x — толщина (лицо при +x), y — вверх, z — ширина (корешок при +z). */
object DvdMeshAsset {
    var pos: FloatArray? = null
    var tri: IntArray? = null

    fun init(am: AssetManager) {
        runCatching {
            val b = am.open("models/dvd_case.bin").use { it.readBytes() }
            val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
            val nv = bb.int; val nt = bb.int
            val p = FloatArray(nv * 3) { bb.float }
            val t = IntArray(nt * 3) { bb.short.toInt() and 0xFFFF }
            pos = p; tri = t
        }
    }
}

private const val M_X = 0.0236f
private const val M_Y0 = 0.0125f
private const val M_Y1 = 0.7434f
private const val M_YC = 0.378f
private const val M_ZW = 0.5156f
private const val M_ZF = 0.2655f
private const val M_ZO = 0.2501f
private const val M_SPINE_Z = 0.2677f

/** Закрытый кейс DVD из реальной 3D-модели: чёрный пластик, обложка/корешок/оборот проекта накладываются на плоские грани. */
internal class DvdMeshScene(val p: Project, val tex: CaseTextures) : SceneRender {
    private val src = DvdMeshAsset.pos!!
    private val srcTri = DvdMeshAsset.tri!!
    private val f = p.format
    private val sz = f.frontW / M_ZW
    private val sy = f.frontH / (M_Y1 - M_Y0)
    private val sx = f.spineW.coerceAtLeast(5f) / (2 * M_X)
    private val camera = 1100f

    private fun cx(zm: Float) = -zm * sz
    private fun cyv(ym: Float) = -(ym - M_YC) * sy
    private fun cz(xm: Float) = xm * sx

    private val nv = src.size / 3
    private val vx = FloatArray(nv) { cx(src[it * 3 + 2]) }
    private val vy = FloatArray(nv) { cyv(src[it * 3 + 1]) }
    private val vz = FloatArray(nv) { cz(src[it * 3]) }
    private val nt = srcTri.size / 3
    private val ti = srcTri.copyOf()
    private val nxA = FloatArray(nt); private val nyA = FloatArray(nt); private val nzA = FloatArray(nt)
    private val rad: Float

    init {
        var r = 0f
        for (i in 0 until nv) r = maxOf(r, sqrt(vx[i] * vx[i] + vy[i] * vy[i] + vz[i] * vz[i]))
        rad = r
        for (t in 0 until nt) {
            val a = ti[t * 3]; val b = ti[t * 3 + 1]; val c = ti[t * 3 + 2]
            var ux = vx[b] - vx[a]; var uy = vy[b] - vy[a]; var uz = vz[b] - vz[a]
            var wx = vx[c] - vx[a]; var wy = vy[c] - vy[a]; var wz = vz[c] - vz[a]
            var nx = uy * wz - uz * wy; var ny = uz * wx - ux * wz; var nz = ux * wy - uy * wx
            val mx = (vx[a] + vx[b] + vx[c]) / 3f; val my = (vy[a] + vy[b] + vy[c]) / 3f; val mz = (vz[a] + vz[b] + vz[c]) / 3f
            if (nx * mx + ny * my + nz * mz < 0f) {
                ti[t * 3 + 1] = c; ti[t * 3 + 2] = b
                nx = -nx; ny = -ny; nz = -nz
            }
            val l = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-9f)
            nxA[t] = nx / l; nyA[t] = ny / l; nzA[t] = nz / l
        }
    }

    private class P(val x: Float, val y: Float, val z: Float)

    override fun render(out: Bitmap, yawDeg: Float, pitchDeg: Float, slide: Float) {
        out.eraseColor(Color.TRANSPARENT)
        val c = Canvas(out)
        val vw = out.width.toFloat(); val vh = out.height.toFloat()
        val yaw = Math.toRadians(yawDeg.toDouble()); val pitch = Math.toRadians(pitchDeg.toDouble())
        val cyw = cos(yaw).toFloat(); val syw = sin(yaw).toFloat()
        val cp = cos(pitch).toFloat(); val sp = sin(pitch).toFloat()
        val scale = min(vw, vh) * 0.47f / rad

        fun proj(x: Float, y0: Float, z0: Float): P {
            val x1 = x * cyw + z0 * syw
            val z1 = -x * syw + z0 * cyw
            val y2 = y0 * cp + z1 * sp
            val z2 = -y0 * sp + z1 * cp
            val k = camera / (camera - z2)
            return P(vw / 2f + x1 * k * scale, vh / 2f + y2 * k * scale, z2)
        }
        fun area(q: Array<P>): Float {
            var s = 0f
            for (i in 0 until 4) { val a = q[i]; val b = q[(i + 1) % 4]; s += a.x * b.y - b.x * a.y }
            return s / 2f
        }
        fun flat(q: Array<P>) = FloatArray(8) { if (it % 2 == 0) q[it / 2].x else q[it / 2].y }
        fun pathOf(q: Array<P>) = Path().apply { moveTo(q[0].x, q[0].y); for (i in 1..3) lineTo(q[i].x, q[i].y); close() }

        // тень на «полу»
        run {
            val b = proj(0f, f.frontH / 2f, 0f)
            val rx = (f.frontW + 10f) * 0.6f * scale
            val oy = b.y + 6f * scale * 0.6f
            val sh = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(vw / 2f, oy, rx, intArrayOf(0x55000000, 0x00000000), null, Shader.TileMode.CLAMP)
            }
            c.save(); c.scale(1f, 0.16f, vw / 2f, oy)
            c.drawCircle(vw / 2f, oy, rx, sh)
            c.restore()
        }

        val px = FloatArray(nv); val py = FloatArray(nv); val pz = FloatArray(nv)
        for (i in 0 until nv) { val r = proj(vx[i], vy[i], vz[i]); px[i] = r.x; py[i] = r.y; pz[i] = r.z }

        val vis = ArrayList<Int>(nt)
        val depth = FloatArray(nt)
        for (t in 0 until nt) {
            val a = ti[t * 3]; val b = ti[t * 3 + 1]; val d = ti[t * 3 + 2]
            val ar = (px[a] * py[b] - px[b] * py[a] + px[b] * py[d] - px[d] * py[b] + px[d] * py[a] - px[a] * py[d]) / 2f
            if (ar > 0f) { vis.add(t); depth[t] = (pz[a] + pz[b] + pz[d]) / 3f }
        }
        vis.sortBy { depth[it] }

        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 0.8f }
        val path = Path()
        for (t in vis) {
            val a = ti[t * 3]; val b = ti[t * 3 + 1]; val d = ti[t * 3 + 2]
            val rx = nxA[t] * cyw + nzA[t] * syw
            val rz1 = -nxA[t] * syw + nzA[t] * cyw
            val ry = nyA[t] * cp + rz1 * sp
            val rz = -nyA[t] * sp + rz1 * cp
            val lit = (-0.35f * rx - 0.5f * ry + 0.8f * rz).coerceIn(-1f, 1f)
            val spec = Math.pow(lit.coerceAtLeast(0f).toDouble(), 6.0).toFloat()
            val base = 0x17 + (lit.coerceAtLeast(0f) * 26f + spec * 70f).roundToInt()
            val col = Color.rgb(base.coerceAtMost(255), base.coerceAtMost(255), (base + 4).coerceAtMost(255))
            fill.color = col; edge.color = col
            path.rewind(); path.moveTo(px[a], py[a]); path.lineTo(px[b], py[b]); path.lineTo(px[d], py[d]); path.close()
            c.drawPath(path, fill); c.drawPath(path, edge)
        }

        val tp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        fun tq(bmp: Bitmap, q: Array<P>) {
            if (area(q) <= 0.5f) return
            val m = Matrix()
            val w = bmp.width.toFloat(); val h = bmp.height.toFloat()
            m.setPolyToPoly(floatArrayOf(0f, 0f, w, 0f, w, h, 0f, h), 0, flat(q), 0, 4)
            val pa = pathOf(q)
            c.save(); c.clipPath(pa); c.concat(m); c.drawBitmap(bmp, 0f, 0f, tp); c.restore()
            // блик на плёнке
            val bd = RectF(); pa.computeBounds(bd, true)
            c.save(); c.clipPath(pa)
            c.drawRect(bd, Paint().apply {
                shader = LinearGradient(
                    bd.left, bd.top, bd.right, bd.bottom,
                    intArrayOf(0x33FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x1AFFFFFF), floatArrayOf(0f, 0.38f, 0.6f, 1f), Shader.TileMode.CLAMP
                )
            })
            c.restore()
        }
        fun pm(xm: Float, ym: Float, zm: Float) = proj(cx(zm), cyv(ym), cz(xm))
        val e = 0.0004f
        // лицо (+x): слева корешок (+z)
        tq(tex.front, arrayOf(pm(M_X + e, M_Y1, M_ZF), pm(M_X + e, M_Y1, -M_ZO), pm(M_X + e, M_Y0, -M_ZO), pm(M_X + e, M_Y0, M_ZF)))
        // оборот (-x): корешок справа
        tq(tex.back, arrayOf(pm(-M_X - e, M_Y1, -M_ZO), pm(-M_X - e, M_Y1, M_ZF), pm(-M_X - e, M_Y0, M_ZF), pm(-M_X - e, M_Y0, -M_ZO)))
        // корешок (+z): справа лицо (+x)
        val sxm = 0.0227f
        tq(tex.spine, arrayOf(pm(-sxm, M_Y1, M_SPINE_Z + e), pm(sxm, M_Y1, M_SPINE_Z + e), pm(sxm, M_Y0, M_SPINE_Z + e), pm(-sxm, M_Y0, M_SPINE_Z + e)))
    }
}
