package com.dvdmaker.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SortLabels = listOf("По дате", "По названию", "По формату")
private val DateFmt get() = SimpleDateFormat("d MMM yyyy", Locale("ru"))

/** Кэш миниатюр: карточки не перерисовываются заново при прокрутке и возврате на главный экран. */
private object ThumbCache : android.util.LruCache<String, ImageBitmap>(12 * 1024 * 1024) {
    override fun sizeOf(key: String, value: ImageBitmap): Int =
        runCatching { value.asAndroidBitmap().byteCount }.getOrDefault(0)
}

object ThumbMemory {
    fun trim(level: Int) {
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE) ThumbCache.evictAll()
        else if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) ThumbCache.trimToSize(3 * 1024 * 1024)
    }
}

@Composable
fun HomeScreen(vm: AppVm) {
    var about by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Project?>(null) }
    var toRename by remember { mutableStateOf<Project?>(null) }
    var showFormats by remember { mutableStateOf(false) }
    var selectedFormat by remember { mutableStateOf(DiscFormat.BLURAY) }
    var customSize by remember { mutableStateOf(false) }
    var customW by remember { mutableStateOf("269") }
    var customH by remember { mutableStateOf("150") }
    var customSpine by remember { mutableStateOf("11") }
    var showAdvanced by remember { mutableStateOf(false) }
    var showSafeZone by remember { mutableStateOf(true) }
    var query by rememberSaveable { mutableStateOf("") }
    var favOnly by rememberSaveable { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    val pickPhotoProject = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) vm.createPhoto(uri) }

    val sort = vm.sortMode.coerceIn(0, 2)
    val q = query.trim()
    val all = vm.projects
    val visible = remember(all, q, favOnly, sort) {
        val f = all.filter { p ->
            (!favOnly || p.favorite) &&
                (q.isEmpty() || p.name.contains(q, ignoreCase = true) || p.format.title.contains(q, ignoreCase = true))
        }
        when (sort) {
            1 -> f.sortedBy { it.name.lowercase() }
            2 -> f.sortedWith(compareBy({ it.format.title }, { it.name.lowercase() }))
            else -> f.sortedByDescending { it.updated }
        }
    }
    val last = remember(all) { all.filter { it.opened > 0 }.maxByOrNull { it.opened } ?: all.maxByOrNull { it.updated } }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(160.dp),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("DVDMaker", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextPrimary,
                    modifier = Modifier.weight(1f))
                IconButton(onClick = { about = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Настройки", tint = Dim)
                }
            }
        }

        if (vm.update != null) item(span = { GridItemSpan(maxLineSpan) }) { UpdateBanner(vm) }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    Modifier.weight(1.2f).height(PrimaryControlHeight)
                        .clip(RoundedCornerShape(RadiusLarge))
                        .background(GoldBrush)
                        .clickable { showFormats = true },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = TextOnAccent)
                    Spacer(Modifier.width(6.dp))
                    Text("Новый проект", color = TextOnAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                }
                Box(
                    Modifier.weight(1f).height(PrimaryControlHeight)
                        .clip(RoundedCornerShape(RadiusLarge))
                        .background(Card)
                        .border(BorderStroke(1.dp, Line), RoundedCornerShape(RadiusLarge))
                        .clickable { vm.checker = true },
                    contentAlignment = Alignment.Center
                ) {
                    Text("Проверить обложку", color = Amber, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 8.dp))
                }
            }
        }

        if (q.isEmpty() && !favOnly && last != null) item(span = { GridItemSpan(maxLineSpan) }) {
            val shape = RoundedCornerShape(RadiusLarge)
            Row(
                Modifier.fillMaxWidth().clip(shape).background(Card)
                    .border(BorderStroke(1.dp, Line.copy(alpha = 0.55f)), shape)
                    .clickable { vm.open(last) }.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ProjectThumb(last, Modifier.width(84.dp).height(56.dp))
                Column(Modifier.weight(1f).padding(horizontal = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("ПРОДОЛЖИТЬ", color = Amber, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Text(last.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${last.format.title} · ${DateFmt.format(Date(last.updated))}", color = Dim, fontSize = 11.sp, maxLines = 1)
                }
            }
        }


        if (all.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                SearchField(query, { query = it }, Modifier.fillMaxWidth())
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Мои проекты", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("${visible.size}", color = Dim, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                FilterChipBtn("Избранные", favOnly) { favOnly = !favOnly }
                Box {
                    Row(
                        Modifier.heightIn(min = 34.dp).clip(RoundedCornerShape(RadiusSmall))
                            .background(Card2).clickable { sortMenu = true }
                            .padding(start = 10.dp, end = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(SortLabels[sort], fontSize = 11.sp, maxLines = 1)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Сортировка", tint = Dim)
                    }
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false },
                        modifier = Modifier.background(Card2)) {
                        SortLabels.forEachIndexed { i, label ->
                            DropdownMenuItem(
                                text = { Text(label, color = if (i == sort) Amber else TextPrimary) },
                                onClick = { vm.setSort(i); sortMenu = false }
                            )
                        }
                    }
                }
            }
        }

        if (visible.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                when {
                    all.isEmpty() -> EmptyState(
                        title = "Начните с новой обложки",
                        message = "Выберите формат — приложение подготовит рабочее поле и панели автоматически."
                    )
                    favOnly && q.isEmpty() -> EmptyState(
                        title = "Пока нет избранного",
                        message = "Добавляйте часто используемые проекты в избранное значком сердца.",
                        actionLabel = "Показать все проекты",
                        onAction = { favOnly = false }
                    )
                    else -> EmptyState(
                        title = "Ничего не найдено",
                        message = "Измените запрос или очистите поиск."
                    )
                }
            }
        } else {
            items(visible, key = { it.id }) { project ->
                ProjectCard(
                    project,
                    onOpen = { vm.open(project) },
                    onFavorite = { vm.toggleFavorite(project) },
                    onRename = { toRename = project },
                    onDuplicate = { vm.duplicate(project) },
                    onDelete = { toDelete = project }
                )
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.height(12.dp)) }
    }

    if (showFormats) {
        val format = if (customSize) {
            val w = customW.toFloatOrNull()?.coerceIn(30f, 600f) ?: 269f
            val h = customH.toFloatOrNull()?.coerceIn(30f, 420f) ?: 150f
            val spine = (customSpine.toFloatOrNull() ?: 11f).coerceIn(0f, (w - 30f).coerceAtLeast(0f))
            DiscFormat("CUSTOM_${w}x${h}x${spine}", "Свой размер", "Пользовательский",
                (w - spine) / 2f, h, spine, (w - spine) / 2f, h, false)
        } else selectedFormat
        Dialog(onDismissRequest = { showFormats = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(Modifier.fillMaxWidth(0.94f).widthIn(max = 720.dp).fillMaxSize(0.94f).imePadding()
                .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                .background(Card).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Создание проекта", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Выберите формат — остальное настроим автоматически", color = Dim, fontSize = 12.sp)
                    }
                    IconButton(onClick = { showFormats = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Закрыть", tint = Dim)
                    }
                }
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("ФОРМАТ", color = Amber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                listOf(DiscFormat.BLURAY, DiscFormat.DVD, DiscFormat.DVD_SLIM, DiscFormat.CD, DiscFormat.PHOTO).chunked(2).forEach { line ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        line.forEach { f ->
                            val active = !customSize && selectedFormat.name == f.name
                            Column(Modifier.weight(1f).clip(RoundedCornerShape(RadiusSmall))
                                .background(if (active) Card2 else SurfaceRaised)
                                .border(BorderStroke(1.dp, if (active) Amber else Line), RoundedCornerShape(RadiusSmall))
                                .clickable { selectedFormat = f; customSize = false }
                                .padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                FormatArt(f, Modifier.fillMaxWidth().height(PrimaryControlHeight))
                                Text(f.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(if (f.photo) "Создать из изображения" else f.specText, color = Dim, fontSize = 10.sp)
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(RadiusSmall))
                    .background(if (customSize) Card2 else SurfaceRaised)
                    .border(BorderStroke(1.dp, if (customSize) Amber else Line), RoundedCornerShape(RadiusSmall))
                    .clickable { customSize = true }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Пользовательский размер", fontWeight = FontWeight.SemiBold)
                        Text("Ширина, высота и корешок в миллиметрах", color = Dim, fontSize = 11.sp)
                    }
                    if (customSize) Text("Выбрано", color = Amber, fontSize = 11.sp)
                }
                if (customSize) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(customW, { customW = it.filter(Char::isDigit).take(4) },
                            Modifier.weight(1f), label = { Text("Ширина") }, singleLine = true)
                        OutlinedTextField(customH, { customH = it.filter(Char::isDigit).take(4) },
                            Modifier.weight(1f), label = { Text("Высота") }, singleLine = true)
                        OutlinedTextField(customSpine, { customSpine = it.filter(Char::isDigit).take(2) },
                            Modifier.weight(0.8f), label = { Text("Корешок") }, singleLine = true)
                    }
                }
                TextButton(onClick = { showAdvanced = !showAdvanced }) {
                    Text(if (showAdvanced) "Скрыть дополнительно" else "Дополнительно", color = Amber)
                }
                if (showAdvanced) {
                    Text("Размеры и безопасная зона", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Показывать безопасную зону", fontSize = 13.sp)
                            Text("Пунктирная граница отступа 3 мм в редакторе", color = Dim, fontSize = 11.sp)
                        }
                        Switch(checked = showSafeZone, onCheckedChange = { showSafeZone = it })
                    }
                    Text("Умные направляющие выравнивания работают автоматически при перемещении объектов. Безопасная зона — пунктирный отступ 3 мм.",
                        color = Dim, fontSize = 11.sp)
                    Text("Пользовательские размеры вводятся в миллиметрах. Для стандартных форматов физические размеры заданы автоматически.",
                        color = Dim, fontSize = 11.sp)
                }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { showFormats = false }, modifier = Modifier.weight(1f)) {
                        Text("Отмена", color = Dim)
                    }
                    Box(Modifier.weight(1.5f).height(PrimaryControlHeight).clip(RoundedCornerShape(RadiusMedium))
                        .background(GoldBrush).clickable {
                            showFormats = false
                            if (format.name == DiscFormat.PHOTO.name && !customSize) {
                            pickPhotoProject.launch("image/*")
                        } else {
                            vm.create(format, showSafeZone)
                        }
                        }, contentAlignment = Alignment.Center) {
                        Text("Создать проект", color = TextOnAccent, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    toRename?.let { project ->
        var name by remember(project.id) { mutableStateOf(project.name) }
        AlertDialog(
            onDismissRequest = { toRename = null },
            containerColor = Card,
            title = { Text("Переименовать") },
            text = {
                OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                TextButton(onClick = { vm.renameProject(project, name); toRename = null }) {
                    Text("Сохранить", color = Amber)
                }
            },
            dismissButton = { TextButton(onClick = { toRename = null }) { Text("Отмена", color = Dim) } }
        )
    }

    toDelete?.let { project ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            containerColor = Card,
            title = { Text("Удалить проект?") },
            text = { Text("«${project.name}» будет удалён без возможности восстановления.", color = Dim) },
            confirmButton = {
                TextButton(onClick = { vm.delete(project); toDelete = null }) {
                    Text("Удалить", color = Danger)
                }
            },
            dismissButton = {
                TextButton(onClick = { toDelete = null }) { Text("Отмена", color = Dim) }
            }
        )
    }

    if (about) AboutDialog(vm) { about = false }
}

@Composable
private fun FilterChipBtn(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.heightIn(min = 34.dp).clip(RoundedCornerShape(RadiusSmall))
            .background(if (selected) Violet else Card2)
            .clickable(onClick = onClick).padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 11.sp, maxLines = 1, color = if (selected) TextOnAccent else TextPrimary,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.height(ControlHeight).clip(RoundedCornerShape(RadiusSmall)).background(Card2).padding(start = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Search, contentDescription = null, tint = Dim, modifier = Modifier.size(20.dp))
        Box(Modifier.weight(1f).padding(horizontal = 8.dp), contentAlignment = Alignment.CenterStart) {
            if (value.isEmpty()) Text("Поиск проектов", color = Dim, fontSize = 14.sp)
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                cursorBrush = SolidColor(Amber),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (value.isNotEmpty()) {
            IconButton(onClick = { onChange("") }) {
                Icon(Icons.Default.Close, contentDescription = "Очистить", tint = Dim)
            }
        }
    }
}

@Composable
fun ProjectThumb(p: Project, modifier: Modifier = Modifier) {
    val key = p.id + ":" + p.updated
    val thumb by produceState<ImageBitmap?>(ThumbCache.get(key), key) {
        if (value == null) {
            val b = withContext(Dispatchers.Default) { renderSheet(p, 1.4f, false, false).asImageBitmap() }
            ThumbCache.put(key, b)
            value = b
        }
    }
    Box(modifier.clip(RoundedCornerShape(RadiusSmall)).background(Card2), contentAlignment = Alignment.Center) {
        thumb?.let {
            Image(it, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
fun ProjectCard(
    p: Project,
    onOpen: () -> Unit,
    onFavorite: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(RadiusMedium)
    Box {
        Column(
            Modifier.fillMaxWidth().clip(shape).background(Card)
                .border(BorderStroke(1.dp, Line.copy(alpha = 0.55f)), shape)
                .clickable(onClick = onOpen)
                .padding(7.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box {
                ProjectThumb(p, Modifier.fillMaxWidth().aspectRatio(1.55f))
                Box(
                    Modifier.align(Alignment.TopEnd).size(38.dp).clickable(onClick = onFavorite),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(28.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.58f)),
                        contentAlignment = Alignment.Center) {
                        Icon(
                            if (p.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Избранное",
                            tint = if (p.favorite) Amber else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(start = 4.dp), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(p.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (p.readOnly) "Только чтение · создан в новой версии" else "${p.format.title} · ${DateFmt.format(Date(p.updated))}",
                        color = if (p.readOnly) Amber else Dim, fontSize = 11.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = { menu = true }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Меню", tint = Dim)
                }
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, modifier = Modifier.background(Card2)) {
            DropdownMenuItem(text = { Text("Переименовать") }, onClick = { menu = false; onRename() })
            DropdownMenuItem(text = { Text("Дублировать") }, onClick = { menu = false; onDuplicate() })
            DropdownMenuItem(text = { Text("Удалить", color = Danger) }, onClick = { menu = false; onDelete() })
        }
    }
}

@Composable
fun UpdateBanner(vm: AppVm) {
    val u = vm.update ?: return
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Card)
            .border(BorderStroke(1.5.dp, GoldBrush), shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Доступно обновление", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text("${u.name} — новая версия DVDMaker. Установится поверх текущей, проекты сохранятся.",
            color = Dim, fontSize = 12.sp)
        val pr = vm.progress
        if (pr != null) {
            LinearProgressIndicator(
                progress = { pr },
                modifier = Modifier.fillMaxWidth(),
                color = Amber, trackColor = Line
            )
            Text("Загрузка ${(pr * 100).toInt()}%", color = Dim, fontSize = 12.sp)
        } else {
            GradientButton("Обновить", onClick = { vm.downloadAndInstall() }, brush = GoldBrush)
        }
        vm.updateMsg?.let { Text(it, color = Danger, fontSize = 12.sp) }
    }
}

@Composable
fun AboutDialog(vm: AppVm, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text("DVDMaker") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Версия ${BuildConfig.VERSION_NAME}", color = Dim)
                if (vm.update != null) UpdateBanner(vm)
                else {
                    if (vm.checking) Text("Проверяем…", color = Amber)
                    vm.updateMsg?.let { Text(it, color = Amber) }
                    GradientButton("Проверить обновления", onClick = { vm.checkUpdate(true) },
                        enabled = !vm.checking)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}
