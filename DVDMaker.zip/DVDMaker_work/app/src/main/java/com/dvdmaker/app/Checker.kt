package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.activity.compose.BackHandler
import androidx.compose.material3.LinearProgressIndicator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Загруженное для проверки изображение: bitmap (до 4096 px) и реальные размеры файла. */
class CheckImage(val bmp: Bitmap, val trueW: Int, val trueH: Int)

enum class CheckTarget(val title: String) {
    WRAP("Вся обложка"), FRONT("Лицо"), BACK("Оборот"), DISC("Диск")
}

enum class FitMode(val title: String) { FILL("Заполнить"), FIT("Вписать"), STRETCH("Растянуть") }

enum class Level { OK, WARN, BAD, INFO }

class Finding(val level: Level, val title: String, val detail: String)

class Report(val findings: List<Finding>, val overall: Level)

fun DiscFormat.checkTargets(): List<CheckTarget> =
    if (tray) listOf(CheckTarget.FRONT, CheckTarget.BACK, CheckTarget.DISC)
    else listOf(CheckTarget.WRAP, CheckTarget.FRONT, CheckTarget.BACK, CheckTarget.DISC)

fun DiscFormat.targetSize(t: CheckTarget): Pair<Float, Float> = when (t) {
    CheckTarget.WRAP -> layout().let { it.w to it.h }
    CheckTarget.FRONT -> frontW to frontH
    CheckTarget.BACK -> backW to backH
    CheckTarget.DISC -> DISC_SIZE_MM to DISC_SIZE_MM
}

object Preflight {
    private fun pct(v: Float): String = String.format(java.util.Locale.US, "%.1f", v * 100f)

    fun analyze(wPx: Int, hPx: Int, tw: Float, th: Float, target: CheckTarget): Report {
        val list = ArrayList<Finding>()
        val ia = wPx.toFloat() / hPx
        val ta = tw / th
        val diff = abs(ia / ta - 1f)
        val needW = (tw / 25.4f * 300f).roundToInt()
        val needH = (th / 25.4f * 300f).roundToInt()

        list.add(Finding(Level.INFO, "Размер макета",
            "Нужно ${fmt(tw)}×${fmt(th)} мм. Для 300 dpi — не меньше $needW×$needH px. У вас $wPx×$hPx px."))

        val orientMismatch = (ia > 1.05f && ta < 0.95f) || (ia < 0.95f && ta > 1.05f)
        if (orientMismatch) {
            list.add(Finding(Level.BAD, "Ориентация не совпадает",
                "Картинка " + (if (ia > 1f) "горизонтальная" else "вертикальная") +
                    ", а нужна " + (if (ta > 1f) "горизонтальная" else "вертикальная") + ". Попробуйте «Повернуть 90°»."))
        }

        when {
            diff <= 0.01f -> list.add(Finding(Level.OK, "Пропорции совпадают",
                "Соотношение сторон в пределах 1% от нужного."))
            diff <= 0.05f -> list.add(Finding(Level.WARN, "Пропорции отличаются на ${pct(diff)}%",
                "Небольшая разница: при подгонке «Заполнить» край слегка обрежется, при «Вписать» появятся тонкие поля."))
            else -> list.add(Finding(Level.BAD, "Пропорции отличаются на ${pct(diff)}%",
                "«Заполнить» заметно обрежет картинку, «Вписать» оставит большие поля, «Растянуть» исказит изображение."))
        }

        val mmPerPx = max(tw / wPx, th / hPx)
        val dpi = 25.4f / mmPerPx
        val dpiText = "При печати в натуральную величину получится ${dpi.roundToInt()} dpi."
        when {
            dpi >= 300f -> list.add(Finding(Level.OK, "Разрешение отличное", dpiText))
            dpi >= 200f -> list.add(Finding(Level.WARN, "Разрешение достаточное",
                "$dpiText Для печати подойдёт, но мелкий текст может быть мягким."))
            dpi >= 150f -> list.add(Finding(Level.WARN, "Разрешение низкое",
                "$dpiText Возможна заметная мягкость и пикселизация."))
            else -> list.add(Finding(Level.BAD, "Разрешение слишком низкое",
                "$dpiText Нужна картинка побольше."))
        }

        if (target == CheckTarget.DISC) {
            list.add(Finding(Level.INFO, "Печать на диске",
                "Печатается кольцо 118 мм с отверстием 22 мм. Важные элементы держите вне центрального отверстия и не ближе 3 мм к краю."))
        }

        val overall = when {
            list.any { it.level == Level.BAD } -> Level.BAD
            list.any { it.level == Level.WARN } -> Level.WARN
            else -> Level.OK
        }
        return Report(list, overall)
    }
}

object Fitter {
    private fun edgeColor(src: Bitmap): Int {
        var r = 0L; var g = 0L; var b = 0L; var n = 0
        val steps = 48
        for (i in 0 until steps) {
            val fx = ((i + 0.5f) / steps * (src.width - 1)).toInt()
            val fy = ((i + 0.5f) / steps * (src.height - 1)).toInt()
            for (px in intArrayOf(
                src.getPixel(fx, 0), src.getPixel(fx, src.height - 1),
                src.getPixel(0, fy), src.getPixel(src.width - 1, fy)
            )) {
                r += android.graphics.Color.red(px); g += android.graphics.Color.green(px)
                b += android.graphics.Color.blue(px); n++
            }
        }
        if (n == 0) return android.graphics.Color.WHITE
        return android.graphics.Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
    }

    /** Возвращает картинку ровно под размер [tw]×[th] мм при заданном [dpi]. */
    fun fit(src: Bitmap, tw: Float, th: Float, mode: FitMode, dpi: Float, padWhite: Boolean): Bitmap {
        var ow = (tw / 25.4f * dpi).roundToInt().coerceAtLeast(1)
        var oh = (th / 25.4f * dpi).roundToInt().coerceAtLeast(1)
        val big = max(ow, oh)
        if (big > 4500) {
            val k = 4500f / big
            ow = (ow * k).roundToInt().coerceAtLeast(1)
            oh = (oh * k).roundToInt().coerceAtLeast(1)
        }
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(android.graphics.Color.WHITE)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
        val sw = src.width.toFloat()
        val sh = src.height.toFloat()
        when (mode) {
            FitMode.FILL -> {
                val s = max(ow / sw, oh / sh)
                val dw = sw * s
                val dh = sh * s
                c.drawBitmap(src, null, RectF((ow - dw) / 2f, (oh - dh) / 2f, (ow + dw) / 2f, (oh + dh) / 2f), paint)
            }
            FitMode.FIT -> {
                c.drawColor(if (padWhite) android.graphics.Color.WHITE else edgeColor(src))
                val s = min(ow / sw, oh / sh)
                val dw = sw * s
                val dh = sh * s
                c.drawBitmap(src, null, RectF((ow - dw) / 2f, (oh - dh) / 2f, (ow + dw) / 2f, (oh + dh) / 2f), paint)
            }
            FitMode.STRETCH -> c.drawBitmap(src, null, RectF(0f, 0f, ow.toFloat(), oh.toFloat()), paint)
        }
        return out
    }

    /** Лёгкий предпросмотр; для диска дополнительно вырезает печатное кольцо. */
    fun preview(src: Bitmap, tw: Float, th: Float, mode: FitMode, padWhite: Boolean, disc: Boolean): Bitmap {
        val f = fit(src, tw, th, mode, 60f, padWhite)
        if (!disc) return f
        val out = Bitmap.createBitmap(f.width, f.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val ppm = f.width / tw
        val cx = f.width / 2f
        val cy = f.height / 2f
        val outer = android.graphics.Path().apply { addCircle(cx, cy, DISC_OUTER_MM * ppm / 2f, android.graphics.Path.Direction.CW) }
        val hole = android.graphics.Path().apply { addCircle(cx, cy, DISC_INNER_MM * ppm / 2f, android.graphics.Path.Direction.CW) }
        c.clipPath(outer)
        c.clipOutPath(hole)
        c.drawBitmap(f, 0f, 0f, null)
        f.recycle()
        return out
    }
}

/** Проект из подогнанной картинки: на каждую нужную панель кладётся нужный кусок изображения. */
fun buildFinishedProject(format: DiscFormat, target: CheckTarget, path: String, name: String): Project {
    val base = newProject(format, name)
    val (tw, _) = format.targetSize(target)
    val panels = base.panels.mapValues { (_, d) -> d.copy(layers = emptyList()) }.toMutableMap()
    fun put(id: PanelId, offsetMm: Float, panelW: Float) {
        val layer = Layer(kind = Kind.IMAGE, path = path, widthMm = tw, x = (tw / 2f - offsetMm) / panelW, y = 0.5f)
        panels[id] = panels.getValue(id).copy(layers = listOf(layer))
    }
    when (target) {
        CheckTarget.FRONT -> put(PanelId.FRONT, 0f, format.frontW)
        CheckTarget.BACK -> put(PanelId.BACK, 0f, format.backW)
        CheckTarget.DISC -> put(PanelId.DISC, 0f, DISC_SIZE_MM)
        CheckTarget.WRAP -> for (pl in format.layout().places) put(pl.id, pl.x, pl.w)
    }
    return base.copy(panels = panels, foldShadow = false)
}

private fun rotateBmp(bmp: Bitmap, quarter: Int): Bitmap {
    val q = ((quarter % 4) + 4) % 4
    if (q == 0) return bmp
    val m = Matrix().apply { postRotate(90f * q) }
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
}

private fun levelColor(l: Level): Color = when (l) {
    Level.OK -> Color(0xFF34D399)
    Level.WARN -> Amber
    Level.BAD -> Color(0xFFFF6B6B)
    Level.INFO -> Dim
}

private fun levelMark(l: Level): String = when (l) {
    Level.OK -> "✓"
    Level.WARN -> "!"
    Level.BAD -> "✕"
    Level.INFO -> "•"
}

@Composable
fun CheckerScreen(vm: AppVm) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var img by remember { mutableStateOf<CheckImage?>(null) }
    var loading by remember { mutableStateOf(false) }
    var format by remember { mutableStateOf(DiscFormat.DVD) }
    var target by remember { mutableStateOf(CheckTarget.WRAP) }
    var quarter by remember { mutableStateOf(0) }
    var mode by remember { mutableStateOf(FitMode.FILL) }
    var padWhite by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var nnProgress by remember { mutableStateOf(0) }
    var enhancing by remember { mutableStateOf(false) }
    var showEnh by remember { mutableStateOf(false) }
    var enhJob by remember { mutableStateOf<Job?>(null) }

    val cur = img
    val rotated: Bitmap? = remember(cur, quarter) { cur?.let { rotateBmp(it.bmp, quarter) } }
    val tgtW = format.targetSize(target).first
    val tgtH = format.targetSize(target).second
    val odd = quarter % 2 != 0
    val trueW = if (cur == null) 0 else if (odd) cur.trueH else cur.trueW
    val trueH = if (cur == null) 0 else if (odd) cur.trueW else cur.trueH
    val report: Report? = remember(cur, quarter, format, target) {
        if (cur == null) null else Preflight.analyze(trueW, trueH, tgtW, tgtH, target)
    }

    val preview by produceState<ImageBitmap?>(null, rotated, format, target, mode, padWhite) {
        val src = rotated
        value = if (src == null) null else withContext(Dispatchers.Default) {
            runCatching {
                Fitter.preview(src, tgtW, tgtH, mode, padWhite, target == CheckTarget.DISC).asImageBitmap()
            }.getOrNull()
        }
    }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            loading = true
            val loaded = withContext(Dispatchers.IO) { vm.store.decodeForCheck(uri) }
            loading = false
            if (loaded == null) {
                Toast.makeText(ctx, "Не удалось открыть изображение", Toast.LENGTH_SHORT).show()
            } else {
                img = loaded
                quarter = 0
            }
        }
    }

    val savePng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        val src = rotated
        if (uri != null && src != null) scope.launch {
            busy = true
            val ok = withContext(Dispatchers.Default) {
                runCatching {
                    val out = Fitter.fit(src, tgtW, tgtH, mode, 300f, padWhite)
                    ctx.contentResolver.openOutputStream(uri)!!.use { os -> out.compress(Bitmap.CompressFormat.PNG, 100, os) }
                    out.recycle()
                }.isSuccess
            }
            busy = false
            Toast.makeText(ctx, if (ok) "Сохранено" else "Не удалось сохранить", Toast.LENGTH_SHORT).show()
        }
    }

    BackHandler(enabled = enhancing) { }
    if (showEnh && cur != null) {
        val dpiNow = 25.4f / max(tgtW / trueW.coerceAtLeast(1), tgtH / trueH.coerceAtLeast(1))
        EnhanceOptionsDialog(dpiNow, onDismiss = { showEnh = false }) { sc, eo ->
            showEnh = false
            val base = cur
            if (!Enhancer.canEnhance(base.bmp, sc)) {
                Toast.makeText(ctx, "Картинка уже максимального размера (${Enhancer.MAX_SIDE} px)", Toast.LENGTH_LONG).show()
                return@EnhanceOptionsDialog
            }
            enhJob = scope.launch {
                busy = true
                enhancing = true
                nnProgress = 0
                val res = withContext(Dispatchers.Default) {
                    try {
                        val out = Enhancer.enhance(ctx, base.bmp, sc, eo) { nnProgress = it }
                        val f = out.width.toFloat() / base.bmp.width
                        CheckImage(out, (base.trueW * f).roundToInt(), (base.trueH * f).roundToInt())
                    } catch (t: CancellationException) {
                        throw t
                    } catch (t: Throwable) {
                        null
                    }
                }
                busy = false
                enhancing = false
                if (res == null) Toast.makeText(ctx, "Не удалось улучшить изображение", Toast.LENGTH_SHORT).show()
                else {
                    img = res
                    Toast.makeText(ctx, "Улучшено: ${res.trueW}×${res.trueH} px", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.checker = false }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text("Проверка готовой обложки", fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
                Text("Подойдёт ли файл для печати и подгонка по размеру", color = Dim, fontSize = 11.sp, maxLines = 1)
            }
        }

        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            GradientButton(
                if (cur == null) "Выбрать изображение" else "Выбрать другое изображение",
                onClick = { pick.launch("image/*") }, enabled = !loading && !busy,
                modifier = Modifier.fillMaxWidth()
            )
            if (loading) Text("Загружаем…", color = Amber, fontSize = 13.sp)

            if (cur == null) {
                Text(
                    "Выберите готовую обложку (JPG или PNG). Приложение сравнит её с нужным размером и разрешением " +
                        "и предложит подгонку: заполнить, вписать или растянуть.",
                    color = Dim, fontSize = 13.sp
                )
            } else {
                SectionLabel("Формат диска")
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiscFormat.values().filter { !it.photo }.forEach { f ->
                        Pill(f.title, f == format, {
                            format = f
                            if (target !in f.checkTargets()) target = f.checkTargets().first()
                        })
                    }
                }
                SectionLabel("Что проверяем")
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    format.checkTargets().forEach { t -> Pill(t.title, t == target, { target = t }) }
                    Pill("Повернуть 90°", false, { quarter = (quarter + 1) % 4 })
                }
                Text(
                    "Нужный размер: ${fmt(tgtW)}×${fmt(tgtH)} мм · файл: $trueW×$trueH px",
                    color = Dim, fontSize = 12.sp
                )

                report?.let { rep ->
                    val col = levelColor(rep.overall)
                    val shape = RoundedCornerShape(14.dp)
                    Column(
                        Modifier.fillMaxWidth().clip(shape).background(Card).border(BorderStroke(1.5.dp, col), shape).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            when (rep.overall) {
                                Level.OK -> "Готова к печати"
                                Level.WARN -> "Подходит с оговорками"
                                else -> "Нужна подгонка или другой файл"
                            },
                            color = col, fontWeight = FontWeight.Bold, fontSize = 15.sp
                        )
                        rep.findings.forEach { fnd ->
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(levelMark(fnd.level), color = levelColor(fnd.level), fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp, modifier = Modifier.width(18.dp))
                                Column {
                                    Text(fnd.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Text(fnd.detail, color = Dim, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                GradientButton(
                    "Улучшить качество", enabled = !busy && cur != null,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { showEnh = true }
                )
                Text(
                    "Нейросеть Real-ESRGAN (на устройстве, без интернета): увеличение ×2, ×3, ×4 " +
                        "или авто до 300 dpi, уберёт артефакты JPEG и дорисует детали. Может занять до нескольких минут.",
                    color = Dim, fontSize = 11.sp
                )

                SectionLabel("Подгонка по размеру")
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FitMode.values().forEach { m -> Pill(m.title, m == mode, { mode = m }) }
                }
                Text(
                    when (mode) {
                        FitMode.FILL -> "Картинка заполнит весь макет, лишнее по краям обрежется."
                        FitMode.FIT -> "Картинка поместится целиком, свободные места закрасятся."
                        FitMode.STRETCH -> "Картинка растянется ровно под размер, пропорции изменятся."
                    },
                    color = Dim, fontSize = 12.sp
                )
                if (mode == FitMode.FIT) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Белые поля (иначе — цвет краёв)", Modifier.weight(1f), fontSize = 13.sp)
                        Switch(checked = padWhite, onCheckedChange = { padWhite = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = Violet))
                    }
                }

                Box(
                    Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 320.dp)
                        .clip(RoundedCornerShape(12.dp)).background(Card2).padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val pv = preview
                    if (pv != null) Image(pv, contentDescription = null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp))
                    else Text("Готовим предпросмотр…", color = Dim, fontSize = 12.sp)
                }
                Text("После подгонки: ровно ${fmt(tgtW)}×${fmt(tgtH)} мм, 300 dpi.", color = Dim, fontSize = 12.sp)

                GradientButton(
                    "Открыть в редакторе", enabled = !busy && rotated != null,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        val src = rotated ?: return@GradientButton
                        scope.launch {
                            busy = true
                            val proj = withContext(Dispatchers.Default) {
                                runCatching {
                                    val out = Fitter.fit(src, tgtW, tgtH, mode, 300f, padWhite)
                                    val path = vm.store.saveBitmap(out)
                                    out.recycle()
                                    path?.let { buildFinishedProject(format, target, it, "Готовая ${format.title}") }
                                }.getOrNull()
                            }
                            busy = false
                            if (proj == null) Toast.makeText(ctx, "Не удалось подготовить проект", Toast.LENGTH_SHORT).show()
                            else vm.createFrom(proj)
                        }
                    }
                )
                GradientButton(
                    "Сохранить PNG под размер", enabled = !busy && rotated != null,
                    modifier = Modifier.fillMaxWidth(), brush = GoldBrush,
                    onClick = { savePng.launch("Обложка_${format.title}_${target.title}.png") }
                )
                if (busy && !enhancing) Text("Готовим файл…", color = Amber, fontSize = 13.sp)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (enhancing) {
        Box(
            Modifier.fillMaxSize().background(Color(0xE6000000))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 32.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Нейросеть улучшает изображение", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("$nnProgress%", color = Amber, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                if (nnProgress <= 0) LinearProgressIndicator(color = Violet, modifier = Modifier.fillMaxWidth())
                else LinearProgressIndicator(progress = { nnProgress / 100f }, color = Violet, modifier = Modifier.fillMaxWidth())
                Text("Это может занять до нескольких минут", color = Dim, fontSize = 12.sp)
                GradientButton("Отменить", onClick = { enhJob?.cancel(); busy = false; enhancing = false },
                    modifier = Modifier.fillMaxWidth())
            }
        }
    }
    }
}

/** Диагностика непрерывности панелей по реальным пикселям их границ. Не меняет проект. */
data class CoverSeamFinding(val title: String, val delta: Float, val textureDelta: Float) {
    val ok: Boolean get() = delta <= 28f && textureDelta <= 38f
}

object CoverSeamChecker {
    fun analyze(project: Project): List<CoverSeamFinding> {
        if (project.format.photo) return emptyList()
        val layout = project.format.layout()
        val ppm = 2f
        val places = layout.places.sortedWith(compareBy<Place> { it.y }.thenBy { it.x })
        val pairs = places.zipWithNext().filter { (a, b) ->
            kotlin.math.abs(a.y - b.y) < 0.5f && kotlin.math.abs((a.x + a.w) - b.x) < 0.5f
        }
        return pairs.mapNotNull { (a, b) ->
            val (aw, ah) = project.format.size(a.id)
            val (bw, bh) = project.format.size(b.id)
            val heightMm = minOf(ah, bh)
            val heightPx = (heightMm * ppm).roundToInt().coerceAtLeast(2)
            fun panel(place: Place, id: PanelId, wMm: Float, hMm: Float): Bitmap {
                val bmp = Bitmap.createBitmap((wMm * ppm).roundToInt().coerceAtLeast(2), (hMm * ppm).roundToInt().coerceAtLeast(2), Bitmap.Config.ARGB_8888)
                drawPanelWithFx(Canvas(bmp), project, id, if (id == PanelId.SPINE && place.x > 0f) 1 else 0,
                    bmp.width.toFloat(), bmp.height.toFloat(), ppm)
                return bmp
            }
            val left = panel(a, a.id, aw, ah)
            val right = panel(b, b.id, bw, bh)
            val rows = minOf(heightPx, left.height, right.height)
            val lp = IntArray(left.width * left.height); left.getPixels(lp, 0, left.width, 0, 0, left.width, left.height)
            val rp = IntArray(right.width * right.height); right.getPixels(rp, 0, right.width, 0, 0, right.width, right.height)
            var rgb = 0.0; var texture = 0.0; var n = 0
            for (y in 0 until rows) {
                val ly = (y.toFloat() / rows * left.height).toInt().coerceIn(0, left.height - 1)
                val ry = (y.toFloat() / rows * right.height).toInt().coerceIn(0, right.height - 1)
                val lc = lp[ly * left.width + left.width - 1]
                val rc = rp[ry * right.width]
                val dr = android.graphics.Color.red(lc) - android.graphics.Color.red(rc)
                val dg = android.graphics.Color.green(lc) - android.graphics.Color.green(rc)
                val db = android.graphics.Color.blue(lc) - android.graphics.Color.blue(rc)
                rgb += kotlin.math.sqrt((dr * dr + dg * dg + db * db).toDouble())
                val l2 = lp[ly * left.width + (left.width - 2).coerceAtLeast(0)]
                val r2 = rp[ry * right.width + minOf(1, right.width - 1)]
                val tl = kotlin.math.sqrt(((android.graphics.Color.red(lc) - android.graphics.Color.red(l2)).let { it * it } +
                    (android.graphics.Color.green(lc) - android.graphics.Color.green(l2)).let { it * it } +
                    (android.graphics.Color.blue(lc) - android.graphics.Color.blue(l2)).let { it * it }).toDouble())
                val tr = kotlin.math.sqrt(((android.graphics.Color.red(rc) - android.graphics.Color.red(r2)).let { it * it } +
                    (android.graphics.Color.green(rc) - android.graphics.Color.green(r2)).let { it * it } +
                    (android.graphics.Color.blue(rc) - android.graphics.Color.blue(r2)).let { it * it }).toDouble())
                texture += kotlin.math.abs(tl - tr); n++
            }
            left.recycle(); right.recycle()
            CoverSeamFinding("${a.id.title} — ${b.id.title}", (rgb / n.coerceAtLeast(1)).toFloat(), (texture / n.coerceAtLeast(1)).toFloat())
        }
    }
}
