package com.dvdmaker.app

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.Image
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

fun normRot(r: Float): Float = ((r + 180f) % 360f + 360f) % 360f - 180f

fun f1(v: Float): String = String.format(java.util.Locale.US, "%.1f", v)

fun Layer.label(): String =
    when (kind) {
        Kind.TEXT -> text.replace("\n", " ").take(12).ifBlank { "Текст" }
        Kind.IMAGE -> "Фото"
        Kind.RECT -> when (name) { "Блюр" -> "Блюр"; "Размытие" -> "Размытие"; else -> "Фигура" }
        Kind.SYMBOL -> "Значок: $text"
    }

@Composable
fun EditorScreen(vm: AppVm) {
    val p = vm.current ?: return
    val ctx = LocalContext.current
    val density = LocalDensity.current

    var showExport by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var guides by remember(p.id) { mutableStateOf(p.showSafeZone) }
    var confirmAutoFit by remember { mutableStateOf(false) }
    var showSharedText by remember { mutableStateOf(false) }
    var sharedText by remember { mutableStateOf("Название фильма") }
    var showTemplate by remember { mutableStateOf(false) }
    var showStyleHub by remember { mutableStateOf(false) }
    var showComposition by remember { mutableStateOf(false) }
    var showDesignerAssistant by remember { mutableStateOf(false) }
    var showFrontColorPicker by remember { mutableStateOf(false) }

    // Открытое окно настроек. shownTool помнит последнее, чтобы окно красиво уходило с экрана.
    var tool by remember { mutableStateOf<Tool?>(null) }
    var photoEditorLayerId by remember { mutableStateOf<String?>(null) }
    var shownTool by remember { mutableStateOf<Tool?>(null) }
    if (tool != null) shownTool = tool
    val hud = remember { SliderHud() }
    var barHeightPx by remember { mutableIntStateOf(0) }
    var show3d by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var confirmClose by remember { mutableStateOf(false) }
    var confirmResetBackground by remember { mutableStateOf(false) }
    var confirmHarmonizeCover by remember { mutableStateOf(false) }
    var showSeamCheck by remember { mutableStateOf(false) }
    var seamBusy by remember { mutableStateOf(false) }
    var seamResults by remember { mutableStateOf<List<CoverSeamFinding>?>(null) }
    val seamScope = rememberCoroutineScope()
    var pendingLayerDelete by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    var overviewZoomed by remember { mutableStateOf(false) }
    var overviewResetKey by remember { mutableIntStateOf(0) }
    val headerButtonSize = 44.dp

    // При смене выбранного объекта / вкладки окно закрывается
    LaunchedEffect(vm.selected, vm.sharedSelected, vm.panel, vm.overview) { tool = null }
    LaunchedEffect(vm.overview) { if (!vm.overview) overviewZoomed = false }
    fun navigateBack() {
        when {
            photoEditorLayerId != null -> photoEditorLayerId = null
            tool != null -> tool = null
            show3d -> show3d = false
            vm.selected != null || vm.multiSelected.isNotEmpty() || vm.sharedSelected != null -> {
                vm.selected = null
                vm.multiSelected = emptySet()
                vm.sharedSelected = null
                vm.clearGuides()
                Interactive.dragging = false
            }
            vm.overview && overviewZoomed -> overviewResetKey++
            vm.overview -> vm.returnToPanel()
            else -> confirmClose = true
        }
    }
    BackHandler(enabled = true) { navigateBack() }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addImage(uri, false)
    }
    val pickBg = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addImage(uri, true)
    }
    val pickUnifiedBg = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addUnifiedBackground(uri)
    }
    val pickUnifiedImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addUnifiedImage(uri)
    }
    val pickSharedImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.addSharedImage(uri)
    }

    // Выбранный слой и всё, что нужно окнам для его правки
    // Обзор — строго режим предварительного просмотра: никаких выбранных слоёв и LayerCtx.
    val shared = false
    val layer: Layer? = if (vm.overview) null else p.panel(vm.panel).layers.firstOrNull { it.id == vm.selected }
    val layerCtx: LayerCtx? = layer?.let { l ->
        if (shared) {
            val lay = p.format.layout()
            LayerCtx(l, lay.w, lay.h, false, true,
                { key, f -> vm.updateSharedLayer(l.id, "canvas-$key-${l.id}", f) },
                { sys, file, ital -> vm.applySharedFont(l.id, sys, file, ital) })
        } else {
            val (pw, ph) = p.format.size(vm.panel)
            LayerCtx(l, pw, ph, vm.panel == PanelId.SPINE, false,
                { key, f -> vm.updateLayer(l.id, "$key${l.id}", f) },
                { sys, file, ital -> vm.applyFont(l.id, sys, file, ital) })
        }
    }

    // Нижняя панель контекстная: выбран объект — его инструменты; ничего не выбрано — инструменты страницы.
    fun toolItem(t: Tool) = BarItem(t.label, t.ico, active = tool == t || (t == Tool.IMAGE_EDIT && photoEditorLayerId != null)) {
        if (t == Tool.IMAGE_EDIT) {
            photoEditorLayerId = layer?.id
            tool = null
        } else tool = if (tool == t) null else t
    }
    val items = ArrayList<BarItem?>()
    if (!vm.overview && layer != null) {
        layerTools(layer, shared).forEach { items += toolItem(it) }
        items += null
        if (!shared) {
            // Копирование и изменение порядка уже доступны в менеджере слоёв.
            // Здесь оставляем только удаление — это действие требует подтверждения.
            items += BarItem("Удалить", Ico.TRASH, danger = true) { pendingLayerDelete = false to layer.id }
        } else {
            // Для общих слоёв отдельного полноценного менеджера пока нет,
            // поэтому быстрые команды порядка остаются в контекстной панели.
            items += BarItem("Выше", Ico.UP) { vm.moveSharedLayerOrder(layer.id, 1) }
            items += BarItem("Ниже", Ico.DOWN) { vm.moveSharedLayerOrder(layer.id, -1) }
            items += BarItem("Удалить", Ico.TRASH, danger = true) { pendingLayerDelete = true to layer.id }
        }
        items += null
        items += BarItem("Готово", Ico.CHEVRON_DOWN) {
            tool = null
            if (shared) vm.sharedSelected = null else vm.selected = null
        }
    } else if (!vm.overview) {
        items += toolItem(Tool.ADD)
        items += toolItem(Tool.BG)
        if (!p.format.photo) items += BarItem("Оформление", Ico.WAND) { tool = null; showStyleHub = true }
    } else if (vm.overview && !p.format.photo) {
        items += BarItem("Фото на всю обложку", Ico.BG) { pickUnifiedBg.launch("image/*") }
    }

    val actions = SheetActions(
        onPhoto = { pickPhoto.launch("image/*") },
        onBgPhoto = { pickBg.launch("image/*") },
        onSharedPhoto = { pickSharedImage.launch("image/*") },
        onSharedText = { showSharedText = true },
        onUnifiedBg = { pickUnifiedBg.launch("image/*") },
        onUnifiedImage = { pickUnifiedImage.launch("image/*") },
        onPickFrontColor = { tool = null; showFrontColorPicker = true },
        onConfirmResetBackground = { confirmResetBackground = true },
        toggleGuides = { guides = !guides },
        close = { tool = null }
    )

    CompositionLocalProvider(LocalSliderHud provides hud) {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().widthIn(max = 1200.dp).align(Alignment.Center)) {
                // Верхняя панель: назад · название · отменить · повторить · меню.
                // Сохранение выполняется автоматически; ручная кнопка не занимает место.
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { navigateBack() }, modifier = Modifier.size(headerButtonSize)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = if (vm.overview) "Выйти из редактора" else "К обзору", tint = Color.White)
                    }
                    Column(Modifier.weight(1f).then(if (!vm.overview) Modifier.clickable { showRename = true } else Modifier).padding(horizontal = 4.dp, vertical = 2.dp)) {
                        Text(p.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                        Text(if (p.readOnly) "${p.format.title} · только чтение (проект из новой версии)" else p.format.title,
                            color = if (p.readOnly) Amber else Dim, fontSize = 10.sp, maxLines = 1)
                    }
                    if (!vm.overview) IconButton(
                        onClick = { vm.undoLast() }, enabled = vm.canUndo,
                        modifier = Modifier.size(headerButtonSize).semantics { contentDescription = "Отменить действие" }
                    ) { Text("↶", fontSize = 24.sp, color = if (vm.canUndo) Color.White else Line) }
                    if (!vm.overview) IconButton(
                        onClick = { vm.redoLast() }, enabled = vm.canRedo,
                        modifier = Modifier.size(headerButtonSize).semantics { contentDescription = "Повторить действие" }
                    ) { Text("↷", fontSize = 24.sp, color = if (vm.canRedo) Color.White else Line) }
                    if (!vm.overview) IconButton(
                        onClick = { tool = if (tool == Tool.LAYERS) null else Tool.LAYERS },
                        modifier = Modifier.size(headerButtonSize).semantics { contentDescription = "Слои" }
                    ) { ToolIcon(Ico.LAYERS, if (tool == Tool.LAYERS) Violet else Color.White, Modifier.size(23.dp)) }
                    Box {
                        IconButton(onClick = { showMenu = true }, modifier = Modifier.size(headerButtonSize)) { ToolIcon(Ico.MORE, Color.White, Modifier.size(24.dp)) }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            if (!vm.overview) DropdownMenuItem(text = { Text("Эффекты") }, onClick = { showMenu = false; tool = Tool.FX })
                            if (!vm.overview) DropdownMenuItem(text = { Text("Экспорт для печати") }, onClick = { showMenu = false; tool = null; showExport = true })
                            if (!vm.overview && !p.format.photo) DropdownMenuItem(text = { Text("Согласовать всю обложку") }, onClick = { showMenu = false; confirmHarmonizeCover = true })
                            if (!vm.overview && !p.format.photo) DropdownMenuItem(text = { Text("Проверить стыки панелей") }, onClick = {
                                showMenu = false; showSeamCheck = true; seamResults = null; seamBusy = true
                                seamScope.launch {
                                    seamResults = withContext(Dispatchers.Default) { CoverSeamChecker.analyze(p) }
                                    seamBusy = false
                                }
                            })
                            if (!vm.overview) DropdownMenuItem(text = { Text(if (guides) "Скрыть безопасную зону" else "Показать безопасную зону") },
                                onClick = { showMenu = false; guides = !guides })
                            if (vm.overview) DropdownMenuItem(text = { Text("3D-вид кейса") }, onClick = { showMenu = false; show3d = true })
                        }
                    }
                }

                // Переключатель частей обложки: все вкладки умещаются без прокрутки
                if (!p.format.photo) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp)
                            .clip(RoundedCornerShape(10.dp)).background(Card).padding(2.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        PanelId.values().forEach { id ->
                            val icon = when (id) {
                                PanelId.FRONT -> Ico.PHOTO
                                PanelId.SPINE -> Ico.GRID
                                PanelId.BACK -> Ico.BG
                                PanelId.DISC -> Ico.SHAPE
                            }
                            SegTab(id.title, icon, !vm.overview && vm.panel == id, Modifier.weight(1f)) {
                                tool = null
                                vm.switchPanel(id)
                            }
                        }
                        SegTab("Обзор", Ico.EYE, vm.overview, Modifier.weight(1f)) { tool = null; vm.showOverview() }
                    }
                }

                Box(
                    Modifier.weight(1f).fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 4.dp,
                        bottom = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (vm.overview && show3d) Case3DDialog(p) { show3d = false }
                    if (vm.overview) OverviewCanvas(p, overviewResetKey) { overviewZoomed = it } else PanelEditor(vm, p, guides)
                    SliderValueHud(hud, Modifier.align(Alignment.TopCenter))
                }

                if (!vm.overview || items.isNotEmpty()) Box(Modifier.onSizeChanged { barHeightPx = it.height }) { ToolBar(items) }
            }

            ToolSheetHost(
                visible = tool != null && !vm.overview,
                hidden = hud.count > 0 || vm.isLayerPreviewActive,
                title = shownTool?.label ?: "",
                bottomPad = with(density) { barHeightPx.toDp() },
                onClose = { tool = null }
            ) {
                val t = shownTool
                if (t != null) {
                    when (t) {
                        Tool.ADD, Tool.BG, Tool.LAYERS, Tool.FX -> GlobalSheet(t, vm, p, guides, actions)
                        else -> if (layerCtx != null) LayerSheet(t, vm, p, layerCtx)
                    }
                }
            }
            val photoEditorLayer = photoEditorLayerId?.let { id ->
                p.panel(vm.panel).layers.firstOrNull { it.id == id && it.kind == Kind.IMAGE }
            }
            if (photoEditorLayerId != null && photoEditorLayer == null) photoEditorLayerId = null
            if (photoEditorLayer != null) {
                val editorBackdrop = remember(p, vm.panel, photoEditorLayer) {
                    materializationBackdrop(p, vm.panel, photoEditorLayer)
                }
                PhotoEditorScreen(
                    layer = photoEditorLayer,
                    backdrop = editorBackdrop,
                    onClose = { photoEditorLayerId = null },
                    onApply = { croppedLayer ->
                        vm.updateLayer(photoEditorLayer.id, "photo-crop-${photoEditorLayer.id}") { croppedLayer }
                        photoEditorLayerId = null
                    }
                )
            }
        }
    }

    if (showStyleHub) AlertDialog(
        onDismissRequest = { showStyleHub = false },
        containerColor = Card,
        title = { Text("Оформление") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Инструменты оформления проекта собраны в одном месте. Выберите нужный режим.", color = Dim, fontSize = 13.sp)
                TextButton(onClick = { showStyleHub = false; showTemplate = true }) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Text("Шаблоны и стили", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Готовые варианты оформления", color = Dim, fontSize = 11.sp)
                    }
                }
                if (!vm.overview) TextButton(onClick = { showStyleHub = false; showComposition = true }) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Text("Умная композиция", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Автоматическая расстановка элементов", color = Dim, fontSize = 11.sp)
                    }
                }
                if (!vm.overview) TextButton(onClick = { showStyleHub = false; showDesignerAssistant = true }) {
                    Column(horizontalAlignment = Alignment.Start) {
                        Text("AI-помощник дизайнера", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Помощь с визуальным оформлением", color = Dim, fontSize = 11.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showStyleHub = false }) { Text("Закрыть") } }
    )
    if (showTemplate) TemplateDialog(vm, p) { showTemplate = false }
    if (showComposition) SmartCompositionDialog(vm, p) { showComposition = false }
    if (showDesignerAssistant) DesignerAssistantDialog(vm, p) { showDesignerAssistant = false }
    if (showFrontColorPicker) {
        FrontColorPickerDialog(p, onDismiss = { showFrontColorPicker = false }) { color ->
            vm.setPanelBackgroundColor(vm.panel, color)
            showFrontColorPicker = false
        }
    }

    if (showSharedText) {
        AlertDialog(
            onDismissRequest = { showSharedText = false },
            containerColor = Card,
            title = { Text("Текст на всю обложку") },
            text = { OutlinedTextField(sharedText, { sharedText = it }, label = { Text("Текст") }, colors = fieldColors()) },
            confirmButton = { TextButton(onClick = { vm.addSharedText(sharedText.ifBlank { "Текст" }); showSharedText = false }) { Text("Добавить") } },
            dismissButton = { TextButton(onClick = { showSharedText = false }) { Text("Отмена") } }
        )
    }

    if (showRename) {
        var name by remember { mutableStateOf(p.name) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            containerColor = Card,
            title = { Text("Название проекта") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, colors = fieldColors()) },
            confirmButton = { TextButton(onClick = { vm.rename(name); showRename = false }) { Text("Готово") } },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("Отмена", color = Dim) } }
        )
    }

    if (showSeamCheck) AlertDialog(
        onDismissRequest = { showSeamCheck = false },
        containerColor = Card,
        title = { Text("Проверка стыков обложки") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when {
                    seamBusy -> Text("Анализируем границы панелей…", color = Dim)
                    seamResults.isNullOrEmpty() -> Text("Смежных панелей для проверки не найдено.", color = Dim)
                    else -> seamResults!!.forEach { result ->
                        Column {
                            Text(result.title, fontWeight = FontWeight.SemiBold)
                            Text("Разница цвета: ${result.delta.toInt()} · различие текстуры: ${result.textureDelta.toInt()}", color = Dim, fontSize = 12.sp)
                            Text(if (result.ok) "Переход выглядит согласованным" else "Возможен заметный шов — проверьте вручную",
                                color = if (result.ok) Color(0xFF72C99A) else Color(0xFFFFB45E), fontSize = 12.sp)
                        }
                    }
                }
                Text("Проверка не изменяет изображения и слои.", color = Dim, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = { showSeamCheck = false }) { Text("Готово") } },
        dismissButton = { TextButton(enabled = !seamBusy, onClick = {
            seamResults = null; seamBusy = true
            seamScope.launch {
                seamResults = withContext(Dispatchers.Default) { CoverSeamChecker.analyze(vm.current ?: p) }
                seamBusy = false
            }
        }) { Text("Повторить") } }
    )

    if (confirmHarmonizeCover) AlertDialog(
        onDismissRequest = { confirmHarmonizeCover = false },
        containerColor = Card,
        title = { Text("Согласовать всю обложку?") },
        text = { Text("Цветовая схема лица будет согласована на всех панелях; типографика текста корешка будет приведена к основному стилю лица без изменения надписей и кегля. Элементы корешка центрируются, переход по его краям перестраивается. Пользовательские изображения, описания, эффекты и диск сохраняются. Действие можно отменить.", color = Dim) },
        confirmButton = {
            TextButton(onClick = {
                vm.harmonizeCoverBackgrounds()
                vm.showOverview()
                confirmHarmonizeCover = false
            }) { Text("Согласовать") }
        },
        dismissButton = { TextButton(onClick = { confirmHarmonizeCover = false }) { Text("Отмена", color = Dim) } }
    )
    if (confirmAutoFit) AlertDialog(
        onDismissRequest = { confirmAutoFit = false }, containerColor = Card,
        title = { Text("Автоматическая подгонка?") },
        text = { Text("Приложение автоматически заполнит стороны добавленными изображениями и аккуратно выровняет элементы. Текущие параметры могут измениться.", color = Dim) },
        confirmButton = { TextButton(onClick = { vm.autoFitAll(); confirmAutoFit = false }) { Text("Да, подогнать") } },
        dismissButton = { TextButton(onClick = { confirmAutoFit = false }) { Text("Отмена", color = Dim) } }
    )
    pendingLayerDelete?.let { (sharedLayer, layerId) ->
        AlertDialog(
            onDismissRequest = { pendingLayerDelete = null },
            containerColor = Card,
            title = { Text("Удалить объект?") },
            text = { Text("Объект будет удалён из проекта. Это действие можно отменить через «Отменить».", color = Dim) },
            confirmButton = {
                TextButton(onClick = {
                    if (sharedLayer) vm.removeSharedLayer(layerId) else if (vm.selected == layerId) vm.removeSelected()
                    pendingLayerDelete = null
                    tool = null
                }) { Text("Удалить", color = Color(0xFFFF8A8A)) }
            },
            dismissButton = { TextButton(onClick = { pendingLayerDelete = null }) { Text("Отмена", color = Dim) } }
        )
    }

    if (confirmResetBackground) AlertDialog(
        onDismissRequest = { confirmResetBackground = false },
        containerColor = Card,
        title = { Text("Сбросить фон?") },
        text = { Text("Текущий фон панели будет заменён стандартным. Изменение можно отменить.", color = Dim) },
        confirmButton = { TextButton(onClick = { vm.resetBackground(); confirmResetBackground = false; tool = null }) { Text("Сбросить", color = Color(0xFFFF8A8A)) } },
        dismissButton = { TextButton(onClick = { confirmResetBackground = false }) { Text("Отмена", color = Dim) } }
    )

    if (confirmClose) AlertDialog(
        onDismissRequest = { confirmClose = false },
        containerColor = Card,
        title = { Text("Закрыть редактор?") },
        text = { Text("Изменения сохраняются автоматически. Вы вернётесь к списку проектов.", color = Dim) },
        confirmButton = { TextButton(onClick = {
            if (vm.close()) confirmClose = false
            else Toast.makeText(ctx, "Не удалось сохранить проект. Проверьте свободное место и повторите.", Toast.LENGTH_LONG).show()
        }) { Text("Закрыть редактор") } },
        dismissButton = { TextButton(onClick = { confirmClose = false }) { Text("Остаться", color = Dim) } }
    )

    if (showExport) ExportDialog(vm, p) { showExport = false }
}

@Composable
private fun SegTab(text: String, icon: Ico, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.heightIn(min = 50.dp).clip(RoundedCornerShape(14.dp))
            .then(if (selected) Modifier.background(BrandBrush) else Modifier.background(Color.Transparent))
            .clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        ToolIcon(icon, if (selected) TextOnAccent else Dim, Modifier.size(18.dp))
        Text(text, color = if (selected) TextOnAccent else TextPrimary,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 10.sp, maxLines = 1, softWrap = false)
    }
}

/** Ползунки положения: объект можно двигать и пальцем по холсту, и точно — ползунками. */
@Composable
fun PositionSliders(
    x: Float, y: Float, wMm: Float, hMm: Float, spine: Boolean,
    onX: (Float) -> Unit, onY: (Float) -> Unit
) {
    // На корешке холст повёрнут: ось X панели идёт по экрану вверх, а Y — вправо.
    val h = if (spine) y else x
    val v = if (spine) 1f - x else y
    val hLen = if (spine) hMm else wMm
    val vLen = if (spine) wMm else hMm
    LabeledSlider("Влево ↔ вправо", h, 0f..1f, "${f1(h * hLen)} мм") { value ->
        if (spine) onY(value) else onX(value)
    }
    LabeledSlider("Вверх ↕ вниз", v, 0f..1f, "${f1(v * vLen)} мм") { value ->
        if (spine) onX(1f - value) else onY(value)
    }
}

/** Тень под текстом: повторяет контур букв. Сила и мягкость + быстрые варианты и «падающая» тень. */
@Composable
fun ShadowControls(l: Layer, vm: AppVm, onChange: (String, (Layer) -> Layer) -> Unit) {
    val presets = listOf(
        Triple("Нет", 0f, 0), Triple("Лёгкая", 0.45f, 1), Triple("Средняя", 0.6f, 2), Triple("Сильная", 0.75f, 3)
    )
    var manual by remember(l.id) { mutableStateOf(true) }
    PresetRow {
        presets.forEach { (name, shade, blur) ->
            val on = if (shade == 0f) l.textShade <= 0.001f else l.textBlur == blur && l.textShade > 0.001f
            val transform: (Layer) -> Layer = { it.copy(textShade = shade, textBlur = blur) }
            PreviewPill(name, on, vm, l.id, transform, { onChange("shade", transform) })
        }
        val dropTransform: (Layer) -> Layer = { it.copy(shadow = !it.shadow) }
        PreviewPill("Объёмная", l.shadow, vm, l.id, dropTransform, { onChange("drop", dropTransform) })
        Pill("Настроить", manual, { manual = !manual })
    }
    if (manual) {
        LabeledSlider("Интенсивность", l.textShade, 0f..0.85f, "${(l.textShade * 100).roundToInt()}%") { v ->
            onChange("shade-a") { it.copy(textShade = v.coerceIn(0f, 0.85f)) }
        }
        LabeledSlider("Размытие", l.textBlur.toFloat(), 0f..3f,
            listOf("Чёткая", "Мягкая", "Средняя", "Сильная")[l.textBlur.coerceIn(0, 3)]) { v ->
            onChange("shade-b") { it.copy(textBlur = v.roundToInt().coerceIn(0, 3)) }
        }
        LabeledSlider("Расстояние", l.textShadowDistance, 0f..0.5f, "${(l.textShadowDistance * 100).roundToInt()}%") { v ->
            onChange("shadow-distance") { it.copy(textShadowDistance = v) }
        }
        LabeledSlider("Угол", l.textShadowAngle, 0f..360f, "${l.textShadowAngle.roundToInt()}°") { v ->
            onChange("shadow-angle") { it.copy(textShadowAngle = v) }
        }
        LabeledSlider("Растяжение по ширине", l.textShadowScaleX, 0.25f..2f, "${(l.textShadowScaleX * 100).roundToInt()}%") { v ->
            onChange("shadow-x") { it.copy(textShadowScaleX = v) }
        }
        LabeledSlider("Растяжение по высоте", l.textShadowScaleY, 0.25f..2f, "${(l.textShadowScaleY * 100).roundToInt()}%") { v ->
            onChange("shadow-y") { it.copy(textShadowScaleY = v) }
        }
        LabeledSlider("Расширение силуэта", l.textShadowSpread, 0f..0.3f, "${(l.textShadowSpread * 100).roundToInt()}%") { v ->
            onChange("shadow-spread") { it.copy(textShadowSpread = v) }
        }
        Text("Цвет тени", color = Dim, fontSize = 11.sp)
        ColorRow(l.textShadowColor) { color ->
            onChange("shadow-color") { it.copy(textShadowColor = color) }
        }
    }
}

@Composable
fun ReflectionControls(l: Layer, onChange: (String, (Layer) -> Layer) -> Unit) {
    Pill("Отражение", l.reflectionOpacity > 0.001f, {
        onChange("reflection-toggle") { it.copy(reflectionOpacity = if (it.reflectionOpacity > 0.001f) 0f else 0.55f) }
    })
    LabeledSlider("Непрозрачность", l.reflectionOpacity, 0f..1f, "${(l.reflectionOpacity * 100).roundToInt()}%") { v ->
        onChange("reflection-opacity") { it.copy(reflectionOpacity = v) }
    }
    LabeledSlider("Отступ от объекта", l.reflectionDistance, 0f..0.5f, if (l.reflectionDistance <= 0.001f) "Вплотную" else "${(l.reflectionDistance * 100).roundToInt()}%") { v ->
        onChange("reflection-distance") { it.copy(reflectionDistance = v) }
    }
    LabeledSlider("Наклон поверхности (к себе / от себя)", l.reflectionAngle, -75f..75f, "${l.reflectionAngle.roundToInt()}°") { v ->
        onChange("reflection-angle") { it.copy(reflectionAngle = v) }
    }
    LabeledSlider("Длина отражения", l.reflectionScale, 0.1f..1.5f, "${(l.reflectionScale * 100).roundToInt()}%") { v ->
        onChange("reflection-scale") { it.copy(reflectionScale = v) }
    }
    LabeledSlider("Растяжение по ширине", l.reflectionScaleX, 0.1f..2f, "${(l.reflectionScaleX * 100).roundToInt()}%") { v ->
        onChange("reflection-scale-x") { it.copy(reflectionScaleX = v) }
    }
    LabeledSlider("Затухание", l.reflectionFade, 0f..1f, "${(l.reflectionFade * 100).roundToInt()}%") { v ->
        onChange("reflection-fade") { it.copy(reflectionFade = v) }
    }
    LabeledSlider("Размытие", l.reflectionBlur, 0f..0.25f, "${(l.reflectionBlur * 100).roundToInt()}%") { v ->
        onChange("reflection-blur") { it.copy(reflectionBlur = v) }
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Violet, unfocusedBorderColor = Line,
    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
    cursorColor = Violet
)

// ---------- Холст ----------

@Composable
fun PanelEditor(vm: AppVm, p: Project, guides: Boolean) {
    val (wMm, hMm) = p.format.size(vm.panel)
    val spine = vm.panel == PanelId.SPINE
    val dw = if (spine) hMm else wMm
    val dh = if (spine) wMm else hMm
    val aspect = dw / dh
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        var cw = maxWidth
        var ch = cw / aspect
        if (ch > maxHeight) {
            ch = maxHeight
            cw = ch * aspect
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          Box(
            Modifier.size(cw, ch).shadow(14.dp, RoundedCornerShape(2.dp)),
            contentAlignment = Alignment.Center
          ) {
            val innerW = if (spine) ch else cw
            val innerH = if (spine) cw else ch
            val m = Modifier.requiredSize(innerW, innerH)
                .then(if (spine) Modifier.graphicsLayer(rotationZ = -90f) else Modifier)
            PanelCanvas(
                project = p, panelId = vm.panel, wMm = wMm, hMm = hMm,
                selectedId = vm.selected, guides = guides,
                guideLines = vm.guideLines,
                gridMm = vm.gridMm,
                onSelect = { vm.selected = it },
                onTransform = { id, rx, ry, rr, zoom, w, snap, show -> vm.transform(id, rx, ry, rr, zoom, w, snap, show) },
                onGestureEnd = { vm.clearGuides() },
                modifier = m
            )
          }
        }
    }
}

private fun hitTest(pos: Offset, layers: List<Layer>, w: Float, h: Float, ppm: Float, pad: Float): String? {
    for (l in layers.asReversed()) {
        if (!l.visible) continue
        val (lw, lh) = layerSize(l, ppm)
        val dx = pos.x - l.x * w
        val dy = pos.y - l.y * h
        val r = Math.toRadians(-l.rot.toDouble())
        var lx = (dx * cos(r) - dy * sin(r)).toFloat()
        var ly = (dx * sin(r) + dy * cos(r)).toFloat()
        if (l.flipX) lx = -lx
        if (l.flipY) ly = -ly
        if (abs(lx) <= lw / 2 + pad && abs(ly) <= lh / 2 + pad && opaqueAt(l, lx, ly, lw, lh, pad)) return l.id
    }
    return null
}

/** У PNG-вырезки нажатие по прозрачному месту не попадает в слой (иначе он перекрывает текст и объекты под ним). */
private fun opaqueAt(l: Layer, lx: Float, ly: Float, lw: Float, lh: Float, pad: Float): Boolean {
    if (l.kind != Kind.IMAGE) return true
    val bmp = ImageProcessingPipeline.previewBitmap(l) ?: return true
    if (!bmp.hasAlpha() || !hasObjectTransparency(l.path)) return true
    val offs = floatArrayOf(-pad, 0f, pad)
    for (ox in offs) for (oy in offs) {
        val u = (lx + ox) / lw + 0.5f
        val v = (ly + oy) / lh + 0.5f
        if (u < 0f || u >= 1f || v < 0f || v >= 1f) continue
        val px = bmp.getPixel((u * bmp.width).toInt().coerceIn(0, bmp.width - 1), (v * bmp.height).toInt().coerceIn(0, bmp.height - 1))
        if ((px ushr 24) > 40) return true
    }
    return false
}

@Composable
fun PanelCanvas(
    project: Project,
    panelId: PanelId,
    wMm: Float,
    hMm: Float,
    selectedId: String?,
    guides: Boolean,
    onSelect: (String?) -> Unit,
    guideLines: List<GuideLine> = emptyList(),
    gridMm: Float = 0f,
    onTransform: (String, Float, Float, Float, Float, Float, Float, Float) -> Unit,
    onGestureEnd: () -> Unit = {},
    modifier: Modifier
) {
    val data = project.panel(panelId)
    val dataState by rememberUpdatedState(data)
    val selectCb by rememberUpdatedState(onSelect)
    val selectedState by rememberUpdatedState(selectedId)
    val transformCb by rememberUpdatedState(onTransform)
    val endCb by rememberUpdatedState(onGestureEnd)

    Canvas(
        modifier.pointerInput(wMm, hMm) {
            val pad = 18.dp.toPx()
            val snapPx = 6.dp.toPx()
            val showPx = 18.dp.toPx()
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val w = size.width.toFloat()
                val h = size.height.toFloat()
                val ppm = w / wMm
                val active = hitTest(down.position, dataState.layers, w, h, ppm, pad)
                if (active != null) selectCb(active)

                var pastSlop = false
                var multiTouch = false
                var rawX = 0f
                var rawY = 0f
                var started = false
                val slop = viewConfiguration.touchSlop
                do {
                    val event = awaitPointerEvent()
                    val canceled = event.changes.any { it.isConsumed }
                    val pressedCount = event.changes.count { it.pressed }
                    if (pressedCount >= 2) {
                        multiTouch = true
                        // На рабочих вкладках мультитач меняет только размер и положение
                        // уже выбранного слоя. Если слой не был выбран до начала жеста,
                        // два пальца не масштабируют ни слой, ни холст.
                        if (!canceled && active != null && selectedState == active) {
                            val points = event.changes.filter { it.pressed }
                            if (points.size >= 2) {
                                val a = points[0]
                                val b = points[1]
                                val oldDistance = (a.previousPosition - b.previousPosition).getDistance()
                                val newDistance = (a.position - b.position).getDistance()
                                val zoomChange = if (oldDistance > 0.5f && newDistance > 0.5f) newDistance / oldDistance else 1f
                                val oldCenter = (a.previousPosition + b.previousPosition) / 2f
                                val newCenter = (a.position + b.position) / 2f
                                val pan = newCenter - oldCenter
                                val layer = dataState.layers.firstOrNull { it.id == active }
                                if (layer != null && (zoomChange != 1f || pan != Offset.Zero)) {
                                    Interactive.dragging = true
                                    transformCb(
                                        active,
                                        layer.x + pan.x / w,
                                        layer.y + pan.y / h,
                                        layer.rot,
                                        zoomChange,
                                        w, snapPx, showPx
                                    )
                                }
                            }
                        }
                    }
                    if (!canceled && !multiTouch && pressedCount == 1) {
                        val change = event.changes.firstOrNull { it.pressed }
                        val delta = change?.let { it.position - it.previousPosition } ?: Offset.Zero
                        if (!pastSlop && delta != Offset.Zero) {
                            val total = change?.position?.minus(down.position) ?: Offset.Zero
                            if (total.getDistance() > slop) pastSlop = true
                        }
                        if (pastSlop && active != null) {
                            if (!started) {
                                val layer = dataState.layers.firstOrNull { it.id == active }
                                if (layer != null) {
                                    rawX = layer.x
                                    rawY = layer.y
                                    started = true
                                }
                            }
                            if (started && delta != Offset.Zero) {
                                Interactive.dragging = true
                                rawX += delta.x / w
                                rawY += delta.y / h
                                transformCb(active, rawX, rawY, dataState.layers.firstOrNull { it.id == active }?.rot ?: 0f, 1f, w, snapPx, showPx)
                            }
                        }
                        if (pastSlop) change?.consume()
                    }
                } while (event.changes.any { it.pressed })
                Interactive.dragging = false
                endCb()
                if (!pastSlop && !multiTouch && active == null) selectCb(null)
            }
        }
    ) {
        val ppm = size.width / wMm
        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            nc.save()
            nc.clipRect(0f, 0f, size.width, size.height)
            drawPanelWithFx(nc, project, panelId, 0, size.width, size.height, ppm)
            nc.restore()
        }
        if (panelId == PanelId.DISC) {
            // Затемняем всё вне печатного кольца и показываем контуры диска и отверстия.
            drawIntoCanvas { cv ->
                val nc = cv.nativeCanvas
                val cx = size.width / 2f
                val cy = size.height / 2f
                val ro = DISC_OUTER_MM * ppm / 2f
                val ri = DISC_INNER_MM * ppm / 2f
                val dim = android.graphics.Paint().apply { color = 0xCC000000.toInt() }
                val outside = android.graphics.Path().apply {
                    fillType = android.graphics.Path.FillType.EVEN_ODD
                    addRect(0f, 0f, size.width, size.height, android.graphics.Path.Direction.CW)
                    addCircle(cx, cy, ro, android.graphics.Path.Direction.CW)
                }
                nc.drawPath(outside, dim)
                nc.drawCircle(cx, cy, ri, dim)
                val line = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    style = android.graphics.Paint.Style.STROKE
                    color = 0xE6FFFFFF.toInt()
                    strokeWidth = 2f
                }
                nc.drawCircle(cx, cy, ro, line)
                nc.drawCircle(cx, cy, ri, line)
            }
        }
        if (gridMm > 0.01f && panelId != PanelId.DISC) {
            val stepX = gridMm * size.width / wMm
            val stepY = gridMm * size.height / hMm
            val gridPaint = Color.White.copy(alpha = 0.13f)
            var gx = stepX
            while (gx < size.width) { drawLine(gridPaint, Offset(gx, 0f), Offset(gx, size.height), 0.5.dp.toPx()); gx += stepX }
            var gy = stepY
            while (gy < size.height) { drawLine(gridPaint, Offset(0f, gy), Offset(size.width, gy), 0.5.dp.toPx()); gy += stepY }
        }
        if (guides) {
            if (panelId == PanelId.DISC) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.45f),
                    radius = (DISC_OUTER_MM / 2f - 3f) * ppm,
                    center = Offset(size.width / 2f, size.height / 2f),
                    style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
                )
            } else {
                val inset = minOf(3f * ppm, size.width * 0.15f)
                drawRect(
                    color = Color.White.copy(alpha = 0.45f),
                    topLeft = Offset(inset, inset),
                    size = Size(size.width - inset * 2, size.height - inset * 2),
                    style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
                )
            }
        }
        val sel = data.layers.firstOrNull { it.id == selectedId }
        if (sel != null) {
            val (lw, lh) = layerSize(sel, ppm)
            val outline = if (sel.kind == Kind.IMAGE) ImageProcessingPipeline.previewBitmap(sel)?.let { bm ->
                val crop = ImageProcessingPipeline.cropFractions(sel)
                ObjectOutline.get(bm, crop.left, crop.top, crop.right, crop.bottom)
            } else null
            withTransform({
                translate(sel.x * size.width, sel.y * size.height)
                rotate(sel.rot, Offset.Zero)
                scale(if (sel.flipX) -1f else 1f, if (sel.flipY) -1f else 1f, Offset.Zero)
            }) {
              if (outline != null) {
                // PNG-вырезка: выделение идёт по контуру объекта (тем же пунктиром, что и у остальных объектов).
                val path = android.graphics.Path()
                for (poly in outline) {
                    var i = 0
                    while (i < poly.size) {
                        val px = poly[i] * lw; val py = poly[i + 1] * lh
                        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                        i += 2
                    }
                }
                clipRect(-lw / 2f, -lh / 2f, lw / 2f, lh / 2f) {
                    drawPath(
                        path = path.asComposePath(),
                        color = Amber,
                        style = Stroke(
                            1.5.dp.toPx(), cap = StrokeCap.Butt, join = StrokeJoin.Round,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
                        )
                    )
                }
              } else {
                drawRect(
                    color = Amber,
                    topLeft = Offset(-lw / 2, -lh / 2),
                    size = Size(lw, lh),
                    style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
                )
                for (cx in listOf(-lw / 2, lw / 2)) for (cy in listOf(-lh / 2, lh / 2)) {
                    drawCircle(Amber, 4.dp.toPx(), Offset(cx, cy))
                }
              }
            }
        }
        // Умные направляющие: белые — объект рядом, зелёные — края/центры совпали идеально
        if (guideLines.isNotEmpty()) {
            val green = Color(0xFF22E06B)
            // сначала белые, потом зелёные — зелёные всегда сверху
            for (g in guideLines.sortedBy { it.exact }) {
                val a: Offset
                val b: Offset
                if (g.vertical) {
                    a = Offset(g.pos * ppm, (g.from * ppm).coerceAtLeast(0f)); b = Offset(g.pos * ppm, (g.to * ppm).coerceAtMost(size.height))
                } else {
                    a = Offset((g.from * ppm).coerceAtLeast(0f), g.pos * ppm); b = Offset((g.to * ppm).coerceAtMost(size.width), g.pos * ppm)
                }
                val main = if (g.exact) green else Color.White
                val wd = (if (g.exact) 1.5.dp else 1.dp).toPx()
                drawLine(Color.Black.copy(alpha = 0.35f), a, b, strokeWidth = wd + 1.5.dp.toPx())
                drawLine(main, a, b, strokeWidth = wd)
                if (g.exact) {
                    val r = 2.5.dp.toPx()
                    drawCircle(green, r, a); drawCircle(green, r, b)
                }
            }
        }
    }
}

@Composable
fun OverviewCanvas(p: Project, resetKey: Int = 0, onZoomedChange: (Boolean) -> Unit = {}) {
    // Только предварительный просмотр всей развёртки. Жесты меняют исключительно
    // масштаб и положение камеры; касания никогда не выбирают и не двигают объекты.
    val lay = p.format.layout()
    val aspect = lay.w / lay.h
    var scale by remember(p.id) { mutableStateOf(1f) }
    var pan by remember(p.id) { mutableStateOf(Offset.Zero) }
    LaunchedEffect(resetKey) { scale = 1f; pan = Offset.Zero }
    LaunchedEffect(scale > 1.001f) { onZoomedChange(scale > 1.001f) }
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        var cw = maxWidth
        var ch = cw / aspect
        if (ch > maxHeight) { ch = maxHeight; cw = ch * aspect }
        val boxW = constraints.maxWidth.toFloat()
        val boxH = constraints.maxHeight.toFloat()
        val cwPx = with(androidx.compose.ui.platform.LocalDensity.current) { cw.toPx() }
        val chPx = with(androidx.compose.ui.platform.LocalDensity.current) { ch.toPx() }
        fun clampPan(pn: Offset, sc: Float): Offset {
            val mx = (cwPx * sc - boxW).coerceAtLeast(0f) / 2f + cwPx * 0.15f
            val my = (chPx * sc - boxH).coerceAtLeast(0f) / 2f + chPx * 0.15f
            return Offset(pn.x.coerceIn(-mx, mx), pn.y.coerceIn(-my, my))
        }
        Box(
            Modifier.fillMaxSize().pointerInput(p.id, lay) {
                detectTransformGestures { centroid, panChange, zoomChange, _ ->
                    val nextScale = (scale * zoomChange).coerceIn(1f, 5f)
                    if (nextScale <= 1.001f) {
                        scale = 1f
                        pan = Offset.Zero
                    } else {
                        val center = Offset(centroid.x - boxW / 2f, centroid.y - boxH / 2f)
                        val factor = nextScale / scale
                        pan = clampPan(center - (center - pan) * factor + panChange, nextScale)
                        scale = nextScale
                    }
                }
            },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(cw, ch).graphicsLayer {
                scaleX = scale; scaleY = scale; translationX = pan.x; translationY = pan.y
            }.shadow(14.dp, RoundedCornerShape(2.dp)).background(Color.White)) {
                val ppm = size.width / lay.w
                drawIntoCanvas { cv -> drawPlaces(cv.nativeCanvas, p, lay.places, 0f, 0f, ppm, false) }
            }
            Row(
                Modifier.align(Alignment.TopEnd).padding(6.dp)
                    .clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("−", color = Color.White, fontSize = 22.sp,
                    modifier = Modifier.clickable { scale = (scale / 1.2f).coerceAtLeast(1f); pan = clampPan(pan, scale); if (scale == 1f) pan = Offset.Zero }.padding(horizontal = 12.dp, vertical = 6.dp))
                Text("${(scale * 100).roundToInt()}%", color = Color.White, fontSize = 11.sp,
                    modifier = Modifier.clickable { scale = 1f; pan = Offset.Zero }.padding(horizontal = 5.dp, vertical = 8.dp))
                Text("+", color = Color.White, fontSize = 22.sp,
                    modifier = Modifier.clickable { scale = (scale * 1.2f).coerceAtMost(5f); pan = clampPan(pan, scale) }.padding(horizontal = 12.dp, vertical = 6.dp))
            }
        }
    }
}

// ---------- Инструменты ----------

@Composable
fun FrontColorPickerDialog(
    project: Project,
    onDismiss: () -> Unit,
    onColorPicked: (Int) -> Unit
) {
    val (frontW, frontH) = project.format.size(PanelId.FRONT)
    val preview = remember(project) {
        val width = 480
        val height = (width * frontH / frontW).toInt().coerceAtLeast(1)
        android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888).also { bmp ->
            drawPanel(android.graphics.Canvas(bmp), project.panel(PanelId.FRONT), width.toFloat(), height.toFloat(), width / frontW)
        }.asImageBitmap()
    }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Пипетка с лицевой стороны", fontWeight = FontWeight.Bold)
            Text("Коснитесь нужного места на изображении, чтобы взять его цвет.", color = Dim, fontSize = 12.sp)
            Image(
                bitmap = preview,
                contentDescription = "Лицевая сторона — выбор цвета",
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxWidth().aspectRatio(frontW / frontH)
                    .clip(RoundedCornerShape(8.dp))
                    .pointerInput(preview) {
                        detectTapGestures { point ->
                            val x = (point.x / size.width * preview.width).toInt().coerceIn(0, preview.width - 1)
                            val y = (point.y / size.height * preview.height).toInt().coerceIn(0, preview.height - 1)
                            onColorPicked(preview.asAndroidBitmap().getPixel(x, y))
                        }
                    }
            )
            TextButton(onClick = onDismiss) { Text("Отмена", color = Dim) }
        }
    }
}

// ---------- Экспорт ----------

@Composable
fun ExportDialog(vm: AppVm, p: Project, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pdf by remember { mutableStateOf(false) }
    var a4 by remember { mutableStateOf(false) }
    var marks by remember { mutableStateOf(true) }
    var disc by remember { mutableStateOf(vm.panel == PanelId.DISC) }
    var busy by remember { mutableStateOf(false) }
    var exportJob by remember { mutableStateOf<Job?>(null) }

    fun save(uri: android.net.Uri, asPdf: Boolean) {
        val proj = vm.current ?: return
        exportJob = scope.launch {
            busy = true
            var ok = false
            try {
                ok = withContext(Dispatchers.IO) {
                    runInterruptible {
                        runCatching {
                            ctx.contentResolver.openOutputStream(uri)!!.use { os ->
                                if (asPdf) Exporter.writePdf(proj, a4, marks, os, disc) else Exporter.writePng(proj, a4, marks, os, disc)
                            }
                        }.isSuccess
                    }
                }
            } finally {
                busy = false
                exportJob = null
            }
            if (ok) {
                Toast.makeText(ctx, "Сохранено", Toast.LENGTH_SHORT).show()
                onDismiss()
            } else {
                Toast.makeText(ctx, "Не удалось сохранить файл. Проверьте разрешение на запись и свободное место.", Toast.LENGTH_LONG).show()
            }
        }
    }

    val savePng = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) save(uri, false)
    }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) save(uri, true)
    }

    val (sw, sh) = sheetSizeMm(p, a4, marks, disc)

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        containerColor = Card,
        title = { Text("Экспорт для печати") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionLabel("Что печатать")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(if (p.format.photo) "Фото" else "Обложка", !disc, { disc = false })
                    if (!p.format.photo) Pill("Диск", disc, { disc = true })
                }
                SectionLabel("Формат файла")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("PNG · 300 dpi", !pdf, { pdf = false })
                    Pill("PDF", pdf, { pdf = true })
                }
                SectionLabel("Лист")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Точный размер", !a4, { a4 = false })
                    Pill("A4", a4, { a4 = true })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (disc) "Метки реза" else "Метки реза и сгиба", Modifier.weight(1f))
                    Switch(
                        checked = marks, onCheckedChange = { marks = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = Violet)
                    )
                }
                Text("Размер листа: ${fmt(sw)}×${fmt(sh)} мм. Печатайте в масштабе 100%.", color = Dim, fontSize = 12.sp)
                if (busy) {
                    androidx.compose.material3.LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text("Формируем изображение высокого разрешения…", color = Amber, fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            Row {
                TextButton(enabled = !busy, onClick = {
                    val proj = vm.current ?: return@TextButton
                    exportJob = scope.launch {
                        busy = true
                        var f: File? = null
                        try {
                            f = withContext(Dispatchers.IO) {
                                runInterruptible { runCatching { Exporter.cacheFile(ctx, proj, pdf, a4, marks, disc) }.getOrNull() }
                            }
                        } finally {
                            busy = false
                            exportJob = null
                        }
                        if (f == null) {
                            Toast.makeText(ctx, "Не удалось подготовить файл для отправки. Проверьте свободное место и повторите попытку.", Toast.LENGTH_LONG).show()
                        } else {
                            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f!!)
                            val i = Intent(Intent.ACTION_SEND)
                                .setType(if (pdf) "application/pdf" else "image/png")
                                .putExtra(Intent.EXTRA_STREAM, uri)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            ctx.startActivity(Intent.createChooser(i, "Поделиться"))
                        }
                    }
                }) { Text("Поделиться") }
                TextButton(enabled = !busy, onClick = {
                    val n = Exporter.safeName(p.name) + if (disc) "-диск" else ""
                    if (pdf) savePdf.launch("$n.pdf") else savePng.launch("$n.png")
                }) { Text("Сохранить", fontWeight = FontWeight.Bold) }
            }
        },
        dismissButton = {
            if (busy) TextButton(onClick = { exportJob?.cancel() }) { Text("Отменить", color = Color(0xFFFF8A8A)) }
            else TextButton(onClick = onDismiss) { Text("Закрыть", color = Dim) }
        }
    )
}

/** Поиск шрифта по надписи, которая уже нарисована на картинке (слои текста при этом скрыты). */
@Composable
fun FontFinderDialog(vm: AppVm, p: Project, layer: Layer, onDismiss: () -> Unit) {
    val srcId = PanelId.FRONT   // шрифт всегда ищем на картинке лицевой стороны
    val (pw, ph) = p.format.size(srcId)
    val bmp = remember(srcId) {
        val ppm = 1400f / max(pw, ph)
        val bw = (pw * ppm).toInt().coerceAtLeast(1)
        val bh = (ph * ppm).toInt().coerceAtLeast(1)
        val b = android.graphics.Bitmap.createBitmap(bw, bh, android.graphics.Bitmap.Config.ARGB_8888)
        val pd = p.panel(srcId)
        drawPanel(android.graphics.Canvas(b),
            pd.copy(layers = pd.layers.filter { it.kind == Kind.IMAGE || it.kind == Kind.RECT }),
            bw.toFloat(), bh.toFloat(), ppm)
        b
    }
    val img = remember(bmp) { bmp.asImageBitmap() }
    var p1 by remember { mutableStateOf<Offset?>(null) }
    var p2 by remember { mutableStateOf<Offset?>(null) }
    var committed by remember { mutableStateOf(false) }
    var invert by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf(layer.text.replace("\n", " ")) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var results by remember { mutableStateOf<List<FontMatch.Result>>(emptyList()) }
    val scope = rememberCoroutineScope()
    val ink = remember(committed, p1, p2, invert) {
        val a = p1
        val b = p2
        if (!committed || a == null || b == null) null
        else runCatching { FontMatch.extractInk(bmp, a.x, a.y, b.x, b.y, invert) }.getOrNull()
    }
    val maskImg = remember(ink) { ink?.toBitmap()?.asImageBitmap() }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Card).padding(14.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Найти шрифт по картинке", fontWeight = FontWeight.Bold)
            Text("Картинка берётся с лицевой стороны. Обведите пальцем надпись, которая уже есть на ней (слои текста скрыты), и впишите, что на ней написано.", color = Dim, fontSize = 12.sp)
            Box(
                Modifier.fillMaxWidth().aspectRatio(bmp.width.toFloat() / bmp.height)
                    .clip(RoundedCornerShape(8.dp))
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { o ->
                                val s = Offset((o.x / size.width).coerceIn(0f, 1f), (o.y / size.height).coerceIn(0f, 1f))
                                p1 = s; p2 = s; committed = false; results = emptyList()
                            },
                            onDrag = { ch, _ ->
                                ch.consume()
                                p2 = Offset((ch.position.x / size.width).coerceIn(0f, 1f), (ch.position.y / size.height).coerceIn(0f, 1f))
                            },
                            onDragEnd = { committed = true },
                            onDragCancel = { committed = true }
                        )
                    }
            ) {
                Image(bitmap = img, contentDescription = null, contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
                Canvas(Modifier.fillMaxSize()) {
                    val a = p1
                    val b = p2
                    if (a != null && b != null) {
                        val tl = Offset(minOf(a.x, b.x) * size.width, minOf(a.y, b.y) * size.height)
                        val sz = Size(abs(a.x - b.x) * size.width, abs(a.y - b.y) * size.height)
                        drawRect(Amber.copy(alpha = 0.15f), tl, sz)
                        drawRect(Amber, tl, sz, style = Stroke(2.dp.toPx()))
                    }
                }
            }
            OutlinedTextField(
                value = text, onValueChange = { text = it; results = emptyList() },
                modifier = Modifier.fillMaxWidth(), colors = fieldColors(),
                label = { Text("Что написано на картинке", color = Dim) }
            )
            if (committed) {
                if (maskImg != null) {
                    Text("Так приложение видит буквы:", color = Dim, fontSize = 11.sp)
                    Image(bitmap = maskImg, contentDescription = null, contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 64.dp).clip(RoundedCornerShape(6.dp)).background(Color.White).padding(4.dp))
                } else {
                    Text("Область слишком мала или без текста — выделите надпись заново.", color = Dim, fontSize = 12.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Pill("Инвертировать", invert, { invert = !invert; results = emptyList() })
                Pill(
                    if (progress != null) "Поиск… ${((progress ?: 0f) * 100).toInt()}%" else "Найти шрифт", true,
                    {
                        val t = ink
                        if (t != null && progress == null && text.isNotBlank()) {
                            scope.launch {
                                progress = 0f
                                results = withContext(Dispatchers.Default) { FontMatch.find(t, text) { progress = it } }
                                progress = null
                            }
                        }
                    }
                )
            }
            results.forEach { r ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Card2)
                        .clickable {
                            vm.applyFont(layer.id, r.entry.sys, r.entry.file, r.italic)
                            onDismiss()
                        }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(r.entry.name + if (r.italic) " · курсив" else "", color = Dim, fontSize = 11.sp)
                        Text(
                            text.trim().take(30),
                            fontFamily = androidx.compose.ui.text.font.FontFamily(Fonts.get(r.entry.sys, r.entry.file, r.italic)),
                            fontSize = 20.sp, color = Color.White, maxLines = 1
                        )
                    }
                    Text("${r.percent}%", color = Amber, fontWeight = FontWeight.Bold)
                }
            }
            if (results.isNotEmpty()) Text("Нажмите на вариант, чтобы применить шрифт к тексту.", color = Dim, fontSize = 11.sp)
            TextButton(onClick = onDismiss) { Text("Закрыть", color = Dim) }
        }
    }
}
