package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.AtomicFile
import androidx.exifinterface.media.ExifInterface
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.math.max

/**
 * Ссылки на ресурсы в JSON проекта хранятся относительно каталога `img` (`img:<имя>`), в памяти —
 * абсолютные пути. Старые абсолютные пути читаются как есть; если каталог данных переехал,
 * путь вида `.../img/<имя>` переназначается на текущий `img`, когда файл там найден.
 */
object ResourcePaths {
    @Volatile var imgRoot: String = ""
    private const val PREFIX = "img:"

    fun toStored(path: String): String {
        if (path.isBlank() || imgRoot.isBlank()) return path
        val file = File(path)
        return if (file.parentFile?.path == imgRoot) PREFIX + file.name else path
    }

    fun fromStored(stored: String): String {
        if (stored.isBlank() || imgRoot.isBlank()) return stored
        if (stored.startsWith(PREFIX)) return File(imgRoot, stored.removePrefix(PREFIX)).path
        val file = File(stored)
        if (!file.exists() && file.parentFile?.name == "img") {
            val moved = File(imgRoot, file.name)
            if (moved.exists()) return moved.path
        }
        return stored
    }
}

class Store(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "projects").apply { mkdirs() }
    private val imgDir = File(ctx.filesDir, "img").apply { mkdirs() }

    init { ResourcePaths.imgRoot = imgDir.absolutePath }
    private val maxImportSide = 4096
    private val maxImportPixels = 10_000_000L

    @Synchronized
    fun loadAll(): List<Project> =
        projectBaseFiles(dir.listFiles() ?: emptyArray())
            .mapNotNull { file ->
                // Include orphaned .json.bak entries: AtomicFile can restore them only
                // when openRead() is called with the base .json path.
                runCatching {
                    AtomicFile(file).openRead().bufferedReader().use { reader ->
                        Project.fromJson(JSONObject(reader.readText()))
                    }
                }.getOrNull()
            }
            .sortedByDescending { it.updated }

    /** Maps both AtomicFile base files and orphaned backups to one base path per project. */
    private fun projectBaseFiles(entries: Array<File>): List<File> {
        val bases = LinkedHashMap<String, File>()
        entries.filter { it.isFile }.forEach { entry ->
            val base = when {
                entry.name.endsWith(".json.bak") -> File(entry.parentFile, entry.name.removeSuffix(".bak"))
                entry.name.endsWith(".json") -> entry
                else -> null
            } ?: return@forEach
            bases.putIfAbsent(base.absolutePath, base)
        }
        return bases.values.toList()
    }

    /** Атомарное сохранение: при сбое записи остаётся предыдущая целая версия проекта. */
    @Synchronized
    fun save(p: Project): Boolean = runCatching {
        val atomic = AtomicFile(File(dir, "${p.id}.json"))
        val stream = atomic.startWrite()
        try {
            val writer = stream.writer(Charsets.UTF_8)
            writer.write(p.toJson().toString())
            writer.flush()
            atomic.finishWrite(stream)
        } catch (t: Throwable) {
            atomic.failWrite(stream)
            throw t
        }
        true
    }.getOrDefault(false)

    /**
     * Deletes a project and then removes unreferenced image resources.
     * If any remaining project file cannot be parsed, cleanup is skipped: its
     * image references are unknown and deleting files could corrupt that project.
     */
    @Synchronized
    fun delete(p: Project, extraUsed: Set<String> = emptySet()) {
        val projectFile = File(dir, "${p.id}.json")
        val backupFile = File(projectFile.path + ".bak")
        if (projectFile.exists() || backupFile.exists()) {
            // Delete even when only .bak remains; otherwise loadAll() could restore
            // a project the user explicitly deleted, or cleanup could miss its refs.
            val deleted = runCatching {
                AtomicFile(projectFile).delete()
                !projectFile.exists() && !backupFile.exists()
            }.getOrDefault(false)
            if (!deleted) return
        }
        cleanupUnreferencedImages(extraUsed)
    }

    /**
     * Удаляет только производные файлы операций (`derived-*`, `mask-*`), на которые не ссылается
     * ни один сохранённый проект и ни один путь из [extraUsed] (текущий проект и его Undo/Redo
     * в памяти). Файлы моложе [minAgeMs] не трогаются: их может создавать незавершённая операция.
     * Оригиналы и рабочие исходники не затрагиваются. При любой ошибке чтения проекта ничего не удаляется.
     */
    @Synchronized
    fun pruneDerived(extraUsed: Set<String>, minAgeMs: Long = 30 * 60_000L): Int {
        val used = referencedImages(extraUsed) ?: return 0
        val imageRoot = runCatching { imgDir.canonicalPath }.getOrNull() ?: return 0
        val now = System.currentTimeMillis()
        var removed = 0
        (imgDir.listFiles() ?: return 0).forEach { candidate ->
            val name = candidate.name
            if (!candidate.isFile || !(name.startsWith("derived-") || name.startsWith("mask-"))) return@forEach
            if (now - candidate.lastModified() < minAgeMs) return@forEach
            val canonical = runCatching { candidate.canonicalPath }.getOrNull() ?: return@forEach
            if (File(canonical).parent == imageRoot && canonical !in used && candidate.delete()) removed++
        }
        return removed
    }

    /** Канонические пути всех ресурсов, на которые ссылаются сохранённые проекты и [extraUsed]; null — если проект не прочитан. */
    private fun referencedImages(extraUsed: Set<String>): Set<String>? {
        val entries = dir.listFiles() ?: return null
        val used = mutableSetOf<String>()
        for (file in projectBaseFiles(entries)) {
            val project = runCatching {
                AtomicFile(file).openRead().bufferedReader().use { reader ->
                    Project.fromJson(JSONObject(reader.readText()))
                }
            }.getOrNull() ?: return null
            project.imagePaths().forEach { path -> runCatching { File(path).canonicalPath }.getOrNull()?.let(used::add) }
        }
        extraUsed.forEach { path -> runCatching { File(path).canonicalPath }.getOrNull()?.let(used::add) }
        return used
    }

    /** Conservative reference scan across every persisted project, including files
     * that loadAll() would otherwise omit after a parse error. */
    @Synchronized
    private fun cleanupUnreferencedImages(extraUsed: Set<String> = emptySet()): Boolean {
        val used = referencedImages(extraUsed) ?: return false

        val imageRoot = runCatching { imgDir.canonicalPath }.getOrNull() ?: return false
        (imgDir.listFiles() ?: return false).forEach { candidate ->
            val canonical = runCatching { candidate.canonicalPath }.getOrNull() ?: return@forEach
            if (File(canonical).parent == imageRoot && canonical !in used && candidate.isFile) {
                candidate.delete()
            }
        }
        return true
    }

    /** Атомарно сохраняет производный bitmap: неполный файл никогда не возвращается как resultPath. */
    fun saveBitmap(bmp: Bitmap, png: Boolean = false, prefix: String = ""): String? {
        val extension = if (png) ".png" else ".jpg"
        val target = File(imgDir, prefix + UUID.randomUUID().toString() + extension)
        val temp = File(imgDir, target.name + ".tmp")
        return try {
            FileOutputStream(temp).use { stream ->
                if (!bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, stream)) {
                    throw IllegalStateException("Не удалось закодировать изображение")
                }
                stream.flush()
                stream.fd.sync()
            }
            if (!temp.renameTo(target)) throw IllegalStateException("Не удалось атомарно сохранить изображение")
            target.absolutePath
        } catch (_: Throwable) {
            temp.delete()
            target.delete()
            null
        }
    }

    /** Загружает изображение для проверки: bitmap (до 4096 px по длинной стороне) и реальные размеры в пикселях. */
    fun decodeForCheck(uri: Uri): CheckImage? = runCatching {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        val sample = decodeSample(bounds.outWidth, bounds.outHeight)
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
        bmp = limitImportSize(bmp)
        var tw = bounds.outWidth
        var th = bounds.outHeight
        val orientation = readExifOrientation(cr, uri)
        bmp = applyExifOrientation(bmp, orientation)
        if (swapsExifDimensions(orientation)) { val t = tw; tw = th; th = t }
        CheckImage(bmp, tw, th)
    }.getOrNull()

    /** Копирует исходный файл побайтно. Этот файл никогда не используется как рабочий bitmap и не перезаписывается. */
    fun importOriginal(uri: Uri): String? = runCatching {
        val mime = ctx.contentResolver.getType(uri).orEmpty().lowercase()
        val ext = when {
            mime.contains("png") -> ".png"
            mime.contains("webp") -> ".webp"
            mime.contains("heic") || mime.contains("heif") -> ".heic"
            mime.contains("jpeg") || mime.contains("jpg") -> ".jpg"
            else -> ".source"
        }
        val target = File(imgDir, "original-" + UUID.randomUUID() + ext)
        val temp = File(imgDir, target.name + ".tmp")
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { input ->
                temp.outputStream().buffered().use { output -> input.copyTo(output, 1 shl 16) }
            }
            if (!temp.renameTo(target)) throw IllegalStateException("Не удалось сохранить оригинал")
            target.absolutePath
        } catch (t: Throwable) {
            temp.delete()
            throw t
        }
    }.getOrNull()

    fun importImage(uri: Uri): String? = runCatching {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        val sample = decodeSample(bounds.outWidth, bounds.outHeight)
        val orientation = readExifOrientation(cr, uri)
        val type = cr.getType(uri) ?: bounds.outMimeType.orEmpty()
        val isJpeg = type.contains("jpeg", ignoreCase = true) || type.contains("jpg", ignoreCase = true)
        // Не перекодируем обычный JPEG: сохраняем исходные байты и качество без потерь поколения.
        if (isJpeg && orientation == ExifInterface.ORIENTATION_NORMAL &&
            max(bounds.outWidth, bounds.outHeight) <= maxImportSide) {
            val target = File(imgDir, UUID.randomUUID().toString() + ".jpg")
            val temp = File(imgDir, target.name + ".tmp")
            try {
                cr.openInputStream(uri)!!.use { input -> temp.outputStream().use { output -> input.copyTo(output, 1 shl 16) } }
            } catch (t: Throwable) {
                temp.delete()
                throw t
            }
            if (!temp.renameTo(target)) {
                temp.delete()
                throw IllegalStateException("Не удалось сохранить исходное изображение")
            }
            return@runCatching target.absolutePath
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
        try {
            bmp = limitImportSize(bmp)
            bmp = applyExifOrientation(bmp, orientation)
            val png = type.contains("png", ignoreCase = true) || type.contains("webp", ignoreCase = true) ||
                bounds.outMimeType?.contains("png", ignoreCase = true) == true || bmp.hasAlpha()
            val f = File(imgDir, UUID.randomUUID().toString() + if (png) ".png" else ".jpg")
            f.outputStream().use {
                bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it)
            }
            f.absolutePath
        } finally {
            if (!bmp.isRecycled) bmp.recycle()
        }
    }.getOrNull()

    /** Keep decode memory bounded while retaining as many source pixels as possible. */
    private fun decodeSample(width: Int, height: Int): Int {
        var sample = 1
        while (width > 0 && height > 0 &&
            (width / sample).toLong() * (height / sample) > maxImportPixels) sample *= 2
        return sample
    }

    private fun readExifOrientation(cr: android.content.ContentResolver, uri: Uri): Int = runCatching {
        cr.openInputStream(uri)!!.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }
    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

    private fun swapsExifDimensions(orientation: Int): Boolean = orientation == ExifInterface.ORIENTATION_TRANSPOSE ||
        orientation == ExifInterface.ORIENTATION_ROTATE_90 || orientation == ExifInterface.ORIENTATION_TRANSVERSE ||
        orientation == ExifInterface.ORIENTATION_ROTATE_270

    /** Applies all eight EXIF orientations, including mirrored camera images. */
    private fun applyExifOrientation(source: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(270f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(270f)
            else -> return source
        }
        val result = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        if (result !== source) source.recycle()
        return result
    }

    /** Decode near the target size, then resample once to the exact supported long-side limit. */
    private fun limitImportSize(source: Bitmap): Bitmap {
        val longest = max(source.width, source.height)
        if (longest <= maxImportSide) return source
        val scale = maxImportSide.toFloat() / longest
        val result = Bitmap.createScaledBitmap(
            source,
            (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1),
            true
        )
        if (result !== source) source.recycle()
        return result
    }

}
