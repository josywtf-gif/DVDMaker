package com.dvdmaker.app

import android.app.Application
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import java.io.File
import org.json.JSONObject
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

private class SpineRes(val path: String, val c1: Int, val c2: Int, val widthMm: Float)

class AppVm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    var projects by mutableStateOf(store.loadAll())
    var current by mutableStateOf<Project?>(null)
    private var previewBase: Project? = null
    /** Активен временный предпросмотр удержанием; скрывает панель инструмента. */
    var isLayerPreviewActive by mutableStateOf(false)
        private set
    var panel by mutableStateOf(PanelId.FRONT)
    var overview by mutableStateOf(false)
    var selected by mutableStateOf<String?>(null)
    var multiSelected by mutableStateOf<Set<String>>(emptySet())
    private val panelSelections = mutableStateMapOf<PanelId, String?>()
    var sharedSelected by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)
    var checker by mutableStateOf(false)
    /** Направляющие, видимые только пока объект двигают. */
    var guideLines by mutableStateOf<List<GuideLine>>(emptyList())
        private set
    var gridMm by mutableStateOf(5f)
        private set
    fun updateGridMm(value: Float) { gridMm = value.coerceIn(0f, 50f); prefs.edit().putFloat("editor_grid_mm", gridMm).apply() }

    private val prefs = app.getSharedPreferences("dvdmaker_prefs", android.content.Context.MODE_PRIVATE)
    /** Последний выбранный шрифт: применяется ко всем новым текстам. */
    init { gridMm = prefs.getFloat("editor_grid_mm", 5f) }
    private var lastFont = prefs.getInt("font_sys", 0)
    private var lastFontFile = prefs.getString("font_file", "") ?: ""
    private var lastItalic = prefs.getBoolean("font_italic", false)
    private val favoriteFontKeys = prefs.getStringSet("favorite_fonts", emptySet())?.toMutableSet() ?: mutableSetOf()
    fun isFavoriteFont(file: String, sys: Int): Boolean = (if (file.isNotEmpty()) "f:$file" else "s:$sys") in favoriteFontKeys
    fun toggleFavoriteFont(file: String, sys: Int) {
        val key = if (file.isNotEmpty()) "f:$file" else "s:$sys"
        if (!favoriteFontKeys.add(key)) favoriteFontKeys.remove(key)
        prefs.edit().putStringSet("favorite_fonts", favoriteFontKeys.toSet()).apply()
    }
    fun savedTextStyleNames(): List<String> = prefs.getStringSet("text_style_names", emptySet())?.toList()?.sorted().orEmpty()
    fun saveTextStyle(name: String, layer: Layer): Boolean {
        val clean = name.trim().take(28)
        if (clean.isBlank()) return false
        val names = prefs.getStringSet("text_style_names", emptySet())?.toMutableSet() ?: mutableSetOf()
        names.add(clean)
        prefs.edit().putStringSet("text_style_names", names).putString("text_style_$clean", layer.toJson().toString()).apply()
        return true
    }
    fun applyTextStyle(layerId: String, name: String) {
        val raw = prefs.getString("text_style_$name", null) ?: return
        val style = runCatching { Layer.fromJson(JSONObject(raw)) }.getOrNull() ?: return
        val applyStyle: (Layer) -> Layer = { it.copy(
            font = style.font, fontFile = style.fontFile, italic = style.italic, color = style.color,
            spacing = style.spacing, lineSpacing = style.lineSpacing, textScaleX = style.textScaleX,
            textScaleY = style.textScaleY, textAutoFit = style.textAutoFit, textArc = style.textArc,
            align = style.align, shadow = style.shadow, textOutlineWidth = style.textOutlineWidth,
            textOutlineColor = style.textOutlineColor, textGlowRadius = style.textGlowRadius,
            textGlowColor = style.textGlowColor, textMaterial = style.textMaterial,
            textShade = style.textShade, textBlur = style.textBlur, textShadowAngle = style.textShadowAngle,
            textShadowDistance = style.textShadowDistance, textShadowScaleX = style.textShadowScaleX,
            textShadowScaleY = style.textShadowScaleY, textShadowSpread = style.textShadowSpread,
            textShadowColor = style.textShadowColor, reflectionOpacity = style.reflectionOpacity,
            reflectionBlur = style.reflectionBlur, reflectionDistance = style.reflectionDistance,
            reflectionScale = style.reflectionScale, reflectionScaleX = style.reflectionScaleX,
            reflectionAngle = style.reflectionAngle, reflectionFade = style.reflectionFade
        ) }
        if (current?.canvasLayers?.any { it.id == layerId } == true) updateSharedLayer(layerId, "text-style-$layerId", applyStyle)
        else updateLayer(layerId, "text-style-$layerId", applyStyle)
    }

    fun rememberFont(sys: Int, file: String, italic: Boolean) {
        lastFont = sys; lastFontFile = file; lastItalic = italic
        prefs.edit().putInt("font_sys", sys).putString("font_file", file).putBoolean("font_italic", italic).apply()
    }

    /** Временный предпросмотр параметра: не создаёт undo-шаг и не запускает автосохранение. */
    fun previewLayer(layerId: String, transform: (Layer) -> Layer) {
        val base = previewBase ?: current ?: return
        if (previewBase == null) previewBase = base
        isLayerPreviewActive = true
        val source = previewBase ?: return
        val panels = source.panels.mapValues { (_, data) ->
            data.copy(layers = data.layers.map { layer -> if (layer.id == layerId) transform(layer) else layer })
        }
        val canvas = source.canvasLayers.map { layer -> if (layer.id == layerId) transform(layer) else layer }
        current = source.copy(panels = panels, canvasLayers = canvas)
    }

    /** Возвращает исходный проект после предпросмотра, не затрагивая историю и сохранение. */
    fun clearLayerPreview() {
        val base = previewBase ?: return
        current = base
        previewBase = null
        isLayerPreviewActive = false
    }

    /** Применяет Gaussian Blur как недеструктивную операцию; результат и стек входят в один undo-шаг. */
    fun setImageBlur(layerId: String, level: Int) {
        if (imageBlurBusy) return
        val project = current ?: return
        val panelId = panel
        val sourceLayer = project.panel(panelId).layers.firstOrNull { it.id == layerId } ?: return
        val safeLevel = level.coerceIn(0, 3)
        val blurInputPath = if (sourceLayer.imageOperations.any { it.type == ImageOperationType.GAUSSIAN_BLUR })
            ImageProcessingPipeline.pathBeforeOperation(sourceLayer, ImageOperationType.GAUSSIAN_BLUR)
        else ImageProcessingPipeline.previewPath(sourceLayer)
        imageBlurBusy = true
        imageBlurBusyLayerId = layerId
        imageBlurError = false
        imageBlurErrorLayerId = null
        viewModelScope.launch {
            try {
                var committed = false
                val replay = try {
                    withContext(Dispatchers.Default) {
                        ImageProcessingPipeline.setGaussianBlur(getApplication<Application>(), store, sourceLayer, safeLevel)
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Throwable) {
                    null
                }
                if (replay != null && current?.id == project.id) {
                    val latest = current?.panel(panelId)?.layers?.firstOrNull { it.id == layerId }
                    // Do not overwrite concurrent edits made while the bitmap was processing.
                    if (latest == sourceLayer) {
                        edit("image-blur-$layerId") { p ->
                            val data = p.panel(panelId)
                            p.copy(panels = p.panels + (panelId to data.copy(layers = data.layers.map { layer ->
                                if (layer.id == layerId) layer.copy(
                                    path = replay.path,
                                    sourcePath = if (safeLevel > 0) layer.sourcePath.ifBlank { blurInputPath } else layer.sourcePath,
                                    imageOperations = replay.operations,
                                    imageBlur = 0
                                ) else layer
                            })))
                        }
                        committed = true
                    }
                }
                imageBlurError = !committed
                imageBlurErrorLayerId = if (committed) null else layerId
            } finally {
                imageBlurBusy = false
                imageBlurBusyLayerId = null
            }
        }
    }

    /** Выбор шрифта для слоя: применяется к слою и запоминается для следующих текстов. */
    fun applyFont(layerId: String, sys: Int, file: String, italic: Boolean? = null) {
        val it0 = current?.panel(panel)?.layers?.firstOrNull { it.id == layerId }
        val ital = italic ?: it0?.italic ?: false
        updateLayer(layerId) { it.copy(font = sys, fontFile = file, italic = ital) }
        rememberFont(sys, file, ital)
    }

    var update by mutableStateOf<UpdateInfo?>(null)
    var checking by mutableStateOf(false)
    var progress by mutableStateOf<Float?>(null)
    var imageBlurBusy by mutableStateOf(false)
        private set
    var imageBlurBusyLayerId by mutableStateOf<String?>(null)
        private set
    var imageBlurError by mutableStateOf(false)
        private set
    var imageBlurErrorLayerId by mutableStateOf<String?>(null)
        private set
    var updateMsg by mutableStateOf<String?>(null)
    fun onMemoryPressure(level: Int) {
        Bitmaps.trim(level)
    }

    private val undo = ArrayList<Project>()
    private val redo = ArrayList<Project>()
    private var lastKey = ""
    private var lastEdit = 0L
    private var saveJob: Job? = null

    fun create(format: DiscFormat, showSafeZone: Boolean = true) {
        val p = newProject(format, "Новый ${format.title}").copy(showSafeZone = showSafeZone)
        store.save(p)
        projects = store.loadAll()
        enter(p)
    }

    /** Проект «Фото»: размер макета берётся из выбранной картинки (300 dpi, длинная сторона до 420 мм). */
    fun createPhoto(uri: Uri) {
        viewModelScope.launch {
            val imported = withContext(Dispatchers.IO) {
                val original = store.importOriginal(uri) ?: return@withContext null
                val working = store.importImage(uri)
                if (working == null) File(original).delete()
                working?.let { original to it }
            } ?: return@launch
            val (originalPath, path) = imported
            val b = Bitmaps.get(path) ?: run { File(originalPath).delete(); return@launch }
            var w = b.width / 300f * 25.4f
            var h = b.height / 300f * 25.4f
            val k = minOf(1f, 420f / max(w, h))
            w = max(30f, w * k); h = max(30f, h * k)
            val f = DiscFormat.photo(w, h)
            val base = newProject(f, "Новое фото")
            val front = base.panel(PanelId.FRONT).copy(layers = listOf(Layer(kind = Kind.IMAGE, path = path, sourcePath = path, originalPath = originalPath, widthMm = f.frontW)))
            val p = base.copy(panels = base.panels + (PanelId.FRONT to front))
            store.save(p)
            projects = store.loadAll()
            enter(p)
        }
    }

    fun open(p: Project) = enter(p)

    /** Создаёт проект из готового Project (например, после подгонки готовой обложки) и открывает его. */
    fun createFrom(p: Project) {
        store.save(p)
        projects = store.loadAll()
        checker = false
        enter(p)
    }

    fun toggleFoldShadow() = edit { it.copy(foldShadow = !it.foldShadow) }

    /** Диск: берёт фон и главное изображение с лицевой стороны и подгоняет под круг диска. */
    fun discFromFront() {
        val p = current ?: return
        val front = p.panel(PanelId.FRONT)
        val img = front.layers.firstOrNull { it.kind == Kind.IMAGE }
        updatePanel(PanelId.DISC) { d ->
            var nd = d.copy(c1 = front.c1, c2 = front.c2, angle = front.angle)
            if (img != null) {
                val b = ImageProcessingPipeline.previewBitmap(img)
                val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                val layer = img.copy(
                    id = java.util.UUID.randomUUID().toString(),
                    x = 0.5f, y = 0.5f, rot = 0f, alpha = 1f,
                    widthMm = max(DISC_SIZE_MM, DISC_SIZE_MM * aspect)
                )
                nd = nd.copy(layers = listOf(layer) + nd.layers.filter { it.kind != Kind.IMAGE })
            }
            nd
        }
        selected = null
    }

    private fun enter(p0: Project) {
        val p = p0.copy(opened = System.currentTimeMillis())
        store.save(p)
        current = p; panel = PanelId.FRONT; overview = false; selected = null
        panelSelections.clear()
        undo.clear(); redo.clear(); canUndo = false; canRedo = false; lastKey = ""
    }


    /** Переключение панели сохраняет выбор слоя каждой рабочей области. */
    fun switchPanel(id: PanelId) {
        if (panel == id && !overview) return
        if (!overview) panelSelections[panel] = selected
        panel = id
        overview = false
        multiSelected = emptySet()
        selected = panelSelections[id]?.takeIf { candidate ->
            current?.panel(id)?.layers?.any { it.id == candidate } == true
        }
        sharedSelected = null
    }

    /** Переход в обзор не закрывает проект и не сбрасывает выбор панели. */
    fun showOverview() {
        if (!overview) panelSelections[panel] = selected
        overview = true
        sharedSelected = null
    }

    /** Возврат из обзора к последней рабочей панели. */
    fun returnToPanel() {
        overview = false
        selected = panelSelections[panel]?.takeIf { candidate ->
            current?.panel(panel)?.layers?.any { it.id == candidate } == true
        }
        sharedSelected = null
    }

    fun close(): Boolean {
        if (!flush()) return false
        current = null
        selected = null
        panelSelections.clear()
        projects = store.loadAll()
        return true
    }

    /** Ресурсы текущего проекта и всех снимков Undo/Redo: их нельзя удалять, пока Undo может к ним вернуться. */
    private fun protectedPaths(): Set<String> =
        (listOfNotNull(current) + undo + redo).flatMapTo(mutableSetOf()) { it.imagePaths() }

    private var lastPrune = 0L

    fun delete(p: Project) {
        store.delete(p, protectedPaths())
        projects = store.loadAll()
    }

    /** Сортировка списка проектов на главном экране (0 — дата, 1 — название, 2 — формат). */
    var sortMode by mutableStateOf(prefs.getInt("home_sort", 0))
        private set

    fun setSort(mode: Int) {
        sortMode = mode
        prefs.edit().putInt("home_sort", mode).apply()
    }

    fun toggleFavorite(p: Project) {
        store.save(p.copy(favorite = !p.favorite))
        projects = store.loadAll()
    }

    fun renameProject(p: Project, name: String) {
        val n = name.trim()
        if (n.isEmpty() || n == p.name) return
        store.save(p.copy(name = n))
        projects = store.loadAll()
    }

    fun duplicate(p: Project) {
        val c = p.copy(
            id = java.util.UUID.randomUUID().toString(), name = p.name + " (копия)",
            updated = System.currentTimeMillis(), opened = 0L, favorite = false
        )
        store.save(c)
        projects = store.loadAll()
    }

    fun flush(): Boolean {
        saveJob?.cancel()
        val project = current ?: return true
        return store.save(project)
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(500)
            current?.let { p ->
                val keep = if (SystemClock.elapsedRealtime() - lastPrune > 120_000L) protectedPaths() else null
                withContext(Dispatchers.IO) {
                    if (store.save(p) && keep != null) store.pruneDerived(keep)
                }
                if (keep != null) lastPrune = SystemClock.elapsedRealtime()
            }
        }
    }

    fun edit(key: String = "", block: (Project) -> Project) {
        clearLayerPreview()
        val p = current ?: return
        val now = SystemClock.elapsedRealtime()
        if (key.isEmpty() || key != lastKey || now - lastEdit > 1200) {
            undo.add(p)
            if (undo.size > 40) undo.removeAt(0)
            redo.clear()
            canUndo = true
            canRedo = false
        }
        lastKey = key
        lastEdit = now
        current = block(p).copy(updated = System.currentTimeMillis())
        scheduleSave()
    }

    fun undoLast() {
        val now = current ?: return
        if (undo.isEmpty()) return
        redo.add(now)
        current = undo.removeAt(undo.lastIndex)
        canUndo = undo.isNotEmpty()
        canRedo = redo.isNotEmpty()
        lastKey = ""
        val p = current
        if (p != null && selected != null &&
            p.panel(panel).layers.none { it.id == selected }) selected = null
        scheduleSave()
    }

    fun redoLast() {
        val now = current ?: return
        if (redo.isEmpty()) return
        undo.add(now)
        if (undo.size > 40) undo.removeAt(0)
        current = redo.removeAt(redo.lastIndex)
        canUndo = undo.isNotEmpty()
        canRedo = redo.isNotEmpty()
        lastKey = ""
        val p = current
        if (p != null && selected != null &&
            p.panel(panel).layers.none { it.id == selected }) selected = null
        scheduleSave()
    }

    fun rename(name: String) = edit { it.copy(name = name.ifBlank { it.name }) }

    fun updatePanel(id: PanelId, key: String = "", f: (PanelData) -> PanelData) =
        edit(key) { p -> p.copy(panels = p.panels + (id to f(p.panel(id)))) }

    fun updateLayer(layerId: String, key: String = "", f: (Layer) -> Layer) =
        updatePanel(panel, key) { pd ->
            pd.copy(layers = pd.layers.map { if (it.id == layerId) f(it) else it })
        }

    fun addLayer(l: Layer) {
        updatePanel(panel) { it.copy(layers = it.layers + l) }
        selected = l.id
    }

    fun addText() {
        val p = current ?: return
        val (w, h) = p.format.size(panel)
        val spine = panel == PanelId.SPINE
        addLayer(
            Layer(
                kind = Kind.TEXT, text = "Текст",
                sizeMm = if (spine) minOf(w * 0.55f, 7f) else 9f,
                font = lastFont, fontFile = lastFontFile, italic = lastItalic,
                rot = if (spine) 90f else 0f
            )
        )
    }

    fun addRect() {
        val p = current ?: return
        val (w, _) = p.format.size(panel)
        addLayer(Layer(kind = Kind.RECT, widthMm = w * 0.6f, sizeMm = 8f, color = 0xFFFFB547.toInt()))
    }

    fun addBlurObject() {
        val p = current ?: return
        val (w, h) = p.format.size(panel)
        addLayer(Layer(kind = Kind.RECT, name = "Блюр", widthMm = w * 0.48f, sizeMm = h * 0.22f, color = 0xFFE7ECFF.toInt(), alpha = 0.58f, blurStrength = 0.65f, blurFeather = 0.82f))
    }

    fun addSoftBlurObject() {
        val p = current ?: return
        val (w, h) = p.format.size(panel)
        addLayer(Layer(kind = Kind.RECT, name = "Размытие", widthMm = w * 0.38f, sizeMm = h * 0.30f, color = 0xFFB8C8FF.toInt(), alpha = 0.48f, blurStrength = 0.5f, blurFeather = 0.68f))
    }

    fun addSharedBlurObject() {
        val p = current ?: return
        addSharedEffectRect(p, "Блюр")
    }

    fun addSharedSoftBlurObject() {
        val p = current ?: return
        addSharedEffectRect(p, "Размытие")
    }

    private fun addSharedEffectRect(p: Project, title: String) {
        val w = p.format.layout().w; val h = p.format.layout().h
        val layer = Layer(kind = Kind.RECT, name = title, widthMm = w * 0.4f, sizeMm = h * 0.25f, color = 0xFFE7ECFF.toInt(), alpha = 0.55f)
        edit("canvas-layer") { it.copy(canvasLayers = it.canvasLayers + layer) }
        sharedSelected = layer.id; selected = null
    }

    fun removeSelected() {
        val id = selected ?: return
        updatePanel(panel) { it.copy(layers = it.layers.filter { l -> l.id != id }) }
        selected = null
    }

    fun duplicateSelected() {
        val id = selected ?: return
        val src = current?.panel(panel)?.layers?.firstOrNull { it.id == id } ?: return
        addLayer(src.copy(id = java.util.UUID.randomUUID().toString(),
            x = (src.x + 0.05f).coerceAtMost(0.95f), y = (src.y + 0.05f).coerceAtMost(0.95f)))
    }

    /** Метаданные и операции менеджера слоёв текущей панели. */
    fun renameLayer(id: String, name: String) = updateLayer(id, "rename-$id") { it.copy(name = name.trim()) }
    fun toggleLayerVisible(id: String) = updateLayer(id, "visible-$id") { it.copy(visible = !it.visible) }
    fun toggleLayerLocked(id: String) = updateLayer(id, "locked-$id") { it.copy(locked = !it.locked) }
    fun selectMany(id: String, additive: Boolean = true) {
        multiSelected = if (additive) {
            if (id in multiSelected) multiSelected - id else multiSelected + id
        } else setOf(id)
        selected = id
    }
    fun clearMultiSelection() { multiSelected = emptySet() }
    fun reorderLayer(id: String, targetIndex: Int) {
        updatePanel(panel, "reorder-$id") { pd ->
            val list = pd.layers.toMutableList()
            val from = list.indexOfFirst { it.id == id }
            if (from < 0 || targetIndex !in list.indices) pd else {
                val item = list.removeAt(from)
                list.add(targetIndex.coerceIn(0, list.size), item)
                pd.copy(layers = list)
            }
        }
    }
    fun groupSelected() {
        val ids = multiSelected.ifEmpty { selected?.let { setOf(it) } ?: emptySet() }
        if (ids.size < 2) return
        val gid = java.util.UUID.randomUUID().toString()
        updatePanel(panel, "group-${gid}") { pd -> pd.copy(layers = pd.layers.map { if (it.id in ids) it.copy(groupId = gid) else it }) }
    }
    fun ungroupSelected() {
        val ids = multiSelected.ifEmpty { selected?.let { setOf(it) } ?: emptySet() }
        updatePanel(panel, "ungroup") { pd -> pd.copy(layers = pd.layers.map { if (it.id in ids) it.copy(groupId = "") else it }) }
    }
    fun duplicateMany() {
        val ids = multiSelected.ifEmpty { selected?.let { setOf(it) } ?: emptySet() }
        if (ids.isEmpty()) return
        val allLayers = current?.panel(panel)?.layers.orEmpty()
        val groupIds = allLayers.filter { it.id in ids }.map { it.groupId }.filter { it.isNotBlank() }.toSet()
        val expandedIds = ids + allLayers.filter { it.groupId in groupIds }.map { it.id }
        val src = allLayers.filter { it.id in expandedIds }
        if (src.isEmpty()) return
        val newIds = src.associate { it.id to java.util.UUID.randomUUID().toString() }
        val newGroups = src.map { it.groupId }.filter { it.isNotBlank() }.distinct().associateWith { java.util.UUID.randomUUID().toString() }
        updatePanel(panel, "duplicate-group") { pd ->
            pd.copy(layers = pd.layers + src.map { layer ->
                layer.copy(id = newIds.getValue(layer.id), groupId = newGroups[layer.groupId] ?: layer.groupId,
                    x = (layer.x + .035f).coerceAtMost(.98f), y = (layer.y + .035f).coerceAtMost(.98f))
            })
        }
        multiSelected = newIds.values.toSet()
        selected = newIds.values.lastOrNull()
    }
    /** Логическое объединение: общий groupId; операция полностью отменяется через undo. */
    fun mergeSelected() = groupSelected()

    fun moveSelected(up: Boolean) {
        val id = selected ?: return
        updatePanel(panel) { pd ->
            val list = pd.layers.toMutableList()
            val i = list.indexOfFirst { it.id == id }
            val j = if (up) i + 1 else i - 1
            if (i >= 0 && j in list.indices) {
                val t = list[i]; list[i] = list[j]; list[j] = t
            }
            pd.copy(layers = list)
        }
    }

    /**
     * Двигает/масштабирует/вращает слой. [rawX]/[rawY]/[rawRot] — «сырое» положение пальца (без привязки),
     * поэтому объект можно спокойно вывести из примагничивания. Возвращённая привязка рисует направляющие.
     */
    fun transform(
        id: String, rawX: Float, rawY: Float, rawRot: Float, zoom: Float,
        cw: Float, snapPx: Float, showPx: Float
    ) {
        val p = current ?: return
        val pd = p.panel(panel)
        val layer = pd.layers.firstOrNull { it.id == id } ?: return
        if (layer.locked) return
        val (wMm, hMm) = p.format.size(panel)
        val ppm = cw / wMm
        val snappedRot = run {
            val snap = listOf(0f, 90f, -90f, 180f, -180f).minByOrNull { kotlin.math.abs((((rawRot - it + 180f) % 360f + 360f) % 360f) - 180f) }
            if (snap != null && kotlin.math.abs((((rawRot - snap + 180f) % 360f + 360f) % 360f) - 180f) <= 1.5f) snap else rawRot
        }
        // размер меняем первым — привязка должна учитывать уже новые габариты
        val sized = when (layer.kind) {
            Kind.TEXT -> layer.copy(sizeMm = (layer.sizeMm * zoom).coerceIn(1f, 120f))
            Kind.IMAGE -> layer.copy(widthMm = (layer.widthMm * zoom).coerceIn(2f, 900f))
            Kind.RECT -> layer.copy(
                widthMm = (layer.widthMm * zoom).coerceIn(0.5f, 900f),
                sizeMm = (layer.sizeMm * zoom).coerceIn(0.3f, 900f)
            )
            Kind.SYMBOL -> layer.copy(widthMm = (layer.widthMm * zoom).coerceIn(4f, 900f))
        }.copy(rot = snappedRot)
        val res = Snap.compute(
            sized, rawX.coerceIn(-0.2f, 1.2f), rawY.coerceIn(-0.2f, 1.2f),
            pd.layers.filter { it.id != id }, wMm, hMm, panel,
            snapMm = snapPx / ppm, showMm = showPx / ppm, gridMm = gridMm
        )
        guideLines = res.guides
        updateLayer(id, "g$id") { sized.copy(x = res.x, y = res.y) }
    }

    fun clearGuides() { if (guideLines.isNotEmpty()) guideLines = emptyList() }

    /** Точное выравнивание и распределение выбранных слоёв панели. */
    fun alignSelected(mode: String) {
        val ids = multiSelected.ifEmpty { selected?.let { setOf(it) } ?: emptySet() }
        if (ids.isEmpty()) return
        updatePanel(panel, "align-$mode") { pd ->
            val targets = pd.layers.filter { it.id in ids && !it.locked }
            if (targets.isEmpty()) pd else {
                val left = targets.minOf { it.x }; val right = targets.maxOf { it.x }
                val top = targets.minOf { it.y }; val bottom = targets.maxOf { it.y }
                val cx = targets.map { it.x }.average().toFloat(); val cy = targets.map { it.y }.average().toFloat()
                pd.copy(layers = pd.layers.map { l -> if (l.id !in ids || l.locked) l else when (mode) {
                    "left" -> l.copy(x = left); "right" -> l.copy(x = right)
                    "top" -> l.copy(y = top); "bottom" -> l.copy(y = bottom)
                    "center-x" -> l.copy(x = cx); "center-y" -> l.copy(y = cy)
                    else -> l
                } })
            }
        }
    }
    fun distributeSelected(horizontal: Boolean) {
        val ids = multiSelected.ifEmpty { return }
        if (ids.size < 3) return
        updatePanel(panel, if (horizontal) "distribute-x" else "distribute-y") { pd ->
            val chosen = pd.layers.filter { it.id in ids && !it.locked }.sortedBy { if (horizontal) it.x else it.y }
            if (chosen.size < 3) pd else {
                val first = if (horizontal) chosen.first().x else chosen.first().y
                val last = if (horizontal) chosen.last().x else chosen.last().y
                val step = (last - first) / (chosen.size - 1)
                val positions = chosen.mapIndexed { i, l -> l.id to (first + step * i) }.toMap()
                pd.copy(layers = pd.layers.map { l -> positions[l.id]?.let { v -> if (horizontal) l.copy(x=v) else l.copy(y=v) } ?: l })
            }
        }
    }

    /** Применяет выбранную композицию одним undo-шагом; заблокированные слои не перемещаются. */
    fun applyComposition(positions: Map<String, Pair<Float, Float>>) {
        if (positions.isEmpty()) return
        updatePanel(panel, "smart-composition") { pd ->
            pd.copy(layers = pd.layers.map { layer ->
                val point = if (layer.locked) null else positions[layer.id]
                if (point == null) layer else layer.copy(
                    x = point.first.coerceIn(0.02f, 0.98f),
                    y = point.second.coerceIn(0.02f, 0.98f)
                )
            })
        }
    }

    fun addSpecialSymbol(symbol: String) {
        val p = current ?: return
        val spine = panel == PanelId.SPINE
        addLayer(Layer(kind = Kind.SYMBOL, text = symbol, widthMm = if (spine) 7f else 42f,
            rot = if (spine) 90f else 0f, color = 0xFFFFFFFF.toInt()))
    }

    /** Аккуратно подгоняет уже добавленные изображения и текст, не удаляя слои. */
    fun autoFitAll() {
        val p = current ?: return
        val fallbackImage = p.panels.values.asSequence().flatMap { it.layers.asSequence() }
            .firstOrNull { it.kind == Kind.IMAGE }
        val panels = p.panels.mapValues { (id, data) ->
            val (w, h) = p.format.size(id)
            var firstImage = true
            val sourceLayers = if (data.layers.none { it.kind == Kind.IMAGE } && fallbackImage != null) {
                val b = ImageProcessingPipeline.previewBitmap(fallbackImage)
                val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                val coverW = max(w, h * aspect)
                data.layers + fallbackImage.copy(id = java.util.UUID.randomUUID().toString(),
                    x = 0.5f, y = 0.5f, widthMm = coverW, rot = 0f)
            } else data.layers
            val fitted = sourceLayers.map { layer ->
                when (layer.kind) {
                    Kind.IMAGE -> {
                        if (!firstImage) layer.copy(x = layer.x.coerceIn(0.05f, 0.95f), y = layer.y.coerceIn(0.05f, 0.95f))
                        else {
                            firstImage = false
                            val b = ImageProcessingPipeline.previewBitmap(layer)
                            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                            val coverW = max(w, h * aspect)
                            layer.copy(x = 0.5f, y = 0.5f, widthMm = coverW, rot = 0f)
                        }
                    }
                    Kind.TEXT -> layer.copy(
                        x = layer.x.coerceIn(0.08f, 0.92f), y = layer.y.coerceIn(0.08f, 0.92f),
                        rot = run { val r = (((layer.rot + 180f) % 360f + 360f) % 360f) - 180f; if (kotlin.math.abs(r) <= 3.5f) 0f else r }
                    )
                    Kind.RECT, Kind.SYMBOL -> layer.copy(x = layer.x.coerceIn(0.05f, 0.95f), y = layer.y.coerceIn(0.05f, 0.95f))
                }
            }
            data.copy(layers = fitted)
        }
        edit("auto-fit") { it.copy(panels = panels) }
        selected = null
    }

    /**
     * Создаёт общий фон для всей развёртки: исходное изображение кадрируется
     * по пропорциям листа и делится на изображения отдельных панелей.
     * Существующие слои остаются поверх нового фона.
     */
    fun addUnifiedBackground(uri: Uri) = addUnifiedArtwork(uri, replaceBackground = true)

    /** Добавляет ещё одно сквозное изображение, сохраняя уже созданный общий фон и содержимое панелей. */
    fun addUnifiedImage(uri: Uri) = addUnifiedArtwork(uri, replaceBackground = false)

    private fun addUnifiedArtwork(uri: Uri, replaceBackground: Boolean) {
        val initial = current ?: return
        if (initial.format.photo) return
        val projectId = initial.id
        val prefix = if (replaceBackground) "unified-bg-" else "unified-layer-"
        viewModelScope.launch {
            val generated = withContext(Dispatchers.IO) {
                runCatching {
                    val sourcePath = store.importImage(uri) ?: return@runCatching null
                    val source = Bitmaps.get(sourcePath) ?: run {
                        File(sourcePath).delete()
                        return@runCatching null
                    }
                    val layout = initial.format.layout()
                    val targetAspect = layout.w / layout.h
                    val sourceAspect = source.width.toFloat() / source.height.toFloat()
                    val cropW: Int
                    val cropH: Int
                    val cropX: Int
                    val cropY: Int
                    if (sourceAspect > targetAspect) {
                        cropH = source.height
                        cropW = (source.height * targetAspect).roundToInt().coerceIn(1, source.width)
                        cropX = (source.width - cropW) / 2
                        cropY = 0
                    } else {
                        cropW = source.width
                        cropH = (source.width / targetAspect).roundToInt().coerceIn(1, source.height)
                        cropX = 0
                        cropY = (source.height - cropH) / 2
                    }
                    // Почти точные пропорции (ИИ-картинки часто отличаются на доли процента): растягиваем без потерь по краям.
                    val ratio = sourceAspect / targetAspect
                    val master = if (ratio in 0.94f..1.06f) {
                        val exactH = (source.width / targetAspect).roundToInt().coerceAtLeast(1)
                        Bitmap.createScaledBitmap(source, source.width, exactH, true)
                    } else Bitmap.createBitmap(source, cropX, cropY, cropW, cropH)
                    val result = LinkedHashMap<PanelId, String>()
                    try {
                        // У трей-форматов корешок встречается дважды при одной модели панели — его не режем.
                        layout.places.filter { it.id != PanelId.DISC && !(initial.format.tray && it.id == PanelId.SPINE) }.forEach { place ->
                            val left = (place.x / layout.w * master.width).roundToInt().coerceIn(0, master.width - 1)
                            val top = (place.y / layout.h * master.height).roundToInt().coerceIn(0, master.height - 1)
                            val right = ((place.x + place.w) / layout.w * master.width).roundToInt().coerceIn(left + 1, master.width)
                            val bottom = ((place.y + place.h) / layout.h * master.height).roundToInt().coerceIn(top + 1, master.height)
                            val part = Bitmap.createBitmap(master, left, top, right - left, bottom - top)
                            try {
                                val path = store.saveBitmap(part, png = true, prefix = prefix)
                                    ?: throw IllegalStateException("Не удалось сохранить часть сквозного изображения")
                                result[place.id] = path
                            } finally {
                                part.recycle()
                            }
                        }
                    } finally {
                        master.recycle()
                        File(sourcePath).delete()
                    }
                    result
                }.getOrNull()
            }
            if (generated.isNullOrEmpty()) return@launch
            val latest = current
            if (latest == null || latest.id != projectId) {
                generated.values.forEach { File(it).delete() }
                return@launch
            }
            val layout = latest.format.layout()
            val panels = latest.panels.toMutableMap()
            generated.forEach { (id, path) ->
                val old = latest.panel(id)
                val oldUnified = old.layers.filter {
                    it.kind == Kind.IMAGE && (File(it.path).name.startsWith("unified-bg-") ||
                        File(it.path).name.startsWith("unified-layer-"))
                }
                val retained = old.layers.filterNot { it in oldUnified }
                val place = layout.places.first { it.id == id }
                val image = Layer(
                    kind = Kind.IMAGE,
                    path = path,
                    x = 0.5f,
                    y = 0.5f,
                    widthMm = place.w,
                    alpha = if (replaceBackground) 1f else 0.72f
                )
                val unifiedLayers = if (replaceBackground) listOf(image)
                    else oldUnified + image
                panels[id] = old.copy(layers = unifiedLayers + retained)
            }
            edit(if (replaceBackground) "unified-background" else "unified-image") {
                it.copy(panels = it.panels + panels)
            }
            selected = null
        }
    }

    /** Готовое оформление: название, подзаголовок с линиями, описание, корешок и атмосфера (виньетка, цветокор, снег). */
    fun applyTemplate(style: Int, title: String, subtitle: String, synopsis: String) {
        edit("template") { Templates.apply(it, style, title, subtitle, synopsis) }
        selected = null
        sharedSelected = null
    }

    /**
     * Согласует фон и типографику корешка с лицом, центрирует его текст/символы
     * и перестраивает цветовой переход по соседним краям. Текстовое содержимое,
     * изображения пользователя, эффекты, общие слои и диск не заменяются.
     */
    fun harmonizeCoverBackgrounds() {
        val p = current ?: return
        if (p.format.photo) return
        val source = p.panel(PanelId.FRONT)
        val panels = p.panels.toMutableMap()
        val referenceText = source.layers.filter { it.visible && it.kind == Kind.TEXT }.maxByOrNull { it.sizeMm }
        listOf(PanelId.FRONT, PanelId.SPINE, PanelId.BACK).forEach { id ->
            val data = p.panel(id)
            val layers = if (id == PanelId.SPINE) data.layers.map { layer ->
                when {
                    layer.kind == Kind.SYMBOL -> layer.copy(x = 0.5f)
                    layer.kind == Kind.TEXT -> {
                        val ref = referenceText
                        if (ref == null) layer.copy(x = 0.5f) else layer.copy(
                            x = 0.5f, font = ref.font, fontFile = ref.fontFile, italic = ref.italic,
                            upper = ref.upper, spacing = ref.spacing, lineSpacing = ref.lineSpacing,
                            textScaleX = ref.textScaleX, textScaleY = ref.textScaleY,
                            shadow = ref.shadow, textMaterial = ref.textMaterial,
                            textOutlineWidth = ref.textOutlineWidth, textOutlineColor = ref.textOutlineColor,
                            textGlowRadius = ref.textGlowRadius, textGlowColor = ref.textGlowColor,
                            textShade = ref.textShade, textBlur = ref.textBlur,
                            textShadowAngle = ref.textShadowAngle, textShadowDistance = ref.textShadowDistance,
                            textShadowScaleX = ref.textShadowScaleX, textShadowScaleY = ref.textShadowScaleY,
                            textShadowSpread = ref.textShadowSpread, textShadowColor = ref.textShadowColor,
                            reflectionOpacity = ref.reflectionOpacity, reflectionBlur = ref.reflectionBlur,
                            reflectionDistance = ref.reflectionDistance, reflectionScale = ref.reflectionScale,
                            reflectionScaleX = ref.reflectionScaleX, reflectionAngle = ref.reflectionAngle,
                            reflectionFade = ref.reflectionFade
                        )
                    }
                    else -> layer
                }
            } else data.layers
            panels[id] = data.copy(c1 = source.c1, c2 = source.c2, angle = source.angle, layers = layers)
        }
        edit("harmonize-cover-backgrounds") { it.copy(panels = it.panels + panels) }
        selected = null
        sharedSelected = null
        // Пересобираем фон корешка по фактическим краям соседних панелей уже после общей цветовой схемы.
        spineFromNeighbors()
    }

    fun updateFx(key: String, f: (Fx) -> Fx) = edit("fx-$key") { it.copy(fx = f(it.fx)) }

    fun savedFxPresetNames(): List<String> =
        prefs.getStringSet("fx_preset_names", emptySet())?.toList()?.sorted().orEmpty()

    fun saveFxPreset(name: String): Boolean {
        val clean = name.trim().take(28)
        val fx = current?.fx ?: return false
        if (clean.isBlank()) return false
        val names = prefs.getStringSet("fx_preset_names", emptySet())?.toMutableSet() ?: mutableSetOf()
        names.add(clean)
        prefs.edit().putStringSet("fx_preset_names", names)
            .putString("fx_preset_$clean", fx.toJson().toString()).apply()
        return true
    }

    fun applyFxPreset(name: String) {
        val raw = prefs.getString("fx_preset_$name", null) ?: return
        val preset = runCatching { Fx.fromJson(JSONObject(raw)) }.getOrNull() ?: return
        updateFx("saved-preset") { preset }
    }

    /** Добавляет текст на общий холст разворота, а не на отдельную панель. */
    fun addSharedRect() {
        val p = current ?: return
        val layout = p.format.layout()
        val layer = Layer(
            kind = Kind.RECT, x = 0.5f, y = 0.5f,
            widthMm = layout.w * 0.22f, sizeMm = layout.h * 0.18f,
            color = 0xAA0B1D30.toInt(), alpha = 0.9f
        )
        edit("canvas-layer") { it.copy(canvasLayers = it.canvasLayers + layer) }
        sharedSelected = layer.id
        selected = null
    }

    fun addSharedText(text: String = "Название фильма") {
        val p = current ?: return
        val layer = Layer(
            kind = Kind.TEXT, text = text, x = 0.68f, y = 0.48f,
            sizeMm = 16f, widthMm = p.format.layout().w * 0.72f,
            font = lastFont, fontFile = lastFontFile, italic = lastItalic,
            shadow = true, textOutlineWidth = 0.025f, textOutlineColor = android.graphics.Color.BLACK
        )
        edit("canvas-layer") { it.copy(canvasLayers = it.canvasLayers + layer) }
        sharedSelected = layer.id
        selected = null
    }

    /** Добавляет изображение как отдельный слой на весь разворот. */
    fun addSharedImage(uri: Uri) {
        viewModelScope.launch {
            val imported = withContext(Dispatchers.IO) {
                val original = store.importOriginal(uri) ?: return@withContext null
                val working = store.importImage(uri)
                if (working == null) File(original).delete()
                working?.let { original to it }
            } ?: return@launch
            val (originalPath, path) = imported
            val p = current ?: run { File(path).delete(); File(originalPath).delete(); return@launch }
            val layout = p.format.layout()
            val layer = Layer(
                kind = Kind.IMAGE, path = path, sourcePath = path, originalPath = originalPath, x = 0.5f, y = 0.5f,
                widthMm = layout.w, alpha = 1f
            )
            edit("canvas-layer") { it.copy(canvasLayers = it.canvasLayers + layer) }
            sharedSelected = layer.id
            selected = null
        }
    }

    fun moveSharedLayer(id: String, dx: Float, dy: Float) {
        edit("canvas-move-$id") { p ->
            p.copy(canvasLayers = p.canvasLayers.map { l ->
                if (l.id == id && !l.locked) l.copy(x = (l.x + dx).coerceIn(-0.5f, 1.5f), y = (l.y + dy).coerceIn(-0.5f, 1.5f)) else l
            })
        }
    }

    fun updateSharedLayer(id: String, key: String = "", f: (Layer) -> Layer) {
        edit(if (key.isBlank()) "canvas-edit-$id" else key) { p ->
            p.copy(canvasLayers = p.canvasLayers.map { if (it.id == id) f(it) else it })
        }
    }

    fun applySharedFont(layerId: String, sys: Int, file: String, italic: Boolean? = null) {
        val layer = current?.canvasLayers?.firstOrNull { it.id == layerId } ?: return
        val ital = italic ?: layer.italic
        updateSharedLayer(layerId, "canvas-font-$layerId") {
            it.copy(font = sys, fontFile = file, italic = ital)
        }
        rememberFont(sys, file, ital)
    }

    fun moveSharedLayerOrder(id: String, direction: Int) {
        edit("canvas-order-$id") { p ->
            val items = p.canvasLayers.toMutableList()
            val from = items.indexOfFirst { it.id == id }
            val to = (from + direction).coerceIn(0, items.lastIndex)
            if (from >= 0 && to != from) {
                val item = items.removeAt(from)
                items.add(to, item)
            }
            p.copy(canvasLayers = items)
        }
    }

    fun removeSharedLayer(id: String) {
        edit { it.copy(canvasLayers = it.canvasLayers.filterNot { l -> l.id == id }) }
        if (sharedSelected == id) sharedSelected = null
    }

    fun transformSharedLayer(id: String, zoom: Float, rotation: Float) {
        edit("canvas-transform-$id") { p ->
            p.copy(canvasLayers = p.canvasLayers.map { layer ->
                if (layer.id != id || layer.locked) layer else when (layer.kind) {
                    Kind.TEXT -> layer.copy(sizeMm = (layer.sizeMm * zoom).coerceIn(2f, 120f), rot = layer.rot + rotation)
                    Kind.IMAGE -> layer.copy(widthMm = (layer.widthMm * zoom).coerceIn(2f, p.format.layout().w * 3f), rot = layer.rot + rotation)
                    Kind.RECT -> layer.copy(widthMm = (layer.widthMm * zoom).coerceIn(2f, p.format.layout().w * 3f), sizeMm = (layer.sizeMm * zoom).coerceIn(2f, p.format.layout().h * 3f), rot = layer.rot + rotation)
                    Kind.SYMBOL -> layer.copy(widthMm = (layer.widthMm * zoom).coerceIn(2f, p.format.layout().w * 3f), rot = layer.rot + rotation)
                }
            })
        }
    }

    fun addImage(uri: Uri, asBackground: Boolean) {
        viewModelScope.launch {
            val imported = withContext(Dispatchers.IO) {
                val original = store.importOriginal(uri) ?: return@withContext null
                val working = store.importImage(uri)
                if (working == null) File(original).delete()
                working?.let { original to it }
            } ?: return@launch
            val (originalPath, path) = imported
            val p = current ?: run { File(path).delete(); File(originalPath).delete(); return@launch }
            val (pw, ph) = p.format.size(panel)
            val b = Bitmaps.get(path)
            val aspect = if (b != null) b.width.toFloat() / b.height else 1f
            val w = if (asBackground) max(pw, ph * aspect) else minOf(pw * 0.7f, ph * 0.7f * aspect)
            addLayer(Layer(kind = Kind.IMAGE, path = path, sourcePath = path, originalPath = originalPath, widthMm = w))
        }
    }

    fun fillSelected(cover: Boolean) {
        val id = selected ?: return
        val p = current ?: return
        val l = p.panel(panel).layers.firstOrNull { it.id == id } ?: return
        val b = ImageProcessingPipeline.previewBitmap(l) ?: return
        val (pw, ph) = p.format.size(panel)
        val aspect = b.width.toFloat() / b.height
        val w = if (cover) max(pw, ph * aspect) else minOf(pw, ph * aspect)
        updateLayer(id) { it.copy(widthMm = w, x = 0.5f, y = 0.5f, rot = 0f) }
    }


    /** Устанавливает выбранный пипеткой цвет как сплошной фон текущей панели. */
    fun setPanelBackgroundColor(target: PanelId, color: Int) {
        updatePanel(target, "sampled-bg-$target") {
            it.copy(c1 = color, c2 = color, angle = 0, layers = it.layers.filterNot { l -> isGenerated(l) })
        }
    }

    /** Возвращает фон панели к исходному: убирает размытие/палитру/переход и ставит градиент по умолчанию. */
    fun resetBackground(target: PanelId = panel) {
        val d = GradientPresets[0]
        updatePanel(target) {
            it.copy(c1 = d.c1, c2 = d.c2, angle = d.angle, layers = it.layers.filterNot { l -> isGenerated(l) })
        }
        selected = null
    }

    fun hasGeneratedBackground(target: PanelId = panel): Boolean =
        current?.panel(target)?.layers?.any { isGenerated(it) } == true

    private fun isGenerated(l: Layer): Boolean {
        if (l.kind != Kind.IMAGE) return false
        val n = java.io.File(l.path).name
        return n.startsWith("blur-") || n.startsWith("spine-")
    }

    /** Размытый фон из того, как реально выглядит лицевая сторона (фон + картинки, без текста), для оборота/корешка. */
    fun useBlurredFrontAsBackground(target: PanelId) {
        val p = current ?: return
        viewModelScope.launch {
            val path = withContext(Dispatchers.Default) {
                runCatching {
                    val front = p.panel(PanelId.FRONT)
                    val (fw, fh) = p.format.size(PanelId.FRONT)
                    val wpx = 1200
                    val ppm = wpx / fw
                    val hpx = (fh * ppm).roundToInt().coerceAtLeast(1)
                    val shot = Bitmap.createBitmap(wpx, hpx, Bitmap.Config.ARGB_8888)
                    drawPanel(Canvas(shot), front.copy(layers = front.layers.filter { it.kind == Kind.IMAGE || it.kind == Kind.RECT }),
                        wpx.toFloat(), hpx.toFloat(), ppm)
                    val blurred = Blur.gaussian(shot)
                    shot.recycle()
                    val saved = store.saveBitmap(blurred, prefix = "blur-")
                    blurred.recycle()
                    saved
                }.getOrNull()
            } ?: return@launch
            val project = current ?: return@launch
            val (pw, ph) = project.format.size(target)
            val b = Bitmaps.get(path)
            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
            val layer = Layer(
                kind = Kind.IMAGE, path = path, x = 0.5f, y = 0.5f, rot = 0f,
                widthMm = max(pw, ph * aspect), alpha = 1f
            )
            updatePanel(target, "blurred-front-$target") { data ->
                data.copy(layers = listOf(layer) + data.layers.filterNot { isGenerated(it) })
            }
            panel = target
            selected = layer.id
        }
    }

    /**
     * «Палитра с лица»: самый частый цвет лицевой стороны занимает ~85% панели, остальные цвета обложки
     * мягко размазаны блюром у края, противоположного корешку. Исходный фон панели (c1/c2) не трогаем —
     * при удалении слоя фон возвращается к тому, что был.
     */
    fun paletteFromFront(target: PanelId) {
        val p = current ?: return
        viewModelScope.launch {
            val saved = withContext(Dispatchers.Default) {
                runCatching {
                    val front = p.panel(PanelId.FRONT)
                    val (fw, fh) = p.format.size(PanelId.FRONT)
                    val wpx = 600
                    val ppm = wpx / fw
                    val hpx = (fh * ppm).roundToInt().coerceAtLeast(1)
                    val shot = Bitmap.createBitmap(wpx, hpx, Bitmap.Config.ARGB_8888)
                    drawPanel(Canvas(shot), front.copy(layers = front.layers.filter { it.kind == Kind.IMAGE || it.kind == Kind.RECT }),
                        wpx.toFloat(), hpx.toFloat(), ppm)
                    val sw = Palette.extract(shot, plain = true)
                    shot.recycle()
                    if (sw.isEmpty()) return@runCatching null
                    val (pw, ph) = p.format.size(target)
                    val k = 1200f / max(pw, ph)
                    // корешок и трей-оборот: «дальний от корешка» край — нижний; у обычного оборота корешок справа, значит дальний — левый
                    val far = if (target == PanelId.BACK && !p.format.tray) Palette.Far.LEFT else Palette.Far.BOTTOM
                    val bmp = Palette.renderDominant(sw, (pw * k).roundToInt().coerceAtLeast(8), (ph * k).roundToInt().coerceAtLeast(8), far)
                    val path = store.saveBitmap(bmp, prefix = "blur-")
                    bmp.recycle()
                    path
                }.getOrNull()
            } ?: return@launch
            val (pw, ph) = p.format.size(target)
            val b = Bitmaps.get(saved)
            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else pw / ph
            val layer = Layer(kind = Kind.IMAGE, path = saved, x = 0.5f, y = 0.5f, rot = 0f, widthMm = max(pw, ph * aspect))
            updatePanel(target, "palette-front-$target") { d ->
                d.copy(layers = listOf(layer) + d.layers.filterNot { isGenerated(it) })
            }
            panel = target
            selected = null
        }
    }

    /**
     * Перенос цвета с лица на оборот/корешок (см. [ColorTransfer]). Режим TONE — рабочий по умолчанию,
     * REINHARD — хук на второй режим (в интерфейсе пока не выведен).
     */
    fun applyColorTransfer(target: PanelId, mode: ColorTransfer.Mode = ColorTransfer.Mode.TONE) {
        val p = current ?: return
        if (target == PanelId.FRONT || target == PanelId.DISC) return
        viewModelScope.launch {
            val res = withContext(Dispatchers.Default) {
                runCatching {
                    val front = p.panel(PanelId.FRONT)
                    val (fw, fh) = p.format.size(PanelId.FRONT)
                    val ppmF = 600f / fw
                    val shot = Bitmap.createBitmap(600, (fh * ppmF).roundToInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                    drawPanel(Canvas(shot), front.copy(layers = front.layers.filter { it.kind == Kind.IMAGE || it.kind == Kind.RECT }),
                        shot.width.toFloat(), shot.height.toFloat(), ppmF)
                    val scheme = ColorTransfer.extractScheme(shot)
                    val (pw, ph) = p.format.size(target)
                    val k = 1000f / max(pw, ph)
                    val w = (pw * k).roundToInt().coerceAtLeast(8)
                    val h = (ph * k).roundToInt().coerceAtLeast(8)
                    val own = p.panel(target)
                    val userImages = own.layers.filter { it.kind == Kind.IMAGE && !isGenerated(it) }
                    val bmp: Bitmap = if (target == PanelId.SPINE) {
                        // стык по цвету: с оборотом и с реальным краем лица
                        val back = p.panel(PanelId.BACK)
                        val left = samplePanelEdge(back, p.format.backW, p.format.backH, p.format.backW, p.format.backH / 2f)
                        val right = if (p.format.tray) left
                            else samplePanelEdge(front, p.format.frontW, p.format.frontH, 0f, p.format.frontH / 2f)
                        ColorTransfer.spineBlend(left, right, w, h)
                    } else {
                        val templ: Bitmap? = if (userImages.isEmpty() && mode == ColorTransfer.Mode.TONE) null else {
                            val t = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            drawPanel(Canvas(t), own.copy(layers = own.layers.filter { (it.kind == Kind.IMAGE && !isGenerated(it)) || it.kind == Kind.RECT }),
                                w.toFloat(), h.toFloat(), w / pw)
                            t
                        }
                        if (mode == ColorTransfer.Mode.REINHARD && templ != null) {
                            ColorTransfer.reinhard(templ, shot).also { templ.recycle() }
                        } else ColorTransfer.tone(scheme, w, h, templ).also { templ?.recycle() }
                    }
                    shot.recycle()
                    val path = store.saveBitmap(bmp, prefix = "blur-")
                    bmp.recycle()
                    if (path == null) null else path to scheme
                }.getOrNull()
            } ?: return@launch
            val (path, scheme) = res
            val (pw, ph) = p.format.size(target)
            val b = Bitmaps.get(path)
            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else pw / ph
            val layer = Layer(kind = Kind.IMAGE, path = path, x = 0.5f, y = 0.5f, rot = 0f, widthMm = max(pw, ph * aspect))
            updatePanel(target, "color-transfer-$target") { d ->
                // текст и рамки, которые плохо читаются на новом фоне, перекрашиваются (WCAG ≥ 4.5:1)
                val fixed = d.layers.filterNot { isGenerated(it) }.map { l ->
                    var n = l
                    if (n.kind == Kind.TEXT && ColorTransfer.contrast(n.color, scheme.bg) < 4.5f) n = n.copy(color = scheme.text)
                    if (n.frame != 0 && ColorTransfer.contrast(n.frameColor, scheme.bg) < 3f) n = n.copy(frameColor = scheme.accentText)
                    n
                }
                d.copy(layers = listOf(layer) + fixed)
            }
            panel = target
            selected = null
        }
    }

    /**
     * Единый фон оборота и корешка: одна непрерывная картинка (оборот + корешок), разрезанная по панелям, —
     * на сгибе нет шва, будто корешок продолжает оборот. Лицо не копируется: берутся только его цвета
     * (доминантный, вторичный и акцентный), а правый край плавно подходит к реальному цвету края лица.
     */
    fun unifyBackAndSpine() {
        val p = current ?: return
        viewModelScope.launch {
            class Out(val path: String, val scheme: ColorTransfer.Scheme)
            val res = withContext(Dispatchers.Default) {
                runCatching {
                    val f = p.format
                    val front = p.panel(PanelId.FRONT)
                    val ppmF = 600f / f.frontW
                    val shot = Bitmap.createBitmap(600, (f.frontH * ppmF).roundToInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                    drawPanel(Canvas(shot), front.copy(layers = front.layers.filter { it.kind == Kind.IMAGE || it.kind == Kind.RECT }),
                        shot.width.toFloat(), shot.height.toFloat(), ppmF)
                    val sc = ColorTransfer.extractScheme(shot)
                    shot.recycle()
                    // полоса: [оборот | корешок]; у трея (CD) — только оборот, края которого совпадают с цветом корешка
                    val totalMm = if (f.tray) f.backW else f.backW + f.spineW
                    val k = 1400f / max(totalMm, f.backH)
                    val w = (totalMm * k).roundToInt().coerceAtLeast(16)
                    val h = (f.backH * k).roundToInt().coerceAtLeast(16)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val cv = Canvas(bmp)
                    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                    if (f.tray) {
                        val mid = androidx.core.graphics.ColorUtils.blendARGB(sc.bg, sc.bg2, 0.45f)
                        paint.shader = android.graphics.LinearGradient(0f, 0f, w.toFloat(), 0f,
                            intArrayOf(sc.bg, mid, sc.bg), floatArrayOf(0f, 0.5f, 1f), android.graphics.Shader.TileMode.CLAMP)
                    } else {
                        val edge = avgColor(intArrayOf(
                            samplePanelEdge(front, f.frontW, f.frontH, 0f, f.frontH * 0.2f),
                            samplePanelEdge(front, f.frontW, f.frontH, 0f, f.frontH * 0.5f),
                            samplePanelEdge(front, f.frontW, f.frontH, 0f, f.frontH * 0.8f)))
                        paint.shader = android.graphics.LinearGradient(0f, 0f, w.toFloat(), 0f,
                            intArrayOf(sc.bg2, sc.bg, edge), floatArrayOf(0f, 0.6f, 1f), android.graphics.Shader.TileMode.CLAMP)
                    }
                    cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
                    // мягкие цветовые пятна, чтобы фон не был плоским градиентом
                    fun blob(cx: Float, cy: Float, r: Float, color: Int, a: Float) {
                        val c = color and 0x00FFFFFF
                        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            shader = android.graphics.RadialGradient(cx, cy, r,
                                c or ((a * 255).toInt() shl 24), c, android.graphics.Shader.TileMode.CLAMP)
                        })
                    }
                    blob(w * 0.30f, h * 0.18f, max(w, h) * 0.55f, sc.accent, 0.20f)
                    blob(w * 0.55f, h * 0.92f, max(w, h) * 0.60f, sc.secondary, 0.22f)
                    val out = Blur.gaussian(bmp, sigmaFrac = 0.03f)
                    bmp.recycle()
                    val path = store.saveBitmap(out, prefix = "blur-")
                    out.recycle()
                    if (path == null) null else Out(path, sc)
                }.getOrNull()
            } ?: return@launch
            val f = p.format
            val totalMm = if (f.tray) f.backW else f.backW + f.spineW
            fun recolor(d: PanelData, img: Layer): PanelData = d.copy(layers = listOf(img) + d.layers.filterNot { isGenerated(it) }.map { l ->
                var n = l
                if (n.kind == Kind.TEXT && ColorTransfer.contrast(n.color, res.scheme.bg) < 4.5f) n = n.copy(color = res.scheme.text)
                n
            })
            // одна и та же картинка стоит в обеих панелях со сдвигом: шва на сгибе нет
            val backImg = Layer(kind = Kind.IMAGE, path = res.path, y = 0.5f, x = (totalMm / 2f) / f.backW, widthMm = totalMm)
            val spineImg = if (f.tray)
                Layer(kind = Kind.IMAGE, path = res.path, y = 0.5f, x = (totalMm / 2f) / f.spineW, widthMm = totalMm)
            else Layer(kind = Kind.IMAGE, path = res.path, y = 0.5f, x = (totalMm / 2f - f.backW) / f.spineW, widthMm = totalMm)
            edit("unify-back-spine") { pr ->
                pr.copy(panels = pr.panels +
                    (PanelId.BACK to recolor(pr.panel(PanelId.BACK), backImg)) +
                    (PanelId.SPINE to recolor(pr.panel(PanelId.SPINE), spineImg)))
            }
            panel = PanelId.BACK
            selected = null
        }
    }

    private fun renderPanelBmp(p: Project, id: PanelId, ppm: Float): Bitmap {
        val (w, h) = p.format.size(id)
        val b = Bitmap.createBitmap((w * ppm).roundToInt().coerceAtLeast(1), (h * ppm).roundToInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        drawPanel(Canvas(b), p.panel(id), b.width.toFloat(), b.height.toFloat(), ppm)
        return b
    }

    /** Средний цвет узкой полосы у края панели для каждой из [rows] строк. */
    private fun edgeColors(b: Bitmap, fromRight: Boolean, rows: Int): IntArray {
        val w = b.width
        val h = b.height
        val sw = minOf(w, 2)
        val px = IntArray(sw * h)
        b.getPixels(px, 0, sw, if (fromRight) w - sw else 0, 0, sw, h)
        return IntArray(rows) { y ->
            val sy = (y.toLong() * h / rows).toInt().coerceIn(0, h - 1)
            var r = 0; var g = 0; var bl = 0
            for (x in 0 until sw) {
                val c = px[sy * sw + x]
                r += (c shr 16) and 255; g += (c shr 8) and 255; bl += c and 255
            }
            (0xFF shl 24) or ((r / sw) shl 16) or ((g / sw) shl 8) or (bl / sw)
        }
    }

    private fun avgColor(a: IntArray): Int {
        var r = 0L; var g = 0L; var b = 0L
        for (c in a) { r += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255 }
        val n = a.size.coerceAtLeast(1)
        return (0xFF shl 24) or ((r / n).toInt() shl 16) or ((g / n).toInt() shl 8) or (b / n).toInt()
    }

    /** Корешок: цвета краёв оборота и лица (построчно, со сглаживанием) плавно перетекают друг в друга. */
    fun spineFromNeighbors() {
        val p = current ?: return
        viewModelScope.launch {
            val res = withContext(Dispatchers.Default) {
                runCatching {
                    val f = p.format
                    val ppm = 4f
                    val back = renderPanelBmp(p, PanelId.BACK, ppm)
                    val rows = back.height
                    val left: IntArray
                    val right: IntArray
                    if (!f.tray) {
                        val front = renderPanelBmp(p, PanelId.FRONT, ppm)
                        left = edgeColors(back, true, rows)
                        right = edgeColors(front, false, rows)
                        front.recycle()
                    } else {
                        val a = edgeColors(back, false, rows)
                        val b = edgeColors(back, true, rows)
                        left = IntArray(rows) { androidx.core.graphics.ColorUtils.blendARGB(a[it], b[it], 0.5f) }
                        right = left
                    }
                    back.recycle()
                    val lh = left.copyOf(); val rh = right.copyOf()
                    Blur.blurPixels(lh, 1, rows, rows * 0.02f)     // мягкий цвет внутри корешка
                    Blur.blurPixels(left, 1, rows, rows * 0.004f)  // точный цвет на самом стыке
                    Blur.blurPixels(right, 1, rows, rows * 0.004f)
                    val sw = (rows * f.spineW / f.backH).roundToInt().coerceAtLeast(8)
                    val fc = (rows * 5f / f.backH).roundToInt().coerceAtLeast(4)   // растушёвка 5 мм за краями корешка
                    val tw = sw + 2 * fc
                    val px = IntArray(tw * rows)
                    fun mix(a: Int, b: Int, t: Float) = androidx.core.graphics.ColorUtils.blendARGB(a, b, t.coerceIn(0f, 1f))
                    for (x in 0 until tw) {
                        for (y in 0 until rows) {
                            val c: Int
                            var alpha = 1f
                            if (x < fc) {
                                c = left[y]
                                val u = (fc - x - 0.5f) / fc
                                alpha = 1f - u * u * (3f - 2f * u)
                            } else if (x >= fc + sw) {
                                c = right[y]
                                val u = (x - fc - sw + 0.5f) / fc
                                alpha = 1f - u * u * (3f - 2f * u)
                            } else {
                                val t = (x - fc + 0.5f) / sw
                                val lc = mix(left[y], lh[y], t * 4f)
                                val rc = mix(right[y], rh[y], (1f - t) * 4f)
                                c = mix(lc, rc, t * t * (3f - 2f * t))
                            }
                            px[y * tw + x] = ((alpha * 255f).roundToInt().coerceIn(0, 255) shl 24) or (c and 0x00FFFFFF)
                        }
                    }
                    val bmp = Bitmap.createBitmap(px, tw, rows, Bitmap.Config.ARGB_8888)
                    val saved = store.saveBitmap(bmp, png = true, prefix = "spine-$fc-$sw-")
                    bmp.recycle()
                    val l2 = lh; val r2 = rh
                    if (saved == null) null else SpineRes(saved, avgColor(l2), avgColor(r2), tw * f.backH / rows)
                }.getOrNull()
            } ?: return@launch
            val layer = Layer(kind = Kind.IMAGE, path = res.path, x = 0.5f, y = 0.5f, rot = 0f, widthMm = res.widthMm)
            updatePanel(PanelId.SPINE, "spine-blend") { d ->
                d.copy(layers = listOf(layer) + d.layers.filterNot { isGenerated(it) })
            }
            panel = PanelId.SPINE
            selected = null
        }
    }

    fun checkUpdate(manual: Boolean) {
        if (checking) return
        viewModelScope.launch {
            checking = true
            if (manual) updateMsg = null
            val u = Updater.check()
            update = u
            if (manual) updateMsg = if (u == null) "У вас последняя версия" else null
            checking = false
        }
    }

    fun downloadAndInstall() {
        val u = update ?: return
        if (progress != null) return
        viewModelScope.launch {
            progress = 0f
            updateMsg = null
            val f = Updater.download(getApplication(), u) { progress = it }
            progress = null
            if (f == null) {
                updateMsg = "Не удалось скачать обновление"
            } else if (!Updater.install(getApplication(), f)) {
                updateMsg = "Разрешите установку из этого источника и нажмите «Обновить» ещё раз"
            }
        }
    }
}
