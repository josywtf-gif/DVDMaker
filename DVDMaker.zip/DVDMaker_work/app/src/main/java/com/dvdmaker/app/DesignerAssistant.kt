package com.dvdmaker.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class DesignerPalette(val name: String, val colors: List<Int>)

/** Локальные эвристики помощника. Не вызывает сеть/модель и никогда не меняет проект при анализе. */
private object DesignerAdvice {
    fun palettes(project: Project, panel: PanelId): List<DesignerPalette> {
        val layers = project.panel(panel).layers
        val source = layers.firstOrNull { it.visible && it.kind == Kind.IMAGE && it.path.isNotBlank() }
            ?: project.panel(PanelId.FRONT).layers.firstOrNull { it.visible && it.kind == Kind.IMAGE && it.path.isNotBlank() }
        val extracted = source?.let { layer -> runCatching { ImageProcessingPipeline.previewBitmap(layer)?.let { Palette.extract(it, 6) } }.getOrNull() }
            .orEmpty().map { it.color }
        val base = extracted.ifEmpty { listOf(0xFF24344D.toInt(), 0xFF527A9B.toInt(), 0xFFE5C58A.toInt(), 0xFFF4F0E8.toInt()) }
        val dark = base.map { androidx.core.graphics.ColorUtils.blendARGB(it, android.graphics.Color.BLACK, .34f) }
        val light = base.map { androidx.core.graphics.ColorUtils.blendARGB(it, android.graphics.Color.WHITE, .28f) }
        return listOf(
            DesignerPalette("По изображению", base),
            DesignerPalette("Кинематографичная", dark),
            DesignerPalette("Светлая", light)
        )
    }

    fun balance(project: Project, panel: PanelId): List<String> {
        val layers = project.panel(panel).layers.filter { it.visible }
        if (layers.isEmpty()) return listOf("На панели пока нет видимых слоёв.")
        val notes = mutableListOf<String>()
        val texts = layers.filter { it.kind == Kind.TEXT }
        val images = layers.filter { it.kind == Kind.IMAGE }
        val locked = layers.count { it.locked }
        if (texts.isEmpty()) notes += "Добавьте главный заголовок: он задаст визуальную иерархию."
        if (images.size > 1 && images.map { it.x }.maxOrNull()!! - images.map { it.x }.minOrNull()!! > .65f)
            notes += "Изображения сильно разнесены по ширине — проверьте равновесие левой и правой частей."
        if (texts.size > 1 && texts.map { it.sizeMm }.maxOrNull()!! / texts.map { it.sizeMm }.minOrNull()!!.coerceAtLeast(.1f) < 1.25f)
            notes += "Кегли заголовков близки: выделите один главный уровень типографики."
        if (layers.any { it.x !in .06f.. .94f || it.y !in .06f.. .94f })
            notes += "Некоторые объекты близко к краю — проверьте безопасную зону печати."
        if (locked > 0) notes += "$locked заблокированных слоя(ёв) помощник не будет перемещать."
        if (notes.isEmpty()) notes += "Композиция выглядит сбалансированной по базовым геометрическим признакам."
        return notes
    }
}

@Composable
fun DesignerAssistantDialog(vm: AppVm, project: Project, onDismiss: () -> Unit) {
    val panel = vm.panel
    val paletteOptions = remember(project, panel) { DesignerAdvice.palettes(project, panel) }
    val advice = remember(project, panel) { DesignerAdvice.balance(project, panel) }
    val layers = project.panel(panel).layers.filter { it.visible }
    val selectedText = layers.firstOrNull { it.id == vm.selected && it.kind == Kind.TEXT }
        ?: layers.filter { it.kind == Kind.TEXT && !it.locked }.maxByOrNull { it.sizeMm }
    val plans = remember(project, panel) { SmartComposition.suggest(project, panel) }
    varUnused()
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text("AI-помощник дизайнера", color = Color.White) },
        text = {
            Column(
                Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Анализ выполняется локально по слоям проекта. Никакие изменения не применяются автоматически.", color = Dim, fontSize = 12.sp)
                Text("Композиция и баланс", color = Color.White, style = MaterialTheme.typography.titleSmall)
                advice.forEach { Text("• $it", color = Dim, fontSize = 12.sp) }
                Text("Варианты композиции", color = Color.White, style = MaterialTheme.typography.titleSmall)
                if (plans.isEmpty()) Text("Добавьте слои, чтобы получить варианты.", color = Dim, fontSize = 12.sp)
                plans.take(3).forEach { plan ->
                    Surface(
                        onClick = { vm.applyComposition(plan.positions) },
                        color = Color.Transparent,
                        border = BorderStroke(1.dp, Line),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(plan.name, color = Color.White, fontSize = 13.sp)
                                Text("${plan.description} · баланс ${plan.score}/100", color = Dim, fontSize = 11.sp)
                            }
                            Text("Применить", color = Amber, fontSize = 11.sp)
                        }
                    }
                }
                Text("Цветовая гамма", color = Color.White, style = MaterialTheme.typography.titleSmall)
                paletteOptions.forEach { palette ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(palette.name, color = Dim, fontSize = 11.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            palette.colors.forEachIndexed { index, color ->
                                Surface(
                                    modifier = Modifier.size(34.dp).clickable {
                                        selectedText?.let { layer -> vm.updateLayer(layer.id, "ai-palette-${layer.id}") { it.copy(color = color) } }
                                    },
                                    color = Color(color),
                                    shape = RoundedCornerShape(8.dp),
                                    border = BorderStroke(1.dp, Color.White.copy(alpha = .25f))
                                ) {}
                            }
                        }
                    }
                }
                Text("Оформление заголовка", color = Color.White, style = MaterialTheme.typography.titleSmall)
                if (selectedText == null) Text("Добавьте текстовый слой — помощник предложит стили для него.", color = Dim, fontSize = 12.sp)
                else {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = { vm.updateLayer(selectedText.id, "ai-heading-classic") { it.copy(font = 0, italic = false, upper = true, shadow = true, textOutlineWidth = 0f, textMaterial = 0) } }) { Text("Классика") }
                        TextButton(onClick = { vm.updateLayer(selectedText.id, "ai-heading-cinema") { it.copy(italic = false, upper = true, shadow = true, textOutlineWidth = .055f, textOutlineColor = 0xFF171923.toInt(), textMaterial = 1) } }) { Text("Кино") }
                        TextButton(onClick = { vm.updateLayer(selectedText.id, "ai-heading-minimal") { it.copy(italic = false, upper = false, shadow = false, textOutlineWidth = 0f, textGlowRadius = 0f, textMaterial = 0, spacing = .04f) } }) { Text("Минимализм") }
                    }
                }
                Text("Корешок", color = Color.White, style = MaterialTheme.typography.titleSmall)
                if (project.format.spineW <= 0f) Text("В этом формате корешок не предусмотрен.", color = Dim, fontSize = 12.sp)
                else Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(onClick = { vm.switchPanel(PanelId.SPINE); vm.addText() }) { Text("Добавить вертикальный текст") }
                    TextButton(onClick = {
                        vm.switchPanel(PanelId.SPINE)
                        vm.addLayer(Layer(kind = Kind.RECT, widthMm = project.format.spineW * .72f, sizeMm = 1.2f, color = 0xFFE5C58A.toInt(), x = .5f, y = .5f, name = "Декоративная линия"))
                    }) { Text("Добавить акцент") }
                }
                Text("Изменения остаются редактируемыми слоями. Используйте Undo, чтобы отменить применённое действие.", color = Dim, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Готово") } }
    )
}

@Composable
private fun varUnused() = Unit
