package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.Matrix
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Атмосфера всего разворота: цветокор, тонировка, виньетка, снег и плёночное зерно.
 * Рисуется поверх готовой обложки, поэтому одинаково работает для любых картинок и текста.
 */
data class Fx(
    val vignette: Float = 0f,
    val tint: Int = 0xFF2E6FD0.toInt(),
    val tintAmount: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val grain: Float = 0f,
    val snow: Float = 0f,
    val snowWind: Float = 0.5f,
    val snowSeed: Int = 7,
    // Дополнительная цветокоррекция; значения по умолчанию сохраняют старые проекты.
    val exposure: Float = 0f,
    val temperature: Float = 0f,
    val hue: Float = 0f,
    val redHue: Float = 0f,
    val redSat: Float = 1f,
    val redLum: Float = 0f,
    val greenHue: Float = 0f,
    val greenSat: Float = 1f,
    val greenLum: Float = 0f,
    val blueHue: Float = 0f,
    val blueSat: Float = 1f,
    val blueLum: Float = 0f,
    val curveGamma: Float = 1f,
    val lut: Int = 0,
    val gradientTop: Int = 0xFF302B63.toInt(),
    val gradientBottom: Int = 0x00000000,
    val gradientAmount: Float = 0f,
    val brightness: Float = 0f
) {
    val hasGrade: Boolean get() =
        abs(contrast - 1f) > 0.001f || abs(saturation - 1f) > 0.001f ||
        abs(exposure) > 0.001f || abs(brightness) > 0.001f || abs(temperature) > 0.001f || abs(hue) > 0.1f ||
        lut != 0 || abs(curveGamma - 1f) > 0.001f ||
        abs(redHue) + abs(greenHue) + abs(blueHue) > 0.1f ||
        abs(redSat - 1f) + abs(greenSat - 1f) + abs(blueSat - 1f) > 0.01f ||
        abs(redLum) + abs(greenLum) + abs(blueLum) > 0.01f

    val active: Boolean
        get() = vignette > 0.001f || tintAmount > 0.001f || hasGrade || grain > 0.001f || snow > 0.001f || gradientAmount > 0.001f || hasGrade

    fun toJson(): JSONObject = JSONObject().apply {
        put("vignette", vignette.toDouble()); put("tint", tint); put("tintAmount", tintAmount.toDouble())
        put("contrast", contrast.toDouble()); put("saturation", saturation.toDouble())
        put("grain", grain.toDouble()); put("snow", snow.toDouble())
        put("snowWind", snowWind.toDouble()); put("snowSeed", snowSeed)
        put("exposure", exposure.toDouble()); put("temperature", temperature.toDouble()); put("hue", hue.toDouble())
        put("redHue", redHue.toDouble()); put("redSat", redSat.toDouble()); put("redLum", redLum.toDouble())
        put("greenHue", greenHue.toDouble()); put("greenSat", greenSat.toDouble()); put("greenLum", greenLum.toDouble())
        put("blueHue", blueHue.toDouble()); put("blueSat", blueSat.toDouble()); put("blueLum", blueLum.toDouble())
        put("curveGamma", curveGamma.toDouble()); put("lut", lut)
        put("gradientTop", gradientTop); put("gradientBottom", gradientBottom); put("gradientAmount", gradientAmount.toDouble())
        put("brightness", brightness.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject?): Fx {
            if (o == null) return Fx()
            return Fx(
                vignette = o.optDouble("vignette", 0.0).toFloat().coerceIn(0f, 1f),
                tint = o.optInt("tint", 0xFF2E6FD0.toInt()),
                tintAmount = o.optDouble("tintAmount", 0.0).toFloat().coerceIn(0f, 0.6f),
                contrast = o.optDouble("contrast", 1.0).toFloat().coerceIn(0.5f, 1.8f),
                saturation = o.optDouble("saturation", 1.0).toFloat().coerceIn(0f, 2f),
                grain = o.optDouble("grain", 0.0).toFloat().coerceIn(0f, 1f),
                snow = o.optDouble("snow", 0.0).toFloat().coerceIn(0f, 1f),
                snowWind = o.optDouble("snowWind", 0.5).toFloat().coerceIn(0f, 1f),
                snowSeed = o.optInt("snowSeed", 7),
                exposure = o.optDouble("exposure", 0.0).toFloat().coerceIn(-2f, 2f),
                temperature = o.optDouble("temperature", 0.0).toFloat().coerceIn(-1f, 1f),
                hue = o.optDouble("hue", 0.0).toFloat().coerceIn(-180f, 180f),
                redHue = o.optDouble("redHue", 0.0).toFloat().coerceIn(-100f, 100f),
                redSat = o.optDouble("redSat", 1.0).toFloat().coerceIn(0f, 2f),
                redLum = o.optDouble("redLum", 0.0).toFloat().coerceIn(-1f, 1f),
                greenHue = o.optDouble("greenHue", 0.0).toFloat().coerceIn(-100f, 100f),
                greenSat = o.optDouble("greenSat", 1.0).toFloat().coerceIn(0f, 2f),
                greenLum = o.optDouble("greenLum", 0.0).toFloat().coerceIn(-1f, 1f),
                blueHue = o.optDouble("blueHue", 0.0).toFloat().coerceIn(-100f, 100f),
                blueSat = o.optDouble("blueSat", 1.0).toFloat().coerceIn(0f, 2f),
                blueLum = o.optDouble("blueLum", 0.0).toFloat().coerceIn(-1f, 1f),
                curveGamma = o.optDouble("curveGamma", 1.0).toFloat().coerceIn(0.5f, 2f),
                lut = o.optInt("lut", 0).coerceIn(0, 4),
                gradientTop = o.optInt("gradientTop", 0xFF302B63.toInt()),
                gradientBottom = o.optInt("gradientBottom", 0x00000000),
                gradientAmount = o.optDouble("gradientAmount", 0.0).toFloat().coerceIn(0f, 1f),
                brightness = o.optDouble("brightness", 0.0).toFloat().coerceIn(-1f, 1f)
            )
        }
    }
}

object FxPainter {
    private var grainTile: Bitmap? = null

    fun trimMemory() {
        // Не recycle(): рендер в другом потоке может ещё использовать Shader этого bitmap.
        grainTile = null
    }

    fun gradeMatrix(fx: Fx): ColorMatrix {
        val cm = ColorMatrix()
        cm.setSaturation(fx.saturation.coerceIn(0f, 2f))
        val c = fx.contrast.coerceIn(0.5f, 1.8f)
        val exp = 255f * (2.0.pow(fx.exposure.coerceIn(-2f, 2f).toDouble()).toFloat() - 1f)
        val temp = fx.temperature.coerceIn(-1f, 1f) * 42f
        val gammaContrast = (1f / fx.curveGamma.coerceIn(0.5f, 2f))
        val lutContrast = when (fx.lut.coerceIn(0, 4)) {
            1 -> 1.12f // Teal & Orange
            2 -> 0.92f // Matte
            3 -> 1.2f  // Cinema
            4 -> 1.04f // Vintage
            else -> 1f
        }
        val k = c * gammaContrast * lutContrast
        val offset = 128f * (1f - k) + exp + fx.brightness.coerceIn(-1f, 1f) * 255f
        cm.postConcat(ColorMatrix(floatArrayOf(
            k, 0f, 0f, 0f, offset + temp,
            0f, k, 0f, 0f, offset + temp * 0.08f,
            0f, 0f, k, 0f, offset - temp,
            0f, 0f, 0f, 1f, 0f
        )))
        if (abs(fx.hue) > 0.1f) cm.postConcat(hueMatrix(fx.hue))
        // Канальные HSL-параметры представлены независимыми RGB-кривыми.
        val rh = fx.redHue.coerceIn(-100f, 100f) * 0.35f
        val gh = fx.greenHue.coerceIn(-100f, 100f) * 0.35f
        val bh = fx.blueHue.coerceIn(-100f, 100f) * 0.35f
        val rs = fx.redSat.coerceIn(0f, 2f); val gs = fx.greenSat.coerceIn(0f, 2f); val bs = fx.blueSat.coerceIn(0f, 2f)
        val rl = fx.redLum.coerceIn(-1f, 1f) * 100f
        val gl = fx.greenLum.coerceIn(-1f, 1f) * 100f
        val bl = fx.blueLum.coerceIn(-1f, 1f) * 100f
        if (abs(rh)+abs(gh)+abs(bh)+abs(rs-1f)+abs(gs-1f)+abs(bs-1f)+abs(rl)+abs(gl)+abs(bl) > 0.001f) {
            cm.postConcat(ColorMatrix(floatArrayOf(
                rs, rh * 0.15f, 0f, 0f, rl,
                0f, gs, gh * 0.15f, 0f, gl,
                bh * 0.15f, 0f, bs, 0f, bl,
                0f, 0f, 0f, 1f, 0f
            )))
        }
        return cm
    }

    /** Цветокор отдельной фотографии: оттенок, насыщенность, контраст/яркость, температура и полная перекраска. */
    fun imageMatrix(l: Layer): ColorMatrix {
        val cm = ColorMatrix()
        if (l.imgColorize > 0.001f) {
            // Перекраска: яркость сохраняется, цвет заменяется выбранным (дуотон тёмный → цвет → светлый).
            val r = Color.red(l.imgColorizeColor) / 255f
            val g = Color.green(l.imgColorizeColor) / 255f
            val b = Color.blue(l.imgColorizeColor) / 255f
            val lum = floatArrayOf(0.299f, 0.587f, 0.114f)
            val full = ColorMatrix(floatArrayOf(
                lum[0] * r * 2f, lum[1] * r * 2f, lum[2] * r * 2f, 0f, 0f,
                lum[0] * g * 2f, lum[1] * g * 2f, lum[2] * g * 2f, 0f, 0f,
                lum[0] * b * 2f, lum[1] * b * 2f, lum[2] * b * 2f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))
            val k = l.imgColorize.coerceIn(0f, 1f)
            val id = ColorMatrix().array
            val mix = FloatArray(20) { id[it] * (1f - k) + full.array[it] * k }
            cm.set(mix)
        }
        if (abs(l.imgHue) > 0.5f) cm.postConcat(hueMatrix(l.imgHue))
        if (abs(l.imgSat - 1f) > 0.001f) cm.postConcat(ColorMatrix().apply { setSaturation(l.imgSat.coerceIn(0f, 2.5f)) })
        val c = l.imgContrast.coerceIn(0.5f, 1.8f)
        val t = 128f * (1f - c) + l.imgBright.coerceIn(-0.6f, 0.6f) * 255f
        val tw = l.imgTemp.coerceIn(-1f, 1f) * 40f
        cm.postConcat(ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t + tw,
            0f, c, 0f, 0f, t + tw * 0.1f,
            0f, 0f, c, 0f, t - tw,
            0f, 0f, 0f, 1f, 0f
        )))
        return cm
    }

    /** Поворот оттенка на [deg] градусов (сохраняет яркость). */
    private fun hueMatrix(deg: Float): ColorMatrix {
        val a = Math.toRadians(deg.toDouble())
        val cs = kotlin.math.cos(a).toFloat()
        val sn = kotlin.math.sin(a).toFloat()
        val lr = 0.213f; val lg = 0.715f; val lb = 0.072f
        return ColorMatrix(floatArrayOf(
            lr + cs * (1 - lr) + sn * (-lr), lg + cs * (-lg) + sn * (-lg), lb + cs * (-lb) + sn * (1 - lb), 0f, 0f,
            lr + cs * (-lr) + sn * 0.143f, lg + cs * (1 - lg) + sn * 0.140f, lb + cs * (-lb) + sn * (-0.283f), 0f, 0f,
            lr + cs * (-lr) + sn * (-(1 - lr)), lg + cs * (-lg) + sn * lg, lb + cs * (1 - lb) + sn * lb, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    /** Области, к которым применяются оверлеи: весь разворот или (для трея) лицо и трей отдельно. */
    private fun areas(places: List<Place>, ox: Float, oy: Float, ppm: Float, tray: Boolean): List<RectF> {
        fun union(list: List<Place>): RectF? {
            if (list.isEmpty()) return null
            return RectF(
                (ox + list.minOf { it.x }) * ppm, (oy + list.minOf { it.y }) * ppm,
                (ox + list.maxOf { it.x + it.w }) * ppm, (oy + list.maxOf { it.y + it.h }) * ppm
            )
        }
        return if (tray) {
            listOfNotNull(union(places.filter { it.id == PanelId.FRONT }), union(places.filter { it.id != PanelId.FRONT }))
        } else listOfNotNull(union(places))
    }

    fun drawOverlays(c: Canvas, fx: Fx, places: List<Place>, ox: Float, oy: Float, ppm: Float, tray: Boolean) {
        val areas = areas(places, ox, oy, ppm, tray)

        if (fx.tintAmount > 0.001f) {
            val p = Paint().apply {
                color = fx.tint
                alpha = (fx.tintAmount.coerceIn(0f, 1f) * 255f).roundToInt()
                xfermode = PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
            }
            for (r in areas) c.drawRect(r, p)
        }

        if (fx.gradientAmount > 0.001f) {
            val p = Paint().apply {
                alpha = (fx.gradientAmount.coerceIn(0f, 1f) * 255f).roundToInt()
                xfermode = PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
            }
            for (r in areas) {
                p.shader = LinearGradient(r.left, r.top, r.left, r.bottom,
                    intArrayOf(fx.gradientTop, fx.gradientBottom), null, Shader.TileMode.CLAMP)
                c.drawRect(r, p)
            }
        }

        if (fx.vignette > 0.001f) {
            for (pl in places) {
                if (pl.id == PanelId.SPINE || pl.id == PanelId.DISC) continue
                val r = RectF((ox + pl.x) * ppm, (oy + pl.y) * ppm, (ox + pl.x + pl.w) * ppm, (oy + pl.y + pl.h) * ppm)
                vignette(c, r, fx.vignette)
            }
        }

        if (fx.snow > 0.001f) for (r in areas) snow(c, r, fx, ppm)

        if (fx.grain > 0.001f) {
            val tile = grainTile ?: makeGrain().also { grainTile = it }
            val sh = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
            val s = maxOf(1f, ppm * 0.12f)
            sh.setLocalMatrix(Matrix().apply { setScale(s, s) })
            val p = Paint().apply {
                shader = sh
                alpha = (fx.grain.coerceIn(0f, 1f) * 0.32f * 255f).roundToInt()
            }
            for (r in areas) c.drawRect(r, p)
        }
    }

    private fun vignette(c: Canvas, r: RectF, amount: Float) {
        val a = amount.coerceIn(0f, 1f)
        val colors = intArrayOf(
            0x00000000, 0x00000000,
            Color.argb((255f * a * 0.55f).roundToInt(), 0, 0, 0),
            Color.argb((255f * a * 0.92f).roundToInt(), 0, 0, 0)
        )
        val stops = floatArrayOf(0f, 0.45f, 0.8f, 1f)
        val shader = RadialGradient(0f, 0f, 1f, colors, stops, Shader.TileMode.CLAMP)
        shader.setLocalMatrix(Matrix().apply {
            setScale(r.width() * 0.72f, r.height() * 0.72f)
            postTranslate(r.centerX(), r.centerY())
        })
        val p = Paint().apply { this.shader = shader }
        c.save()
        c.clipRect(r)
        c.drawRect(r, p)
        c.restore()
    }

    /** Снегопад: короткие штрихи под углом ветра; положения детерминированы, поэтому превью и экспорт совпадают. */
    private fun snow(c: Canvas, r: RectF, fx: Fx, ppm: Float) {
        val rnd = java.util.Random(fx.snowSeed.toLong())
        val areaMm2 = r.width() * r.height() / (ppm * ppm)
        val count = (areaMm2 * 0.035f * fx.snow).toInt().coerceIn(0, 4500)
        var dx = -(0.3f + fx.snowWind * 1.2f)
        var dy = 0.6f
        val norm = sqrt(dx * dx + dy * dy)
        dx /= norm; dy /= norm
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        c.save()
        c.clipRect(r)
        for (i in 0 until count) {
            val x = r.left + rnd.nextFloat() * r.width()
            val y = r.top + rnd.nextFloat() * r.height()
            val depth = rnd.nextFloat()
            val d2 = depth * depth
            val radius = (0.10f + d2 * 0.85f) * ppm
            val len = radius * (1.5f + fx.snowWind * 5f) * (0.6f + rnd.nextFloat() * 0.8f)
            val a = (40f + d2 * 215f).roundToInt().coerceIn(0, 255)
            if (d2 > 0.6f) {
                p.alpha = a / 4
                p.strokeWidth = radius * 4.2f
                c.drawLine(x, y, x + dx * len, y + dy * len, p)
            }
            p.alpha = a
            p.strokeWidth = radius * 2f
            c.drawLine(x, y, x + dx * len, y + dy * len, p)
        }
        c.restore()
    }

    private fun makeGrain(): Bitmap {
        val n = 128
        val rnd = java.util.Random(99)
        val px = IntArray(n * n) {
            val v = rnd.nextInt(256)
            if (rnd.nextBoolean()) Color.argb(v, 255, 255, 255) else Color.argb(v, 0, 0, 0)
        }
        return Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }
}
