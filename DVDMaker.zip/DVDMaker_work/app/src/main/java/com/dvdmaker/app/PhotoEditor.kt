package com.dvdmaker.app

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private val PhotoEditorOrange = Violet

internal data class PhotoViewportTransform(val scale: Float, val offset: Offset)

internal data class CropSelection(val left: Float = 0f, val top: Float = 0f, val right: Float = 1f, val bottom: Float = 1f) {
    val width get() = right - left
    val height get() = bottom - top
}

internal enum class CropHandle { TOP_LEFT, TOP, TOP_RIGHT, RIGHT, BOTTOM_RIGHT, BOTTOM, BOTTOM_LEFT, LEFT, MOVE, PAN, PINCH }

/** Immutable editor-local checkpoint. These values are drafts until the user taps Save. */
internal data class PhotoEditorDraftState(
    val crop: CropSelection = CropSelection(),
    val rotation: Float = 0f,
    val perspectiveVertical: Float = 0f,
    val perspectiveHorizontal: Float = 0f,
    val mirrorHorizontal: Boolean = false,
    val mirrorVertical: Boolean = false,
    val scale: Float = 1f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val perspectiveQuad: List<Offset> = listOf(Offset(0f, 0f), Offset(1f, 0f), Offset(1f, 1f), Offset(0f, 1f))
)

internal fun appendPhotoEditorHistory(
    history: List<PhotoEditorDraftState>, cursor: Int, next: PhotoEditorDraftState, limit: Int = 50
): Pair<List<PhotoEditorDraftState>, Int> {
    val prefix = history.take((cursor + 1).coerceIn(0, history.size))
    val appended = prefix + next
    val trimmed = if (appended.size > limit + 1) appended.drop(appended.size - (limit + 1)) else appended
    return trimmed to (trimmed.lastIndex)
}

internal fun transformPhotoViewport(
    currentScale: Float,
    currentOffset: Offset,
    centroid: Offset,
    pan: Offset,
    zoomChange: Float,
    viewport: IntSize,
    imageWidth: Int,
    imageHeight: Int
): PhotoViewportTransform {
    if (viewport.width <= 0 || viewport.height <= 0 || imageWidth <= 0 || imageHeight <= 0) {
        return PhotoViewportTransform(currentScale, currentOffset)
    }
    val nextScale = (currentScale * zoomChange).coerceIn(1f, 8f)
    val center = Offset(viewport.width / 2f, viewport.height / 2f)
    val effectiveZoom = nextScale / currentScale.coerceAtLeast(0.001f)
    val focal = centroid - center
    val raw = currentOffset * effectiveZoom + focal * (1f - effectiveZoom) + pan
    val fit = min(viewport.width / imageWidth.toFloat(), viewport.height / imageHeight.toFloat())
    val fittedWidth = imageWidth * fit
    val fittedHeight = imageHeight * fit
    val maxX = max(0f, (fittedWidth * nextScale - viewport.width) / 2f)
    val maxY = max(0f, (fittedHeight * nextScale - viewport.height) / 2f)
    return PhotoViewportTransform(nextScale, Offset(raw.x.coerceIn(-maxX, maxX), raw.y.coerceIn(-maxY, maxY)))
}

private fun Float.clampTo(lo: Float, hi: Float) = if (hi < lo) lo else coerceIn(lo, hi)

internal fun updateCropSelection(
    crop: CropSelection,
    handle: CropHandle,
    deltaX: Float,
    deltaY: Float,
    minSize: Float = 0.05f,
    boundLeft: Float = 0f,
    boundTop: Float = 0f,
    boundRight: Float = 1f,
    boundBottom: Float = 1f
): CropSelection {
    val minW = minSize.coerceIn(0.001f, 0.49f)
    val minH = minSize.coerceIn(0.001f, 0.49f)
    var l = crop.left; var t = crop.top; var r = crop.right; var b = crop.bottom
    when (handle) {
        CropHandle.TOP_LEFT -> { l = (l + deltaX).clampTo(boundLeft, r - minW); t = (t + deltaY).clampTo(boundTop, b - minH) }
        CropHandle.TOP -> t = (t + deltaY).clampTo(boundTop, b - minH)
        CropHandle.TOP_RIGHT -> { r = (r + deltaX).clampTo(l + minW, boundRight); t = (t + deltaY).clampTo(boundTop, b - minH) }
        CropHandle.RIGHT -> r = (r + deltaX).clampTo(l + minW, boundRight)
        CropHandle.BOTTOM_RIGHT -> { r = (r + deltaX).clampTo(l + minW, boundRight); b = (b + deltaY).clampTo(t + minH, boundBottom) }
        CropHandle.BOTTOM -> b = (b + deltaY).clampTo(t + minH, boundBottom)
        CropHandle.BOTTOM_LEFT -> { l = (l + deltaX).clampTo(boundLeft, r - minW); b = (b + deltaY).clampTo(t + minH, boundBottom) }
        CropHandle.LEFT -> l = (l + deltaX).clampTo(boundLeft, r - minW)
        CropHandle.MOVE -> {
            val width = r - l; val height = b - t
            l = (l + deltaX).clampTo(boundLeft, boundRight - width)
            t = (t + deltaY).clampTo(boundTop, boundBottom - height)
            r = l + width; b = t + height
        }
        else -> Unit
    }
    return CropSelection(l, t, r, b)
}

/**
 * Append a crop relative to the materialized preview shown in PhotoEditor.
 * Earlier crop/geometry/effect nodes remain untouched and keep their original order.
 */
internal fun applyCropSelection(layer: Layer, selection: CropSelection): Layer {
    val normalized = sanitizeCropSelection(selection)
    if (normalized == CropSelection()) return layer

    // The editor selection is relative to the materialized preview. Legacy Layer crop is
    // projected after persisted operations, so adding the first stable crop suppresses that
    // projection. Fold those legacy bounds into the new operation to preserve the exact
    // preview the user edited. If a stable crop already exists, keep it in stack order and
    // append this crop relative to its rendered output (and any operations after it).
    val hasStableCrop = layer.imageOperations.any {
        it.type == ImageOperationType.CROP && it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION
    }
    val legacyBase = if (!hasStableCrop) sanitizeCropSelection(CropSelection(
        layer.cropLeft, layer.cropTop, layer.cropRight, layer.cropBottom
    )) else CropSelection()
    val committedCrop = if (legacyBase != CropSelection()) composeCrop(legacyBase, normalized) else normalized

    // Layer-field projections remain projections; the newly persisted stable crop now
    // becomes the source of truth and prevents the old legacy crop from being replayed.
    val base = layer.imageOperations.filterNot { ImageProcessingPipeline.isLayerProjection(it) }
    val parameters = JSONObject().put("left", committedCrop.left.toDouble()).put("top", committedCrop.top.toDouble())
        .put("right", committedCrop.right.toDouble()).put("bottom", committedCrop.bottom.toDouble()).toString()
    val operation = ImageOperation(type = ImageOperationType.CROP, enabled = true, parameters = parameters)
    return ImageProcessingPipeline.recordOperation(layer.copy(imageOperations = base), operation, replaceType = false)
}

/** Commits crop and geometry as independent parameters; crop never absorbs rotation or perspective. */
internal fun applyPhotoEditorEdits(
    layer: Layer,
    selection: CropSelection,
    rotationDelta: Float,
    perspectiveVertical: Float,
    perspectiveHorizontal: Float,
    mirrorHorizontal: Boolean = false,
    mirrorVertical: Boolean = false
): Layer {
    val cropped = applyCropSelection(layer, selection)
    val nextRotation = ((layer.rot + rotationDelta) % 360f).let { if (it < 0f) it + 360f else it }
    return cropped.copy(
        rot = nextRotation,
        flipX = layer.flipX xor mirrorHorizontal,
        flipY = layer.flipY xor mirrorVertical,
        imageTiltX = (layer.imageTiltX + perspectiveVertical).coerceIn(-65f, 65f),
        imageTiltY = (layer.imageTiltY + perspectiveHorizontal).coerceIn(-65f, 65f)
    )
}

/** Crop detached from a layer so the editor can show the full original and re-edit the crop. */
internal data class DetachedCrop(val layer: Layer, val crop: CropSelection, val insertAt: Int)

private fun isCropOperation(op: ImageOperation) =
    (op.type == ImageOperationType.CROP && op.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION) ||
        op.type == ImageOperationType.LEGACY_PREFIX + "crop"

private fun relinkOperations(ops: List<ImageOperation>): List<ImageOperation> {
    var previous = ""
    return ops.map { op ->
        if (op.type.startsWith(ImageOperationType.LEGACY_PREFIX)) op
        else op.copy(inputOperationId = previous).also { previous = op.id }
    }
}

/**
 * Strips every crop from the layer (the original file is never touched) and returns the
 * combined crop as the editor's initial selection. Returns null when a bitmap/geometry
 * operation follows a crop: removing it would change that operation's input, so the editor
 * keeps the old append-only behaviour for such layers.
 */
internal fun detachCrop(layer: Layer): DetachedCrop? {
    val ops = layer.imageOperations.filterNot { ImageProcessingPipeline.isLayerProjection(it) }
    val first = ops.indexOfFirst { isCropOperation(it) }
    if (first < 0) {
        val legacy = sanitizeCropSelection(CropSelection(layer.cropLeft, layer.cropTop, layer.cropRight, layer.cropBottom))
        return DetachedCrop(
            layer.copy(cropLeft = 0f, cropTop = 0f, cropRight = 1f, cropBottom = 1f),
            if (legacy == sanitizeCropSelection(CropSelection())) CropSelection() else legacy, ops.size
        )
    }
    val blocked = ops.drop(first).any {
        !isCropOperation(it) && (it.type == ImageOperationType.ENHANCE || it.type == ImageOperationType.BACKGROUND_REMOVAL ||
            it.type == ImageOperationType.GAUSSIAN_BLUR || it.type == ImageOperationType.GEOMETRY)
    }
    if (blocked) return null
    var combined = CropSelection()
    ops.filter { isCropOperation(it) && it.enabled }.forEach { op ->
        val p = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
        val step = sanitizeCropSelection(CropSelection(
            p.optDouble("left", 0.0).toFloat(), p.optDouble("top", 0.0).toFloat(),
            p.optDouble("right", 1.0).toFloat(), p.optDouble("bottom", 1.0).toFloat()
        ))
        combined = composeCrop(combined, step)
    }
    val remaining = relinkOperations(ops.filterNot { isCropOperation(it) })
    return DetachedCrop(layer.copy(imageOperations = remaining), combined, first.coerceAtMost(remaining.size))
}

/** Puts the freshly committed crop back at the stack position the old crop had. */
internal fun restoreCropPosition(layer: Layer, insertAt: Int): Layer {
    val ops = layer.imageOperations
    val index = ops.indexOfLast { it.type == ImageOperationType.CROP && it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION }
    if (index < 0) return layer
    val target = insertAt.coerceIn(0, ops.lastIndex)
    if (index <= target) return layer
    val moved = ops.toMutableList()
    moved.add(target, moved.removeAt(index))
    return layer.copy(imageOperations = relinkOperations(moved))
}

/** Store a four-corner rectification as a non-destructive geometry node. Points are normalized TL,TR,BR,BL. */
internal fun applyPerspectiveQuad(layer: Layer, points: List<Offset>): Layer {
    if (points.size != 4 || points.any { !it.x.isFinite() || !it.y.isFinite() || it.x !in 0f..1f || it.y !in 0f..1f }) return layer
    val values = points.flatMap { listOf(it.x, it.y) }
    val quad = org.json.JSONArray().also { a -> values.forEach { a.put(it.toDouble()) } }
    // The quad is authored against the current materialized preview bitmap. Never move
    // earlier stack nodes: append a geometry node after the existing crop/effects so its
    // Matrix source coordinates are exactly the pixels shown in PhotoEditor.
    val params = JSONObject().put("perspectiveQuad", quad)
    val operation = ImageOperation(type = ImageOperationType.GEOMETRY, enabled = true, parameters = params.toString())
    return ImageProcessingPipeline.recordOperation(layer, operation, replaceType = false)
}

internal fun stepPhotoRotation(current: Float, delta: Float): Float {
    val value = (current + delta) % 360f
    return if (value > 180f) value - 360f else if (value < -180f) value + 360f else value
}

private fun sanitizeCropSelection(crop: CropSelection): CropSelection {
    val left = crop.left.coerceIn(0f, 0.95f)
    val top = crop.top.coerceIn(0f, 0.95f)
    val right = crop.right.coerceIn(left + 0.05f, 1f)
    val bottom = crop.bottom.coerceIn(top + 0.05f, 1f)
    return CropSelection(left, top, right, bottom)
}

private fun composeCrop(base: CropSelection, selection: CropSelection) = CropSelection(
    (base.left + base.width * selection.left).coerceIn(0f, 0.999f),
    (base.top + base.height * selection.top).coerceIn(0f, 0.999f),
    (base.left + base.width * selection.right).coerceIn(0.001f, 1f),
    (base.top + base.height * selection.bottom).coerceIn(0.001f, 1f)
)

private fun fittedPhotoRect(viewport: IntSize, imageWidth: Int, imageHeight: Int): Rect {
    if (viewport.width <= 0 || viewport.height <= 0 || imageWidth <= 0 || imageHeight <= 0) return Rect.Zero
    val fit = min(viewport.width / imageWidth.toFloat(), viewport.height / imageHeight.toFloat())
    val w = imageWidth * fit; val h = imageHeight * fit
    return Rect((viewport.width - w) / 2f, (viewport.height - h) / 2f,
        (viewport.width + w) / 2f, (viewport.height + h) / 2f)
}

private fun transformPhotoRect(base: Rect, scale: Float, offset: Offset, viewport: IntSize): Rect {
    val center = Offset(viewport.width / 2f, viewport.height / 2f)
    return Rect(
        center.x + (base.left - center.x) * scale + offset.x,
        center.y + (base.top - center.y) * scale + offset.y,
        center.x + (base.right - center.x) * scale + offset.x,
        center.y + (base.bottom - center.y) * scale + offset.y
    )
}

/** Crop handles are a stationary viewport window; the photograph moves/zooms beneath it. */
internal fun transformedCropRect(base: Rect, crop: CropSelection, scale: Float, offset: Offset, viewport: IntSize): Rect =
    Rect(base.left + base.width * crop.left, base.top + base.height * crop.top,
        base.left + base.width * crop.right, base.top + base.height * crop.bottom)

/** Convert the stationary crop window back into source-image coordinates after viewport zoom/pan. */
internal fun photoViewportCropSelection(base: Rect, crop: CropSelection, scale: Float, offset: Offset, viewport: IntSize): CropSelection {
    if (base.width <= 0f || base.height <= 0f || viewport.width <= 0 || viewport.height <= 0 || scale <= 0f) return crop
    val window = transformedCropRect(base, crop, scale, offset, viewport)
    val photo = transformPhotoRect(base, scale, offset, viewport)
    val left = ((window.left - photo.left) / photo.width.coerceAtLeast(1f)).coerceIn(0f, 0.95f)
    val top = ((window.top - photo.top) / photo.height.coerceAtLeast(1f)).coerceIn(0f, 0.95f)
    val right = ((window.right - photo.left) / photo.width.coerceAtLeast(1f)).coerceIn(left + 0.05f, 1f)
    val bottom = ((window.bottom - photo.top) / photo.height.coerceAtLeast(1f)).coerceIn(top + 0.05f, 1f)
    return CropSelection(left, top, right, bottom)
}

/**
 * Hit-test the full crop edge, not only a tiny midpoint handle. Corner zones are
 * reserved for the four perspective points so edge drags cannot steal corner gestures.
 */
internal fun hitCropEdge(rect: Rect, position: Offset, touchRadius: Float): CropHandle? {
    val cornerGuard = touchRadius * 1.35f
    val xInside = position.x > rect.left + cornerGuard && position.x < rect.right - cornerGuard
    val yInside = position.y > rect.top + cornerGuard && position.y < rect.bottom - cornerGuard
    return when {
        xInside && kotlin.math.abs(position.y - rect.top) <= touchRadius -> CropHandle.TOP
        yInside && kotlin.math.abs(position.x - rect.right) <= touchRadius -> CropHandle.RIGHT
        xInside && kotlin.math.abs(position.y - rect.bottom) <= touchRadius -> CropHandle.BOTTOM
        yInside && kotlin.math.abs(position.x - rect.left) <= touchRadius -> CropHandle.LEFT
        else -> null
    }
}

/** Corner perspective points are normalized to the cropped bitmap passed to Matrix.setPolyToPoly. */
internal fun updatePerspectiveCorner(points: List<Offset>, index: Int, dx: Float, dy: Float): List<Offset> {
    if (points.size != 4 || index !in 0..3) return points
    val next = points.toMutableList()
    next[index] = Offset((next[index].x + dx).coerceIn(0f, 1f), (next[index].y + dy).coerceIn(0f, 1f))
    var sign = 0
    var twiceArea = 0f
    for (i in 0..3) {
        val a = next[i]; val b = next[(i + 1) % 4]; val c = next[(i + 2) % 4]
        twiceArea += a.x * b.y - b.x * a.y
        val cross = (b.x - a.x) * (c.y - b.y) - (b.y - a.y) * (c.x - b.x)
        if (kotlin.math.abs(cross) < 0.0005f) return points
        val currentSign = if (cross > 0f) 1 else -1
        if (sign != 0 && sign != currentSign) return points
        sign = currentSign
    }
    return if (kotlin.math.abs(twiceArea) < 0.005f) points else next
}

@Composable
fun PhotoEditorScreen(
    layer: Layer,
    backdrop: BackdropLight?,
    onCancel: () -> Unit,
    onApply: (Layer) -> Unit
) {
    // This is a layer editor, not project navigation: Back leaves the photo editor
    // and returns to the still-open composition. Draft changes are discarded.
    var showDiscardConfirmation by remember(layer.id) { mutableStateOf(false) }
    BackHandler(enabled = true, onBack = { showDiscardConfirmation = true })
    DisposableEffect(layer.id) { onDispose { ImageOperationRenderer.cancelPendingPreview() } }
    // The editor always works on the full original: existing crops are detached, shown as the
    // initial frame and can be widened or reset. Saving writes one replacement crop.
    val detached = remember(layer.id) { detachCrop(layer) }
    val editLayer = detached?.layer ?: layer
    val initialCrop = detached?.crop ?: CropSelection()
    val bitmap by produceState<Bitmap?>(null, editLayer, backdrop) {
        value = withContext(Dispatchers.Default) { ImageOperationRenderer.renderPreviewBitmap(editLayer, backdrop) }
    }
    var scale by remember(layer.id) { mutableFloatStateOf(1f) }
    var offset by remember(layer.id) { mutableStateOf(Offset.Zero) }
    var viewport by remember(layer.id) { mutableStateOf(IntSize.Zero) }
    var crop by remember(layer.id) { mutableStateOf(initialCrop) }
    var cropMode by remember(layer.id) { mutableStateOf(true) }
    var rotation by remember(layer.id) { mutableFloatStateOf(0f) }
    var perspectiveVertical by remember(layer.id) { mutableFloatStateOf(0f) }
    var perspectiveHorizontal by remember(layer.id) { mutableFloatStateOf(0f) }
    var perspectiveMode by remember(layer.id) { mutableStateOf(false) }
    val defaultPerspectiveQuad = listOf(Offset(0f, 0f), Offset(1f, 0f), Offset(1f, 1f), Offset(0f, 1f))
    var perspectiveQuad by remember(layer.id) { mutableStateOf(defaultPerspectiveQuad) }
    val latestPerspectiveQuad = rememberUpdatedState(perspectiveQuad)
    var mirrorHorizontal by remember(layer.id) { mutableStateOf(false) }
    var mirrorVertical by remember(layer.id) { mutableStateOf(false) }
    val latestScale = rememberUpdatedState(scale)
    val latestOffset = rememberUpdatedState(offset)
    val latestCrop = rememberUpdatedState(crop)
    val latestCropMode = rememberUpdatedState(cropMode)
    val latestViewport = rememberUpdatedState(viewport)
    val latestBitmap = rememberUpdatedState(bitmap)

    // Explicit precision zoom is used by the tilt controls only. Crop edges and
    // perspective points never change the viewport scale; pinch remains independent.
    fun zoomForPrecision(targetScale: Float, anchor: Offset? = null) {
        val currentBitmap = bitmap ?: return
        val view = viewport
        if (view.width <= 0 || view.height <= 0) return
        val nextScale = targetScale.coerceIn(1f, 2.4f).coerceAtLeast(scale)
        if (nextScale <= scale + 0.001f) return
        val focus = anchor ?: Offset(view.width / 2f, view.height / 2f)
        val next = transformPhotoViewport(
            scale, offset, focus, Offset.Zero, nextScale / scale.coerceAtLeast(0.001f),
            view, currentBitmap.width, currentBitmap.height
        )
        scale = next.scale
        offset = next.offset
    }

    fun currentDraft() = PhotoEditorDraftState(
        crop, rotation, perspectiveVertical, perspectiveHorizontal,
        mirrorHorizontal, mirrorVertical, scale, offset.x, offset.y, perspectiveQuad
    )
    // With an existing crop the history starts at the full original, so Undo always returns to it.
    var history by remember(layer.id) {
        mutableStateOf(if (initialCrop == CropSelection()) listOf(PhotoEditorDraftState())
            else listOf(PhotoEditorDraftState(), PhotoEditorDraftState(crop = initialCrop)))
    }
    var historyCursor by remember(layer.id) { mutableStateOf(history.lastIndex) }
    fun checkpoint() {
        val snapshot = currentDraft()
        if (history.getOrNull(historyCursor) == snapshot) return
        val (nextHistory, nextCursor) = appendPhotoEditorHistory(history, historyCursor, snapshot)
        history = nextHistory
        historyCursor = nextCursor
    }
    fun restoreDraft(state: PhotoEditorDraftState) {
        crop = state.crop
        rotation = state.rotation
        perspectiveVertical = state.perspectiveVertical
        perspectiveHorizontal = state.perspectiveHorizontal
        mirrorHorizontal = state.mirrorHorizontal
        mirrorVertical = state.mirrorVertical
        scale = state.scale
        offset = Offset(state.offsetX, state.offsetY)
        perspectiveQuad = state.perspectiveQuad
    }
    fun undoDraft() {
        if (historyCursor > 0) {
            historyCursor -= 1
            restoreDraft(history[historyCursor])
        }
    }
    fun redoDraft() {
        if (historyCursor < history.lastIndex) {
            historyCursor += 1
            restoreDraft(history[historyCursor])
        }
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().background(Bg.copy(alpha = 0.96f))
                .padding(horizontal = 18.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "Назад", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(RadiusSmall))
                    .clickable { showDiscardConfirmation = true }
                    .padding(horizontal = 4.dp, vertical = 9.dp)
            )
            Text("Фото", color = Dim, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Сохранить", color = Violet, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(RadiusSmall)).clickable {
                    val sourceCrop = bitmap?.let { source ->
                        val base = fittedPhotoRect(viewport, source.width, source.height)
                        photoViewportCropSelection(base, crop, scale, offset, viewport)
                    } ?: crop
                    var result = applyPhotoEditorEdits(editLayer, sourceCrop, rotation, perspectiveVertical, perspectiveHorizontal, mirrorHorizontal, mirrorVertical)
                    if (perspectiveQuad != defaultPerspectiveQuad) result = applyPerspectiveQuad(result, perspectiveQuad)
                    if (detached != null) result = restoreCropPosition(result, detached.insertAt)
                    onApply(result)
                }.padding(horizontal = 4.dp, vertical = 9.dp)
            )
        }

        Box(
            Modifier.weight(1f).fillMaxWidth()
                // Photo editing is independent from the DVD canvas/backdrop.
                .background(Bg),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.fillMaxSize()
                    // Keep crop handles and drag starts away from Android system edge-gesture zones.
                    // Outside Crop the photo remains edge-to-edge; in Crop the image, overlay and
                    // pointer coordinates share the same 24 dp inset viewport.
                    .then(if (cropMode) Modifier.padding(horizontal = 24.dp, vertical = 24.dp) else Modifier)
                    .onSizeChanged { viewport = it }
                .pointerInput(layer.id, viewport, bitmap?.width, bitmap?.height) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val source = latestBitmap.value
                        if (source == null) return@awaitEachGesture
                        val base = fittedPhotoRect(latestViewport.value, source.width, source.height)
                        val frame = transformedCropRect(base, latestCrop.value, latestScale.value, latestOffset.value, latestViewport.value)
                        val downPosition = down.position
                        val densityPx = 24.dp.toPx()
                        // Both tools share one frame: side handles resize the crop, corner handles
                        // edit the homography quad in crop-local coordinates.
                        val quadScreenPoints = latestPerspectiveQuad.value.map { Offset(frame.left + it.x * frame.width, frame.top + it.y * frame.height) }
                        val quadHandle = if (latestCropMode.value) quadScreenPoints.indices.firstOrNull { index ->
                            hypot((downPosition.x - quadScreenPoints[index].x).toDouble(), (downPosition.y - quadScreenPoints[index].y).toDouble()) <= densityPx * 1.35
                        } else null
                        // The four corner points keep their own hit zones; ordinary crop
                        // edges respond across their full length with a forgiving touch band.
                        val handle = if (latestCropMode.value) hitCropEdge(frame, downPosition, densityPx * 1.25f) else null
                        var mode = when {
                            quadHandle != null -> CropHandle.PAN
                            handle != null -> handle
                            latestCropMode.value && frame.contains(downPosition) -> CropHandle.MOVE
                            else -> CropHandle.PAN
                        }
                        var previous = downPosition
                        var gestureScale = latestScale.value
                        var gestureOffset = latestOffset.value
                        val startCrop = latestCrop.value
                        val startQuad = latestPerspectiveQuad.value
                        var dragCrop = startCrop
                        val activeQuadHandle = quadHandle
                        val dragQuad = latestPerspectiveQuad.value.toMutableList()
                        var previousCentroid = downPosition
                        var previousDistance = 0f
                        var multiInitialized = false
                        while (true) {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.filter { it.pressed }
                            if (pressed.isEmpty()) break
                            if (pressed.size >= 2) {
                                val a = pressed[0].position
                                val b = pressed[1].position
                                val centroid = Offset((a.x + b.x) / 2f, (a.y + b.y) / 2f)
                                val distance = hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat()
                                if (!multiInitialized) {
                                    previousCentroid = centroid; previousDistance = distance; multiInitialized = true
                                    mode = CropHandle.PINCH
                                    // The first finger of a pinch may have already nudged the frame or a corner:
                                    // zoom must never change the frame, so restore its pre-gesture state.
                                    dragCrop = startCrop; crop = startCrop
                                    dragQuad.clear(); dragQuad.addAll(startQuad); perspectiveQuad = startQuad
                                } else {
                                    val currentBitmap = latestBitmap.value
                                    if (currentBitmap != null) {
                                        val next = transformPhotoViewport(
                                            gestureScale, gestureOffset, previousCentroid,
                                            centroid - previousCentroid,
                                            if (previousDistance > 0f) distance / previousDistance else 1f,
                                            latestViewport.value, currentBitmap.width, currentBitmap.height
                                        )
                                        gestureScale = next.scale
                                        gestureOffset = next.offset
                                        scale = gestureScale
                                        offset = gestureOffset
                                    }
                                    previousCentroid = centroid; previousDistance = distance
                                }
                            } else if (mode != CropHandle.PINCH) {
                                val change = pressed.first()
                                val changePosition = change.position
                                val delta = changePosition - previous
                                val currentBitmap = latestBitmap.value
                                if (currentBitmap != null && delta != Offset.Zero) {
                                    val fitted = fittedPhotoRect(latestViewport.value, currentBitmap.width, currentBitmap.height)
                                    // The crop window is fixed on screen, so handle movement is
                                    // measured against the fitted viewport image, not the zoomed bitmap.
                                    val normalizedX = delta.x / fitted.width.coerceAtLeast(1f)
                                    val normalizedY = delta.y / fitted.height.coerceAtLeast(1f)
                                    if (activeQuadHandle != null && latestCropMode.value) {
                                        val rect = transformedCropRect(fitted, latestCrop.value, latestScale.value, latestOffset.value, latestViewport.value)
                                        dragQuad[activeQuadHandle] = updatePerspectiveCorner(
                                            dragQuad, activeQuadHandle,
                                            delta.x / rect.width.coerceAtLeast(1f),
                                            delta.y / rect.height.coerceAtLeast(1f)
                                        )[activeQuadHandle]
                                        perspectiveQuad = dragQuad.toList()
                                    } else when (mode) {
                                        CropHandle.PAN -> {
                                            if (!latestCropMode.value || !frame.contains(changePosition)) {
                                                val next = transformPhotoViewport(gestureScale, gestureOffset,
                                                    changePosition, delta, 1f, latestViewport.value,
                                                    currentBitmap.width, currentBitmap.height)
                                                gestureScale = next.scale
                                                gestureOffset = next.offset
                                                scale = gestureScale
                                                offset = gestureOffset
                                            }
                                        }
                                        else -> {
                                            // The frame is free on screen: limited only by the visible part of the
                                            // zoomed photo, not by the fit-to-screen rectangle.
                                            val photoNow = transformPhotoRect(fitted, latestScale.value, latestOffset.value, latestViewport.value)
                                            val vw = latestViewport.value.width.toFloat(); val vh = latestViewport.value.height.toFloat()
                                            val bw = fitted.width.coerceAtLeast(1f); val bh = fitted.height.coerceAtLeast(1f)
                                            dragCrop = updateCropSelection(dragCrop, mode, normalizedX, normalizedY, 0.05f,
                                                (max(photoNow.left, 0f) - fitted.left) / bw, (max(photoNow.top, 0f) - fitted.top) / bh,
                                                (min(photoNow.right, vw) - fitted.left) / bw, (min(photoNow.bottom, vh) - fitted.top) / bh)
                                            crop = dragCrop
                                        }
                                    }
                                }
                                previous = changePosition
                            }
                            event.changes.forEach { it.consume() }
                        }
                        checkpoint() // one history step per complete drag/pinch gesture
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            val currentBitmap = bitmap
            if (currentBitmap != null) {
                Image(
                    bitmap = currentBitmap.asImageBitmap(), contentDescription = "Редактируемая фотография",
                    modifier = Modifier.fillMaxSize().clipToBounds().graphicsLayer {
                        scaleX = scale * if (!cropMode && mirrorHorizontal) -1f else 1f
                        scaleY = scale * if (!cropMode && mirrorVertical) -1f else 1f
                        translationX = offset.x; translationY = offset.y
                        rotationZ = if (cropMode) 0f else rotation
                        rotationX = if (cropMode) 0f else perspectiveVertical
                        rotationY = if (cropMode) 0f else perspectiveHorizontal
                        cameraDistance = 12f * density
                    }, contentScale = ContentScale.Fit
                )
                if (cropMode) androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                    val viewportSize = IntSize(size.width.toInt(), size.height.toInt())
                    val base = fittedPhotoRect(viewportSize, currentBitmap.width, currentBitmap.height)
                    val photoRect = transformPhotoRect(base, scale, offset, viewportSize)
                    val frame = transformedCropRect(base, crop, scale, offset, viewportSize)
                    val quadPoints = perspectiveQuad.map { Offset(frame.left + it.x * frame.width, frame.top + it.y * frame.height) }
                    val shade = Color.Black.copy(alpha = 0.52f)
                    drawRect(shade, topLeft = Offset(photoRect.left, photoRect.top), size = androidx.compose.ui.geometry.Size(photoRect.width, (frame.top - photoRect.top).coerceAtLeast(0f)))
                    drawRect(shade, topLeft = Offset(photoRect.left, frame.bottom), size = androidx.compose.ui.geometry.Size(photoRect.width, (photoRect.bottom - frame.bottom).coerceAtLeast(0f)))
                    drawRect(shade, topLeft = Offset(photoRect.left, frame.top), size = androidx.compose.ui.geometry.Size((frame.left - photoRect.left).coerceAtLeast(0f), frame.height))
                    drawRect(shade, topLeft = Offset(frame.right, frame.top), size = androidx.compose.ui.geometry.Size((photoRect.right - frame.right).coerceAtLeast(0f), frame.height))
                    for (i in 0..3) drawLine(PhotoEditorOrange, quadPoints[i], quadPoints[(i + 1) % 4], 1.8.dp.toPx())
                    for (t in 1..2) {
                        val f = t / 3f
                        drawLine(TextPrimary.copy(alpha = 0.34f), quadPoints[0] + (quadPoints[1] - quadPoints[0]) * f,
                            quadPoints[3] + (quadPoints[2] - quadPoints[3]) * f, 0.7.dp.toPx())
                        drawLine(TextPrimary.copy(alpha = 0.34f), quadPoints[0] + (quadPoints[3] - quadPoints[0]) * f,
                            quadPoints[1] + (quadPoints[2] - quadPoints[1]) * f, 0.7.dp.toPx())
                    }
                    quadPoints.forEach { point ->
                        drawCircle(Color.Black.copy(alpha = 0.82f), 10.dp.toPx(), point)
                        drawCircle(PhotoEditorOrange, 7.dp.toPx(), point)
                        drawCircle(Color.White, 2.5.dp.toPx(), point)
                    }
                }
                if (!cropMode && perspectiveMode) {
                    androidx.compose.foundation.Canvas(
                        Modifier.fillMaxSize().graphicsLayer {
                            scaleX = scale * if (mirrorHorizontal) -1f else 1f
                            scaleY = scale * if (mirrorVertical) -1f else 1f
                            translationX = offset.x; translationY = offset.y
                            rotationZ = rotation
                            rotationX = perspectiveVertical
                            rotationY = perspectiveHorizontal
                            cameraDistance = 12f * density
                        }
                    ) {
                        val guideRect = fittedPhotoRect(IntSize(size.width.toInt(), size.height.toInt()), currentBitmap.width, currentBitmap.height)
                        drawRoundRect(PhotoEditorOrange.copy(alpha = 0.9f), Offset(guideRect.left, guideRect.top),
                            androidx.compose.ui.geometry.Size(guideRect.width, guideRect.height), style = Stroke(1.5.dp.toPx()))
                        for (i in 1..2) {
                            val x = guideRect.left + guideRect.width * i / 3f
                            val y = guideRect.top + guideRect.height * i / 3f
                            drawLine(PhotoEditorOrange.copy(alpha = 0.72f), Offset(x, guideRect.top), Offset(x, guideRect.bottom), 1.dp.toPx())
                            drawLine(PhotoEditorOrange.copy(alpha = 0.72f), Offset(guideRect.left, y), Offset(guideRect.right, y), 1.dp.toPx())
                        }
                        drawCircle(PhotoEditorOrange, 3.dp.toPx(), Offset(guideRect.center.x, guideRect.center.y))
                    }
                }
            } else Text("Не удалось загрузить изображение", color = Dim)
            }

            // Compact translucent controls float over the canvas; no opaque instruction panel.
            if (bitmap != null && !cropMode) {
                Column(
                    Modifier.align(Alignment.BottomCenter).padding(horizontal = 16.dp, vertical = 12.dp)
                        .clip(RoundedCornerShape(RadiusLarge))
                        .background(SurfaceRaised.copy(alpha = 0.58f))
                        .border(1.dp, Line.copy(alpha = 0.42f), RoundedCornerShape(RadiusLarge))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(0.dp)
                ) {
                    if (perspectiveMode) {
                        LabeledSlider("Вертикаль", perspectiveVertical, -65f..65f, "${perspectiveVertical.toInt()}°", accent = Violet) { perspectiveVertical = it; zoomForPrecision(1.3f); checkpoint() }
                        LabeledSlider("Горизонталь", perspectiveHorizontal, -65f..65f, "${perspectiveHorizontal.toInt()}°", accent = Violet) { perspectiveHorizontal = it; zoomForPrecision(1.3f); checkpoint() }
                    } else {
                        LabeledSlider("Поворот", rotation, -180f..180f, "${rotation.toInt()}°", accent = Violet) { rotation = it; checkpoint() }
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(SurfaceRaised.copy(alpha = 0.78f))
                .border(1.dp, Line.copy(alpha = 0.42f), RoundedCornerShape(topStart = RadiusLarge, topEnd = RadiusLarge))
                .padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PhotoEditorAction(Ico.CROP, "Кроп", selected = cropMode) { cropMode = true; perspectiveMode = false }
            PhotoEditorAction(Ico.ROTATE, "Поворот", selected = !cropMode && !perspectiveMode) { cropMode = false; perspectiveMode = false }
            PhotoEditorAction(Ico.PERSPECTIVE, "Наклон", selected = perspectiveMode) { cropMode = false; perspectiveMode = true }
            PhotoEditorAction(Ico.UNDO, "Undo") { undoDraft() }
            PhotoEditorAction(Ico.REDO, "Redo") { redoDraft() }
        }
    }

    if (showDiscardConfirmation) {
        AlertDialog(
            onDismissRequest = { showDiscardConfirmation = false },
            containerColor = Card,
            title = { Text("Выйти из редактора фото?", color = TextPrimary) },
            text = {
                Text(
                    "Несохранённые изменения этой фотографии будут отменены. Сам проект и остальные фотографии останутся открытыми.",
                    color = Dim
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showDiscardConfirmation = false
                    onCancel()
                }) { Text("Выйти без сохранения", color = Violet) }
            },
            dismissButton = {
                TextButton(onClick = { showDiscardConfirmation = false }) {
                    Text("Продолжить", color = TextPrimary)
                }
            }
        )
    }
}

@Composable
private fun PhotoEditorAction(
    icon: Ico,
    label: String,
    selected: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        Modifier.size(44.dp)
            .clip(RoundedCornerShape(RadiusMedium))
            .background(if (selected) Violet.copy(alpha = 0.14f) else Color.Transparent)
            .clickable(onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) {
        ToolIcon(icon, if (selected) Violet else TextPrimary, Modifier.size(22.dp))
    }
}
