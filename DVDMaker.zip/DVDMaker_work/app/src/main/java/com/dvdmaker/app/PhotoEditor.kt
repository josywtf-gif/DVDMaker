package com.dvdmaker.app

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

internal data class PhotoViewportTransform(val scale: Float, val offset: Offset)

internal data class CropSelection(val left: Float = 0f, val top: Float = 0f, val right: Float = 1f, val bottom: Float = 1f) {
    val width get() = right - left
    val height get() = bottom - top
}

internal enum class CropHandle { TOP_LEFT, TOP, TOP_RIGHT, RIGHT, BOTTOM_RIGHT, BOTTOM, BOTTOM_LEFT, LEFT, MOVE, PAN, PINCH }

internal fun transformPhotoViewport(
    currentScale: Float,
    currentOffset: Offset,
    centroid: Offset,
    pan: Offset,
    zoomChange: Float,
    viewport: IntSize,
    imageWidth: Int,
    imageHeight: Int
): PhotoViewportTransform {
    if (viewport.width <= 0 || viewport.height <= 0 || imageWidth <= 0 || imageHeight <= 0) {
        return PhotoViewportTransform(currentScale, currentOffset)
    }
    val nextScale = (currentScale * zoomChange).coerceIn(1f, 8f)
    val center = Offset(viewport.width / 2f, viewport.height / 2f)
    val effectiveZoom = nextScale / currentScale.coerceAtLeast(0.001f)
    val focal = centroid - center
    val raw = currentOffset * effectiveZoom + focal * (1f - effectiveZoom) + pan
    val fit = min(viewport.width / imageWidth.toFloat(), viewport.height / imageHeight.toFloat())
    val fittedWidth = imageWidth * fit
    val fittedHeight = imageHeight * fit
    val maxX = max(0f, (fittedWidth * nextScale - viewport.width) / 2f)
    val maxY = max(0f, (fittedHeight * nextScale - viewport.height) / 2f)
    return PhotoViewportTransform(nextScale, Offset(raw.x.coerceIn(-maxX, maxX), raw.y.coerceIn(-maxY, maxY)))
}

internal fun updateCropSelection(
    crop: CropSelection,
    handle: CropHandle,
    deltaX: Float,
    deltaY: Float,
    minSize: Float = 0.05f
): CropSelection {
    val minW = minSize.coerceIn(0.001f, 0.49f)
    val minH = minSize.coerceIn(0.001f, 0.49f)
    var l = crop.left; var t = crop.top; var r = crop.right; var b = crop.bottom
    when (handle) {
        CropHandle.TOP_LEFT -> { l = (l + deltaX).coerceIn(0f, r - minW); t = (t + deltaY).coerceIn(0f, b - minH) }
        CropHandle.TOP -> t = (t + deltaY).coerceIn(0f, b - minH)
        CropHandle.TOP_RIGHT -> { r = (r + deltaX).coerceIn(l + minW, 1f); t = (t + deltaY).coerceIn(0f, b - minH) }
        CropHandle.RIGHT -> r = (r + deltaX).coerceIn(l + minW, 1f)
        CropHandle.BOTTOM_RIGHT -> { r = (r + deltaX).coerceIn(l + minW, 1f); b = (b + deltaY).coerceIn(t + minH, 1f) }
        CropHandle.BOTTOM -> b = (b + deltaY).coerceIn(t + minH, 1f)
        CropHandle.BOTTOM_LEFT -> { l = (l + deltaX).coerceIn(0f, r - minW); b = (b + deltaY).coerceIn(t + minH, 1f) }
        CropHandle.LEFT -> l = (l + deltaX).coerceIn(0f, r - minW)
        CropHandle.MOVE -> {
            val width = r - l; val height = b - t
            l = (l + deltaX).coerceIn(0f, 1f - width)
            t = (t + deltaY).coerceIn(0f, 1f - height)
            r = l + width; b = t + height
        }
        else -> Unit
    }
    return CropSelection(l, t, r, b)
}

/** Applies a selection relative to the currently rendered photo without destructively changing source files. */
internal fun applyCropSelection(layer: Layer, selection: CropSelection): Layer {
    val stableIndex = layer.imageOperations.indexOfLast { it.type == ImageOperationType.CROP }
    val stableOperation = layer.imageOperations.getOrNull(stableIndex)
    if (stableOperation != null && stableOperation.schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION) return layer
    val base = when {
        stableOperation == null -> CropSelection(layer.cropLeft, layer.cropTop, layer.cropRight, layer.cropBottom)
        !stableOperation.enabled -> CropSelection()
        else -> runCatching { JSONObject(stableOperation.parameters) }.getOrDefault(JSONObject()).let { params ->
            CropSelection(
                params.optDouble("left", 0.0).toFloat().coerceIn(0f, 0.8f),
                params.optDouble("top", 0.0).toFloat().coerceIn(0f, 0.8f),
                params.optDouble("right", 1.0).toFloat().coerceIn(0.2f, 1f),
                params.optDouble("bottom", 1.0).toFloat().coerceIn(0.2f, 1f)
            )
        }
    }.let(::sanitizeCropSelection)
    val composed = composeCrop(base, sanitizeCropSelection(selection))
    val parameters = JSONObject().put("left", composed.left.toDouble()).put("top", composed.top.toDouble())
        .put("right", composed.right.toDouble()).put("bottom", composed.bottom.toDouble()).toString()
    val operation = stableOperation?.copy(enabled = true, parameters = parameters, resultPath = "")
        ?: ImageOperation(type = ImageOperationType.CROP, enabled = true, parameters = parameters)
    // A stable crop node suppresses the legacy Layer-field projection. This lets the
    // editor preserve old crop values while storing the composed selection after the
    // existing ordered stack, without destructively recropping the source bitmap.
    return ImageProcessingPipeline.recordOperation(layer, operation, replaceType = true)
}

private fun sanitizeCropSelection(crop: CropSelection): CropSelection {
    val left = crop.left.coerceIn(0f, 0.95f)
    val top = crop.top.coerceIn(0f, 0.95f)
    val right = crop.right.coerceIn(left + 0.05f, 1f)
    val bottom = crop.bottom.coerceIn(top + 0.05f, 1f)
    return CropSelection(left, top, right, bottom)
}

private fun composeCrop(base: CropSelection, selection: CropSelection) = CropSelection(
    (base.left + base.width * selection.left).coerceIn(0f, 0.999f),
    (base.top + base.height * selection.top).coerceIn(0f, 0.999f),
    (base.left + base.width * selection.right).coerceIn(0.001f, 1f),
    (base.top + base.height * selection.bottom).coerceIn(0.001f, 1f)
)

private fun fittedPhotoRect(viewport: IntSize, imageWidth: Int, imageHeight: Int): Rect {
    if (viewport.width <= 0 || viewport.height <= 0 || imageWidth <= 0 || imageHeight <= 0) return Rect.Zero
    val fit = min(viewport.width / imageWidth.toFloat(), viewport.height / imageHeight.toFloat())
    val w = imageWidth * fit; val h = imageHeight * fit
    return Rect((viewport.width - w) / 2f, (viewport.height - h) / 2f,
        (viewport.width + w) / 2f, (viewport.height + h) / 2f)
}

private fun transformPhotoRect(base: Rect, scale: Float, offset: Offset, viewport: IntSize): Rect {
    val center = Offset(viewport.width / 2f, viewport.height / 2f)
    return Rect(
        center.x + (base.left - center.x) * scale + offset.x,
        center.y + (base.top - center.y) * scale + offset.y,
        center.x + (base.right - center.x) * scale + offset.x,
        center.y + (base.bottom - center.y) * scale + offset.y
    )
}

private fun transformedCropRect(base: Rect, crop: CropSelection, scale: Float, offset: Offset, viewport: IntSize): Rect {
    val photo = transformPhotoRect(base, scale, offset, viewport)
    return Rect(photo.left + photo.width * crop.left, photo.top + photo.height * crop.top,
        photo.left + photo.width * crop.right, photo.top + photo.height * crop.bottom)
}

private fun handlePoints(rect: Rect): List<Pair<CropHandle, Offset>> = listOf(
    CropHandle.TOP_LEFT to Offset(rect.left, rect.top), CropHandle.TOP to Offset(rect.center.x, rect.top),
    CropHandle.TOP_RIGHT to Offset(rect.right, rect.top), CropHandle.RIGHT to Offset(rect.right, rect.center.y),
    CropHandle.BOTTOM_RIGHT to Offset(rect.right, rect.bottom), CropHandle.BOTTOM to Offset(rect.center.x, rect.bottom),
    CropHandle.BOTTOM_LEFT to Offset(rect.left, rect.bottom), CropHandle.LEFT to Offset(rect.left, rect.center.y)
)

@Composable
fun PhotoEditorScreen(
    layer: Layer,
    backdrop: BackdropLight?,
    onClose: () -> Unit,
    onApply: (Layer) -> Unit
) {
    BackHandler(enabled = true, onBack = onClose)
    DisposableEffect(layer.id) { onDispose { ImageOperationRenderer.cancelPendingPreview() } }
    val bitmap by produceState<Bitmap?>(null, layer, backdrop) {
        value = withContext(Dispatchers.Default) { ImageOperationRenderer.renderPreviewBitmap(layer, backdrop) }
    }
    var scale by remember(layer.id) { mutableFloatStateOf(1f) }
    var offset by remember(layer.id) { mutableStateOf(Offset.Zero) }
    var viewport by remember(layer.id) { mutableStateOf(IntSize.Zero) }
    var crop by remember(layer.id) { mutableStateOf(CropSelection()) }
    var cropMode by remember(layer.id) { mutableStateOf(true) }
    val latestScale = rememberUpdatedState(scale)
    val latestOffset = rememberUpdatedState(offset)
    val latestCrop = rememberUpdatedState(crop)
    val latestCropMode = rememberUpdatedState(cropMode)
    val latestViewport = rememberUpdatedState(viewport)
    val latestBitmap = rememberUpdatedState(bitmap)

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().background(Card).padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose, modifier = Modifier.size(44.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Закрыть редактор", tint = TextPrimary)
            }
            Column(Modifier.weight(1f)) {
                Text("Кадрирование", color = TextPrimary, fontSize = 16.sp)
                Text("Углы — две стороны · стороны — одна", color = Dim, fontSize = 10.sp)
            }
            IconButton(onClick = { scale = 1f; offset = Offset.Zero; crop = CropSelection() }, modifier = Modifier.size(44.dp)) {
                Icon(Icons.Default.Refresh, contentDescription = "Сбросить кадрирование", tint = TextPrimary)
            }
            GradientButton(text = "Готово", onClick = { onApply(applyCropSelection(layer, crop)) })
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(8.dp)
                .clip(RoundedCornerShape(RadiusMedium)).background(Card2)
                .onSizeChanged { viewport = it }
                .pointerInput(layer.id, viewport, bitmap?.width, bitmap?.height) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val source = latestBitmap.value
                        if (source == null) return@awaitEachGesture
                        val base = fittedPhotoRect(latestViewport.value, source.width, source.height)
                        val frame = transformedCropRect(base, latestCrop.value, latestScale.value, latestOffset.value, latestViewport.value)
                        val densityPx = 24.dp.toPx()
                        val handle = handlePoints(frame).firstOrNull { (_, point) ->
                            hypot((down.position.x - point.x).toDouble(), (down.position.y - point.y).toDouble()) <= densityPx
                        }?.first
                        var mode = when {
                            handle != null && latestCropMode.value -> handle
                            latestCropMode.value && frame.contains(down.position) -> CropHandle.MOVE
                            else -> CropHandle.PAN
                        }
                        var previous = down.position
                        var previousCentroid = down.position
                        var previousDistance = 0f
                        var multiInitialized = false
                        while (true) {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.filter { it.pressed }
                            if (pressed.isEmpty()) break
                            if (pressed.size >= 2) {
                                val a = pressed[0].position; val b = pressed[1].position
                                val centroid = Offset((a.x + b.x) / 2f, (a.y + b.y) / 2f)
                                val distance = hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat()
                                if (!multiInitialized) {
                                    previousCentroid = centroid; previousDistance = distance; multiInitialized = true
                                    mode = CropHandle.PINCH
                                } else {
                                    val currentBitmap = latestBitmap.value
                                    if (currentBitmap != null) {
                                        val next = transformPhotoViewport(
                                            latestScale.value, latestOffset.value, previousCentroid,
                                            centroid - previousCentroid,
                                            if (previousDistance > 0f) distance / previousDistance else 1f,
                                            latestViewport.value, currentBitmap.width, currentBitmap.height
                                        )
                                        scale = next.scale; offset = next.offset
                                    }
                                    previousCentroid = centroid; previousDistance = distance
                                }
                            } else if (mode != CropHandle.PINCH) {
                                val change = pressed.first()
                                val delta = change.position - previous
                                val currentBitmap = latestBitmap.value
                                if (currentBitmap != null && delta != Offset.Zero) {
                                    val fitted = fittedPhotoRect(latestViewport.value, currentBitmap.width, currentBitmap.height)
                                    val normalizedX = delta.x / (fitted.width * latestScale.value).coerceAtLeast(1f)
                                    val normalizedY = delta.y / (fitted.height * latestScale.value).coerceAtLeast(1f)
                                    when (mode) {
                                        CropHandle.PAN -> {
                                            if (!latestCropMode.value || !frame.contains(change.position)) {
                                                val next = transformPhotoViewport(latestScale.value, latestOffset.value,
                                                    change.position, delta, 1f, latestViewport.value,
                                                    currentBitmap.width, currentBitmap.height)
                                                offset = next.offset
                                            }
                                        }
                                        else -> crop = updateCropSelection(latestCrop.value, mode, normalizedX, normalizedY)
                                    }
                                }
                                previous = change.position
                            }
                            event.changes.forEach { it.consume() }
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            val currentBitmap = bitmap
            if (currentBitmap != null) {
                Image(
                    bitmap = currentBitmap.asImageBitmap(), contentDescription = "Редактируемая фотография",
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        scaleX = scale; scaleY = scale; translationX = offset.x; translationY = offset.y
                    }, contentScale = ContentScale.Fit
                )
                androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                    val viewportSize = IntSize(size.width.toInt(), size.height.toInt())
                    val base = fittedPhotoRect(viewportSize, currentBitmap.width, currentBitmap.height)
                    val photoRect = transformPhotoRect(base, scale, offset, viewportSize)
                    val frame = transformedCropRect(base, crop, scale, offset, viewportSize)
                    val shade = Color.Black.copy(alpha = 0.52f)
                    drawRect(shade, topLeft = Offset(photoRect.left, photoRect.top), size = androidx.compose.ui.geometry.Size(photoRect.width, (frame.top - photoRect.top).coerceAtLeast(0f)))
                    drawRect(shade, topLeft = Offset(photoRect.left, frame.bottom), size = androidx.compose.ui.geometry.Size(photoRect.width, (photoRect.bottom - frame.bottom).coerceAtLeast(0f)))
                    drawRect(shade, topLeft = Offset(photoRect.left, frame.top), size = androidx.compose.ui.geometry.Size((frame.left - photoRect.left).coerceAtLeast(0f), frame.height))
                    drawRect(shade, topLeft = Offset(frame.right, frame.top), size = androidx.compose.ui.geometry.Size((photoRect.right - frame.right).coerceAtLeast(0f), frame.height))
                    drawRect(Violet, topLeft = Offset(frame.left, frame.top), size = androidx.compose.ui.geometry.Size(frame.width, frame.height), style = Stroke(2.dp.toPx()))
                    for (i in 1..2) {
                        val x = frame.left + frame.width * i / 3f
                        val y = frame.top + frame.height * i / 3f
                        drawLine(TextPrimary.copy(alpha = 0.55f), Offset(x, frame.top), Offset(x, frame.bottom), 1.dp.toPx())
                        drawLine(TextPrimary.copy(alpha = 0.55f), Offset(frame.left, y), Offset(frame.right, y), 1.dp.toPx())
                    }
                    val handleSize = 12.dp.toPx()
                    handlePoints(frame).forEach { (_, point) ->
                        val left = (point.x - handleSize / 2f).coerceIn(photoRect.left, photoRect.right - handleSize)
                        val top = (point.y - handleSize / 2f).coerceIn(photoRect.top, photoRect.bottom - handleSize)
                        drawRoundRect(Color.White, Offset(left, top), androidx.compose.ui.geometry.Size(handleSize, handleSize), cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
                        drawRoundRect(Violet, Offset(left, top), androidx.compose.ui.geometry.Size(handleSize, handleSize), cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()), style = Stroke(1.5.dp.toPx()))
                    }
                }
            } else Text("Не удалось загрузить изображение", color = Dim)
        }

        Column(Modifier.fillMaxWidth().background(Card).padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                TabChip("Кадр", cropMode, { cropMode = true })
                TabChip("Фото", !cropMode, { cropMode = false })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (cropMode) "Тяните углы и стороны рамки" else "Перемещайте фото · pinch для масштаба", color = Dim, fontSize = 12.sp)
                Text("${(scale * 100).toInt()}%", color = TextPrimary, fontSize = 12.sp)
            }
            if (bitmap != null) LabeledSlider("Масштаб", scale, 1f..8f, "${(scale * 100).toInt()}%") { requested ->
                val source = bitmap ?: return@LabeledSlider
                val next = transformPhotoViewport(scale, offset, Offset(viewport.width / 2f, viewport.height / 2f), Offset.Zero,
                    requested / scale.coerceAtLeast(0.001f), viewport, source.width, source.height)
                scale = next.scale; offset = next.offset
            }
        }
    }
}
