package com.dvdmaker.app

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

private val PhotoEditorOrange = Color(0xFFFF8A32)

internal data class PhotoViewportTransform(val scale: Float, val offset: Offset)

internal data class CropSelection(val left: Float = 0f, val top: Float = 0f, val right: Float = 1f, val bottom: Float = 1f) {
    val width get() = right - left
    val height get() = bottom - top
}

internal enum class CropHandle { TOP_LEFT, TOP, TOP_RIGHT, RIGHT, BOTTOM_RIGHT, BOTTOM, BOTTOM_LEFT, LEFT, MOVE, PAN, PINCH }

/** Immutable editor-local checkpoint. These values are drafts until the user taps Save. */
internal data class PhotoEditorDraftState(
    val crop: CropSelection = CropSelection(),
    val rotation: Float = 0f,
    val perspectiveVertical: Float = 0f,
    val perspectiveHorizontal: Float = 0f,
    val mirrorHorizontal: Boolean = false,
    val mirrorVertical: Boolean = false,
    val scale: Float = 1f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val perspectiveQuad: List<Offset> = listOf(Offset(0f, 0f), Offset(1f, 0f), Offset(1f, 1f), Offset(0f, 1f))
)

internal fun appendPhotoEditorHistory(
    history: List<PhotoEditorDraftState>, cursor: Int, next: PhotoEditorDraftState, limit: Int = 50
): Pair<List<PhotoEditorDraftState>, Int> {
    val prefix = history.take((cursor + 1).coerceIn(0, history.size))
    val appended = prefix + next
    val trimmed = if (appended.size > limit + 1) appended.drop(appended.size - (limit + 1)) else appended
    return trimmed to (trimmed.lastIndex)
}

internal fun transformPhotoViewport(
    currentScale: Float,
    currentOffset: Offset,
    centroid: Offset,
    pan: Offset,
    zoomChange: Float,
    viewport: IntSize,
    imageWidth: Int,
    imageHeight: Int
): PhotoViewportTransform {
    if (viewport.width <= 0 || viewport.height <= 0 || imageWidth <= 0 || imageHeight <= 0) {
        return PhotoViewportTransform(currentScale, currentOffset)
    }
    val nextScale = (currentScale * zoomChange).coerceIn(1f, 8f)
    val center = Offset(viewport.width / 2f, viewport.height / 2f)
    val effectiveZoom = nextScale / currentScale.coerceAtLeast(0.001f)
    val focal = centroid - center
    val raw = currentOffset * effectiveZoom + focal * (1f - effectiveZoom) + pan
    val fit = min(viewport.width / imageWidth.toFloat(), viewport.height / imageHeight.toFloat())
    val fittedWidth = imageWidth * fit
    val fittedHeight = imageHeight * fit
    val maxX = max(0f, (fittedWidth * nextScale - viewport.width) / 2f)
    val maxY = max(0f, (fittedHeight * nextScale - viewport.height) / 2f)
    return PhotoViewportTransform(nextScale, Offset(raw.x.coerceIn(-maxX, maxX), raw.y.coerceIn(-maxY, maxY)))
}

internal fun updateCropSelection(
    crop: CropSelection,
    handle: CropHandle,
    deltaX: Float,
    deltaY: Float,
    minSize: Float = 0.05f
): CropSelection {
    val minW = minSize.coerceIn(0.001f, 0.49f)
    val minH = minSize.coerceIn(0.001f, 0.49f)
    var l = crop.left; var t = crop.top; var r = crop.right; var b = crop.bottom
    when (handle) {
        CropHandle.TOP_LEFT -> { l = (l + deltaX).coerceIn(0f, r - minW); t = (t + deltaY).coerceIn(0f, b - minH) }
        CropHandle.TOP -> t = (t + deltaY).coerceIn(0f, b - minH)
        CropHandle.TOP_RIGHT -> { r = (r + deltaX).coerceIn(l + minW, 1f); t = (t + deltaY).coerceIn(0f, b - minH) }
        CropHandle.RIGHT -> r = (r + deltaX).coerceIn(l + minW, 1f)
        CropHandle.BOTTOM_RIGHT -> { r = (r + deltaX).coerceIn(l + minW, 1f); b = (b + deltaY).coerceIn(t + minH, 1f) }
        CropHandle.BOTTOM -> b = (b + deltaY).coerceIn(t + minH, 1f)
        CropHandle.BOTTOM_LEFT -> { l = (l + deltaX).coerceIn(0f, r - minW); b = (b + deltaY).coerceIn(t + minH, 1f) }
        CropHandle.LEFT -> l = (l + deltaX).coerceIn(0f, r - minW)
        CropHandle.MOVE -> {
            val width = r - l; val height = b - t
            l = (l + deltaX).coerceIn(0f, 1f - width)
            t = (t + deltaY).coerceIn(0f, 1f - height)
            r = l + width; b = t + height
        }
        else -> Unit
    }
    return CropSelection(l, t, r, b)
}

/** Applies a selection relative to the currently rendered photo without destructively changing source files. */
internal fun applyCropSelection(layer: Layer, selection: CropSelection): Layer {
    val stableIndex = layer.imageOperations.indexOfLast { it.type == ImageOperationType.CROP }
    val stableOperation = layer.imageOperations.getOrNull(stableIndex)
    if (stableOperation != null && stableOperation.schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION) return layer
    val base = when {
        stableOperation == null -> CropSelection(layer.cropLeft, layer.cropTop, layer.cropRight, layer.cropBottom)
        !stableOperation.enabled -> CropSelection()
        else -> runCatching { JSONObject(stableOperation.parameters) }.getOrDefault(JSONObject()).let { params ->
            CropSelection(
                params.optDouble("left", 0.0).toFloat().coerceIn(0f, 0.8f),
                params.optDouble("top", 0.0).toFloat().coerceIn(0f, 0.8f),
                params.optDouble("right", 1.0).toFloat().coerceIn(0.2f, 1f),
                params.optDouble("bottom", 1.0).toFloat().coerceIn(0.2f, 1f)
            )
        }
    }.let(::sanitizeCropSelection)
    val composed = composeCrop(base, sanitizeCropSelection(selection))
    val parameters = JSONObject().put("left", composed.left.toDouble()).put("top", composed.top.toDouble())
        .put("right", composed.right.toDouble()).put("bottom", composed.bottom.toDouble()).toString()
    val operation = stableOperation?.copy(enabled = true, parameters = parameters, resultPath = "")
        ?: ImageOperation(type = ImageOperationType.CROP, enabled = true, parameters = parameters)
    // A stable crop node suppresses the legacy Layer-field projection. This lets the
    // editor preserve old crop values while storing the composed selection after the
    // existing ordered stack, without destructively recropping the source bitmap.
    return ImageProcessingPipeline.recordOperation(layer, operation, replaceType = true)
}

/** Commits crop and geometry as independent parameters; crop never absorbs rotation or perspective. */
internal fun applyPhotoEditorEdits(
    layer: Layer,
    selection: CropSelection,
    rotationDelta: Float,
    perspectiveVertical: Float,
    perspectiveHorizontal: Float,
    mirrorHorizontal: Boolean = false,
    mirrorVertical: Boolean = false
): Layer {
    val cropped = applyCropSelection(layer, selection)
    val nextRotation = ((layer.rot + rotationDelta) % 360f).let { if (it < 0f) it + 360f else it }
    return cropped.copy(
        rot = nextRotation,
        flipX = layer.flipX xor mirrorHorizontal,
        flipY = layer.flipY xor mirrorVertical,
        imageTiltX = (layer.imageTiltX + perspectiveVertical).coerceIn(-65f, 65f),
        imageTiltY = (layer.imageTiltY + perspectiveHorizontal).coerceIn(-65f, 65f)
    )
}

/** Store a four-corner rectification as a non-destructive geometry node. Points are normalized TL,TR,BR,BL. */
internal fun applyPerspectiveQuad(layer: Layer, points: List<Offset>): Layer {
    if (points.size != 4 || points.any { !it.x.isFinite() || !it.y.isFinite() || it.x !in 0f..1f || it.y !in 0f..1f }) return layer
    val values = points.flatMap { listOf(it.x, it.y) }
    val quad = org.json.JSONArray().also { a -> values.forEach { a.put(it.toDouble()) } }
    val existing = layer.imageOperations.lastOrNull { it.type == ImageOperationType.GEOMETRY }
    val params = runCatching { JSONObject(existing?.parameters ?: "{}") }.getOrDefault(JSONObject())
        .put("perspectiveQuad", quad)
    val operation = existing?.copy(enabled = true, parameters = params.toString(), resultPath = "")
        ?: ImageOperation(type = ImageOperationType.GEOMETRY, enabled = true, parameters = params.toString())
    return ImageProcessingPipeline.recordOperation(layer, operation, replaceType = true)
}

internal fun stepPhotoRotation(current: Float, delta: Float): Float {
    val value = (current + delta) % 360f
    return if (value > 180f) value - 360f else if (value < -180f) value + 360f else value
}

private fun sanitizeCropSelection(crop: CropSelection): CropSelection {
    val left = crop.left.coerceIn(0f, 0.95f)
    val top = crop.top.coerceIn(0f, 0.95f)
    val right = crop.right.coerceIn(left + 0.05f, 1f)
    val bottom = crop.bottom.coerceIn(top + 0.05f, 1f)
    return CropSelection(left, top, right, bottom)
}

private fun composeCrop(base: CropSelection, selection: CropSelection) = CropSelection(
    (base.left + base.width * selection.left).coerceIn(0f, 0.999f),
    (base.top + base.height * selection.top).coerceIn(0f, 0.999f),
    (base.left + base.width * selection.right).coerceIn(0.001f, 1f),
    (base.top + base.height * selection.bottom).coerceIn(0.001f, 1f)
)

private fun fittedPhotoRect(viewport: IntSize, imageWidth: Int, imageHeight: Int): Rect {
    if (viewport.width <= 0 || viewport.height <= 0 || imageWidth <= 0 || imageHeight <= 0) return Rect.Zero
    val fit = min(viewport.width / imageWidth.toFloat(), viewport.height / imageHeight.toFloat())
    val w = imageWidth * fit; val h = imageHeight * fit
    return Rect((viewport.width - w) / 2f, (viewport.height - h) / 2f,
        (viewport.width + w) / 2f, (viewport.height + h) / 2f)
}

private fun transformPhotoRect(base: Rect, scale: Float, offset: Offset, viewport: IntSize): Rect {
    val center = Offset(viewport.width / 2f, viewport.height / 2f)
    return Rect(
        center.x + (base.left - center.x) * scale + offset.x,
        center.y + (base.top - center.y) * scale + offset.y,
        center.x + (base.right - center.x) * scale + offset.x,
        center.y + (base.bottom - center.y) * scale + offset.y
    )
}

private fun transformedCropRect(base: Rect, crop: CropSelection, scale: Float, offset: Offset, viewport: IntSize): Rect {
    val photo = transformPhotoRect(base, scale, offset, viewport)
    return Rect(photo.left + photo.width * crop.left, photo.top + photo.height * crop.top,
        photo.left + photo.width * crop.right, photo.top + photo.height * crop.bottom)
}

private fun handlePoints(rect: Rect): List<Pair<CropHandle, Offset>> = listOf(
    CropHandle.TOP_LEFT to Offset(rect.left, rect.top), CropHandle.TOP to Offset(rect.center.x, rect.top),
    CropHandle.TOP_RIGHT to Offset(rect.right, rect.top), CropHandle.RIGHT to Offset(rect.right, rect.center.y),
    CropHandle.BOTTOM_RIGHT to Offset(rect.right, rect.bottom), CropHandle.BOTTOM to Offset(rect.center.x, rect.bottom),
    CropHandle.BOTTOM_LEFT to Offset(rect.left, rect.bottom), CropHandle.LEFT to Offset(rect.left, rect.center.y)
)

@Composable
fun PhotoEditorScreen(
    layer: Layer,
    backdrop: BackdropLight?,
    onClose: () -> Unit,
    onApply: (Layer) -> Unit
) {
    BackHandler(enabled = true, onBack = onClose)
    DisposableEffect(layer.id) { onDispose { ImageOperationRenderer.cancelPendingPreview() } }
    val bitmap by produceState<Bitmap?>(null, layer, backdrop) {
        value = withContext(Dispatchers.Default) { ImageOperationRenderer.renderPreviewBitmap(layer, backdrop) }
    }
    var scale by remember(layer.id) { mutableFloatStateOf(1f) }
    var offset by remember(layer.id) { mutableStateOf(Offset.Zero) }
    var viewport by remember(layer.id) { mutableStateOf(IntSize.Zero) }
    var crop by remember(layer.id) { mutableStateOf(CropSelection()) }
    var cropMode by remember(layer.id) { mutableStateOf(true) }
    var rotation by remember(layer.id) { mutableFloatStateOf(0f) }
    var perspectiveVertical by remember(layer.id) { mutableFloatStateOf(0f) }
    var perspectiveHorizontal by remember(layer.id) { mutableFloatStateOf(0f) }
    var perspectiveMode by remember(layer.id) { mutableStateOf(false) }
    var quadMode by remember(layer.id) { mutableStateOf(false) }
    val latestQuadMode = rememberUpdatedState(quadMode)
    val defaultPerspectiveQuad = listOf(Offset(0f, 0f), Offset(1f, 0f), Offset(1f, 1f), Offset(0f, 1f))
    var perspectiveQuad by remember(layer.id) { mutableStateOf(defaultPerspectiveQuad) }
    val latestPerspectiveQuad = rememberUpdatedState(perspectiveQuad)
    var mirrorHorizontal by remember(layer.id) { mutableStateOf(false) }
    var mirrorVertical by remember(layer.id) { mutableStateOf(false) }
    val latestScale = rememberUpdatedState(scale)
    val latestOffset = rememberUpdatedState(offset)
    val latestCrop = rememberUpdatedState(crop)
    val latestCropMode = rememberUpdatedState(cropMode)
    val latestViewport = rememberUpdatedState(viewport)
    val latestBitmap = rememberUpdatedState(bitmap)

    fun currentDraft() = PhotoEditorDraftState(
        crop, rotation, perspectiveVertical, perspectiveHorizontal,
        mirrorHorizontal, mirrorVertical, scale, offset.x, offset.y, perspectiveQuad
    )
    var history by remember(layer.id) { mutableStateOf(listOf(PhotoEditorDraftState())) }
    var historyCursor by remember(layer.id) { mutableStateOf(0) }
    fun checkpoint() {
        val snapshot = currentDraft()
        if (history.getOrNull(historyCursor) == snapshot) return
        val (nextHistory, nextCursor) = appendPhotoEditorHistory(history, historyCursor, snapshot)
        history = nextHistory
        historyCursor = nextCursor
    }
    fun restoreDraft(state: PhotoEditorDraftState) {
        crop = state.crop
        rotation = state.rotation
        perspectiveVertical = state.perspectiveVertical
        perspectiveHorizontal = state.perspectiveHorizontal
        mirrorHorizontal = state.mirrorHorizontal
        mirrorVertical = state.mirrorVertical
        scale = state.scale
        offset = Offset(state.offsetX, state.offsetY)
        perspectiveQuad = state.perspectiveQuad
        perspectiveQuad = state.perspectiveQuad
    }
    fun undoDraft() {
        if (historyCursor > 0) {
            historyCursor -= 1
            restoreDraft(history[historyCursor])
        }
    }
    fun redoDraft() {
        if (historyCursor < history.lastIndex) {
            historyCursor += 1
            restoreDraft(history[historyCursor])
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF080808))) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF111111)).padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "Вернуть", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(RadiusSmall)).clickable(onClick = onClose)
                    .padding(horizontal = 8.dp, vertical = 10.dp)
            )
            Text("Фото", color = Dim, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            GradientButton(
                text = "Сохранить",
                onClick = {
                    var result = applyPhotoEditorEdits(layer, crop, rotation, perspectiveVertical, perspectiveHorizontal, mirrorHorizontal, mirrorVertical)
                    if (perspectiveQuad != defaultPerspectiveQuad) result = applyPerspectiveQuad(result, perspectiveQuad)
                    onApply(result)
                },
                modifier = Modifier,
                brush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(PhotoEditorOrange, Color(0xFFFFB15C)))
            )
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(8.dp)
                .clip(RoundedCornerShape(4.dp)).background(Color(0xFF050505))
                .onSizeChanged { viewport = it }
                .pointerInput(layer.id, viewport, bitmap?.width, bitmap?.height) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val source = latestBitmap.value
                        if (source == null) return@awaitEachGesture
                        val base = fittedPhotoRect(latestViewport.value, source.width, source.height)
                        val frame = transformedCropRect(base, latestCrop.value, latestScale.value, latestOffset.value, latestViewport.value)
                        val downPosition = down.position
                        val densityPx = 24.dp.toPx()
                        val photoRect = transformPhotoRect(base, latestScale.value, latestOffset.value, latestViewport.value)
                        val quadScreenPoints = latestPerspectiveQuad.value.map { Offset(photoRect.left + it.x * photoRect.width, photoRect.top + it.y * photoRect.height) }
                        val quadHandle = if (latestQuadMode.value && !latestCropMode.value) quadScreenPoints.indices.firstOrNull { index ->
                            hypot((downPosition.x - quadScreenPoints[index].x).toDouble(), (downPosition.y - quadScreenPoints[index].y).toDouble()) <= densityPx * 1.35
                        } else null
                        val handle = if (latestCropMode.value) handlePoints(frame).firstOrNull { (_, point) ->
                            hypot((downPosition.x - point.x).toDouble(), (downPosition.y - point.y).toDouble()) <= densityPx
                        }?.first else null
                        var mode = when {
                            quadHandle != null -> CropHandle.PAN
                            handle != null -> handle
                            latestCropMode.value && frame.contains(downPosition) -> CropHandle.MOVE
                            else -> CropHandle.PAN
                        }
                        var previous = downPosition
                        val activeQuadHandle = quadHandle
                        val dragQuad = latestPerspectiveQuad.value.toMutableList()
                        var previousCentroid = downPosition
                        var previousDistance = 0f
                        var multiInitialized = false
                        while (true) {
                            val event = awaitPointerEvent()
                            val pressed = event.changes.filter { it.pressed }
                            if (pressed.isEmpty()) break
                            if (pressed.size >= 2) {
                                val a = pressed[0].position
                                val b = pressed[1].position
                                val centroid = Offset((a.x + b.x) / 2f, (a.y + b.y) / 2f)
                                val distance = hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat()
                                if (!multiInitialized) {
                                    previousCentroid = centroid; previousDistance = distance; multiInitialized = true
                                    mode = CropHandle.PINCH
                                } else {
                                    val currentBitmap = latestBitmap.value
                                    if (currentBitmap != null) {
                                        val next = transformPhotoViewport(
                                            latestScale.value, latestOffset.value, previousCentroid,
                                            centroid - previousCentroid,
                                            if (previousDistance > 0f) distance / previousDistance else 1f,
                                            latestViewport.value, currentBitmap.width, currentBitmap.height
                                        )
                                        scale = next.scale; offset = next.offset
                                    }
                                    previousCentroid = centroid; previousDistance = distance
                                }
                            } else if (mode != CropHandle.PINCH) {
                                val change = pressed.first()
                                val changePosition = change.position
                                val delta = changePosition - previous
                                val currentBitmap = latestBitmap.value
                                if (currentBitmap != null && delta != Offset.Zero) {
                                    val fitted = fittedPhotoRect(latestViewport.value, currentBitmap.width, currentBitmap.height)
                                    val normalizedX = delta.x / (fitted.width * latestScale.value).coerceAtLeast(1f)
                                    val normalizedY = delta.y / (fitted.height * latestScale.value).coerceAtLeast(1f)
                                    if (activeQuadHandle != null && latestQuadMode.value && !latestCropMode.value) {
                                        val rect = transformPhotoRect(fitted, latestScale.value, latestOffset.value, latestViewport.value)
                                        val old = dragQuad[activeQuadHandle]
                                        dragQuad[activeQuadHandle] = Offset(
                                            (old.x + delta.x / rect.width.coerceAtLeast(1f)).coerceIn(0f, 1f),
                                            (old.y + delta.y / rect.height.coerceAtLeast(1f)).coerceIn(0f, 1f)
                                        )
                                        perspectiveQuad = dragQuad.toList()
                                    } else when (mode) {
                                        CropHandle.PAN -> {
                                            if (!latestCropMode.value || !frame.contains(changePosition)) {
                                                val next = transformPhotoViewport(latestScale.value, latestOffset.value,
                                                    changePosition, delta, 1f, latestViewport.value,
                                                    currentBitmap.width, currentBitmap.height)
                                                offset = next.offset
                                            }
                                        }
                                        else -> crop = updateCropSelection(latestCrop.value, mode, normalizedX, normalizedY)
                                    }
                                }
                                previous = changePosition
                            }
                            event.changes.forEach { it.consume() }
                        }
                        checkpoint() // one history step per complete drag/pinch gesture
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            val currentBitmap = bitmap
            if (currentBitmap != null) {
                Image(
                    bitmap = currentBitmap.asImageBitmap(), contentDescription = "Редактируемая фотография",
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        scaleX = scale * if (!cropMode && !quadMode && mirrorHorizontal) -1f else 1f
                        scaleY = scale * if (!cropMode && !quadMode && mirrorVertical) -1f else 1f
                        translationX = offset.x; translationY = offset.y
                        rotationZ = if (cropMode || quadMode) 0f else rotation
                        rotationX = if (cropMode || quadMode) 0f else perspectiveVertical
                        rotationY = if (cropMode || quadMode) 0f else perspectiveHorizontal
                        cameraDistance = 12f * density
                    }, contentScale = ContentScale.Fit
                )
                if (cropMode) androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                        val viewportSize = IntSize(size.width.toInt(), size.height.toInt())
                        val base = fittedPhotoRect(viewportSize, currentBitmap.width, currentBitmap.height)
                        val photoRect = transformPhotoRect(base, scale, offset, viewportSize)
                        val frame = transformedCropRect(base, crop, scale, offset, viewportSize)
                        val shade = Color.Black.copy(alpha = 0.56f)
                        drawRect(shade, topLeft = Offset(photoRect.left, photoRect.top), size = androidx.compose.ui.geometry.Size(photoRect.width, (frame.top - photoRect.top).coerceAtLeast(0f)))
                        drawRect(shade, topLeft = Offset(photoRect.left, frame.bottom), size = androidx.compose.ui.geometry.Size(photoRect.width, (photoRect.bottom - frame.bottom).coerceAtLeast(0f)))
                        drawRect(shade, topLeft = Offset(photoRect.left, frame.top), size = androidx.compose.ui.geometry.Size((frame.left - photoRect.left).coerceAtLeast(0f), frame.height))
                        drawRect(shade, topLeft = Offset(frame.right, frame.top), size = androidx.compose.ui.geometry.Size((photoRect.right - frame.right).coerceAtLeast(0f), frame.height))
                        drawRect(PhotoEditorOrange, topLeft = Offset(frame.left, frame.top), size = androidx.compose.ui.geometry.Size(frame.width, frame.height), style = Stroke(2.dp.toPx()))
                        for (i in 1..2) {
                            val x = frame.left + frame.width * i / 3f
                            val y = frame.top + frame.height * i / 3f
                            drawLine(TextPrimary.copy(alpha = 0.48f), Offset(x, frame.top), Offset(x, frame.bottom), 0.8.dp.toPx())
                            drawLine(TextPrimary.copy(alpha = 0.48f), Offset(frame.left, y), Offset(frame.right, y), 0.8.dp.toPx())
                        }
                        val handleSize = 12.dp.toPx()
                        handlePoints(frame).forEach { (_, point) ->
                            val left = (point.x - handleSize / 2f).coerceIn(photoRect.left, photoRect.right - handleSize)
                            val top = (point.y - handleSize / 2f).coerceIn(photoRect.top, photoRect.bottom - handleSize)
                            drawRoundRect(Color.White, Offset(left, top), androidx.compose.ui.geometry.Size(handleSize, handleSize), cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
                            drawRoundRect(PhotoEditorOrange, Offset(left, top), androidx.compose.ui.geometry.Size(handleSize, handleSize), cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()), style = Stroke(1.5.dp.toPx()))
                        }
                }
                if (!cropMode && quadMode) {
                    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                        val viewportSize = IntSize(size.width.toInt(), size.height.toInt())
                        val fitted = fittedPhotoRect(viewportSize, currentBitmap.width, currentBitmap.height)
                        val rect = transformPhotoRect(fitted, scale, offset, viewportSize)
                        val pts = perspectiveQuad.map { Offset(rect.left + it.x * rect.width, rect.top + it.y * rect.height) }
                        for (i in 0..3) drawLine(PhotoEditorOrange, pts[i], pts[(i + 1) % 4], 2.dp.toPx())
                        for (t in 1..2) {
                            val f = t / 3f
                            val top = pts[0] + (pts[1] - pts[0]) * f
                            val bottom = pts[3] + (pts[2] - pts[3]) * f
                            val left = pts[0] + (pts[3] - pts[0]) * f
                            val right = pts[1] + (pts[2] - pts[1]) * f
                            drawLine(PhotoEditorOrange.copy(alpha = 0.55f), top, bottom, 1.dp.toPx())
                            drawLine(PhotoEditorOrange.copy(alpha = 0.55f), left, right, 1.dp.toPx())
                        }
                        pts.forEach { point ->
                            drawCircle(Color.Black.copy(alpha = 0.8f), 11.dp.toPx(), point)
                            drawCircle(PhotoEditorOrange, 8.dp.toPx(), point)
                            drawCircle(Color.White, 3.dp.toPx(), point)
                        }
                    }
                }
                if (!cropMode && perspectiveMode) {
                    androidx.compose.foundation.Canvas(
                        Modifier.fillMaxSize().graphicsLayer {
                            scaleX = scale * if (mirrorHorizontal) -1f else 1f
                            scaleY = scale * if (mirrorVertical) -1f else 1f
                            translationX = offset.x; translationY = offset.y
                            rotationZ = rotation
                            rotationX = perspectiveVertical
                            rotationY = perspectiveHorizontal
                            cameraDistance = 12f * density
                        }
                    ) {
                        val guideRect = fittedPhotoRect(IntSize(size.width.toInt(), size.height.toInt()), currentBitmap.width, currentBitmap.height)
                        drawRoundRect(PhotoEditorOrange.copy(alpha = 0.9f), Offset(guideRect.left, guideRect.top),
                            androidx.compose.ui.geometry.Size(guideRect.width, guideRect.height), style = Stroke(1.5.dp.toPx()))
                        for (i in 1..2) {
                            val x = guideRect.left + guideRect.width * i / 3f
                            val y = guideRect.top + guideRect.height * i / 3f
                            drawLine(PhotoEditorOrange.copy(alpha = 0.72f), Offset(x, guideRect.top), Offset(x, guideRect.bottom), 1.dp.toPx())
                            drawLine(PhotoEditorOrange.copy(alpha = 0.72f), Offset(guideRect.left, y), Offset(guideRect.right, y), 1.dp.toPx())
                        }
                        drawCircle(PhotoEditorOrange, 3.dp.toPx(), Offset(guideRect.center.x, guideRect.center.y))
                    }
                }
            } else Text("Не удалось загрузить изображение", color = Dim)
        }


        // Compact parameter strip above a single icon-only tool rail.
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xCC202020))
                .border(1.dp, Color(0x553F3F3F), RoundedCornerShape(20.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                val activeValue = when { cropMode -> "Кроп"; quadMode -> "Перспектива"; perspectiveMode -> "Наклон"; else -> "Поворот" }
                Text(activeValue, color = PhotoEditorOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("${(scale * 100).toInt()}%", color = Dim, fontSize = 11.sp)
            }
            if (bitmap != null) {
                when {
                    quadMode -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Перетащите углы объекта", color = TextPrimary, fontSize = 11.sp)
                        PhotoEditorAction("✓", "Выправить", selected = true) {
                            var result = applyPhotoEditorEdits(layer, crop, rotation, perspectiveVertical, perspectiveHorizontal, mirrorHorizontal, mirrorVertical)
                            result = applyPerspectiveQuad(result, perspectiveQuad)
                            onApply(result)
                        }
                    }
                    perspectiveMode -> {
                        LabeledSlider("Вертикаль", perspectiveVertical, -65f..65f, "${perspectiveVertical.toInt()}°", accent = PhotoEditorOrange) { perspectiveVertical = it; checkpoint() }
                        LabeledSlider("Горизонталь", perspectiveHorizontal, -65f..65f, "${perspectiveHorizontal.toInt()}°", accent = PhotoEditorOrange) { perspectiveHorizontal = it; checkpoint() }
                    }
                    cropMode -> Text("Изменяйте рамку на фотографии", color = TextPrimary, fontSize = 11.sp)
                    else -> LabeledSlider("Поворот", rotation, -180f..180f, "${rotation.toInt()}°", accent = PhotoEditorOrange) { rotation = it; checkpoint() }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF171717)).padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PhotoEditorAction("⌗", "Кроп", selected = cropMode) { cropMode = true; perspectiveMode = false; quadMode = false }
            PhotoEditorAction("↻", "Поворот", selected = !cropMode && !perspectiveMode && !quadMode) { cropMode = false; perspectiveMode = false; quadMode = false }
            PhotoEditorAction("◇", "Перспектива", selected = quadMode || perspectiveMode) {
                cropMode = false; perspectiveMode = false; quadMode = true
            }
            PhotoEditorAction("⌕", "Зум") { scale = 1f; offset = Offset.Zero }
            PhotoEditorAction("↶", "Undo") { undoDraft() }
            PhotoEditorAction("↷", "Redo") { redoDraft() }
        }

    }
}

@Composable
private fun PhotoEditorAction(
    glyph: String,
    label: String,
    selected: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        Modifier.clip(RoundedCornerShape(RadiusMedium))
            .background(if (selected) PhotoEditorOrange.copy(alpha = 0.16f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(glyph, color = if (selected) PhotoEditorOrange else TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        Text(label, color = if (selected) PhotoEditorOrange else Dim, fontSize = 9.sp, maxLines = 1)
    }
}
