package com.dvdmaker.app

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

internal data class PhotoViewportTransform(val scale: Float, val offset: Offset)

/** Applies a focal-point-preserving pinch/pan and clamps the image so no empty area can be exposed. */
internal fun transformPhotoViewport(
    currentScale: Float,
    currentOffset: Offset,
    centroid: Offset,
    pan: Offset,
    zoomChange: Float,
    viewport: IntSize,
    imageWidth: Int,
    imageHeight: Int
): PhotoViewportTransform {
    if (viewport.width <= 0 || viewport.height <= 0 || imageWidth <= 0 || imageHeight <= 0) {
        return PhotoViewportTransform(currentScale, currentOffset)
    }
    val nextScale = (currentScale * zoomChange).coerceIn(1f, 8f)
    val center = Offset(viewport.width / 2f, viewport.height / 2f)
    val effectiveZoom = nextScale / currentScale.coerceAtLeast(0.001f)
    val focal = centroid - center
    val raw = currentOffset * effectiveZoom + focal * (1f - effectiveZoom) + pan
    val fit = min(viewport.width / imageWidth.toFloat(), viewport.height / imageHeight.toFloat())
    val fittedWidth = imageWidth * fit
    val fittedHeight = imageHeight * fit
    val maxX = max(0f, (fittedWidth * nextScale - viewport.width) / 2f)
    val maxY = max(0f, (fittedHeight * nextScale - viewport.height) / 2f)
    return PhotoViewportTransform(
        nextScale,
        Offset(raw.x.coerceIn(-maxX, maxX), raw.y.coerceIn(-maxY, maxY))
    )
}

@Composable
fun PhotoEditorScreen(layer: Layer, backdrop: BackdropLight?, onClose: () -> Unit) {
    BackHandler(enabled = true, onBack = onClose)
    DisposableEffect(layer.id) {
        onDispose { ImageOperationRenderer.cancelPendingPreview() }
    }
    val bitmap by produceState<Bitmap?>(null, layer, backdrop) {
        value = withContext(Dispatchers.Default) { ImageOperationRenderer.renderPreviewBitmap(layer, backdrop) }
    }
    var scale by remember(layer.id) { mutableFloatStateOf(1f) }
    var offset by remember(layer.id) { mutableStateOf(Offset.Zero) }
    var viewport by remember(layer.id) { mutableStateOf(IntSize.Zero) }
    val latestScale = rememberUpdatedState(scale)
    val latestOffset = rememberUpdatedState(offset)

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().background(Card).padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose, modifier = Modifier.size(44.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Закрыть редактор", tint = TextPrimary)
            }
            Column(Modifier.weight(1f)) {
                Text("Редактор фото", color = TextPrimary, fontSize = 16.sp)
                Text("Перемещение · масштабирование", color = Dim, fontSize = 11.sp)
            }
            IconButton(onClick = { scale = 1f; offset = Offset.Zero }, modifier = Modifier.size(44.dp)) {
                Icon(Icons.Default.Refresh, contentDescription = "Сбросить масштаб", tint = TextPrimary)
            }
            GradientButton(text = "Готово", onClick = onClose)
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().padding(8.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(RadiusMedium))
                .background(Card2)
                .onSizeChanged { viewport = it }
                .pointerInput(bitmap, viewport) {
                    detectTransformGestures { centroid, pan, zoom, _ ->
                        val source = bitmap ?: return@detectTransformGestures
                        val next = transformPhotoViewport(
                            latestScale.value, latestOffset.value, centroid, pan, zoom, viewport,
                            source.width, source.height
                        )
                        scale = next.scale
                        offset = next.offset
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap!!.asImageBitmap(),
                    contentDescription = "Редактируемая фотография",
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationX = offset.x
                        translationY = offset.y
                    },
                    contentScale = ContentScale.Fit
                )
            } else {
                Text("Не удалось загрузить изображение", color = Dim)
            }
        }

        Column(Modifier.fillMaxWidth().background(Card).padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Один палец — перемещение", color = Dim, fontSize = 12.sp)
                Text("Два пальца — масштаб", color = Dim, fontSize = 12.sp)
            }
            if (bitmap != null) LabeledSlider("Масштаб", scale, 1f..8f, "${(scale * 100).toInt()}%") { requested ->
                val source = bitmap ?: return@LabeledSlider
                val next = transformPhotoViewport(
                    scale, offset, Offset(viewport.width / 2f, viewport.height / 2f), Offset.Zero,
                    requested / scale.coerceAtLeast(0.001f), viewport, source.width, source.height
                )
                scale = next.scale
                offset = next.offset
            }
        }
    }
}
