package com.dvdmaker.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Camera
import android.graphics.ColorMatrixColorFilter
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.util.LruCache
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.CancellationException
import kotlin.math.roundToInt
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/**
 * Ordered image-operation executor shared by preview and export.
 * Every supported node mutates only a derived working bitmap in serialized order.
 * Geometry is rasterized at its node position, so later crops/effects consume its output.
 * Source files and Layer JSON remain untouched.
 */
object ImageOperationRenderer {
    /** Apply the serialized fade operation (or its legacy image-effects form), or draw unchanged. */
    fun drawFade(
        canvas: Canvas,
        layer: Layer,
        bitmap: Bitmap,
        sourceRect: Rect,
        destinationRect: RectF,
        paint: Paint,
        operation: ImageOperation?,
        sourcePath: String = layer.path
    ) {
        val isSupportedFadeOperation = operation?.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION &&
            (operation.type == ImageOperationType.FADE || operation.type == ImageOperationType.LEGACY_PREFIX + "image-effects")
        // A persisted disabled operation explicitly means identity. Do not fall
        // through to Layer's compatibility fields, which may still contain the
        // pre-migration value and would accidentally re-enable the effect.
        if (isSupportedFadeOperation && operation?.enabled == false) {
            canvas.drawBitmap(bitmap, sourceRect, destinationRect, paint)
            return
        }
        val params = operation?.takeIf {
            it.enabled && it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION &&
                (it.type == ImageOperationType.FADE || it.type == ImageOperationType.LEGACY_PREFIX + "image-effects")
        }?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }

        // Layer fields remain the compatibility source for projects that have not
        // yet materialized an operation snapshot (including older JSON documents).
        val fade = params?.optDouble("fade", layer.imageFade.toDouble())?.toFloat()
            ?: layer.imageFade
        val style = (params?.optInt("fadeStyle", layer.imageFadeStyle) ?: layer.imageFadeStyle).coerceIn(0, 1)
        val edges = (params?.optInt("fadeEdges", layer.imageFadeEdges) ?: layer.imageFadeEdges).coerceIn(1, 15)
            .let { it and 15 }
        if (fade <= 0.001f) {
            canvas.drawBitmap(bitmap, sourceRect, destinationRect, paint)
            return
        }

        // Overscan prevents a thin antialiased fringe after rotation/perspective.
        val expanded = RectF(destinationRect).apply { inset(-4f, -4f) }
        val save = canvas.saveLayer(expanded, null)
        canvas.drawBitmap(bitmap, sourceRect, destinationRect, paint)

        val fadeWidth = (destinationRect.width() * fade).coerceAtLeast(1f)
        val fadeHeight = (destinationRect.height() * fade).coerceAtLeast(1f)
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }

        // Transparent cutouts fade along the real object silhouette, not file bounds.
        val objectMask = ObjectMasks.mask(sourcePath, bitmap, fade, style, edges)
        if (objectMask != null) {
            // The mask is built at <=1536 px; sourceRect is in bitmap pixels. Without rescaling,
            // only part of the mask covered the image and the rest stayed unmasked (rectangular fade).
            val mx = objectMask.width / bitmap.width.toFloat()
            val my = objectMask.height / bitmap.height.toFloat()
            val maskRect = Rect(
                (sourceRect.left * mx).roundToInt().coerceIn(0, objectMask.width - 1),
                (sourceRect.top * my).roundToInt().coerceIn(0, objectMask.height - 1),
                (sourceRect.right * mx).roundToInt().coerceIn(1, objectMask.width),
                (sourceRect.bottom * my).roundToInt().coerceIn(1, objectMask.height)
            )
            canvas.drawBitmap(objectMask, maskRect, destinationRect, maskPaint)
        } else if (style == 1) {
            val maskBitmap = OrganicFadeMasks.get(edges, fade)
            val shader = BitmapShader(maskBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            shader.setLocalMatrix(Matrix().apply {
                setScale(destinationRect.width() / maskBitmap.width, destinationRect.height() / maskBitmap.height)
                postTranslate(destinationRect.left, destinationRect.top)
            })
            maskPaint.shader = shader
            canvas.drawRect(expanded, maskPaint)
        } else {
            val positions = floatArrayOf(0f, 0.12f, 0.35f, 0.65f, 0.88f, 1f)
            val rise = intArrayOf(0x00000000, 0x16000000, 0x66000000,
                0xCC000000.toInt(), Color.WHITE, Color.WHITE)
            val fall = intArrayOf(Color.WHITE, Color.WHITE, 0xCC000000.toInt(),
                0x66000000, 0x16000000, 0x00000000)
            val masks = ArrayList<Shader>(4)
            if (edges and 1 != 0) masks += LinearGradient(destinationRect.left, 0f,
                destinationRect.left + fadeWidth, 0f, rise, positions, Shader.TileMode.CLAMP)
            if (edges and 2 != 0) masks += LinearGradient(destinationRect.right - fadeWidth, 0f,
                destinationRect.right, 0f, fall, positions, Shader.TileMode.CLAMP)
            if (edges and 4 != 0) masks += LinearGradient(0f, destinationRect.top,
                0f, destinationRect.top + fadeHeight, rise, positions, Shader.TileMode.CLAMP)
            if (edges and 8 != 0) masks += LinearGradient(0f, destinationRect.bottom - fadeHeight,
                0f, destinationRect.bottom, fall, positions, Shader.TileMode.CLAMP)
            if (masks.isNotEmpty()) {
                val combined = masks.drop(1).fold(masks.first()) { acc, shader ->
                    ComposeShader(acc, shader, PorterDuff.Mode.MULTIPLY)
                }
                maskPaint.shader = combined
                canvas.drawRect(expanded, maskPaint)
            }
        }
        canvas.restoreToCount(save)
    }

    private data class OrderedBitmapResult(val bitmap: Bitmap, val referenceWidth: Int)

    // Full-resolution results (cut-outs, upscales) are larger than the old fixed 24 MB and were
    // evicted on insert, so the whole stack — including SHA-256 hashing — re-ran every frame.
    private val previewGeneration = AtomicLong(0L)
    private val prefixCacheHits = AtomicLong(0L)

    internal fun prefixCacheHitsForTest(): Long = prefixCacheHits.get()
    internal fun resetPrefixCacheStatsForTest() { prefixCacheHits.set(0L) }

    /** Invalidates any in-flight preview executor. Call when a newer slider/render state is requested. */
    fun cancelPendingPreview() { previewGeneration.incrementAndGet() }

    private fun previewStillCurrent(generation: Long): Boolean =
        previewGeneration.get() == generation && !Thread.currentThread().isInterrupted

    // Prefix snapshots are copies: the live executor is free to recycle its working bitmap
    // after advancing to the next node without invalidating an earlier cached prefix.
    private fun cachePrefix(key: String, bitmap: Bitmap, referenceWidth: Int) {
        val snapshot = runCatching { bitmap.copy(Bitmap.Config.ARGB_8888, false) }.getOrNull() ?: return
        orderedBitmapCache.put(key, OrderedBitmapResult(snapshot, referenceWidth.coerceAtLeast(1)))
    }

    private val orderedBitmapCache = object : LruCache<String, OrderedBitmapResult>(
        (Runtime.getRuntime().maxMemory() / 6).coerceIn(24L * 1024 * 1024, 96L * 1024 * 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: OrderedBitmapResult): Int = value.bitmap.byteCount
    }

    private fun prefixCacheKey(
        layer: Layer,
        plan: ImageProcessingPipeline.ImageRenderPlan,
        backdrop: BackdropLight?,
        endExclusive: Int,
        preview: Boolean
    ): String = buildString {
        append(plan.sourcePath).append("|").append(layer.id).append("|prefix=").append(endExclusive)
        plan.execution.take(endExclusive).forEach { step ->
            val op = step.operation
            append("|").append(op.id).append(':').append(op.type).append(':').append(op.enabled)
                .append(':').append(op.schemaVersion).append(':').append(op.parameters)
                .append(':').append(op.assetPath).append(':').append(op.resultPath)
                .append(':').append(op.inputOperationId).append(':').append(step.dependencyValid)
        }
        append("|preview=").append(preview)
        // Geometry/crop/color prefixes are backdrop-independent and remain reusable.
        // Only include the panel light context after a backdrop-consuming node.
        val usesBackdrop = plan.execution.take(endExclusive).any { it.operation.type == ImageOperationType.EDGE_INTEGRATION ||
            it.operation.type == ImageOperationType.LEGACY_PREFIX + "edge-integration" }
        if (usesBackdrop) append("|env=").append(backdrop?.color ?: layer.imageWrapColor)
            .append(':').append(backdrop?.lx ?: 0f).append(':').append(backdrop?.ly ?: 0f)
            .append(':').append(backdrop?.amount ?: 0f).append(':').append(backdrop?.strength ?: 1f)
    }

    private fun operationCacheKey(
        layer: Layer,
        plan: ImageProcessingPipeline.ImageRenderPlan,
        backdrop: BackdropLight?
    ): String = buildString {
        append(plan.sourcePath).append('|').append(layer.id)
        plan.orderedOperations.forEach { op ->
            append('|').append(op.id).append(':').append(op.type).append(':').append(op.enabled)
                .append(':').append(op.schemaVersion).append(':').append(op.parameters)
                .append(':').append(op.assetPath).append(':').append(op.resultPath)
                .append(':').append(op.inputOperationId)
        }
        append("|blur=").append(plan.blurLevel)
        append("|env=").append(backdrop?.color ?: layer.imageWrapColor)
            .append(':').append(backdrop?.lx ?: 0f).append(':').append(backdrop?.ly ?: 0f)
            .append(':').append(backdrop?.amount ?: 0f).append(':').append(backdrop?.strength ?: 1f)
    }

    private fun cropBitmap(source: Bitmap, params: JSONObject): Bitmap {
        val left = params.optDouble("left", 0.0).toFloat().coerceIn(0f, 0.8f)
        val top = params.optDouble("top", 0.0).toFloat().coerceIn(0f, 0.8f)
        val right = params.optDouble("right", 1.0).toFloat().coerceIn(0.2f, 1f)
        val bottom = params.optDouble("bottom", 1.0).toFloat().coerceIn(0.2f, 1f)
        val l = (left * source.width).toInt().coerceIn(0, source.width - 1)
        val t = (top * source.height).toInt().coerceIn(0, source.height - 1)
        val r = (right * source.width).toInt().coerceIn(l + 1, source.width)
        val b = (bottom * source.height).toInt().coerceIn(t + 1, source.height)
        if (l == 0 && t == 0 && r == source.width && b == source.height) return source
        return Bitmap.createBitmap(source, l, t, r - l, b - t)
    }

    private fun gradeBitmap(source: Bitmap, params: JSONObject): Bitmap {
        val grade = Layer(
            imgHue = params.optDouble("hue", 0.0).toFloat().coerceIn(-180f, 180f),
            imgSat = params.optDouble("saturation", 1.0).toFloat().coerceIn(0f, 2.5f),
            imgBright = params.optDouble("brightness", 0.0).toFloat().coerceIn(-0.6f, 0.6f),
            imgContrast = params.optDouble("contrast", 1.0).toFloat().coerceIn(0.5f, 1.8f),
            imgTemp = params.optDouble("temperature", 0.0).toFloat().coerceIn(-1f, 1f),
            imgColorize = params.optDouble("colorize", 0.0).toFloat().coerceIn(0f, 1f),
            imgColorizeColor = params.optInt("colorizeColor", 0xFF2E6FD0.toInt())
        )
        if (!grade.hasImageGrade) return source
        val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(FxPainter.imageMatrix(grade))
        }
        Canvas(out).drawBitmap(source, 0f, 0f, paint)
        return out
    }

    private fun fadeBitmap(source: Bitmap, layer: Layer, operation: ImageOperation, cacheKey: String): Bitmap {
        val params = runCatching { JSONObject(operation.parameters) }.getOrDefault(JSONObject())
        if (params.optDouble("fade", layer.imageFade.toDouble()).toFloat() <= 0.001f) return source
        val out = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val rect = Rect(0, 0, source.width, source.height)
        drawFade(
            Canvas(out), layer, source, rect,
            RectF(0f, 0f, source.width.toFloat(), source.height.toFloat()),
            Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG), operation,
            "$cacheKey|fade:${operation.id}|${source.width}x${source.height}"
        )
        return out
    }

    private fun edgeBitmap(
        source: Bitmap,
        layer: Layer,
        operation: ImageOperation,
        backdrop: BackdropLight?,
        environmentColor: Int,
        cacheKey: String
    ): Bitmap {
        val p = runCatching { JSONObject(operation.parameters) }.getOrDefault(JSONObject())
        val edgeClean = p.optDouble("edgeClean", layer.imageEdgeClean.toDouble()).toFloat().coerceIn(0f, 1f)
        val lightWrap = p.optDouble("lightWrap", layer.imageLightWrap.toDouble()).toFloat().coerceIn(0f, 1f)
        val edgeRelight = p.optDouble("edgeRelight", layer.imageEdgeRelight.toDouble()).toFloat().coerceIn(0f, 1f)
        val wrapAuto = p.optBoolean("wrapAuto", layer.imageWrapAuto)
        val wrapColor = if (wrapAuto) environmentColor else p.optInt("wrapColor", layer.imageWrapColor)
        return EdgeIntegration.process(
            "$cacheKey|edge:${operation.id}", source,
            edgeClean,
            lightWrap * (backdrop?.strength ?: 1f),
            edgeRelight * (backdrop?.strength ?: 1f),
            wrapColor, backdrop?.lx ?: 0f, backdrop?.ly ?: 0f,
            backdrop?.amount ?: 0f,
            p.optDouble("choke", layer.imageChoke.toDouble()).toFloat().coerceIn(0f, 1f),
            p.optDouble("edgeShade", layer.imageEdgeShade.toDouble()).toFloat().coerceIn(0f, 1f),
            p.optDouble("colorMatch", layer.imageColorMatch.toDouble()).toFloat().coerceIn(0f, 1f),
            environmentColor
        )
    }

    /** Apply a geometry node to the current raster, expanding its bounds instead of
     * deferring the transform until the final draw. This makes Crop→Geometry and
     * Geometry→Crop observably different and preserves the complete transformed image. */
    private fun geometryBitmap(source: Bitmap, params: JSONObject): Bitmap? {
        val rotation = params.optDouble("rotation", 0.0).toFloat()
        val flipX = params.optBoolean("flipX", false)
        val flipY = params.optBoolean("flipY", false)
        val tiltX = params.optDouble("tiltX", 0.0).toFloat()
        val tiltY = params.optDouble("tiltY", 0.0).toFloat()
        val changed = kotlin.math.abs(rotation) > 0.001f || flipX || flipY ||
            kotlin.math.abs(tiltX) > 0.01f || kotlin.math.abs(tiltY) > 0.01f
        if (!changed) return source

        // Ask Android's Canvas matrix for the exact bounds of the same transform
        // sequence used by the historical renderer (including Camera perspective).
        val probe = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        val probeCanvas = Canvas(probe)
        probeCanvas.translate(source.width / 2f, source.height / 2f)
        applyGeometryValues(probeCanvas, rotation, flipX, flipY, tiltX, tiltY)
        val matrix = Matrix()
        @Suppress("DEPRECATION")
        probeCanvas.getMatrix(matrix)
        probe.recycle()

        val bounds = RectF(-source.width / 2f, -source.height / 2f,
            source.width / 2f, source.height / 2f)
        // mapRect's Boolean reports whether the mapped rectangle remains axis-aligned;
        // false is expected for rotations and is not a mapping failure.
        matrix.mapRect(bounds)
        if (!bounds.left.isFinite() || !bounds.top.isFinite() ||
            !bounds.right.isFinite() || !bounds.bottom.isFinite()) return null
        val outWidth = kotlin.math.ceil(bounds.width().toDouble()).toInt().coerceAtLeast(1)
        val outHeight = kotlin.math.ceil(bounds.height().toDouble()).toInt().coerceAtLeast(1)
        // A malformed/future transform must not trigger an unbounded allocation.
        if (outWidth > 16384 || outHeight > 16384 || outWidth.toLong() * outHeight.toLong() > 24L * 1024L * 1024L) return null

        val output = runCatching {
            Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
        }.getOrNull() ?: return null
        val canvas = Canvas(output)
        canvas.translate(-bounds.left, -bounds.top)
        canvas.translate(source.width / 2f, source.height / 2f)
        applyGeometryValues(canvas, rotation, flipX, flipY, tiltX, tiltY)
        canvas.drawBitmap(source, -source.width / 2f, -source.height / 2f,
            Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return output
    }

    /** Opacity is a real stack node: later Fade/Blur/Edge nodes receive its alpha. */
    private fun opacityBitmap(source: Bitmap, opacity: Float): Bitmap {
        val alpha = (opacity.coerceIn(0f, 1f) * 255f).roundToInt()
        if (alpha >= 255) return source
        val output = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { this.alpha = alpha }
        Canvas(output).drawBitmap(source, 0f, 0f, paint)
        return output
    }

    /** A PNG materialization of the exact ordered prefix immediately before an AI node. */
    class MaterializedInput internal constructor(
        val filePath: String,
        val bitmap: Bitmap,
        val fingerprint: String,
        val operations: List<ImageOperation>,
        internal val generatedPaths: List<String> = emptyList()
    ) : AutoCloseable {
        private var inputReleased = false
        private var generatedCommitted = false

        fun commitGenerated() { generatedCommitted = true }

        fun releaseInput() {
            if (inputReleased) return
            inputReleased = true
            if (!bitmap.isRecycled) bitmap.recycle()
            runCatching { File(filePath).delete() }
        }

        override fun close() {
            releaseInput()
            if (!generatedCommitted) generatedPaths.forEach { runCatching { File(it).delete() } }
        }
    }

    /** Pixel fingerprint shared by AI materialization, replay and synchronous preview validation. */
    private val fingerprintCache = LruCache<String, String>(64)

    fun bitmapFingerprint(bitmap: Bitmap): String {
        // generationId changes on any pixel mutation, so a hit is exact and spares a full-image hash.
        val memoKey = "${bitmap.generationId}:${bitmap.width}x${bitmap.height}"
        fingerprintCache.get(memoKey)?.let { return it }
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(ByteBuffer.allocate(8).putInt(bitmap.width).putInt(bitmap.height).array())
        val row = IntArray(bitmap.width)
        val bytes = ByteBuffer.allocate(bitmap.width * 4)
        val ints = bytes.asIntBuffer()
        for (y in 0 until bitmap.height) {
            bitmap.getPixels(row, 0, bitmap.width, 0, y, bitmap.width, 1)
            ints.clear()
            ints.put(row)
            digest.update(bytes.array())
        }
        val result = digest.digest().joinToString("") { "%02x".format(it) }
        fingerprintCache.put(memoKey, result)
        return result
    }

    internal fun materializePng(context: Context, source: Bitmap): Pair<File, Bitmap>? {
        val file = runCatching { File.createTempFile("dvd-ai-input-", ".png", context.cacheDir) }.getOrNull() ?: return null
        return try {
            FileOutputStream(file).use { stream ->
                if (!source.compress(Bitmap.CompressFormat.PNG, 100, stream)) throw IllegalStateException("PNG encode failed")
                stream.flush()
                stream.fd.sync()
            }
            val decoded = BitmapFactory.decodeFile(file.absolutePath) ?: throw IllegalStateException("PNG decode failed")
            if (decoded.width != source.width || decoded.height != source.height) {
                decoded.recycle()
                throw IllegalStateException("Materialized bitmap dimensions changed")
            }
            file to decoded
        } catch (_: Throwable) {
            file.delete()
            null
        }
    }

    private fun withInputFingerprint(operation: ImageOperation, fingerprint: String): ImageOperation {
        val params = runCatching { JSONObject(operation.parameters) }.getOrDefault(JSONObject())
        params.put("inputFingerprint", fingerprint)
        return operation.copy(parameters = params.toString())
    }

    /**
     * Executes every supported node before [targetType], materializes that exact raster
     * as a durable-for-the-call PNG, then decodes the file for the AI model. Previous AI
     * nodes are reused only when their stored input fingerprint matches; otherwise they
     * are rerun from a freshly materialized predecessor and their cache paths are updated.
     * Unsupported/future nodes and backdrop-dependent edge operations without a backdrop
     * fail closed instead of handing AI a stale or visually different source.
     */
    suspend fun materializeBeforeOperation(
        context: Context,
        store: Store,
        layer: Layer,
        targetType: String,
        backdrop: BackdropLight? = null,
        onProgress: (Int) -> Unit = {}
    ): MaterializedInput? {
        val plan = ImageProcessingPipeline.renderPlan(layer)
        // A not-yet-recorded cut-out/upscale will be inserted before Fade/Edge effects.
        val targetIndex = ImageProcessingPipeline.insertionIndex(plan.orderedOperations, targetType)
        val stableTypes = plan.orderedOperations.filterNot { it.type.startsWith(ImageOperationType.LEGACY_PREFIX) }
            .mapTo(mutableSetOf()) { it.type }
        var current = Bitmaps.get(plan.sourcePath) ?: return null
        var ownsCurrent = false
        var prefixChanged = false
        val updated = plan.orderedOperations.toMutableList()
        val generatedPaths = mutableListOf<String>()
        var completed = false
        val key = operationCacheKey(layer, plan, backdrop)

        fun adopt(next: Bitmap, owned: Boolean) {
            if (next === current) return
            if (ownsCurrent && !current.isRecycled) current.recycle()
            current = next
            ownsCurrent = owned
            prefixChanged = true
        }

        try {
            for (index in 0 until targetIndex) {
                currentCoroutineContext().ensureActive()
                val step = plan.execution[index]
                val op = step.operation
                val isLegacy = op.type.startsWith(ImageOperationType.LEGACY_PREFIX)
                if (!step.dependencyValid) return null
                if (isLegacy) {
                    val params = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
                    when (op.type) {
                        ImageOperationType.LEGACY_PREFIX + "crop" -> if (ImageOperationType.CROP !in stableTypes) adopt(cropBitmap(current, params), true)
                        ImageOperationType.LEGACY_PREFIX + "geometry" -> if (ImageOperationType.GEOMETRY !in stableTypes) {
                            val next = geometryBitmap(current, params) ?: return null
                            adopt(next, true)
                        }
                        ImageOperationType.LEGACY_PREFIX + "opacity" -> if (ImageOperationType.OPACITY !in stableTypes) adopt(opacityBitmap(current, params.optDouble("value", layer.alpha.toDouble()).toFloat()), true)
                        ImageOperationType.LEGACY_PREFIX + "color-grade" -> if (ImageOperationType.COLOR_GRADE !in stableTypes) adopt(gradeBitmap(current, params), true)
                        ImageOperationType.LEGACY_PREFIX + "image-effects" -> if (ImageOperationType.FADE !in stableTypes) adopt(fadeBitmap(current, layer, op, key), true)
                        ImageOperationType.LEGACY_PREFIX + "edge-integration" -> if (ImageOperationType.EDGE_INTEGRATION !in stableTypes) {
                            if (backdrop == null && (params.optBoolean("wrapAuto", layer.imageWrapAuto) ||
                                params.optDouble("lightWrap", layer.imageLightWrap.toDouble()) > 0.001 ||
                                params.optDouble("edgeRelight", layer.imageEdgeRelight.toDouble()) > 0.001 ||
                                params.optDouble("edgeShade", layer.imageEdgeShade.toDouble()) > 0.001 ||
                                params.optDouble("colorMatch", layer.imageColorMatch.toDouble()) > 0.001)) return null
                            adopt(edgeBitmap(current, layer, op, backdrop, backdrop?.color ?: layer.imageWrapColor, key), false)
                        }
                        ImageOperationType.LEGACY_PREFIX + "blur" -> if (ImageOperationType.GAUSSIAN_BLUR !in stableTypes) {
                            val level = params.optInt("level", layer.imageBlur).coerceIn(1, 3)
                            val sigma = when (level) { 1 -> 0.006f; 2 -> 0.012f; else -> 0.022f }
                            adopt(Blur.gaussianPreserveAlpha(current, sigma), true)
                        }
                    }
                    continue
                }
                if (!op.enabled) continue
                if (op.schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION) return null
                val params = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
                when (op.type) {
                    ImageOperationType.CROP -> adopt(cropBitmap(current, params), true)
                    ImageOperationType.GEOMETRY -> adopt(geometryBitmap(current, params) ?: return null, true)
                    ImageOperationType.OPACITY -> adopt(opacityBitmap(current, params.optDouble("value", layer.alpha.toDouble()).toFloat()), true)
                    ImageOperationType.COLOR_GRADE -> adopt(gradeBitmap(current, params), true)
                    ImageOperationType.FADE -> adopt(fadeBitmap(current, layer, op, key), true)
                    ImageOperationType.EDGE_INTEGRATION -> {
                        if (backdrop == null && (params.optBoolean("wrapAuto", layer.imageWrapAuto) ||
                            params.optDouble("lightWrap", layer.imageLightWrap.toDouble()) > 0.001 ||
                            params.optDouble("edgeRelight", layer.imageEdgeRelight.toDouble()) > 0.001 ||
                            params.optDouble("edgeShade", layer.imageEdgeShade.toDouble()) > 0.001 ||
                            params.optDouble("colorMatch", layer.imageColorMatch.toDouble()) > 0.001)) return null
                        adopt(edgeBitmap(current, layer, op, backdrop, backdrop?.color ?: layer.imageWrapColor, key), false)
                    }
                    ImageOperationType.GAUSSIAN_BLUR -> {
                        val inputFingerprint = bitmapFingerprint(current)
                        val storedFingerprint = params.optString("inputFingerprint", "")
                        val cached = op.resultPath.takeIf {
                            storedFingerprint.isNotBlank() && storedFingerprint == inputFingerprint && File(it).isFile
                        }?.let { Bitmaps.get(it) }
                        if (cached != null) {
                            adopt(cached, false)
                            prefixChanged = false
                        } else {
                            val sigma = params.optDouble("sigmaFrac", 0.012).toFloat().coerceIn(0.001f, 0.12f)
                            val blurred = Blur.gaussianPreserveAlpha(current, sigma)
                            val saved = store.saveBitmap(blurred, png = true, prefix = "derived-") ?: run {
                                if (blurred !== current && !blurred.isRecycled) blurred.recycle()
                                return null
                            }
                            generatedPaths += saved
                            updated[index] = withInputFingerprint(op.copy(resultPath = saved), inputFingerprint)
                            adopt(blurred, blurred !== current)
                            prefixChanged = false
                        }
                    }
                    ImageOperationType.ENHANCE, ImageOperationType.BACKGROUND_REMOVAL -> {
                        val fingerprint = bitmapFingerprint(current)
                        val storedFingerprint = params.optString("inputFingerprint", "")
                        val cached = op.resultPath.takeIf { it.isNotBlank() && File(it).isFile &&
                            ((storedFingerprint.isNotBlank() && storedFingerprint == fingerprint) ||
                                (storedFingerprint.isBlank() && !prefixChanged)) }?.let { Bitmaps.get(it) }
                        if (cached != null) {
                            adopt(cached, false)
                            prefixChanged = false
                        } else {
                            val materialized = materializePng(context, current) ?: return null
                            val (file, aiInput) = materialized
                            var basePath = ""
                            val output = try {
                                when (op.type) {
                                    ImageOperationType.ENHANCE -> {
                                        val enhanced = Enhancer.enhanceKeepingBase(
                                            context.applicationContext, store, aiInput,
                                            params.optDouble("scale", 1.0).toFloat().coerceIn(1f, 4f),
                                            EnhanceOpts(
                                                params.optDouble("detail", 0.45).toFloat().coerceIn(0f, 1f),
                                                params.optDouble("grain", 0.6).toFloat().coerceIn(0f, 1f)
                                            )
                                        ) { onProgress(it) } ?: return null
                                        basePath = enhanced.basePath
                                        generatedPaths += basePath
                                        enhanced.bitmap
                                    }
                                    else -> {
                                        val mask = ImageProcessingPipeline.loadMask(op.assetPath) ?: return null
                                        BgRemover.applyMask(aiInput, mask.first, mask.second.first, mask.second.second) { onProgress(it) }
                                    }
                                }
                            } finally {
                                if (!aiInput.isRecycled) aiInput.recycle()
                                file.delete()
                            }
                            val saved = store.saveBitmap(output, png = true, prefix = "derived-")
                            if (saved == null) { if (!output.isRecycled) output.recycle(); return null }
                            generatedPaths += saved
                            updated[index] = withInputFingerprint(
                                op.copy(resultPath = saved, assetPath = if (op.type == ImageOperationType.ENHANCE) basePath else op.assetPath),
                                fingerprint
                            )
                            adopt(output, true)
                            prefixChanged = false
                        }
                    }
                    else -> return null
                }
            }
            val finalInput = materializePng(context, current) ?: return null
            try {
                val fingerprint = bitmapFingerprint(finalInput.second)
                // Stored operations are a prefix of the effective list; Layer-field projections
                // must not leak into the persisted stack.
                val result = MaterializedInput(
                    finalInput.first.absolutePath, finalInput.second, fingerprint,
                    updated.take(layer.imageOperations.size), generatedPaths.toList()
                )
                completed = true
                return result
            } catch (t: Throwable) {
                if (!finalInput.second.isRecycled) finalInput.second.recycle()
                finalInput.first.delete()
                throw t
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Throwable) {
            return null
        } finally {
            if (!completed) generatedPaths.forEach { runCatching { File(it).delete() } }
            if (ownsCurrent && !current.isRecycled) current.recycle()
        }
    }

    /**
     * Executes the persisted stack from its immutable source, one operation at a time.
     * AI inference stays outside draw; this synchronous path consumes an AI result only
     * when its stored input fingerprint matches the current ordered bitmap.
     */
    private fun executeOrderedBitmapStack(
        layer: Layer,
        plan: ImageProcessingPipeline.ImageRenderPlan,
        backdrop: BackdropLight?
    ): Pair<OrderedBitmapResult, String>? {
        val generation = previewGeneration.incrementAndGet()
        val cacheKey = operationCacheKey(layer, plan, backdrop)
        orderedBitmapCache.get(cacheKey)?.let {
            return if (previewStillCurrent(generation)) it to cacheKey else null
        }
        var current = Bitmaps.get(plan.sourcePath) ?: return null
        var ownsCurrent = false
        var changedSinceMaterializedResult = false
        // Cropping establishes the pixel-to-layout scale; subsequent geometry can
        // expand the raster bounds without silently rescaling the source pixels.
        var referenceWidth = current.width
        var reachedEnd = true
        var completedPrefixLength = 0
        // Presence of a stable Blur record suppresses the old Layer.imageBlur fallback
        // even when that record is disabled.
        val stableTypes = plan.orderedOperations.filterNot { it.type.startsWith(ImageOperationType.LEGACY_PREFIX) }
            .mapTo(mutableSetOf()) { it.type }
        val hasStableBlur = ImageOperationType.GAUSSIAN_BLUR in stableTypes ||
            plan.orderedOperations.any { it.type == ImageOperationType.LEGACY_PREFIX + "blur" }
        val hasStableFade = ImageOperationType.FADE in stableTypes

        fun adopt(next: Bitmap, owned: Boolean) {
            if (current === next) return
            if (ownsCurrent && !current.isRecycled) current.recycle()
            current = next
            ownsCurrent = owned
            changedSinceMaterializedResult = true
        }

        // While a settings slider is dragged, Fade/Edge/Blur run on a <=800 px copy
        // (full quality is recomputed on release). AI nodes keep the full-res input they fingerprint.
        val adjusting = Interactive.adjusting
        var shrunk = false
        fun shrinkForPreview() {
            if (!adjusting || shrunk) return
            val side = maxOf(current.width, current.height)
            if (side <= 800) return
            val k = 800f / side
            val small = Bitmap.createScaledBitmap(
                current, (current.width * k).roundToInt().coerceAtLeast(1),
                (current.height * k).roundToInt().coerceAtLeast(1), true
            )
            referenceWidth = (referenceWidth * k).roundToInt().coerceAtLeast(1)
            adopt(small, true)
            shrunk = true
        }
        fun isHeavy(type: String) = type == ImageOperationType.FADE || type == ImageOperationType.EDGE_INTEGRATION ||
            type == ImageOperationType.GAUSSIAN_BLUR || type == ImageOperationType.LEGACY_PREFIX + "image-effects" ||
            type == ImageOperationType.LEGACY_PREFIX + "edge-integration" || type == ImageOperationType.LEGACY_PREFIX + "blur"

        for (index in plan.execution.indices) {
            if (!previewStillCurrent(generation)) return null
            val step = plan.execution[index]
            val op = step.operation
            val isLegacy = op.type.startsWith(ImageOperationType.LEGACY_PREFIX)
            if (!step.dependencyValid) { reachedEnd = false; break }
            completedPrefixLength = index + 1
            if (!op.enabled) continue
            if (op.schemaVersion != ImageOperation.CURRENT_SCHEMA_VERSION) { reachedEnd = false; completedPrefixLength = index; break }
            val params = runCatching { JSONObject(op.parameters) }.getOrDefault(JSONObject())
            if (isHeavy(op.type)) shrinkForPreview()
            val prefixKey = prefixCacheKey(layer, plan, backdrop, index + 1, shrunk)
            val cachedPrefix = orderedBitmapCache.get(prefixKey)
            if (cachedPrefix != null) {
                prefixCacheHits.incrementAndGet()
                adopt(cachedPrefix.bitmap, false)
                referenceWidth = cachedPrefix.referenceWidth
                changedSinceMaterializedResult = false
                continue
            }
            if (isLegacy) {
                when (op.type) {
                    ImageOperationType.LEGACY_PREFIX + "crop" -> if (ImageOperationType.CROP !in stableTypes) {
                        val next = cropBitmap(current, params)
                        if (next !== current) {
                            adopt(next, true)
                            referenceWidth = current.width
                        }
                    }
                    ImageOperationType.LEGACY_PREFIX + "opacity" -> if (ImageOperationType.OPACITY !in stableTypes) {
                        val value = params.optDouble("value", layer.alpha.toDouble()).toFloat().coerceIn(0f, 1f)
                        val next = opacityBitmap(current, value)
                        if (next !== current) adopt(next, true)
                    }
                    ImageOperationType.LEGACY_PREFIX + "color-grade" -> if (ImageOperationType.COLOR_GRADE !in stableTypes) {
                        val next = gradeBitmap(current, params)
                        if (next !== current) adopt(next, true)
                    }
                    ImageOperationType.LEGACY_PREFIX + "image-effects" -> if (!hasStableFade) {
                        adopt(fadeBitmap(current, layer, op, cacheKey), true)
                    }
                    ImageOperationType.LEGACY_PREFIX + "edge-integration" -> if (ImageOperationType.EDGE_INTEGRATION !in stableTypes) {
                        val next = edgeBitmap(current, layer, op, backdrop, backdrop?.color ?: layer.imageWrapColor, cacheKey)
                        if (next !== current) adopt(next, false)
                    }
                    ImageOperationType.LEGACY_PREFIX + "geometry" -> if (ImageOperationType.GEOMETRY !in stableTypes) {
                        val next = geometryBitmap(current, params)
                        if (next == null) { reachedEnd = false; completedPrefixLength = index; break }
                        if (next !== current) adopt(next, true)
                    }
                    ImageOperationType.LEGACY_PREFIX + "blur" -> if (ImageOperationType.GAUSSIAN_BLUR !in stableTypes) {
                        val level = params.optInt("level", layer.imageBlur).coerceIn(1, 3)
                        val sigma = when (level) { 1 -> 0.006f; 2 -> 0.012f; else -> 0.022f }
                        val next = try {
                            Blur.gaussianPreserveAlpha(current, sigma, isCancelled = { !previewStillCurrent(generation) })
                        } catch (_: CancellationException) { return null }
                        if (next !== current) adopt(next, true)
                    }
                }
                if (!previewStillCurrent(generation)) return null
                cachePrefix(prefixKey, current, referenceWidth)
                continue
            }
            when (op.type) {
                ImageOperationType.CROP -> {
                    val next = cropBitmap(current, params)
                    if (next !== current) {
                        adopt(next, true)
                        referenceWidth = current.width
                    }
                }
                ImageOperationType.GEOMETRY -> {
                    val next = geometryBitmap(current, params)
                    if (next == null) { reachedEnd = false; completedPrefixLength = index; break }
                    if (next !== current) adopt(next, true)
                }
                ImageOperationType.OPACITY -> {
                    val value = params.optDouble("value", layer.alpha.toDouble()).toFloat().coerceIn(0f, 1f)
                    val next = opacityBitmap(current, value)
                    if (next !== current) adopt(next, true)
                }
                ImageOperationType.COLOR_GRADE -> {
                    val next = gradeBitmap(current, params)
                    if (next !== current) adopt(next, true)
                }
                ImageOperationType.FADE, ImageOperationType.LEGACY_PREFIX + "image-effects" ->
                    adopt(fadeBitmap(current, layer, op, cacheKey), true)
                ImageOperationType.EDGE_INTEGRATION -> {
                    val next = edgeBitmap(
                        current, layer, op, backdrop,
                        backdrop?.color ?: layer.imageWrapColor, cacheKey
                    )
                    if (next !== current) adopt(next, false)
                }
                ImageOperationType.GAUSSIAN_BLUR -> {
                    val expectedInput = params.optString("inputFingerprint", "")
                    val inputMatches = expectedInput.isNotBlank() && expectedInput == bitmapFingerprint(current)
                    val legacyInputMatches = expectedInput.isBlank() && !changedSinceMaterializedResult
                    val materialized = op.resultPath.takeIf {
                        (inputMatches || legacyInputMatches) && it.isNotBlank() && java.io.File(it).isFile
                    }?.let { Bitmaps.get(it) }
                    if (materialized != null) {
                        adopt(materialized, false)
                        changedSinceMaterializedResult = false
                    } else {
                        val sigma = params.optDouble("sigmaFrac", 0.012).toFloat().coerceIn(0.001f, 0.12f)
                        val next = try {
                            Blur.gaussianPreserveAlpha(current, sigma, isCancelled = { !previewStillCurrent(generation) })
                        } catch (_: CancellationException) { return null }
                        if (next !== current) adopt(next, true)
                    }
                }
                ImageOperationType.ENHANCE, ImageOperationType.BACKGROUND_REMOVAL -> {
                    // An AI result is valid only for the exact raster that was handed
                    // to the model. New operations carry a pixel fingerprint; older
                    // projects without one retain the conservative unchanged-prefix rule.
                    val expectedInput = params.optString("inputFingerprint", "")
                    val inputMatches = expectedInput.isNotBlank() && expectedInput == bitmapFingerprint(current)
                    val legacyInputMatches = expectedInput.isBlank() && !changedSinceMaterializedResult
                    val result = op.resultPath.takeIf {
                        (inputMatches || legacyInputMatches) && it.isNotBlank() && java.io.File(it).isFile
                    }?.let { Bitmaps.get(it) }
                    if (result == null) { reachedEnd = false; completedPrefixLength = index; break }
                    adopt(result, false)
                    // AI may upscale while preserving the same physical object width.
                    referenceWidth = result.width.coerceAtLeast(1)
                    changedSinceMaterializedResult = false
                }
                else -> { reachedEnd = false; completedPrefixLength = index; break }
            }
            if (!previewStillCurrent(generation)) return null
            if (reachedEnd || completedPrefixLength == index + 1) {
                cachePrefix(prefixKey, current, referenceWidth)
            }
        }

        if (!previewStillCurrent(generation)) return null
        if (reachedEnd && !hasStableBlur && plan.blurLevel > 0) {
            shrinkForPreview()
            val sigma = when (plan.blurLevel.coerceIn(1, 3)) {
                1 -> 0.006f
                2 -> 0.012f
                else -> 0.022f
            }
            val blurred = try {
                Blur.gaussianPreserveAlpha(current, sigma, isCancelled = { !previewStillCurrent(generation) })
            } catch (_: CancellationException) { return null }
            if (blurred !== current) adopt(blurred, true)
        }

        val result = OrderedBitmapResult(current, referenceWidth.coerceAtLeast(1))
        // A safe prefix may be rendered when an asynchronous/unknown node cannot
        // run, but it gets a distinct cache identity and can never masquerade as
        // the complete stack result.
        val resultKey = (if (reachedEnd) cacheKey else "$cacheKey|prefix:$completedPrefixLength") +
            if (shrunk) "|preview" else ""
        // Results borrowed from other caches (AI output, Edge Integration) are memoized too;
        // nothing recycles a cached result, and not memoizing them forced a full re-run per frame.
        if (!previewStillCurrent(generation)) return null
        orderedBitmapCache.put(resultKey, result)
        return if (previewStillCurrent(generation)) result to resultKey else null
    }

    private fun applyGeometryValues(
        canvas: Canvas,
        rotation: Float,
        flipX: Boolean,
        flipY: Boolean,
        tiltX: Float,
        tiltY: Float
    ) {
        if (kotlin.math.abs(rotation) > 0.001f) canvas.rotate(rotation)
        if (flipX || flipY) canvas.scale(if (flipX) -1f else 1f, if (flipY) -1f else 1f)
        if (kotlin.math.abs(tiltX) > 0.01f || kotlin.math.abs(tiltY) > 0.01f) {
            val camera = Camera().apply { rotateX(tiltX.coerceIn(-65f, 65f)); rotateY(tiltY.coerceIn(-65f, 65f)) }
            val matrix = Matrix()
            camera.getMatrix(matrix)
            canvas.concat(matrix)
        }
    }

    /** Final layout bounds of the already-executed ordered raster stack. */
    fun renderedLayerSize(
        layer: Layer,
        ppm: Float,
        backdrop: BackdropLight? = null,
        renderPlan: ImageProcessingPipeline.ImageRenderPlan = ImageProcessingPipeline.renderPlan(layer)
    ): Pair<Float, Float>? {
        val executed = executeOrderedBitmapStack(layer, renderPlan, backdrop) ?: return null
        val bitmap = executed.first.bitmap
        val referenceWidth = executed.first.referenceWidth.toFloat().coerceAtLeast(1f)
        val scale = layer.widthMm * ppm / referenceWidth
        return (bitmap.width * scale) to (bitmap.height * scale)
    }

    /** Shared ordered executor used by both preview and export. */
    fun drawImageLayer(
        canvas: Canvas,
        layer: Layer,
        ppm: Float,
        backdrop: BackdropLight? = null,
        renderPlan: ImageProcessingPipeline.ImageRenderPlan = ImageProcessingPipeline.renderPlan(layer)
    ) {
        val executed = executeOrderedBitmapStack(layer, renderPlan, backdrop) ?: return
        val bitmap = executed.first.bitmap
        val cacheKey = executed.second
        val referenceWidth = executed.first.referenceWidth.toFloat().coerceAtLeast(1f)
        val width = layer.widthMm * ppm * bitmap.width / referenceWidth
        val height = layer.widthMm * ppm * bitmap.height / referenceWidth
        val destination = RectF(-width / 2f, -height / 2f, width / 2f, height / 2f)
        canvas.save()

        // Reflection and contact shadow consume the exact final executor output.
        // Re-reading previewPath(layer) here could reintroduce an old cached image
        // or apply compatibility Edge/Blur a second time after the ordered stack.
        val reflectionBitmap = bitmap.takeIf { layer.reflectionOpacity > 0.001f }

        if (layer.reflectionOpacity > 0.001f && reflectionBitmap != null) {
            val scaleY = layer.reflectionScale.coerceIn(0.1f, 1.5f)
            val scaleX = layer.reflectionScaleX.coerceIn(0.1f, 2f)
            val gap = height * layer.reflectionDistance.coerceIn(0f, 0.5f)
            val reflectedWidth = width * scaleX
            val reflectedHeight = height * scaleY
            val pivotY = height / 2f + gap
            val angle = layer.reflectionAngle.coerceIn(-75f, 75f)
            val pad = maxOf(reflectedWidth, reflectedHeight) * 0.65f + 8f
            val reflectedBounds = RectF(
                -reflectedWidth / 2f - pad, pivotY - pad,
                reflectedWidth / 2f + pad, pivotY + reflectedHeight + pad
            )
            val reflectionSave = canvas.saveLayer(reflectedBounds, null)
            canvas.save()
            applyReflectionTilt(canvas, angle, pivotY)
            val matrix = Matrix().apply {
                setScale(reflectedWidth / reflectionBitmap.width.toFloat(), -reflectedHeight / reflectionBitmap.height.toFloat())
                postTranslate(-reflectedWidth / 2f, pivotY + reflectedHeight)
            }
            val reflectionPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = (layer.reflectionOpacity.coerceIn(0f, 1f) * 255f).roundToInt()
                if (layer.reflectionBlur > 0.001f) {
                    maskFilter = android.graphics.BlurMaskFilter(
                        width * layer.reflectionBlur.coerceIn(0f, 0.25f),
                        android.graphics.BlurMaskFilter.Blur.NORMAL
                    )
                }
            }
            canvas.drawBitmap(reflectionBitmap, matrix, reflectionPaint)
            val fade = layer.reflectionFade.coerceIn(0f, 1f)
            val fadePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, pivotY, 0f, pivotY + reflectedHeight,
                    intArrayOf(Color.WHITE, Color.WHITE, Color.TRANSPARENT),
                    floatArrayOf(0f, 1f - fade, 1f), Shader.TileMode.CLAMP
                )
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            canvas.drawRect(
                -reflectedWidth / 2f - pad, pivotY,
                reflectedWidth / 2f + pad, pivotY + reflectedHeight, fadePaint
            )
            canvas.restore()
            canvas.restoreToCount(reflectionSave)
        }

        val edge = renderPlan.edgeSettings
        if (edge.contactShadow > 0.001f) {
            ContactShadowCache.get("$cacheKey|shadow", bitmap, edge.contactShadow)?.let { shadow ->
                val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    alpha = (edge.contactShadow * 150f).roundToInt().coerceIn(0, 150)
                }
                val dx = if (backdrop != null) -backdrop.lx * width * 0.018f else width * 0.008f
                val dy = if (backdrop != null) -backdrop.ly * height * 0.018f + height * 0.006f else height * 0.012f
                canvas.drawBitmap(shadow, null, RectF(destination).apply { offset(dx, dy) }, shadowPaint)
            }
        }

        val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(bitmap, null, destination, photoPaint)
        canvas.restore()
    }

    private fun applyReflectionTilt(canvas: Canvas, angle: Float, pivotY: Float) {
        if (kotlin.math.abs(angle) < 0.01f) return
        val camera = android.graphics.Camera()
        camera.rotateX(angle.coerceIn(-75f, 75f))
        val matrix = android.graphics.Matrix()
        camera.getMatrix(matrix)
        matrix.preTranslate(0f, -pivotY)
        matrix.postTranslate(0f, pivotY)
        canvas.concat(matrix)
    }

    fun trimMemory() {
        ContactShadowCache.trim()
        orderedBitmapCache.evictAll()
    }

    private object ContactShadowCache {
        private val cache = object : android.util.LruCache<String, Bitmap>(12 * 1024 * 1024) {
            override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
        }
        fun trim() = cache.evictAll()

        fun get(path: String, source: Bitmap, amount: Float): Bitmap? {
            val level = (amount.coerceIn(0f, 1f) * 20f).roundToInt()
            if (level <= 0) return null
            val key = "$path|$level|${source.width}x${source.height}"
            cache.get(key)?.let { return it }
            val pixels = IntArray(source.width * source.height)
            source.getPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
            for (i in pixels.indices) pixels[i] = ((pixels[i] ushr 24) shl 24)
            val mask = Bitmap.createBitmap(pixels, source.width, source.height, Bitmap.Config.ARGB_8888)
            val blurred = Blur.gaussian(mask, sigmaFrac = 0.012f + level / 1800f, workSide = 700)
            mask.recycle()
            cache.put(key, blurred)
            return blurred
        }
    }

}
