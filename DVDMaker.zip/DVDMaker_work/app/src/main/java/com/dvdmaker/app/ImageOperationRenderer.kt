package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.LinearGradient
import android.graphics.Matrix
import org.json.JSONObject

/**
 * Executes render-time image operations against the shared Canvas path.
 * This keeps preview and export on the same compositing implementation while
 * leaving source bitmaps and serialized legacy Layer fields untouched.
 */
object ImageOperationRenderer {
    /** Apply the serialized fade operation (or its legacy image-effects form), or draw unchanged. */
    fun drawFade(
        canvas: Canvas,
        layer: Layer,
        bitmap: Bitmap,
        sourceRect: Rect,
        destinationRect: RectF,
        paint: Paint,
        operation: ImageOperation?
    ) {
        val params = operation?.takeIf {
            it.enabled && it.schemaVersion == ImageOperation.CURRENT_SCHEMA_VERSION &&
                (it.type == ImageOperationType.FADE || it.type == ImageOperationType.LEGACY_PREFIX + "image-effects")
        }?.let { runCatching { JSONObject(it.parameters) }.getOrDefault(JSONObject()) }

        // Layer fields remain the compatibility source for projects that have not
        // yet materialized an operation snapshot (including older JSON documents).
        val fade = params?.optDouble("fade", layer.imageFade.toDouble())?.toFloat()
            ?: layer.imageFade
        val style = (params?.optInt("fadeStyle", layer.imageFadeStyle) ?: layer.imageFadeStyle).coerceIn(0, 1)
        val edges = (params?.optInt("fadeEdges", layer.imageFadeEdges) ?: layer.imageFadeEdges).coerceIn(1, 15)
            .let { it and 15 }
        if (fade <= 0.001f) {
            canvas.drawBitmap(bitmap, sourceRect, destinationRect, paint)
            return
        }

        // Overscan prevents a thin antialiased fringe after rotation/perspective.
        val expanded = RectF(destinationRect).apply { inset(-4f, -4f) }
        val save = canvas.saveLayer(expanded, null)
        canvas.drawBitmap(bitmap, sourceRect, destinationRect, paint)

        val fadeWidth = (destinationRect.width() * fade).coerceAtLeast(1f)
        val fadeHeight = (destinationRect.height() * fade).coerceAtLeast(1f)
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }

        // Transparent cutouts fade along the real object silhouette, not file bounds.
        val objectMask = ObjectMasks.mask(layer.path, bitmap, fade, style, edges)
        if (objectMask != null) {
            canvas.drawBitmap(objectMask, sourceRect, destinationRect, maskPaint)
        } else if (style == 1) {
            val maskBitmap = OrganicFadeMasks.get(edges, fade)
            val shader = BitmapShader(maskBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            shader.setLocalMatrix(Matrix().apply {
                setScale(destinationRect.width() / maskBitmap.width, destinationRect.height() / maskBitmap.height)
                postTranslate(destinationRect.left, destinationRect.top)
            })
            maskPaint.shader = shader
            canvas.drawRect(expanded, maskPaint)
        } else {
            val positions = floatArrayOf(0f, 0.12f, 0.35f, 0.65f, 0.88f, 1f)
            val rise = intArrayOf(0x00000000, 0x16000000, 0x66000000,
                0xCC000000.toInt(), Color.WHITE, Color.WHITE)
            val fall = intArrayOf(Color.WHITE, Color.WHITE, 0xCC000000.toInt(),
                0x66000000, 0x16000000, 0x00000000)
            val masks = ArrayList<Shader>(4)
            if (edges and 1 != 0) masks += LinearGradient(destinationRect.left, 0f,
                destinationRect.left + fadeWidth, 0f, rise, positions, Shader.TileMode.CLAMP)
            if (edges and 2 != 0) masks += LinearGradient(destinationRect.right - fadeWidth, 0f,
                destinationRect.right, 0f, fall, positions, Shader.TileMode.CLAMP)
            if (edges and 4 != 0) masks += LinearGradient(0f, destinationRect.top,
                0f, destinationRect.top + fadeHeight, rise, positions, Shader.TileMode.CLAMP)
            if (edges and 8 != 0) masks += LinearGradient(0f, destinationRect.bottom - fadeHeight,
                0f, destinationRect.bottom, fall, positions, Shader.TileMode.CLAMP)
            if (masks.isNotEmpty()) {
                val combined = masks.drop(1).fold(masks.first()) { acc, shader ->
                    ComposeShader(acc, shader, PorterDuff.Mode.MULTIPLY)
                }
                maskPaint.shader = combined
                canvas.drawRect(expanded, maskPaint)
            }
        }
        canvas.restoreToCount(save)
    }
}
