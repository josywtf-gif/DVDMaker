#!/usr/bin/env bash
# Скачивает шрифты Google Fonts (OFL, с кириллицей) в assets. Ошибки не фатальны.
cd "$(dirname "$0")"
OUT=app/src/main/assets/fonts
mkdir -p "$OUT"
BASE=https://raw.githubusercontent.com/google/fonts/main
while IFS='|' read -r path name; do
  [ -z "$path" ] && continue
  enc=$(printf '%s' "$path" | sed 's/\[/%5B/g; s/\]/%5D/g; s/,/%2C/g')
  if curl -fsSL --retry 2 --max-time 60 -o "$OUT/$name.ttf" "$BASE/$enc"; then
    echo "ok   $name"
  else
    rm -f "$OUT/$name.ttf"; echo "skip $name"
  fi
done < fonts.txt
ls "$OUT" | wc -l
