# PROJECT_MAP.md

Техническая карта Android-приложения DVDMaker. Описания ниже сверены с исходниками архива; карта описывает фактическую структуру, а не предполагаемые модули.

## 1. Технологии и границы проекта

- **Платформа:** Android, `applicationId`/namespace `com.dvdmaker.app`.
- **Язык и UI:** Kotlin 2.0.21, Jetpack Compose (Material 3).
- **Сборка:** Android Gradle Plugin 8.7.2, Gradle 8.9 в CI, JVM 17, `compileSdk 35`, `minSdk 26`, `targetSdk 35`.
- **Архитектура:** один Android app-модуль (`:app`); UI Compose, состояние и операции проекта сосредоточены в `AppVm`, модель проекта — в `Model.kt`, файловое хранение — в `Store`.
- **Обработка изображений:** Android `Bitmap`/`Canvas`, локальные алгоритмы Kotlin, ONNX Runtime Android для нейросетевых моделей.
- **Экспорт:** собственный рендеринг в PNG/PDF через `Exporter`.
- **Сеть:** интернет нужен для проверки/загрузки обновлений; заявленные в README инструменты удаления фона и апскейлинга выполняются локально после наличия модели.

## 2. Полная структура репозитория

```text
DVDMaker/
├── .github/
│   └── workflows/
│       └── build.yml
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── assets/
│   │       │   ├── bluray/
│   │       │   │   ├── hinge_side.png
│   │       │   │   ├── inner_door.png
│   │       │   │   ├── inner_tray.png
│   │       │   │   ├── shell_back.png
│   │       │   │   ├── shell_front.png
│   │       │   │   └── side_open.png
│   │       │   ├── fonts/
│   │       │   │   ├── Carlito.ttf
│   │       │   │   ├── DejaVu_Sans_Condensed_Bold.ttf
│   │       │   │   ├── DejaVu_Serif_Bold.ttf
│   │       │   │   ├── Inter.otf
│   │       │   │   ├── Inter_Black.otf
│   │       │   │   ├── Inter_Light.otf
│   │       │   │   ├── Liberation_Mono.ttf
│   │       │   │   ├── Liberation_Serif.ttf
│   │       │   │   └── Lora.ttf
│   │       │   ├── models/
│   │       │   │   ├── dvd_case.bin
│   │       │   │   └── realesr-general-x4v3.onnx
│   │       │   └── symbols_bluray.png
│   │       ├── java/com/dvdmaker/app/
│   │       │   ├── BgEditor.kt
│   │       │   ├── BgRemove.kt
│   │       │   ├── Blur.kt
│   │       │   ├── Bluray3D.kt
│   │       │   ├── Case3D.kt
│   │       │   ├── Checker.kt
│   │       │   ├── ColorTransfer.kt
│   │       │   ├── Components.kt
│   │       │   ├── CoverTools.kt
│   │       │   ├── DvdMesh3D.kt
│   │       │   ├── EdgeIntegration.kt
│   │       │   ├── Editor.kt
│   │       │   ├── Enhance.kt
│   │       │   ├── Export.kt
│   │       │   ├── FontMatch.kt
│   │       │   ├── Fx.kt
│   │       │   ├── Home.kt
│   │       │   ├── MainActivity.kt
│   │       │   ├── Model.kt
│   │       │   ├── Neural.kt
│   │       │   ├── Outline.kt
│   │       │   ├── Palette.kt
│   │       │   ├── Render.kt
│   │       │   ├── Snap.kt
│   │       │   ├── Store.kt
│   │       │   ├── Templates.kt
│   │       │   ├── Textures.kt
│   │       │   ├── Theme.kt
│   │       │   ├── Tools.kt
│   │       │   ├── Update.kt
│   │       │   └── Vm.kt
│   │       ├── res/
│   │       │   ├── drawable/
│   │       │   │   ├── ic_launcher_background.xml
│   │       │   │   └── ic_launcher_foreground.xml
│   │       │   ├── mipmap-anydpi-v26/ic_launcher.xml
│   │       │   ├── values/
│   │       │   │   ├── colors.xml
│   │       │   │   └── themes.xml
│   │       │   └── xml/file_paths.xml
│   │       └── AndroidManifest.xml
│   ├── build.gradle.kts
│   ├── dvdmaker.jks
│   └── proguard-rules.pro
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── fonts.txt
├── get_fonts.sh
├── README.md
├── UX_REDESIGN.md
├── .gitignore
├── PROJECT_MAP.md
└── AI_RULES.md
```

> Дерево отражает содержимое переданного архива и два добавляемых документа. Если в рабочем репозитории присутствуют не включённые в архив локальные файлы, их нужно сохранить и внести в карту при следующем обновлении.

## 3. Точка входа и навигация по экранам

### `MainActivity.kt`
- `MainActivity : ComponentActivity` создаёт/получает `AppVm`, инициализирует кэш шрифтов и графических ресурсов (`Fonts`, `SymbolAssets`, `BlurayAssets`, `DvdMeshAsset`), включает edge-to-edge и запускает Compose UI. `Root` учитывает безопасные системные области/вырезы через `safeDrawingPadding` и сдвигает контент при открытии клавиатуры через `imePadding`.
- `Root(vm)` — корневой переключатель экранов. При `vm.current != null` показывает `EditorScreen`; при `vm.checker` — `CheckerScreen`; иначе — `HomeScreen`.
- `BackHandler` корневого уровня закрывает режим проверки; системный возврат редактора обрабатывает `EditorScreen` с приоритетом закрытия окна инструмента, возврата из обзора к панели и подтверждения выхода. `onPause()` вызывает `vm.flush()` для сохранения отложенных изменений.

### `Home.kt`
- `HomeScreen(vm)` — главный экран/список проектов, создание и выбор проекта, сортировка и действия с проектами.
- `ProjectThumb(p)` — миниатюра проекта.
- `ProjectCard(...)` — карточка проекта.
- `UpdateBanner(vm)` и `AboutDialog(...)` — баннер обновления и сведения о приложении.

### `Editor.kt`
- `EditorScreen(vm)` — экран открытого проекта: переключение панелей (лицо, корешок, оборот, диск), режим обзора/редактирования, выбор слоя и вызов инструментов; единый возврат закрывает активную панель инструмента, возвращает из обзора к рабочей панели и запрашивает подтверждение выхода из редактора. Удаление слоя и сброс фона подтверждаются отдельно; undo/redo постоянно доступны в верхней панели.
- `PanelEditor(vm, p, guides)` — редактор выбранной панели; холст автоматически вписывается в доступную область; перетаскивание одним пальцем перемещает выбранный объект, а жест сведения/разведения двумя пальцами изменяет размер выбранного объекта. Масштабирование холста и его панорамирование в редакторе панели отключены.
- `PanelCanvas(...)` — отрисовка и интерактивное размещение содержимого панели; увеличенная зона попадания помогает выбирать небольшие объекты; перетаскивание выбранного объекта выполняется одним пальцем, а мультитач изменяет размер выбранного объекта без масштабирования холста.
- `OverviewCanvas(...)` — холст обзора развёртки; поддерживает мультитач-масштабирование/перемещение развёртки и быстрые кнопки изменения масштаба/сброса к 100%.
- `PositionSliders(...)`, `ShadowControls(...)` — отдельные группы настроек положения и тени.
- `normRot`, `f1`, `Layer.label` — нормализация угла, форматирование и подпись слоя.

### `Checker.kt`
- `CheckerScreen(vm)` — проверка готовой обложки перед печатью, отчёт о соответствии размерам и создание проекта по результату.
- `Preflight.analyze(...)` — анализ разрешения/целевого размера.
- `Fitter.fit(...)` и `Fitter.preview(...)` — вписывание/кадрирование/растягивание исходного изображения и предпросмотр.
- `buildFinishedProject(...)` — создание проекта из проверенного изображения.
- `DiscFormat.checkTargets()` и `targetSize(...)` — доступные цели проверки для формата.

## 4. Состояние, модель и сохранение проектов

### `Vm.kt` — `AppVm`
Центральный `AndroidViewModel`. Содержит `Store`, список `projects`, текущий `Project`, активную `PanelId`, выбранные слои, состояние undo/redo, направляющие, параметры проверки и обновления.
Ключевые операции:
- `switchPanel(id)`, `showOverview()` и `returnToPanel()` управляют переходами между рабочими панелями и обзором; выбор слоя сохраняется отдельно для каждой панели в состоянии VM.
- `create(format, showSafeZone)` — новый проект выбранного формата.
- `createPhoto(uri)` — проект на основе импортированной фотографии.
- `open(p)` / `createFrom(p)` — открыть/создать на основе существующего проекта.
- `discFromFront()` — перенос изображения с лицевой панели на диск.
- `close()` — закрывает проект только после успешного `flush()`; `delete(p)`, `renameProject(...)`, `duplicate(p)`, `toggleFavorite(p)`, `setSort(...)` — управление проектами.
- `edit(key, block)`, `undoLast()` и связанная логика истории — изменение проекта и отмена/повтор.
- `rememberFont(...)`, `applyFont(...)` — запоминание и применение шрифтов.
- `flush()` — запись отложенных изменений.
- `checkUpdate(...)` — проверка обновления через `Updater`.

### `Model.kt` — формат данных проекта
- `PanelId` — `FRONT`, `SPINE`, `BACK`, `DISC`.
- `DiscFormat` — геометрия и параметры DVD, DVD Slim, CD, Blu-ray и пользовательского фото; `layout()` и `discLayout()` рассчитывают компоновку листа/диска.
- `Kind` — виды слоёв: текст, изображение, прямоугольник, символ.
- `Layer` — модель слоя: геометрия, содержимое, параметры текста/изображения/эффектов; `toJson()`/`fromJson()` сериализуют слой.
- `PanelData`, `Place`, `Group`, `SheetLayout` — данные панели и геометрия развёртки.
- `Project` (в том же файле) — контейнер проекта, панели и сериализация. Сериализацию менять только с сохранением чтения старых JSON-проектов.

### `Store.kt` — файловое хранилище
- `Store.loadAll()` читает список сохранённых проектов.
- `Store.save(p)` сохраняет проект и возвращает признак успешной записи; `AppVm.flush()` передаёт этот результат интерфейсу для корректного сообщения пользователю.
- `Store.delete(p)` удаляет проект и учитывает повторное использование файлов изображений.
- `saveBitmap(...)` сохраняет обработанные bitmap в каталог данных приложения.
- `decodeForCheck(uri)` читает изображение для проверки размеров/EXIF.
- `importImage(uri)` импортирует изображение, учитывает ориентацию EXIF и выбирает PNG/JPEG с учётом прозрачности.
Это основной слой доступа к локальным файлам; не дублировать его логику в UI.

## 5. Рендеринг, текст, слои и эффекты

### `Render.kt`
Общий низкоуровневый рендеринг:
- `Fonts` — список/загрузка системных и asset-шрифтов, кэш `Typeface`.
- `Bitmaps.get(path)` — декодирование/кэширование bitmap.
- `Interactive` — кэш/генерация масок и вспомогательных визуальных ресурсов.
- `SymbolAssets.init(...)` — загрузка символов из assets.
- `Halo` и связанные функции — кэш и генерация свечения/ореола текста.
- `Info`, `mask(...)` — информация об альфа-канале и обработка краёв изображения.
Использовать этот модуль как отправную точку для выяснения фактического порядка рисования и повторного использования графических ресурсов.

### `Fx.kt`
- `Fx` — сериализуемые параметры атмосферы/цветокоррекции; `toJson()` и `fromJson()` обеспечивают хранение.
- `FxPainter` — применение цветовой матрицы, параметров изображения и оверлеев к Canvas.

### `Textures.kt`
- `TextTextures` — процедурные бесшовные текстуры материалов текста; `shader(material, sizePx)` предоставляет `Shader`, генерация не требует отдельных файлов текстур.

### `Templates.kt`
- `CoverStyle` — описание стиля.
- `Templates.styles` — каталог встроенных стилей.
- `fxOf(style)` — эффект для выбранного стиля.
- `existingText(...)` — поиск ранее существующего текста.
- `apply(p, style, title, sub, synopsis)` — построение/замена шаблонных слоёв на панелях проекта. При изменении важно сохранять пользовательские слои, не относящиеся к шаблону.

### `Tools.kt` и `Components.kt`
- `Tools.kt`: `Ico`, `Tool` — перечень пиктограмм и единых названий инструментов; `ToolIcon`, `ToolBar`, `BottomTabs`, `ToolGrid`, `ToolSheetHost`, `GlobalSheet`, `LayerSheet` — визуальные панели инструментов и редакторы параметров выбранного слоя. Закрытие панели настроек унифицировано через действие «Готово» и системный возврат; опасный сброс фона передаётся в `Editor` для подтверждения. Основные элементы `ToolBar`, `BottomTabs` и `ToolGrid` используют увеличенные зоны нажатия для сенсорного управления. `LayerCtx` и `SheetActions` передают данные/действия из `Editor`.
- `Components.kt`: общие Compose-элементы интерфейса (градиентная кнопка, чипы, плашки, слайдеры, образцы цвета, диалоги выбора цвета/шрифта и другие повторно используемые контролы).

## 6. Изображения и специальные инструменты

| Файл | Ответственность |
|---|---|
| `Blur.kt` | Gaussian blur и плавное масштабирование bitmap; общий низкоуровневый инструмент качества изображения. |
| `BgRemove.kt` | `BgRemover`: проверка доступности ONNX-модели, нейросетевой inference маски, применение маски; `BgRemoveDialog` — UI удаления фона. |
| `BgEditor.kt` | `BgEdit`: ручное редактирование маски (undo/redo, reset, выбор областей, кисть/штамп, compute/render); `BgEditor` — экран уточнения маски. |
| `Enhance.kt` | `Enhancer`: расчёт масштаба и улучшение изображения; `EnhanceOptionsDialog`/`EnhanceDialog` — UI апскейлинга. |
| `Neural.kt` | `NeuralUpscaler`: ONNX-апскейлинг изображения, проверка доступности модели и прогресс. |
| `EdgeIntegration.kt` | Локальная обработка цветной каймы/краёв прозрачного изображения; использовать при работе с краевыми RGB-пикселями и альфа-каналом. |
| `Outline.kt` | `ObjectOutline`: получение геометрии/контуров объекта из изображения. |
| `ColorTransfer.kt` | Преобразования RGB/Lab, контраст и перенос/согласование цветовой схемы изображения. |
| `Palette.kt` | Извлечение цветовых образцов/доминирующей палитры и построение bitmap-представлений палитры. |
| `FontMatch.kt` | Поиск похожего шрифта по растровому образцу текста; `extractInk(...)` извлекает маску чернил, `find(...)` ранжирует варианты. |
| `CoverTools.kt` | UI диалога шаблонов и управления параметрами эффектов (`TemplateDialog`, `FxControls`). |
| `Snap.kt` | Расчёт привязки слоёв к направляющим/краям/центрам; `Snap.compute(...)` возвращает координаты и `GuideLine`. |

### Практические маршруты по задачам
- **Создание проекта:** `Home.kt` → `AppVm.create(...)`/`createPhoto(...)` в `Vm.kt` → `Model.kt` → `Store.kt`.
- **Открытие/копирование/переименование:** `Home.kt` → соответствующие методы `AppVm` в `Vm.kt` → `Store.kt`.
- **Редактирование обложки:** `EditorScreen`/`PanelEditor` в `Editor.kt` → `Tool`/`LayerSheet` в `Tools.kt` → `AppVm.edit(...)` → `Project`/`Layer` в `Model.kt`.
- **Текст/шрифт/материал:** `Model.kt` (`Layer`) → `Tools.kt`/`Components.kt` → `Render.kt` (`Fonts`, `Halo`) и `Textures.kt`; шаблонный текст — `Templates.kt`.
- **Картинки и маски:** `Store.kt` (импорт) → `Render.kt`/`Bitmaps` → инструменты `BgRemove.kt`, `BgEditor.kt`, `Enhance.kt`, `EdgeIntegration.kt`, `ColorTransfer.kt`, `Palette.kt`.
- **Эффекты:** `CoverTools.kt` → `Fx.kt` и `Templates.kt`; сохранение параметров связано с моделью проекта в `Model.kt`.
- **Слои/позиционирование:** `Layer` в `Model.kt`, UI — `Editor.kt`/`Tools.kt`, snapping — `Snap.kt`, отрисовка — `Render.kt`.
- **Проверка печати:** `Checker.kt` → `Preflight`/`Fitter` → `Store.kt`/`Model.kt`.
- **Экспорт:** UI-кнопки редактора/главного экрана вызывают `Exporter` в `Export.kt`; `writePng(...)`, `writePdf(...)`, `cacheFile(...)` выполняют формирование результата.
- **3D-просмотр:** `Case3DDialog` в `Case3D.kt` строит текстуры из проекта; `DvdMesh3D.kt` — геометрия стандартного кейса; `Bluray3D.kt` — текстуры/геометрия Blu-ray-кейса и анимация крышки/лотка.

## 7. Экспорт и 3D

### `Export.kt` — `Exporter`
- `safeName(n)` формирует безопасное имя файла.
- `writePng(p, a4, marks, out, disc)` рисует проект в PNG с опциями листа/меток/диска.
- `writePdf(...)` формирует PDF.
- `cacheFile(...)` готовит экспортный файл в кэше приложения.
Качество экспорта зависит от геометрии `DiscFormat`, рендеринга `Layer` и параметров DPI. Не снижать разрешение/качество ради оптимизации без отдельной проверки печатного результата.

### 3D-модули
- `Case3D.kt`: `CaseTextures`, `buildCaseTextures(p)`, `Case3DDialog(p, ...)` — собирает изображения панелей/диска и показывает 3D-кейс.
- `DvdMesh3D.kt`: `DvdMeshAsset` загружает `models/dvd_case.bin`; содержит геометрию/проекцию стандартного DVD-кейса.
- `Bluray3D.kt`: `BlurayAssets` загружает изображения из `assets/bluray`; `composeBlurayTextures(...)` готовит текстуры; `BlurayTex` содержит рендеринг Blu-ray корпуса/крышки/лотка.
- `app/src/main/assets/bluray/*.png`, `symbols_bluray.png`, `models/dvd_case.bin` — визуальные ресурсы 3D.

## 8. Обновления и конфигурация

- `Update.kt`: `UpdateInfo`, `Updater.check()`, `download(...)`, `install(...)` — проверка GitHub Releases, загрузка APK и запуск установки через `FileProvider`.
- `AndroidManifest.xml`: launcher Activity, разрешения `INTERNET` и `REQUEST_INSTALL_PACKAGES`, `FileProvider`.
- `res/xml/file_paths.xml`: пути, доступные `FileProvider`.
- `res/values/themes.xml`, `colors.xml`, drawable/mipmap XML — тема и иконка приложения.
- `Theme.kt`: Compose-палитра и `DVDMakerTheme`.
- `fonts.txt`, `get_fonts.sh`: список/загрузка дополнительных шрифтов (CI вызывает скрипт, но допускает его неуспех).
- `README.md`: пользовательская документация по функциям и ограничениям.
- `UX_REDESIGN.md`: UX-предложения/описание редизайна; это не исполняемый код.
- `.gitignore`: исключения Git.
- `gradle.properties`: параметры Gradle/Kotlin.
- `build.gradle.kts`: версии плагинов Android/Kotlin/Compose.
- `settings.gradle.kts`: имя проекта, репозитории и включение `:app`.
- `app/build.gradle.kts`: SDK, идентификатор, versionCode, ABI, Compose, зависимости, сборка release/debug и подпись.
- `app/proguard-rules.pro`: правила R8/ProGuard (в текущей конфигурации minification отключён).
- `app/dvdmaker.jks`: keystore для подписи APK. Не публиковать пароли/ключи и не менять signing config без отдельной задачи.
- `.github/workflows/build.yml`: GitHub Actions распаковывает входной ZIP при наличии, требует `plugin/model_fp16.onnx` или `.github/plugin/model_fp16.onnx`, копирует его как `assets/models/bgremove.onnx`, загружает шрифты и собирает `assembleRelease`.

## 9. Зависимости и архитектурные особенности

Основные зависимости из `app/build.gradle.kts`:
- Compose BOM `2024.10.01`, Compose UI/Foundation/Material 3 и Material Icons.
- `activity-compose 1.9.3`.
- Lifecycle ViewModel/Runtime Compose `2.8.7`.
- Core KTX `1.13.1`, ExifInterface `1.3.7`.
- ONNX Runtime Android `1.19.2`.

Важные особенности:
1. Проект — один app-модуль, отдельного слоя domain/data Gradle-модуля нет.
2. UI и состояние связаны через `AppVm`; перед изменением поведения сначала проследить вызовы из Compose UI в VM и далее в model/store.
3. Форматы и координаты обложек задаются в миллиметрах в `DiscFormat`/`Layer`; не подменять их пиксельными значениями без учёта DPI.
4. Сериализация проекта находится в `Model.kt` и `Fx.kt`. Новые поля должны иметь безопасные значения по умолчанию/обратную совместимость.
5. Изображения импортируются и сохраняются через `Store`; EXIF и прозрачность влияют на ориентацию и формат хранения.
6. `Render.kt`, `Blur.kt` и `Export.kt` критичны для качества изображения и печати.
7. Нейросетевые модели — крупные бинарные ресурсы. В архиве присутствуют `realesr-general-x4v3.onnx` и `dvd_case.bin`; `bgremove.onnx` формируется CI из внешнего файла модели. README также указывает, что модель удаления фона не входит в архив.
8. CI зависит от наличия внешней модели RMBG; без неё workflow завершится ошибкой до сборки APK.
9. В `app/build.gradle.kts` release и debug используют signing config с `app/dvdmaker.jks`; секреты подписи нельзя переносить в документацию или выводить в лог.

## 10. Проверка перед изменениями

1. Найти задачу в разделе 6 и открыть указанные исходники.
2. Проверить фактические сигнатуры и вызывающие места в репозитории — карта помогает навигации, но не заменяет исходный код.
3. Для изменения модели/сохранения проверить `Model.kt`, `Fx.kt`, `Store.kt`, старые JSON-данные.
4. Для изображения/печати проверить `Render.kt`, `Blur.kt`, `Export.kt`, а также `Checker.kt`, если затронуты размеры.
5. Для UI проверить связанные `Editor.kt`, `Tools.kt`, `Components.kt`, `Vm.kt`.
6. После изменения обновить эту карту в той же задаче и выполнить доступные проверки сборки/тестов.
