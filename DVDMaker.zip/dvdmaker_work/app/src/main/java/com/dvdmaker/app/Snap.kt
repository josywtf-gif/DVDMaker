package com.dvdmaker.app

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Направляющая на холсте (в миллиметрах панели).
 * [vertical] = true → вертикальная линия x = [pos], тянется от [from] до [to] по оси Y; иначе наоборот.
 * [exact] = true → края/центры совпали идеально (рисуется зелёным), иначе объект просто рядом (белая).
 */
data class GuideLine(val vertical: Boolean, val pos: Float, val from: Float, val to: Float, val exact: Boolean)

/** «Умная» привязка в стиле Figma: к краям и центру панели, к безопасной зоне и к краям/центрам других объектов. */
object Snap {
    class Result(val x: Float, val y: Float, val guides: List<GuideLine>)

    private class Target(val pos: Float, val from: Float, val to: Float)

    /** Габариты слоя с учётом поворота (половины ширины и высоты охватывающего прямоугольника), мм. */
    private fun halfExtents(l: Layer): Pair<Float, Float> {
        val k = 10f
        val (pw, ph) = layerSize(l, k)
        val w = pw / k
        val h = ph / k
        val r = Math.toRadians(l.rot.toDouble())
        val c = abs(cos(r)).toFloat()
        val s = abs(sin(r)).toFloat()
        return ((w * c + h * s) / 2f) to ((w * s + h * c) / 2f)
    }

    /**
     * @param moving  слой, который двигают (его x/y игнорируются — вместо них [rawX], [rawY] в долях панели)
     * @param others  остальные слои панели
     * @param wMm,hMm размер панели, мм
     * @param snapMm  расстояние, на котором происходит примагничивание
     * @param showMm  расстояние, на котором направляющая уже показывается (белая)
     */
    fun compute(
        moving: Layer, rawX: Float, rawY: Float, others: List<Layer>,
        wMm: Float, hMm: Float, panelId: PanelId, snapMm: Float, showMm: Float
    ): Result {
        val (hx, hy) = halfExtents(moving)
        var cx = rawX * wMm
        var cy = rawY * hMm

        // ----- цели привязки -----
        val tx = ArrayList<Target>()   // вертикальные линии (x)
        val ty = ArrayList<Target>()   // горизонтальные линии (y)
        val inset = 3f
        if (panelId == PanelId.DISC) {
            val r = DISC_OUTER_MM / 2f
            for (v in listOf(0f, DISC_SIZE_MM / 2f - r, DISC_SIZE_MM / 2f, DISC_SIZE_MM / 2f + r, DISC_SIZE_MM)) {
                tx.add(Target(v, 0f, hMm)); ty.add(Target(v, 0f, wMm))
            }
        } else {
            val xi = minOf(inset, wMm * 0.15f)
            val yi = minOf(inset, hMm * 0.15f)
            for (v in listOf(0f, xi, wMm / 2f, wMm - xi, wMm)) tx.add(Target(v, 0f, hMm))
            for (v in listOf(0f, yi, hMm / 2f, hMm - yi, hMm)) ty.add(Target(v, 0f, wMm))
        }
        for (o in others) {
            val (ox, oy) = halfExtents(o)
            val ocx = o.x * wMm
            val ocy = o.y * hMm
            // фоновые картинки на всю панель не служат ориентиром
            if (o.kind == Kind.IMAGE && ox * 2f >= wMm * 0.98f && oy * 2f >= hMm * 0.98f) continue
            for (v in listOf(ocx - ox, ocx, ocx + ox)) if (v in -0.01f..wMm + 0.01f) tx.add(Target(v, ocy - oy, ocy + oy))
            for (v in listOf(ocy - oy, ocy, ocy + oy)) if (v in -0.01f..hMm + 0.01f) ty.add(Target(v, ocx - ox, ocx + ox))
        }

        // ----- примагничивание по каждой оси -----
        fun best(center: Float, half: Float, targets: List<Target>): Float {
            var bestD = Float.MAX_VALUE
            for (t in targets) for (o in floatArrayOf(-half, 0f, half)) {
                val d = t.pos - (center + o)
                if (abs(d) < abs(bestD)) bestD = d
            }
            return if (abs(bestD) <= snapMm) bestD else 0f
        }
        cx += best(cx, hx, tx)
        cy += best(cy, hy, ty)

        // ----- направляющие (после привязки) -----
        val eps = 0.02f
        val guides = ArrayList<GuideLine>()

        fun collect(vertical: Boolean, center: Float, half: Float, otherCenter: Float, otherHalf: Float, targets: List<Target>) {
            val found = HashMap<Int, GuideLine>()
            val near = ArrayList<Pair<Float, GuideLine>>()
            for (t in targets) for (o in floatArrayOf(-half, 0f, half)) {
                val d = abs(t.pos - (center + o))
                if (d > showMm) continue
                val exact = d <= eps
                val from = minOf(t.from, otherCenter - otherHalf)
                val to = maxOf(t.to, otherCenter + otherHalf)
                val key = Math.round(t.pos * 50f)
                val g = GuideLine(vertical, t.pos, from, to, exact)
                if (exact) {
                    val old = found[key]
                    found[key] = if (old == null) g else GuideLine(vertical, t.pos, minOf(old.from, from), maxOf(old.to, to), true)
                } else near.add(d to g)
            }
            guides.addAll(found.values)
            // белые — только самые близкие, чтобы не засорять холст
            val used = HashSet<Int>(found.keys)
            for ((_, g) in near.sortedBy { it.first }) {
                val key = Math.round(g.pos * 50f)
                if (used.size >= found.size + 2) break
                if (used.add(key)) guides.add(g)
            }
        }
        collect(true, cx, hx, cy, hy, tx)
        collect(false, cy, hy, cx, hx, ty)
        return Result(cx / wMm, cy / hMm, guides)
    }
}
