package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas as UiCanvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Текстуры для 3D-просмотра: те же панели и эффекты, что в проекте, плюс диск с печатью из вкладки «Диск». */
class CaseTextures(val front: Bitmap, val spine: Bitmap, val back: Bitmap, val disc: Bitmap, val discBack: Bitmap)

fun buildCaseTextures(p: Project): CaseTextures {
    fun panel(id: PanelId): Bitmap {
        val (wm, hm) = p.format.size(id)
        val ppm = min(6f, 1400f / max(wm, hm))
        val bmp = Bitmap.createBitmap((wm * ppm).roundToInt().coerceAtLeast(2), (hm * ppm).roundToInt().coerceAtLeast(2), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        drawPanelWithFx(c, p, id, 0, bmp.width.toFloat(), bmp.height.toFloat(), ppm)
        return bmp
    }
    return CaseTextures(
        front = panel(PanelId.FRONT), spine = panel(PanelId.SPINE), back = panel(PanelId.BACK),
        disc = makeDisc(p), discBack = makeDisc(null)
    )
}

/** Диск 120 мм: серебристая основа, печать проекта (если [p] задан) в печатном кольце, прозрачная ступица и отверстие. */
private fun makeDisc(p: Project?): Bitmap {
    val ppm = 5f
    val s = (DISC_SIZE_MM * ppm).roundToInt()
    val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val cx = s / 2f
    val cy = s / 2f
    val rOuter = (DISC_SIZE_MM / 2f - 0.4f) * ppm
    val rPrint = DISC_INNER_MM / 2f * ppm
    val rHub = 7.5f * ppm
    c.save()
    c.clipPath(Path().apply { addCircle(cx, cy, rOuter, Path.Direction.CW) })
    c.clipOutPath(Path().apply { addCircle(cx, cy, rPrint, Path.Direction.CW) })
    c.drawPaint(Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(cx, cy, rOuter, intArrayOf(0xFFE9ECF1.toInt(), 0xFFC7CCD4.toInt()), null, Shader.TileMode.CLAMP)
    })
    if (p == null) {
        // обратная сторона: радужный блик, как у настоящего диска
        c.drawPaint(Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = SweepGradient(
                cx, cy,
                intArrayOf(0x00FFFFFF, 0x55B8D8FF, 0x00FFFFFF, 0x55FFD0F0, 0x00FFFFFF, 0x55D8FFC8, 0x00FFFFFF),
                null
            )
        })
    }
    c.restore()
    if (p != null) {
        drawPanelWithFx(c, p, PanelId.DISC, 0, s.toFloat(), s.toFloat(), ppm, true)
    }
    // прозрачная ступица и отверстие
    val hub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99DDE2E8.toInt() }
    c.save()
    c.clipPath(Path().apply { addCircle(cx, cy, rPrint, Path.Direction.CW) })
    c.drawCircle(cx, cy, rPrint, hub)
    c.restore()
    c.drawCircle(cx, cy, rHub, Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) })
    c.drawCircle(cx, cy, rHub, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2f; color = 0x44000000 })
    return bmp
}

private class Face(val pts: FloatArray /* 4 угла × xyz: левый-верхний, правый-верхний, правый-нижний, левый-нижний */, val kind: Int)

private const val F_FRONT = 0
private const val F_BACK = 1
private const val F_SPINE = 2
private const val F_PLASTIC = 3

/** Программный 3D: проекция углов и перспективное наложение текстур через Matrix.setPolyToPoly. */
private class CaseScene(val p: Project, val tex: CaseTextures) {
    val f = p.format
    val w = f.frontW
    val h = max(f.frontH, f.backH)
    val d = if (f.tray) 10.4f else f.spineW.coerceAtLeast(5f)
    val plastic = when (f.name) {
        "BLURAY" -> 0xFF1D5BC4.toInt()
        "CD" -> 0xFF9AA3AD.toInt()
        else -> 0xFF17171B.toInt()
    }
    val discR = DISC_SIZE_MM / 2f
    /** Центр диска по X, когда он выдвинут полностью. */
    val discOutX = w / 2f + 12f
    private val camera = 1100f

    private fun q(vararg v: Float) = v

    val faces: List<Face> get() {
        val x = w / 2f; val y = h / 2f; val z = d / 2f
        return listOf(
            Face(q(-x, -y, z, x, -y, z, x, y, z, -x, y, z), F_FRONT),
            Face(q(x, -y, -z, -x, -y, -z, -x, y, -z, x, y, -z), F_BACK),
            Face(q(-x, -y, -z, -x, -y, z, -x, y, z, -x, y, -z), F_SPINE),
            Face(q(x, -y, z, x, -y, -z, x, y, -z, x, y, z), F_PLASTIC),
            Face(q(-x, -y, -z, x, -y, -z, x, -y, z, -x, -y, z), F_PLASTIC),
            Face(q(-x, y, z, x, y, z, x, y, -z, -x, y, -z), F_PLASTIC)
        )
    }

    private val shiftX = -(discOutX + discR - w / 2f) / 2f

    private class P(val x: Float, val y: Float, val z: Float)

    fun render(out: Bitmap, yawDeg: Float, pitchDeg: Float, slide: Float) {
        out.eraseColor(Color.TRANSPARENT)
        val c = Canvas(out)
        val vw = out.width.toFloat(); val vh = out.height.toFloat()
        val yaw = Math.toRadians(yawDeg.toDouble()); val pitch = Math.toRadians(pitchDeg.toDouble())
        val cy = cos(yaw).toFloat(); val sy = sin(yaw).toFloat()
        val cp = cos(pitch).toFloat(); val sp = sin(pitch).toFloat()
        val radius = hypot(w + discOutX + discR - w / 2f, h) / 2f
        val scale = min(vw, vh) * 0.47f / radius

        fun proj(x0: Float, y0: Float, z0: Float): P {
            val x = x0 + shiftX
            val x1 = x * cy + z0 * sy
            val z1 = -x * sy + z0 * cy
            val y2 = y0 * cp + z1 * sp
            val z2 = -y0 * sp + z1 * cp
            val k = camera / (camera - z2)
            return P(vw / 2f + x1 * k * scale, vh / 2f + y2 * k * scale, z2)
        }
        fun quad(pts: FloatArray): Array<P> = Array(4) { proj(pts[it * 3], pts[it * 3 + 1], pts[it * 3 + 2]) }
        fun area(q: Array<P>): Float {
            var s = 0f
            for (i in 0 until 4) { val a = q[i]; val b = q[(i + 1) % 4]; s += a.x * b.y - b.x * a.y }
            return s / 2f
        }
        fun flat(q: Array<P>) = FloatArray(8) { if (it % 2 == 0) q[it / 2].x else q[it / 2].y }
        fun path(q: Array<P>) = Path().apply { moveTo(q[0].x, q[0].y); for (i in 1..3) lineTo(q[i].x, q[i].y); close() }
        fun drawTex(bmp: Bitmap, q: Array<P>, sl: Float = 0f, sr: Float = 1f, tex: Paint) {
            val m = Matrix()
            val x0 = bmp.width * sl; val x1 = bmp.width * sr; val hh = bmp.height.toFloat()
            m.setPolyToPoly(floatArrayOf(x0, 0f, x1, 0f, x1, hh, x0, hh), 0, flat(q), 0, 4)
            c.save()
            c.clipPath(path(q))
            c.concat(m)
            c.drawBitmap(bmp, 0f, 0f, tex)
            c.restore()
        }

        val texPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

        // тень на «полу»
        run {
            val b = proj(0f, h / 2f, 0f)
            val rx = (w + discOutX) * 0.5f * scale
            val sh = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    vw / 2f, b.y + 6f * scale * 0.6f, rx,
                    intArrayOf(0x55000000, 0x00000000), null, Shader.TileMode.CLAMP
                )
            }
            c.save(); c.scale(1f, 0.16f, vw / 2f, b.y + 6f * scale * 0.6f)
            c.drawCircle(vw / 2f, b.y + 6f * scale * 0.6f, rx, sh)
            c.restore()
        }

        // диск
        val dc = discOutX * slide
        val dq = quad(floatArrayOf(dc - discR, -discR, 0f, dc + discR, -discR, 0f, dc + discR, discR, 0f, dc - discR, discR, 0f))
        val discFront = area(dq) > 0f
        fun regionPath(x0: Float, x1: Float): Path {
            val r = Array(4) { i -> val xx = if (i == 0 || i == 3) x0 else x1; val yy = if (i < 2) -200f else 200f; proj(xx, yy, 0f) }
            return path(r)
        }
        fun drawDisc(clip: Path) {
            c.save()
            c.clipPath(clip)
            drawTex(if (discFront) tex.disc else tex.discBack, dq, tex = texPaint)
            c.restore()
        }
        // часть диска внутри корпуса — всегда под стенками
        drawDisc(regionPath(-w / 2f - 1f, w / 2f))
        val outside = regionPath(w / 2f, dc + discR + 5f)

        val visible = faces.map { it to quad(it.pts) }.filter { area(it.second) > 0.5f }.sortedBy { e -> e.second.sumOf { it.z.toDouble() } }
        val viewFromRight = visible.any { it.first.pts[0] == w / 2f && it.first.kind == F_PLASTIC && it.first.pts[3] == w / 2f }
        if (!viewFromRight && slide > 0.001f) drawDisc(outside)

        val plasticPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = plastic }
        for ((face, q) in visible) {
            val pa = path(q)
            when (face.kind) {
                F_FRONT -> drawTex(tex.front, q, tex = texPaint)
                F_BACK -> {
                    if (f.tray) {
                        // у jewel-кейса оборот шире кейса: показываем центральную часть
                        val frac = (w / f.backW).coerceIn(0.3f, 1f)
                        drawTex(tex.back, q, (1f - frac) / 2f, 1f - (1f - frac) / 2f, texPaint)
                    } else drawTex(tex.back, q, tex = texPaint)
                }
                F_SPINE -> {
                    if (f.tray) {
                        c.drawPath(pa, plasticPaint)
                        // вкладыш корешка по центру толщины
                        val inset = ((d - f.spineW) / 2f).coerceAtLeast(0f)
                        val z0 = -d / 2f + inset; val z1 = d / 2f - inset
                        val x = -w / 2f; val y = h / 2f
                        drawTex(tex.spine, quad(floatArrayOf(x, -y, z0, x, -y, z1, x, y, z1, x, y, z0)), tex = texPaint)
                    } else drawTex(tex.spine, q, tex = texPaint)
                }
                else -> c.drawPath(pa, plasticPaint)
            }
            // освещение: чем больше грань повёрнута к лампе, тем светлее
            val nx: Float; val ny: Float; val nz: Float
            when {
                face.kind == F_FRONT -> { nx = 0f; ny = 0f; nz = 1f }
                face.kind == F_BACK -> { nx = 0f; ny = 0f; nz = -1f }
                face.kind == F_SPINE -> { nx = -1f; ny = 0f; nz = 0f }
                face.pts[0] == w / 2f && face.pts[3] == w / 2f -> { nx = 1f; ny = 0f; nz = 0f }
                face.pts[1] < 0f && face.pts[4] < 0f -> { nx = 0f; ny = -1f; nz = 0f }
                else -> { nx = 0f; ny = 1f; nz = 0f }
            }
            val rx = nx * cy + nz * sy
            val rz1 = -nx * sy + nz * cy
            val ry = ny * cp + rz1 * sp
            val rz = -ny * sp + rz1 * cp
            val lit = (-0.35f * rx - 0.5f * ry + 0.8f * rz).coerceIn(-1f, 1f)
            val shade = ((1f - (0.62f + 0.38f * lit)) * if (face.kind == F_PLASTIC) 0.9f else 0.45f).coerceIn(0f, 0.7f)
            if (shade > 0.01f) {
                c.drawPath(pa, Paint().apply { color = Color.argb((shade * 255).roundToInt(), 0, 0, 0) })
            }
            if (face.kind == F_FRONT || face.kind == F_BACK) {
                // блик на прозрачной плёнке кейса
                val b = RectF(); pa.computeBounds(b, true)
                c.save(); c.clipPath(pa)
                c.drawRect(b, Paint().apply {
                    shader = LinearGradient(
                        b.left, b.top, b.right, b.bottom,
                        intArrayOf(0x33FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x1AFFFFFF),
                        floatArrayOf(0f, 0.38f, 0.6f, 1f), Shader.TileMode.CLAMP
                    )
                })
                c.restore()
            }
            c.drawPath(pa, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE; strokeWidth = 1.6f
                color = if (face.kind == F_PLASTIC) 0x66FFFFFF else 0x55000000
            })
        }
        if (viewFromRight && slide > 0.001f) drawDisc(outside)
    }
}

/** Полноэкранный 3D-просмотр: кейс с обложкой и диск, выезжающий из него. Вращение — пальцем, нажатие на диск — убрать/достать. */
@Composable
fun Case3DDialog(p: Project, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    val tex by produceState<CaseTextures?>(null, p) { value = withContext(Dispatchers.Default) { buildCaseTextures(p) } }
    val scene = remember(tex) { tex?.let { CaseScene(p, it) } }
    var yaw by remember { mutableFloatStateOf(-28f) }
    var pitch by remember { mutableFloatStateOf(12f) }
    val slide = remember { Animatable(0f) }
    var box by remember { mutableStateOf(IntSize(1, 1)) }
    var version by remember { mutableIntStateOf(0) }
    val mutex = remember { Mutex() }
    val frame = remember(box) {
        val k = min(1f, 1400f / max(box.width, box.height).coerceAtLeast(1))
        Bitmap.createBitmap((box.width * k).roundToInt().coerceAtLeast(2), (box.height * k).roundToInt().coerceAtLeast(2), Bitmap.Config.ARGB_8888)
    }

    LaunchedEffect(scene) { if (scene != null) { slide.snapTo(0f); slide.animateTo(1f, tween(1500, 350, FastOutSlowInEasing)) } }
    LaunchedEffect(scene, yaw, pitch, slide.value, frame) {
        val s = scene ?: return@LaunchedEffect
        withContext(Dispatchers.Default) { mutex.withLock { s.render(frame, yaw, pitch, slide.value) } }
        version++
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(listOf(androidx.compose.ui.graphics.Color(0xFF2B2B31), androidx.compose.ui.graphics.Color(0xFF0E0E10)))
            )
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(start = 8.dp)) {
                    Text("3D-просмотр", color = androidx.compose.ui.graphics.Color.White, fontSize = 16.sp)
                    Text(p.format.title, color = Dim, fontSize = 11.sp)
                }
                TextButton(onClick = onClose) { Text("Закрыть", color = Amber) }
            }
            Box(Modifier.weight(1f).fillMaxWidth().onSizeChanged { box = it }
                .pointerInput(scene) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        yaw += drag.x * 0.4f
                        pitch = (pitch - drag.y * 0.3f).coerceIn(-50f, 50f)
                    }
                }
                .pointerInput(scene) {
                    detectTapGestures {
                        scope.launch { slide.animateTo(if (slide.value > 0.5f) 0f else 1f, tween(1100, 0, FastOutSlowInEasing)) }
                    }
                },
                contentAlignment = Alignment.Center
            ) {
                if (scene == null) {
                    CircularProgressIndicator(color = Violet)
                } else {
                    UiCanvas(Modifier.fillMaxSize()) {
                        version
                        drawIntoCanvas { cv ->
                            cv.nativeCanvas.drawBitmap(
                                frame, null,
                                RectF(0f, 0f, size.width, size.height),
                                Paint(Paint.FILTER_BITMAP_FLAG)
                            )
                        }
                    }
                }
            }
            Text(
                "Проведите пальцем, чтобы повернуть. Нажмите, чтобы задвинуть или достать диск. Печать диска и обложки — из вашего проекта.",
                color = Dim, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }
}
