package com.dvdmaker.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.util.Half
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Удаление фона нейросетью (RMBG-1.4, ONNX fp16) прямо на устройстве, без интернета.
 *
 * Файл модели в APK не лежит в исходниках: его кладёт в assets шаг сборки на GitHub
 * (см. .github/workflows/build.yml, путь в APK — [ASSET]). Если модели нет — [available] вернёт false.
 *
 * Вход сети: NCHW 1×3×1024×1024, значения (пиксель/255 − 0.5). Выход: маска переднего плана 0…1.
 */
object BgRemover {
    const val ASSET = "models/bgremove.onnx"
    private const val SIZE = 1024
    /** Предел по длинной стороне результата (как у улучшения качества). */
    private const val MAX_SIDE = 4096

    fun available(ctx: Context): Boolean = try {
        ctx.assets.open(ASSET).close(); true
    } catch (_: Throwable) {
        false
    }

    /** ORT лучше грузить с файла, а не из массива в памяти (модель ≈ 88 МБ): копируем из assets один раз. */
    private fun modelFile(ctx: Context): File {
        val f = File(ctx.noBackupFilesDir, "bgremove.onnx")
        val size = ctx.assets.openFd(ASSET).use { it.length }
        if (!f.exists() || f.length() != size) {
            val tmp = File(f.parentFile, "bgremove.onnx.tmp")
            ctx.assets.open(ASSET).use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
            if (f.exists()) f.delete()
            tmp.renameTo(f)
        }
        return f
    }

    /** Возвращает копию [src] с прозрачным фоном (ARGB_8888). [onProgress] получает 0…100. */
    suspend fun remove(ctx: Context, src: Bitmap, onProgress: (Int) -> Unit): Bitmap {
        onProgress(2)
        val file = modelFile(ctx)
        currentCoroutineContext().ensureActive()

        // 1. Вход: растягиваем до 1024×1024 на белой подложке (прозрачные места не должны стать чёрными).
        val small = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        Canvas(small).apply {
            drawColor(Color.WHITE)
            drawBitmap(
                src, Rect(0, 0, src.width, src.height), Rect(0, 0, SIZE, SIZE),
                Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            )
        }
        val pix = IntArray(SIZE * SIZE)
        small.getPixels(pix, 0, SIZE, 0, 0, SIZE, SIZE)
        small.recycle()
        onProgress(8)

        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(min(4, max(2, Runtime.getRuntime().availableProcessors() - 1)))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.BASIC_OPT)
        }
        var mask = FloatArray(0)
        var mw = SIZE
        var mh = SIZE
        try {
            env.createSession(file.absolutePath, opts).use { session ->
                onProgress(20)
                currentCoroutineContext().ensureActive()
                val inName = session.inputNames.first()
                val half = (session.inputInfo[inName]?.info as? ai.onnxruntime.TensorInfo)?.type == OnnxJavaType.FLOAT16
                val plane = SIZE * SIZE
                val shape = longArrayOf(1, 3, SIZE.toLong(), SIZE.toLong())

                val tensor: OnnxTensor = if (half) {
                    val bb = ByteBuffer.allocateDirect(3 * plane * 2).order(ByteOrder.nativeOrder())
                    val sb = bb.asShortBuffer()
                    for (i in 0 until plane) {
                        val c = pix[i]
                        sb.put(i, Half.toHalf((((c shr 16) and 255) / 255f) - 0.5f))
                        sb.put(plane + i, Half.toHalf((((c shr 8) and 255) / 255f) - 0.5f))
                        sb.put(2 * plane + i, Half.toHalf(((c and 255) / 255f) - 0.5f))
                    }
                    OnnxTensor.createTensor(env, bb, shape, OnnxJavaType.FLOAT16)
                } else {
                    val data = FloatArray(3 * plane)
                    for (i in 0 until plane) {
                        val c = pix[i]
                        data[i] = (((c shr 16) and 255) / 255f) - 0.5f
                        data[plane + i] = (((c shr 8) and 255) / 255f) - 0.5f
                        data[2 * plane + i] = ((c and 255) / 255f) - 0.5f
                    }
                    OnnxTensor.createTensor(env, java.nio.FloatBuffer.wrap(data), shape)
                }
                onProgress(30)
                tensor.use { t ->
                    // Один проход сети — самая долгая часть (десятки секунд на телефоне).
                    session.run(mapOf(inName to t)).use { res ->
                        onProgress(85)
                        currentCoroutineContext().ensureActive()
                        val out = res.get(0) as OnnxTensor
                        val oshape = out.info.shape
                        mh = oshape[oshape.size - 2].toInt()
                        mw = oshape[oshape.size - 1].toInt()
                        val n = mw * mh
                        val m = FloatArray(n)
                        if (out.info.type == OnnxJavaType.FLOAT16) {
                            val sb = out.byteBuffer.order(ByteOrder.nativeOrder()).asShortBuffer()
                            for (i in 0 until n) m[i] = Half.toFloat(sb.get(i))
                        } else {
                            out.floatBuffer.get(m, 0, n)
                        }
                        mask = m
                    }
                }
            }
        } finally {
            opts.close()
        }

        // 2. Нормализация маски (как в эталонном коде RMBG): если сеть вернула логиты — сначала сигмоида.
        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        for (v in mask) { if (v < lo) lo = v; if (v > hi) hi = v }
        if (lo < -0.01f || hi > 1.01f) {
            for (i in mask.indices) mask[i] = 1f / (1f + Math.exp(-mask[i].toDouble()).toFloat())
            lo = Float.MAX_VALUE; hi = -Float.MAX_VALUE
            for (v in mask) { if (v < lo) lo = v; if (v > hi) hi = v }
        }
        val range = (hi - lo).coerceAtLeast(1e-6f)
        for (i in mask.indices) {
            val t = ((mask[i] - lo) / range).coerceIn(0f, 1f)
            // лёгкая S-кривая: убирает «дымку» по краю и полупрозрачный фон, но оставляет мягкий переход
            val u = ((t - 0.06f) / 0.88f).coerceIn(0f, 1f)
            mask[i] = u * u * (3f - 2f * u)
        }
        onProgress(90)

        // 3. Применяем маску к картинке в полном размере (билинейно), полосами — чтобы не раздувать память.
        var w = src.width
        var h = src.height
        val k = MAX_SIDE.toFloat() / max(w, h)
        val base = if (k < 1f) {
            w = (w * k).roundToInt().coerceAtLeast(1); h = (h * k).roundToInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(src, w, h, true)
        } else src
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val band = 64
        val row = IntArray(w * band)
        var y0 = 0
        while (y0 < h) {
            currentCoroutineContext().ensureActive()
            val bh = min(band, h - y0)
            base.getPixels(row, 0, w, 0, y0, w, bh)
            for (yy in 0 until bh) {
                val fy = ((y0 + yy + 0.5f) * mh / h - 0.5f).coerceIn(0f, mh - 1f)
                val iy = fy.toInt(); val iy2 = min(iy + 1, mh - 1); val ty = fy - iy
                for (x in 0 until w) {
                    val fx = ((x + 0.5f) * mw / w - 0.5f).coerceIn(0f, mw - 1f)
                    val ix = fx.toInt(); val ix2 = min(ix + 1, mw - 1); val tx = fx - ix
                    val a0 = mask[iy * mw + ix] * (1 - tx) + mask[iy * mw + ix2] * tx
                    val a1 = mask[iy2 * mw + ix] * (1 - tx) + mask[iy2 * mw + ix2] * tx
                    val m = a0 * (1 - ty) + a1 * ty
                    val c = row[yy * w + x]
                    val a = (m * (c ushr 24)).roundToInt().coerceIn(0, 255)
                    row[yy * w + x] = (a shl 24) or (c and 0x00FFFFFF)
                }
            }
            out.setPixels(row, 0, w, 0, y0, w, bh)
            y0 += bh
            onProgress(90 + (y0 * 10 / h).coerceAtMost(9))
        }
        if (base !== src) base.recycle()
        onProgress(100)
        return out
    }
}

/** Диалог удаления фона у выбранной картинки на макете. Во время обработки доступна только кнопка «Отменить». */
@Composable
fun BgRemoveDialog(vm: AppVm, layer: Layer, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var progress by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val hasModel = remember { BgRemover.available(ctx) }

    fun start() {
        if (Bitmaps.get(layer.path) == null) { onDismiss(); return }
        job = scope.launch {
            busy = true
            progress = 0
            var failure: String? = null
            val newPath = withContext(Dispatchers.Default) {
                try {
                    val src = Bitmaps.get(layer.path) ?: return@withContext null
                    val out = BgRemover.remove(ctx.applicationContext, src) { progress = it }
                    val p = vm.store.saveBitmap(out, true)
                    out.recycle()
                    p
                } catch (t: CancellationException) {
                    throw t
                } catch (t: OutOfMemoryError) {
                    failure = "Не хватило памяти. Закройте другие приложения и попробуйте ещё раз"
                    null
                } catch (t: Throwable) {
                    failure = "Не удалось удалить фон: ${t.message ?: t.javaClass.simpleName}"
                    null
                }
            }
            busy = false
            if (newPath == null) {
                Toast.makeText(ctx, failure ?: "Не удалось удалить фон", Toast.LENGTH_LONG).show()
            } else {
                vm.updateLayer(layer.id) { it.copy(path = newPath) }
                Toast.makeText(ctx, "Фон удалён", Toast.LENGTH_SHORT).show()
                onDismiss()
            }
        }
    }

    if (!busy) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Card,
            title = { Text("Удалить фон") },
            text = {
                Text(
                    if (hasModel)
                        "Нейросеть найдёт главный объект и сделает всё остальное прозрачным. Работает на устройстве без интернета, " +
                            "обычно занимает от десяти секунд до минуты. Результат — PNG с прозрачным фоном; исходный файл не меняется."
                    else
                        "В этой сборке нет файла нейросети. Положите model_fp16.onnx в папку plugin/ репозитория и соберите приложение заново.",
                    color = Dim, fontSize = 13.sp
                )
            },
            confirmButton = { if (hasModel) TextButton(onClick = { start() }) { Text("Удалить фон") } },
            dismissButton = { TextButton(onClick = onDismiss) { Text(if (hasModel) "Отмена" else "Закрыть", color = Dim) } }
        )
    } else {
        AlertDialog(
            onDismissRequest = { },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
            containerColor = Card,
            title = { Text("Удаление фона") },
            text = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Нейросеть вырезает объект: $progress%", color = Amber, fontSize = 14.sp)
                    if (progress in 30..84) LinearProgressIndicator(color = Violet, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(progress = { progress / 100f }, color = Violet, modifier = Modifier.fillMaxWidth())
                    Text("Не закрывайте приложение.", color = Dim, fontSize = 12.sp)
                }
            },
            confirmButton = { },
            dismissButton = { TextButton(onClick = { job?.cancel(); busy = false }) { Text("Отменить", color = Dim) } }
        )
    }
}
