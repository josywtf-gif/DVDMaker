package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Canvas
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Данные редактора вырезки. Маска [m] идёт от нейросети; поверх неё:
 *  — выбор объектов (связные области маски: нажатие убирает/возвращает область),
 *  — мазки кисти «оставить» / «стереть»,
 *  — граница (порог), мягкость и сглаживание.
 */
class BgEdit(val m: BgRemover.Masks) {
    val w = m.w
    val h = m.h
    private val n = w * h

    /** Номер области для каждого пикселя (0 — не принадлежит ни одной). */
    val labels = IntArray(n)
    var removed = BooleanArray(1)
        private set
    val edit = ByteArray(n) // 0 — нет правки, 1 — оставить, 2 — стереть

    /** Заметный объект: номер области, площадь и центр (в пикселях маски). */
    class Obj(val label: Int, val area: Int, val cx: Float, val cy: Float)
    /** Заметные объекты по убыванию площади (до 9): по ним редактор предлагает выбрать, что оставить. */
    var objects: List<Obj> = emptyList()
        private set

    var threshold = 0.5f
    var soft = 0.12f
    var feather = 1
    var refine = true

    private val undoEdit = ArrayList<ByteArray>()
    private val undoRemoved = ArrayList<BooleanArray>()
    private val redoEdit = ArrayList<ByteArray>()
    private val redoRemoved = ArrayList<BooleanArray>()
    val canUndo get() = undoEdit.isNotEmpty()
    val canRedo get() = redoEdit.isNotEmpty()

    init { label() }

    /** Связные области маски (4-связность, порог 0.25). Мелкие и сильно уступающие главной по площади убираются сразу. */
    private fun label() {
        val stack = IntArray(n)
        val areas = ArrayList<Int>()
        areas.add(0)
        val sx = ArrayList<Double>(); val sy = ArrayList<Double>()
        sx.add(0.0); sy.add(0.0)
        var id = 0
        for (start in 0 until n) {
            if (labels[start] != 0 || m.raw[start] < 0.25f) continue
            id++
            var sp = 0
            var area = 0
            var ax = 0.0; var ay = 0.0
            stack[sp++] = start
            labels[start] = id
            while (sp > 0) {
                val p = stack[--sp]
                area++
                val x = p % w
                ax += x; ay += p / w
                if (x > 0 && labels[p - 1] == 0 && m.raw[p - 1] >= 0.25f) { labels[p - 1] = id; stack[sp++] = p - 1 }
                if (x < w - 1 && labels[p + 1] == 0 && m.raw[p + 1] >= 0.25f) { labels[p + 1] = id; stack[sp++] = p + 1 }
                if (p >= w && labels[p - w] == 0 && m.raw[p - w] >= 0.25f) { labels[p - w] = id; stack[sp++] = p - w }
                if (p < n - w && labels[p + w] == 0 && m.raw[p + w] >= 0.25f) { labels[p + w] = id; stack[sp++] = p + w }
            }
            areas.add(area); sx.add(ax); sy.add(ay)
        }
        val biggest = (areas.maxOrNull() ?: 0)
        objects = (1..id).filter { areas[it] >= 60 && areas[it] >= biggest / 20 }
            .sortedByDescending { areas[it] }.take(9)
            .map { Obj(it, areas[it], (sx[it] / areas[it]).toFloat(), (sy[it] / areas[it]).toFloat()) }
        removed = BooleanArray(id + 1) { i -> i > 0 && (areas[i] < 60 || areas[i] < biggest / 8) }
    }

    fun pushUndo() {
        undoEdit.add(edit.copyOf()); undoRemoved.add(removed.copyOf())
        if (undoEdit.size > 30) { undoEdit.removeAt(0); undoRemoved.removeAt(0) }
        redoEdit.clear(); redoRemoved.clear() // новое действие обрывает цепочку «вперёд»
    }

    fun undo() {
        if (undoEdit.isEmpty()) return
        redoEdit.add(edit.copyOf()); redoRemoved.add(removed.copyOf())
        undoEdit.removeAt(undoEdit.size - 1).copyInto(edit)
        undoRemoved.removeAt(undoRemoved.size - 1).copyInto(removed)
    }

    fun redo() {
        if (redoEdit.isEmpty()) return
        undoEdit.add(edit.copyOf()); undoRemoved.add(removed.copyOf())
        redoEdit.removeAt(redoEdit.size - 1).copyInto(edit)
        redoRemoved.removeAt(redoRemoved.size - 1).copyInto(removed)
    }

    fun reset() {
        pushUndo()
        edit.fill(0)
        label2()
    }

    private fun label2() {
        // вернуть автоматический выбор областей
        val areas = IntArray(removed.size)
        for (l in labels) if (l > 0) areas[l]++
        val biggest = areas.maxOrNull() ?: 0
        for (i in removed.indices) removed[i] = i > 0 && (areas[i] < 60 || areas[i] < biggest / 8)
    }

    /** Область под точкой (в пикселях маски) или ближайшая в радиусе [reach]. 0 — ничего. */
    fun labelAt(mx: Float, my: Float, reach: Int = 10): Int {
        val cx = mx.toInt(); val cy = my.toInt()
        var best = 0
        var bestD = Int.MAX_VALUE
        for (dy in -reach..reach) for (dx in -reach..reach) {
            val x = cx + dx; val y = cy + dy
            if (x < 0 || y < 0 || x >= w || y >= h) continue
            val l = labels[y * w + x]
            if (l == 0) continue
            val d = dx * dx + dy * dy
            if (d < bestD) { bestD = d; best = l }
        }
        return best
    }

    /** Оставить только области из [keep] среди заметных объектов; остальные заметные — убрать. */
    fun setKept(keep: List<Int>) {
        for (o in objects) removed[o.label] = o.label !in keep
    }

    fun toggle(label: Int) { if (label in 1 until removed.size) removed[label] = !removed[label] }

    fun stamp(cx: Float, cy: Float, rx: Float, ry: Float, value: Byte) {
        val x0 = max(0, (cx - rx).toInt()); val x1 = min(w - 1, (cx + rx).toInt() + 1)
        val y0 = max(0, (cy - ry).toInt()); val y1 = min(h - 1, (cy + ry).toInt() + 1)
        for (y in y0..y1) for (x in x0..x1) {
            val dx = (x - cx) / rx; val dy = (y - cy) / ry
            if (dx * dx + dy * dy <= 1f) edit[y * w + x] = value
        }
    }

    /** Итоговая маска w×h, 0…1. */
    fun compute(): FloatArray {
        val base = if (refine) m.refined else m.raw
        val lo = threshold - soft
        val inv = 1f / (2f * soft)
        val out = FloatArray(n)
        for (i in 0 until n) {
            val lab = labels[i]
            var s = if (lab > 0 && removed[lab]) 0f else {
                val u = ((base[i] - lo) * inv).coerceIn(0f, 1f)
                u * u * (3f - 2f * u)
            }
            when (edit[i].toInt()) { 1 -> s = 1f; 2 -> s = 0f }
            out[i] = s
        }
        if (feather <= 0) return out
        var r = BgRemover.box(out, w, h, feather)
        r = BgRemover.box(r, w, h, feather)
        return r
    }

    /** Картинка предпросмотра: цвета из [pv] (pw×ph), прозрачность из [mask]; убранные области подсвечены красным. */
    fun render(pv: IntArray, pw: Int, ph: Int, mask: FloatArray): IntArray {
        val out = IntArray(pw * ph)
        for (y in 0 until ph) {
            val fy = ((y + 0.5f) * h / ph - 0.5f).coerceIn(0f, h - 1f)
            val iy = fy.toInt(); val iy2 = min(iy + 1, h - 1); val ty = fy - iy
            for (x in 0 until pw) {
                val fx = ((x + 0.5f) * w / pw - 0.5f).coerceIn(0f, w - 1f)
                val ix = fx.toInt(); val ix2 = min(ix + 1, w - 1); val tx = fx - ix
                val a0 = mask[iy * w + ix] * (1 - tx) + mask[iy * w + ix2] * tx
                val a1 = mask[iy2 * w + ix] * (1 - tx) + mask[iy2 * w + ix2] * tx
                val a = a0 * (1 - ty) + a1 * ty
                val c = pv[y * pw + x]
                if (a < 0.02f) {
                    val lab = labels[iy * w + ix]
                    out[y * pw + x] = if (lab > 0 && removed[lab] && edit[iy * w + ix].toInt() != 2)
                        (0x66 shl 24) or 0xFF3B30 else 0
                } else {
                    out[y * pw + x] = ((a * 255f + 0.5f).toInt().coerceIn(0, 255) shl 24) or (c and 0x00FFFFFF)
                }
            }
        }
        return out
    }
}

private enum class BgMode { OBJECT, KEEP, ERASE, HAND }

/** Полноэкранный редактор вырезки. [onDone] получает итоговую маску (w×h, 0…1). */
@Composable
fun BgEditor(src: Bitmap, edit: BgEdit, onCancel: () -> Unit, onDone: (FloatArray) -> Unit) {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    // предпросмотр: длинная сторона до 1024 px
    val pvScale = min(1f, 1024f / max(src.width, src.height))
    val pw = (src.width * pvScale).roundToInt().coerceAtLeast(1)
    val ph = (src.height * pvScale).roundToInt().coerceAtLeast(1)
    val pvPix = remember(src) {
        val b = if (pvScale < 1f) Bitmap.createScaledBitmap(src, pw, ph, true) else src
        val p = IntArray(pw * ph)
        b.getPixels(p, 0, pw, 0, 0, pw, ph)
        if (b !== src) b.recycle()
        // прозрачные места исходника при предпросмотре считаем белыми
        for (i in p.indices) if ((p[i] ushr 24) < 255) p[i] = 0xFFFFFFFF.toInt()
        p
    }
    val shown = remember { Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888) }
    var version by remember { mutableIntStateOf(0) }

    var mode by remember { mutableStateOf(BgMode.OBJECT) }
    var brush by remember { mutableFloatStateOf(22f) } // dp
    var thr by remember { mutableFloatStateOf(edit.threshold) }
    var soft by remember { mutableFloatStateOf(edit.soft) }
    var feather by remember { mutableFloatStateOf(edit.feather.toFloat()) }
    var refine by remember { mutableStateOf(edit.refine) }
    var canUndoS by remember { mutableStateOf(edit.canUndo) }
    var canRedoS by remember { mutableStateOf(edit.canRedo) }
    fun sync() { canUndoS = edit.canUndo; canRedoS = edit.canRedo }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize(1, 1)) }
    var cursor by remember { mutableStateOf<Offset?>(null) }
    var darkBg by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf(edit.objects.size >= 2) }

    var renderJob by remember { mutableStateOf<Job?>(null) }
    fun render() {
        renderJob?.cancel()
        renderJob = scope.launch(Dispatchers.Default) {
            val px = edit.render(pvPix, pw, ph, edit.compute())
            withContext(Dispatchers.Main) {
                shown.setPixels(px, 0, pw, 0, 0, pw, ph)
                version++
            }
        }
    }
    LaunchedEffect(Unit) { render() }
    DisposableEffect(Unit) { onDispose { renderJob?.cancel() } }

    // клетчатый фон (шахматка) — шейдер из маленькой плитки
    val cell = with(density) { 10.dp.toPx() }.roundToInt().coerceAtLeast(4)
    val checkerLight = remember(cell) { checkerPaint(cell, 0xFFD9D9D9.toInt(), 0xFFFFFFFF.toInt()) }
    val checkerDark = remember(cell) { checkerPaint(cell, 0xFF2A2A2A.toInt(), 0xFF3C3C3C.toInt()) }

    // геометрия изображения на экране
    fun fit() = min(box.width.toFloat() / pw, box.height.toFloat() / ph)
    fun dispW() = pw * fit() * zoom
    fun dispH() = ph * fit() * zoom
    fun left() = box.width / 2f + pan.x - dispW() / 2f
    fun top() = box.height / 2f + pan.y - dispH() / 2f
    fun toMask(o: Offset) = Offset((o.x - left()) / dispW() * edit.w, (o.y - top()) / dispH() * edit.h)

    fun stampAt(o: Offset) {
        val c = toMask(o)
        val rPx = with(density) { brush.dp.toPx() }
        edit.stamp(c.x, c.y, rPx * edit.w / dispW(), rPx * edit.h / dispH(), if (mode == BgMode.KEEP) 1 else 2)
    }

    Dialog(
        onDismissRequest = { },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                TextButton(onClick = onCancel) { Text("Отмена", color = Dim) }
                Text("Удалить фон", color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                androidx.compose.material3.IconButton(onClick = { edit.undo(); sync(); render() }, enabled = canUndoS) {
                    Text("↶", fontSize = 26.sp, color = if (canUndoS) Color.White else Line)
                }
                androidx.compose.material3.IconButton(onClick = { edit.redo(); sync(); render() }, enabled = canRedoS) {
                    Text("↷", fontSize = 26.sp, color = if (canRedoS) Color.White else Line)
                }
                TextButton(onClick = {
                    scope.launch {
                        val mask = withContext(Dispatchers.Default) { edit.compute() }
                        onDone(mask)
                    }
                }) { Text("Готово", color = Amber) }
            }

            Box(
                Modifier.weight(1f).fillMaxWidth().clipToBounds().onSizeChanged { box = it }
                    .pointerInput(mode) {
                        when (mode) {
                            BgMode.OBJECT -> detectTapGestures { o ->
                                val c = toMask(o)
                                val l = edit.labelAt(c.x, c.y, (14 * edit.w / dispW() * density.density).roundToInt().coerceIn(4, 40))
                                if (l > 0) { edit.pushUndo(); edit.toggle(l); sync(); render() }
                            }
                            BgMode.HAND -> detectTransformGestures { _, p, z, _ ->
                                zoom = (zoom * z).coerceIn(1f, 8f)
                                pan = if (zoom <= 1.001f) Offset.Zero else pan + p
                            }
                            else -> detectTapGestures { o ->
                                edit.pushUndo(); sync(); stampAt(o); render()
                            }
                        }
                    }
                    .pointerInput(mode) {
                        if (mode == BgMode.KEEP || mode == BgMode.ERASE) {
                            var last = Offset.Zero
                            detectDragGestures(
                                onDragStart = { o -> edit.pushUndo(); sync(); last = o; cursor = o; stampAt(o); render() },
                                onDragEnd = { cursor = null },
                                onDragCancel = { cursor = null }
                            ) { change, _ ->
                                change.consume()
                                val o = change.position
                                cursor = o
                                val step = with(density) { brush.dp.toPx() } / 3f
                                val dist = (o - last).getDistance()
                                val k = max(1, (dist / step).toInt())
                                for (i in 1..k) stampAt(last + (o - last) * (i / k.toFloat()))
                                last = o
                                render()
                            }
                        }
                    }
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    version // чтение состояния: перерисовка при новом предпросмотре
                    val l = left(); val t = top(); val r = l + dispW(); val b = t + dispH()
                    drawIntoCanvas { cv ->
                        val rect = RectF(l, t, r, b)
                        cv.nativeCanvas.drawRect(rect, if (darkBg) checkerDark else checkerLight)
                        cv.nativeCanvas.drawBitmap(shown, null, rect, Paint(Paint.FILTER_BITMAP_FLAG))
                    }
                    if (picking) drawIntoCanvas { cv ->
                        val nc = cv.nativeCanvas
                        val rad = 15.dp.toPx()
                        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
                        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = android.graphics.Color.WHITE; textAlign = Paint.Align.CENTER
                            textSize = 16.sp.toPx(); isFakeBoldText = true
                        }
                        edit.objects.forEachIndexed { i, o ->
                            val x = l + o.cx / edit.w * (r - l)
                            val y = t + o.cy / edit.h * (b - t)
                            bg.color = if (edit.removed[o.label]) 0xE6D32F2F.toInt() else 0xE62E9E5B.toInt()
                            nc.drawCircle(x, y, rad, bg)
                            nc.drawText("${i + 1}", x, y + tp.textSize * 0.35f, tp)
                        }
                    }
                    cursor?.let {
                        drawCircle(Color.White, brush.dp.toPx(), it, style = Stroke(1.5.dp.toPx()))
                        drawCircle(Color.Black.copy(alpha = 0.6f), brush.dp.toPx() + 1.5.dp.toPx(), it, style = Stroke(1.dp.toPx()))
                    }
                }
            }

            if (picking) {
                version
                Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Найдено объектов: ${edit.objects.size}. Какие оставить?", color = Color.White, fontSize = 14.sp)
                    Text("Зелёный номер — оставить, красный — убрать. Выбирайте кнопками или нажатием на объект на фото.", color = Dim, fontSize = 11.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        edit.objects.forEachIndexed { i, o ->
                            Pill("${i + 1}", !edit.removed[o.label], { edit.pushUndo(); edit.toggle(o.label); sync(); render() })
                        }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill("Оставить все", false, { edit.pushUndo(); edit.setKept(edit.objects.map { it.label }); sync(); render() })
                        Pill("Только крупнейший", false, { edit.pushUndo(); edit.setKept(listOf(edit.objects.first().label)); sync(); render() })
                        Pill("Продолжить", true, { picking = false })
                    }
                }
            } else Column(
                Modifier.fillMaxWidth().heightIn(max = 300.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill("Объекты", mode == BgMode.OBJECT, { mode = BgMode.OBJECT })
                    Pill("Оставить кистью", mode == BgMode.KEEP, { mode = BgMode.KEEP })
                    Pill("Стереть кистью", mode == BgMode.ERASE, { mode = BgMode.ERASE })
                    Pill("Масштаб", mode == BgMode.HAND, { mode = BgMode.HAND })
                }
                Text(
                    when (mode) {
                        BgMode.OBJECT -> "Нажмите на область: красная — убрана, нажатие вернёт её; нажмите на объект, чтобы убрать."
                        BgMode.KEEP -> "Проведите по тому, что нужно сохранить (например, пропущенная часть объекта)."
                        BgMode.ERASE -> "Проведите по тому, что нужно убрать (остатки фона, тени)."
                        BgMode.HAND -> "Двумя пальцами: приблизить и двигать картинку."
                    },
                    color = Dim, fontSize = 11.sp
                )
                if (mode == BgMode.KEEP || mode == BgMode.ERASE) {
                    LabeledSlider("Размер кисти", brush, 6f..60f, "${brush.toInt()}") { brush = it }
                }
                LabeledSlider("Граница (выше — вырезка плотнее к объекту)", thr, 0.15f..0.85f, "${(thr * 100).toInt()}%") {
                    thr = it; edit.threshold = it; render()
                }
                LabeledSlider("Мягкость края", soft, 0.02f..0.3f, "${(soft * 100).toInt()}%") {
                    soft = it; edit.soft = it; render()
                }
                LabeledSlider("Сглаживание", feather, 0f..6f, if (feather.roundToInt() == 0) "Выкл." else "${feather.roundToInt()}") {
                    feather = it; edit.feather = it.roundToInt(); render()
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Pill("Подгонка по краям фото", refine, { refine = !refine; edit.refine = refine; render() })
                    Pill("Сбросить правки", false, { edit.reset(); sync(); render() })
                    Pill(if (darkBg) "Тёмный фон" else "Светлый фон", false, { darkBg = !darkBg; version++ })
                }
            }
        }
    }
}

private fun checkerPaint(cell: Int, a: Int, b: Int): Paint {
    val tile = Bitmap.createBitmap(cell * 2, cell * 2, Bitmap.Config.ARGB_8888)
    val px = IntArray(cell * 2 * cell * 2) { i ->
        val x = (i % (cell * 2)) / cell; val y = (i / (cell * 2)) / cell
        if ((x + y) % 2 == 0) a else b
    }
    tile.setPixels(px, 0, cell * 2, 0, 0, cell * 2, cell * 2)
    return Paint().apply { shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
}
