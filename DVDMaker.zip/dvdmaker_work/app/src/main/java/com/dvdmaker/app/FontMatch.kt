package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Подбор шрифта по тексту, уже нарисованному на картинке: сравнение формы букв с каждым шрифтом приложения. */
object FontMatch {
    /** Плотность «чернил» 0..1, обрезанная по границам текста. */
    class Ink(val w: Int, val h: Int, val v: FloatArray) {
        fun toBitmap(): Bitmap {
            val px = IntArray(w * h) { if (v[it] > 0.5f) Color.BLACK else Color.WHITE }
            return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        }
    }

    class Result(val entry: Fonts.Entry, val italic: Boolean, val score: Float) {
        val percent: Int get() = ((1f - score) * 100f).roundToInt().coerceIn(0, 99)
    }

    private const val GH = 48

    /** Вырезает прямоугольник (доли 0..1) из картинки и выделяет буквы (порог Отсу, чернила — меньшая по площади часть). */
    fun extractInk(src: Bitmap, l: Float, t: Float, r: Float, b: Float, invert: Boolean): Ink? {
        val x0 = (minOf(l, r) * src.width).toInt().coerceIn(0, src.width - 1)
        val y0 = (minOf(t, b) * src.height).toInt().coerceIn(0, src.height - 1)
        val x1 = (maxOf(l, r) * src.width).toInt().coerceIn(x0 + 1, src.width)
        val y1 = (maxOf(t, b) * src.height).toInt().coerceIn(y0 + 1, src.height)
        val cw = x1 - x0
        val ch = y1 - y0
        if (cw < 8 || ch < 8) return null
        val crop = Bitmap.createBitmap(src, x0, y0, cw, ch)
        var s = 1f
        if (ch < 96) s = 96f / ch
        if (max(cw, ch) * s > 1024f) s = 1024f / max(cw, ch)
        val bm = if (s != 1f) Bitmap.createScaledBitmap(crop, (cw * s).roundToInt().coerceAtLeast(1), (ch * s).roundToInt().coerceAtLeast(1), true) else crop
        val w = bm.width
        val h = bm.height
        val px = IntArray(w * h)
        bm.getPixels(px, 0, w, 0, 0, w, h)
        val lum = IntArray(w * h) {
            val p = px[it]
            (299 * ((p shr 16) and 255) + 587 * ((p shr 8) and 255) + 114 * (p and 255)) / 1000
        }
        val hist = IntArray(256)
        for (v in lum) hist[v]++
        val total = w * h
        var sum = 0L
        for (i in 0..255) sum += i.toLong() * hist[i]
        var sumB = 0L
        var wB = 0
        var best = -1.0
        var thr = 128
        for (i in 0..255) {
            wB += hist[i]
            if (wB == 0) continue
            val wF = total - wB
            if (wF == 0) break
            sumB += i.toLong() * hist[i]
            val mB = sumB.toDouble() / wB
            val mF = (sum - sumB).toDouble() / wF
            val vb = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (vb > best) { best = vb; thr = i }
        }
        var dark = 0
        for (v in lum) if (v <= thr) dark++
        var inkDark = dark * 2 <= total
        if (invert) inkDark = !inkDark
        val mask = BooleanArray(total) { if (inkDark) lum[it] <= thr else lum[it] > thr }
        val rc = IntArray(h)
        val cc = IntArray(w)
        for (y in 0 until h) for (x in 0 until w) if (mask[y * w + x]) { rc[y]++; cc[x]++ }
        val rowT = max(2, (w * 0.012f).toInt())
        val colT = max(2, (h * 0.012f).toInt())
        val ty0 = (0 until h).firstOrNull { rc[it] >= rowT } ?: return null
        val ty1 = (h - 1 downTo 0).firstOrNull { rc[it] >= rowT } ?: return null
        val tx0 = (0 until w).firstOrNull { cc[it] >= colT } ?: return null
        val tx1 = (w - 1 downTo 0).firstOrNull { cc[it] >= colT } ?: return null
        val bw = tx1 - tx0 + 1
        val bh = ty1 - ty0 + 1
        if (bw < 8 || bh < 8) return null
        val v = FloatArray(bw * bh) { if (mask[(ty0 + it / bw) * w + tx0 + it % bw]) 1f else 0f }
        return Ink(bw, bh, v)
    }

    private fun renderInk(text: String, tf: Typeface): Ink? {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 80f; typeface = tf; color = Color.BLACK }
        val bigW = 6000
        val sl = StaticLayout.Builder.obtain(text, 0, text.length, tp, bigW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build()
        var maxW = 1f
        for (i in 0 until sl.lineCount) maxW = max(maxW, sl.getLineWidth(i))
        val bw = ceil(maxW).toInt() + 20
        val bh = sl.height + 20
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ALPHA_8)
        val c = Canvas(bmp)
        c.translate(10f - (bigW / 2f - maxW / 2f), 10f)
        sl.draw(c)
        val px = IntArray(bw * bh)
        bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
        bmp.recycle()
        var minX = bw; var maxX = -1; var minY = bh; var maxY = -1
        for (y in 0 until bh) for (x in 0 until bw) if ((px[y * bw + x] ushr 24) > 96) {
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (y < minY) minY = y; if (y > maxY) maxY = y
        }
        if (maxX < 0) return null
        val w = maxX - minX + 1
        val h = maxY - minY + 1
        val v = FloatArray(w * h) { (px[(minY + it / w) * bw + minX + it % w] ushr 24) / 255f }
        return Ink(w, h, v)
    }

    private fun toGrid(v: FloatArray, w: Int, h: Int, gw: Int, gh: Int): FloatArray {
        val out = FloatArray(gw * gh)
        for (gy in 0 until gh) {
            val y0 = gy * h / gh
            val y1 = max(y0 + 1, ((gy + 1) * h + gh - 1) / gh).coerceAtMost(h)
            for (gx in 0 until gw) {
                val x0 = gx * w / gw
                val x1 = max(x0 + 1, ((gx + 1) * w + gw - 1) / gw).coerceAtMost(w)
                var s = 0f
                for (y in y0 until y1) {
                    val row = y * w
                    for (x in x0 until x1) s += v[row + x]
                }
                out[gy * gw + gx] = s / ((y1 - y0) * (x1 - x0))
            }
        }
        return out
    }

    private fun smooth(g: FloatArray, gw: Int, gh: Int): FloatArray {
        val o = FloatArray(g.size)
        for (y in 0 until gh) for (x in 0 until gw) {
            var s = 0f
            var n = 0
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx; val yy = y + dy
                if (xx in 0 until gw && yy in 0 until gh) { s += g[yy * gw + xx]; n++ }
            }
            o[y * gw + x] = s / n
        }
        return o
    }

    /** Возвращает до 8 лучших шрифтов (с учётом курсива), лучший первым. */
    fun find(target: Ink, text: String, onProgress: (Float) -> Unit): List<Result> {
        val clean = text.trim().take(60)
        if (clean.isEmpty()) return emptyList()
        val aspectT = target.w.toFloat() / target.h
        val gw = (GH * aspectT).roundToInt().coerceIn(24, 400)
        val t = smooth(toGrid(target.v, target.w, target.h, gw, GH), gw, GH)
        val entries = Fonts.entries
        val out = ArrayList<Result>()
        entries.forEachIndexed { idx, e ->
            var bestScore = Float.MAX_VALUE
            var bestItalic = false
            for (italic in listOf(false, true)) {
                val ink = runCatching { renderInk(clean, Fonts.get(e.sys, e.file, italic)) }.getOrNull() ?: continue
                val c = smooth(toGrid(ink.v, ink.w, ink.h, gw, GH), gw, GH)
                var d = 0f
                var s = 0f
                for (i in t.indices) { d += abs(t[i] - c[i]); s += t[i] + c[i] }
                val aspectC = ink.w.toFloat() / ink.h
                val score = (if (s <= 0f) 1f else d / s) + 0.12f * abs(ln(aspectC / aspectT))
                if (score < bestScore) { bestScore = score; bestItalic = italic }
            }
            if (bestScore < Float.MAX_VALUE) out.add(Result(e, bestItalic, bestScore.coerceIn(0f, 1f)))
            onProgress((idx + 1f) / entries.size)
        }
        return out.sortedBy { it.score }.take(8)
    }
}
