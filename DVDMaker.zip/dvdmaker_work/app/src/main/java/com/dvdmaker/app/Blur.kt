package com.dvdmaker.app

import android.graphics.Bitmap
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Качественное гауссово размытие: три прохода box-blur на уменьшенной копии, плавное увеличение и микро-дизеринг (без «квадратиков» и бандинга). */
object Blur {
    fun gaussian(src: Bitmap, sigmaFrac: Float = 0.03f, workSide: Int = 560): Bitmap {
        val w = src.width
        val h = src.height
        val k = min(1f, workSide / max(w, h).toFloat())
        val ww = (w * k).roundToInt().coerceAtLeast(2)
        val hh = (h * k).roundToInt().coerceAtLeast(2)
        val small = scaleSmooth(src, ww, hh)
        val px = IntArray(ww * hh)
        small.getPixels(px, 0, ww, 0, 0, ww, hh)
        if (small !== src) small.recycle()
        blurPixels(px, ww, hh, sigmaFrac * max(ww, hh))
        val blurred = Bitmap.createBitmap(ww, hh, Bitmap.Config.ARGB_8888)
        blurred.setPixels(px, 0, ww, 0, 0, ww, hh)
        var big = scaleSmooth(blurred, w, h)
        if (big !== blurred) blurred.recycle()
        if (!big.isMutable || big.config != Bitmap.Config.ARGB_8888) {
            val c = big.copy(Bitmap.Config.ARGB_8888, true)
            big.recycle()
            big = c
        }
        dither(big)
        return big
    }

    /** Масштаб ступенями ×2 с билинейной фильтрацией: без алиасинга при уменьшении и без блочности при увеличении. */
    fun scaleSmooth(src: Bitmap, tw: Int, th: Int): Bitmap {
        var cur = src
        fun step(nw: Int, nh: Int) {
            val n = Bitmap.createScaledBitmap(cur, nw.coerceAtLeast(1), nh.coerceAtLeast(1), true)
            if (n !== cur) {
                if (cur !== src) cur.recycle()
                cur = n
            }
        }
        while (cur.width / 2 >= tw && cur.height / 2 >= th) step(cur.width / 2, cur.height / 2)
        while (cur.width * 2 <= tw && cur.height * 2 <= th) step(cur.width * 2, cur.height * 2)
        if (cur.width != tw || cur.height != th) step(tw, th)
        return cur
    }

    private fun dither(b: Bitmap) {
        val w = b.width
        val h = b.height
        val row = IntArray(w)
        var seed = 12345
        for (y in 0 until h) {
            b.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                seed = seed * 1103515245 + 12345
                val n = ((seed ushr 16) % 3) - 1
                val p = row[x]
                val r = (((p shr 16) and 255) + n).coerceIn(0, 255)
                val g = (((p shr 8) and 255) + n).coerceIn(0, 255)
                val bl = ((p and 255) + n).coerceIn(0, 255)
                row[x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
            }
            b.setPixels(row, 0, w, 0, y, w, 1)
        }
    }

    fun blurPixels(px: IntArray, w: Int, h: Int, sigma: Float) {
        val tmp = IntArray(px.size)
        for (box in boxesForGauss(sigma.coerceAtLeast(0.5f), 3)) {
            val r = (box - 1) / 2
            boxH(px, tmp, w, h, r)
            boxV(tmp, px, w, h, r)
        }
    }

    private fun boxesForGauss(sigma: Float, n: Int): IntArray {
        val wIdeal = sqrt(12f * sigma * sigma / n + 1f)
        var wl = floor(wIdeal).toInt()
        if (wl % 2 == 0) wl--
        if (wl < 1) wl = 1
        val wu = wl + 2
        val mIdeal = (12f * sigma * sigma - n * wl * wl - 4f * n * wl - 3f * n) / (-4f * wl - 4f)
        val m = mIdeal.roundToInt()
        return IntArray(n) { if (it < m) wl else wu }
    }

    private fun boxH(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val p = src[row + i.coerceIn(0, w - 1)]
                sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (x in 0 until w) {
                dst[row + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val a = src[row + min(x + r + 1, w - 1)]
                val d = src[row + max(x - r, 0)]
                sr += ((a shr 16) and 255) - ((d shr 16) and 255)
                sg += ((a shr 8) and 255) - ((d shr 8) and 255)
                sb += (a and 255) - (d and 255)
            }
        }
    }

    private fun boxV(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        for (x in 0 until w) {
            var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val p = src[i.coerceIn(0, h - 1) * w + x]
                sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (y in 0 until h) {
                dst[y * w + x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val a = src[min(y + r + 1, h - 1) * w + x]
                val d = src[max(y - r, 0) * w + x]
                sr += ((a shr 16) and 255) - ((d shr 16) and 255)
                sg += ((a shr 8) and 255) - ((d shr 8) and 255)
                sb += (a and 255) - (d and 255)
            }
        }
    }
}
