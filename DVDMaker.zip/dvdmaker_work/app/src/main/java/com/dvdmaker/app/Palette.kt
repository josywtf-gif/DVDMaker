package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.sqrt

/** Основная палитра изображения (k-means) и красивый «меш»-градиент из неё с сохранением расположения цветов. */
object Palette {
    class Swatch(val color: Int, val cx: Float, val cy: Float, val share: Float)

    fun extract(src: Bitmap, k: Int = 5): List<Swatch> {
        val n = 56
        val small = Bitmap.createScaledBitmap(src, n, n, true)
        val px = IntArray(n * n)
        small.getPixels(px, 0, n, 0, 0, n, n)
        val r = FloatArray(px.size) { ((px[it] shr 16) and 255).toFloat() }
        val g = FloatArray(px.size) { ((px[it] shr 8) and 255).toFloat() }
        val b = FloatArray(px.size) { (px[it] and 255).toFloat() }
        fun d2(i: Int, cr: Float, cg: Float, cb: Float): Float {
            val dr = r[i] - cr; val dg = g[i] - cg; val db = b[i] - cb
            return dr * dr + dg * dg + db * db
        }
        val cr = FloatArray(k); val cg = FloatArray(k); val cb = FloatArray(k)
        cr[0] = r.average().toFloat(); cg[0] = g.average().toFloat(); cb[0] = b.average().toFloat()
        for (c in 1 until k) {
            var best = -1f; var bi = 0
            for (i in px.indices) {
                var m = Float.MAX_VALUE
                for (j in 0 until c) m = minOf(m, d2(i, cr[j], cg[j], cb[j]))
                if (m > best) { best = m; bi = i }
            }
            cr[c] = r[bi]; cg[c] = g[bi]; cb[c] = b[bi]
        }
        val asg = IntArray(px.size)
        repeat(10) {
            for (i in px.indices) {
                var bj = 0; var bd = Float.MAX_VALUE
                for (j in 0 until k) { val d = d2(i, cr[j], cg[j], cb[j]); if (d < bd) { bd = d; bj = j } }
                asg[i] = bj
            }
            val sr = FloatArray(k); val sg = FloatArray(k); val sb = FloatArray(k); val cnt = IntArray(k)
            for (i in px.indices) { val j = asg[i]; sr[j] += r[i]; sg[j] += g[i]; sb[j] += b[i]; cnt[j]++ }
            for (j in 0 until k) if (cnt[j] > 0) { cr[j] = sr[j] / cnt[j]; cg[j] = sg[j] / cnt[j]; cb[j] = sb[j] / cnt[j] }
        }
        val out = ArrayList<Swatch>()
        for (j in 0 until k) {
            var cnt = 0; var sx = 0f; var sy = 0f
            for (i in px.indices) if (asg[i] == j) { cnt++; sx += (i % n) + 0.5f; sy += (i / n) + 0.5f }
            if (cnt == 0 || cnt.toFloat() / px.size < 0.03f) continue
            val col = (0xFF shl 24) or (cr[j].toInt().coerceIn(0, 255) shl 16) or (cg[j].toInt().coerceIn(0, 255) shl 8) or cb[j].toInt().coerceIn(0, 255)
            out.add(Swatch(col, sx / cnt / n, sy / cnt / n, cnt.toFloat() / px.size))
        }
        small.recycle()
        return out.sortedByDescending { it.share }
    }

    fun render(sw: List<Swatch>, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(sw.firstOrNull()?.color ?: 0xFF000000.toInt())
        val side = max(w, h).toFloat()
        val narrow = w < h * 0.4f
        for (s in sw.sortedByDescending { it.share }) {   // крупные пятна снизу, мелкие — сверху
            val cx = if (narrow) w / 2f else s.cx * w
            val cy = s.cy * h
            val radius = side * (0.35f + 0.9f * sqrt(s.share))
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(cx, cy, radius, s.color, s.color and 0x00FFFFFF, Shader.TileMode.CLAMP)
            }
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }
        val out = Blur.gaussian(bmp, sigmaFrac = 0.02f)
        bmp.recycle()
        return out
    }
}
