package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.sqrt

/** Основная палитра изображения (k-means) и красивый «меш»-градиент из неё с сохранением расположения цветов. */
object Palette {
    class Swatch(val color: Int, val cx: Float, val cy: Float, val share: Float)

    private fun colorDist(a: Int, b: Int): Float {
        val dr = ((a shr 16) and 255) - ((b shr 16) and 255)
        val dg = ((a shr 8) and 255) - ((b shr 8) and 255)
        val db = (a and 255) - (b and 255)
        return sqrt((dr * dr + dg * dg + db * db).toFloat())
    }

    fun extract(src: Bitmap, k: Int = 6): List<Swatch> {
        val n = 56
        val small = Bitmap.createScaledBitmap(src, n, n, true)
        val px = IntArray(n * n)
        small.getPixels(px, 0, n, 0, 0, n, n)
        val r = FloatArray(px.size) { ((px[it] shr 16) and 255).toFloat() }
        val g = FloatArray(px.size) { ((px[it] shr 8) and 255).toFloat() }
        val b = FloatArray(px.size) { (px[it] and 255).toFloat() }
        fun d2(i: Int, cr: Float, cg: Float, cb: Float): Float {
            val dr = r[i] - cr; val dg = g[i] - cg; val db = b[i] - cb
            return dr * dr + dg * dg + db * db
        }
        val cr = FloatArray(k); val cg = FloatArray(k); val cb = FloatArray(k)
        cr[0] = r.average().toFloat(); cg[0] = g.average().toFloat(); cb[0] = b.average().toFloat()
        for (c in 1 until k) {
            var best = -1f; var bi = 0
            for (i in px.indices) {
                var m = Float.MAX_VALUE
                for (j in 0 until c) m = minOf(m, d2(i, cr[j], cg[j], cb[j]))
                if (m > best) { best = m; bi = i }
            }
            cr[c] = r[bi]; cg[c] = g[bi]; cb[c] = b[bi]
        }
        val asg = IntArray(px.size)
        repeat(10) {
            for (i in px.indices) {
                var bj = 0; var bd = Float.MAX_VALUE
                for (j in 0 until k) { val d = d2(i, cr[j], cg[j], cb[j]); if (d < bd) { bd = d; bj = j } }
                asg[i] = bj
            }
            val sr = FloatArray(k); val sg = FloatArray(k); val sb = FloatArray(k); val cnt = IntArray(k)
            for (i in px.indices) { val j = asg[i]; sr[j] += r[i]; sg[j] += g[i]; sb[j] += b[i]; cnt[j]++ }
            for (j in 0 until k) if (cnt[j] > 0) { cr[j] = sr[j] / cnt[j]; cg[j] = sg[j] / cnt[j]; cb[j] = sb[j] / cnt[j] }
        }
        val out = ArrayList<Swatch>()
        for (j in 0 until k) {
            var cnt = 0; var sx = 0f; var sy = 0f
            for (i in px.indices) if (asg[i] == j) { cnt++; sx += (i % n) + 0.5f; sy += (i / n) + 0.5f }
            if (cnt == 0 || cnt.toFloat() / px.size < 0.03f) continue
            val col = (0xFF shl 24) or (cr[j].toInt().coerceIn(0, 255) shl 16) or (cg[j].toInt().coerceIn(0, 255) shl 8) or cb[j].toInt().coerceIn(0, 255)
            out.add(Swatch(col, sx / cnt / n, sy / cnt / n, cnt.toFloat() / px.size))
        }
        small.recycle()
        // близкие цвета объединяем, чтобы доли были честными
        val merged = ArrayList<Swatch>()
        for (sw in out.sortedByDescending { it.share }) {
            val i = merged.indexOfFirst { colorDist(it.color, sw.color) < 38f }
            if (i < 0) merged.add(sw) else {
                val m = merged[i]
                val t = m.share + sw.share
                merged[i] = Swatch(m.color, (m.cx * m.share + sw.cx * sw.share) / t, (m.cy * m.share + sw.cy * sw.share) / t, t)
            }
        }
        return merged.sortedByDescending { it.share }
    }

    /**
     * Крупные цвета (по площади) образуют плавный вертикальный градиент: чем больше доля, тем больше места он занимает.
     * Мелкие цвета — лёгкие, широкие, полупрозрачные «подсветки», разбросанные по краям и углам, без плотных пятен.
     */
    fun render(sw: List<Swatch>, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val sorted = sw.sortedByDescending { it.share }
        val top = sorted.firstOrNull()?.share ?: 1f
        var major = sorted.filter { it.share >= maxOf(0.14f, top * 0.35f) }
        if (major.isEmpty()) major = sorted.take(1)
        if (major.size < 2 && sorted.size >= 2) major = sorted.take(2)
        val minors = sorted.filter { it !in major }
        val ordered = major.sortedBy { it.cy }
        val total = ordered.sumOf { it.share.toDouble() }.toFloat().coerceAtLeast(0.001f)
        val colors = ArrayList<Int>()
        val pos = ArrayList<Float>()
        colors.add(ordered.first().color); pos.add(0f)
        var cum = 0f
        for (m in ordered) {
            val p = ((cum + m.share / 2f) / total).coerceIn(0.02f, 0.98f)
            if (p > pos.last()) { colors.add(m.color); pos.add(p) }
            cum += m.share
        }
        colors.add(ordered.last().color); pos.add(1f)
        val grad = if (colors.size >= 2)
            android.graphics.LinearGradient(0f, 0f, 0f, h.toFloat(), colors.toIntArray(), pos.toFloatArray(), Shader.TileMode.CLAMP)
        else null
        if (grad != null) c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply { shader = grad })
        else c.drawColor(colors[0])
        val side = max(w, h).toFloat()
        val narrow = w < h * 0.4f
        minors.forEachIndexed { i, s ->
            val ux = (0.15f + (i + 1) * 0.7548777f) % 1f
            val uy = (0.15f + (i + 1) * 0.5698403f) % 1f
            // подсветки жмём к краям: центр панели остаётся чистым
            val px = if (narrow) 0.5f else edge(0.5f * s.cx + 0.5f * ux)
            val py = edge(0.5f * s.cy + 0.5f * uy)
            val radius = side * (0.55f + 0.5f * sqrt(s.share))
            val a = (0.12f + 1.5f * s.share).coerceAtMost(0.4f)
            val col = s.color and 0x00FFFFFF
            val shader = RadialGradient(
                px * w, py * h, radius,
                intArrayOf(col or ((a * 255).toInt() shl 24), col or ((a * 110).toInt() shl 24), col),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint(Paint.ANTI_ALIAS_FLAG).apply { this.shader = shader })
        }
        val out = Blur.gaussian(bmp, sigmaFrac = 0.03f)
        bmp.recycle()
        return out
    }

    /** Сдвигает координату от центра к краю (0.5 → ближе к 0.2 или 0.8). */
    private fun edge(v: Float): Float = if (v < 0.5f) 0.05f + v * 0.5f else 0.95f - (1f - v) * 0.5f
}
