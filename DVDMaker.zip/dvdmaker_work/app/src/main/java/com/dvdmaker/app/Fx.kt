package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Атмосфера всего разворота: цветокор, тонировка, виньетка, снег и плёночное зерно.
 * Рисуется поверх готовой обложки, поэтому одинаково работает для любых картинок и текста.
 */
data class Fx(
    val vignette: Float = 0f,
    val tint: Int = 0xFF2E6FD0.toInt(),
    val tintAmount: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val grain: Float = 0f,
    val snow: Float = 0f,
    val snowWind: Float = 0.5f,
    val snowSeed: Int = 7
) {
    val hasGrade: Boolean get() = abs(contrast - 1f) > 0.001f || abs(saturation - 1f) > 0.001f

    val active: Boolean
        get() = vignette > 0.001f || tintAmount > 0.001f || hasGrade || grain > 0.001f || snow > 0.001f

    fun toJson(): JSONObject = JSONObject().apply {
        put("vignette", vignette.toDouble()); put("tint", tint); put("tintAmount", tintAmount.toDouble())
        put("contrast", contrast.toDouble()); put("saturation", saturation.toDouble())
        put("grain", grain.toDouble()); put("snow", snow.toDouble())
        put("snowWind", snowWind.toDouble()); put("snowSeed", snowSeed)
    }

    companion object {
        fun fromJson(o: JSONObject?): Fx {
            if (o == null) return Fx()
            return Fx(
                vignette = o.optDouble("vignette", 0.0).toFloat().coerceIn(0f, 1f),
                tint = o.optInt("tint", 0xFF2E6FD0.toInt()),
                tintAmount = o.optDouble("tintAmount", 0.0).toFloat().coerceIn(0f, 0.6f),
                contrast = o.optDouble("contrast", 1.0).toFloat().coerceIn(0.5f, 1.8f),
                saturation = o.optDouble("saturation", 1.0).toFloat().coerceIn(0f, 2f),
                grain = o.optDouble("grain", 0.0).toFloat().coerceIn(0f, 1f),
                snow = o.optDouble("snow", 0.0).toFloat().coerceIn(0f, 1f),
                snowWind = o.optDouble("snowWind", 0.5).toFloat().coerceIn(0f, 1f),
                snowSeed = o.optInt("snowSeed", 7)
            )
        }
    }
}

object FxPainter {
    private var grainTile: Bitmap? = null

    fun gradeMatrix(fx: Fx): ColorMatrix {
        val cm = ColorMatrix()
        cm.setSaturation(fx.saturation.coerceIn(0f, 2f))
        val c = fx.contrast.coerceIn(0.5f, 1.8f)
        val t = 128f * (1f - c)
        cm.postConcat(ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t,
            0f, c, 0f, 0f, t,
            0f, 0f, c, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )))
        return cm
    }

    /** Цветокор отдельной фотографии: оттенок, насыщенность, контраст/яркость, температура и полная перекраска. */
    fun imageMatrix(l: Layer): ColorMatrix {
        val cm = ColorMatrix()
        if (l.imgColorize > 0.001f) {
            // Перекраска: яркость сохраняется, цвет заменяется выбранным (дуотон тёмный → цвет → светлый).
            val r = Color.red(l.imgColorizeColor) / 255f
            val g = Color.green(l.imgColorizeColor) / 255f
            val b = Color.blue(l.imgColorizeColor) / 255f
            val lum = floatArrayOf(0.299f, 0.587f, 0.114f)
            val full = ColorMatrix(floatArrayOf(
                lum[0] * r * 2f, lum[1] * r * 2f, lum[2] * r * 2f, 0f, 0f,
                lum[0] * g * 2f, lum[1] * g * 2f, lum[2] * g * 2f, 0f, 0f,
                lum[0] * b * 2f, lum[1] * b * 2f, lum[2] * b * 2f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))
            val k = l.imgColorize.coerceIn(0f, 1f)
            val id = ColorMatrix().array
            val mix = FloatArray(20) { id[it] * (1f - k) + full.array[it] * k }
            cm.set(mix)
        }
        if (abs(l.imgHue) > 0.5f) cm.postConcat(hueMatrix(l.imgHue))
        if (abs(l.imgSat - 1f) > 0.001f) cm.postConcat(ColorMatrix().apply { setSaturation(l.imgSat.coerceIn(0f, 2.5f)) })
        val c = l.imgContrast.coerceIn(0.5f, 1.8f)
        val t = 128f * (1f - c) + l.imgBright.coerceIn(-0.6f, 0.6f) * 255f
        val tw = l.imgTemp.coerceIn(-1f, 1f) * 40f
        cm.postConcat(ColorMatrix(floatArrayOf(
            c, 0f, 0f, 0f, t + tw,
            0f, c, 0f, 0f, t + tw * 0.1f,
            0f, 0f, c, 0f, t - tw,
            0f, 0f, 0f, 1f, 0f
        )))
        return cm
    }

    /** Поворот оттенка на [deg] градусов (сохраняет яркость). */
    private fun hueMatrix(deg: Float): ColorMatrix {
        val a = Math.toRadians(deg.toDouble())
        val cs = kotlin.math.cos(a).toFloat()
        val sn = kotlin.math.sin(a).toFloat()
        val lr = 0.213f; val lg = 0.715f; val lb = 0.072f
        return ColorMatrix(floatArrayOf(
            lr + cs * (1 - lr) + sn * (-lr), lg + cs * (-lg) + sn * (-lg), lb + cs * (-lb) + sn * (1 - lb), 0f, 0f,
            lr + cs * (-lr) + sn * 0.143f, lg + cs * (1 - lg) + sn * 0.140f, lb + cs * (-lb) + sn * (-0.283f), 0f, 0f,
            lr + cs * (-lr) + sn * (-(1 - lr)), lg + cs * (-lg) + sn * lg, lb + cs * (1 - lb) + sn * lb, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    /** Области, к которым применяются оверлеи: весь разворот или (для трея) лицо и трей отдельно. */
    private fun areas(places: List<Place>, ox: Float, oy: Float, ppm: Float, tray: Boolean): List<RectF> {
        fun union(list: List<Place>): RectF? {
            if (list.isEmpty()) return null
            return RectF(
                (ox + list.minOf { it.x }) * ppm, (oy + list.minOf { it.y }) * ppm,
                (ox + list.maxOf { it.x + it.w }) * ppm, (oy + list.maxOf { it.y + it.h }) * ppm
            )
        }
        return if (tray) {
            listOfNotNull(union(places.filter { it.id == PanelId.FRONT }), union(places.filter { it.id != PanelId.FRONT }))
        } else listOfNotNull(union(places))
    }

    fun drawOverlays(c: Canvas, fx: Fx, places: List<Place>, ox: Float, oy: Float, ppm: Float, tray: Boolean) {
        val areas = areas(places, ox, oy, ppm, tray)

        if (fx.tintAmount > 0.001f) {
            val p = Paint().apply {
                color = fx.tint
                alpha = (fx.tintAmount.coerceIn(0f, 1f) * 255f).roundToInt()
                xfermode = PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
            }
            for (r in areas) c.drawRect(r, p)
        }

        if (fx.vignette > 0.001f) {
            for (pl in places) {
                if (pl.id == PanelId.SPINE || pl.id == PanelId.DISC) continue
                val r = RectF((ox + pl.x) * ppm, (oy + pl.y) * ppm, (ox + pl.x + pl.w) * ppm, (oy + pl.y + pl.h) * ppm)
                vignette(c, r, fx.vignette)
            }
        }

        if (fx.snow > 0.001f) for (r in areas) snow(c, r, fx, ppm)

        if (fx.grain > 0.001f) {
            val tile = grainTile ?: makeGrain().also { grainTile = it }
            val sh = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
            val s = maxOf(1f, ppm * 0.12f)
            sh.setLocalMatrix(Matrix().apply { setScale(s, s) })
            val p = Paint().apply {
                shader = sh
                alpha = (fx.grain.coerceIn(0f, 1f) * 0.32f * 255f).roundToInt()
            }
            for (r in areas) c.drawRect(r, p)
        }
    }

    private fun vignette(c: Canvas, r: RectF, amount: Float) {
        val a = amount.coerceIn(0f, 1f)
        val colors = intArrayOf(
            0x00000000, 0x00000000,
            Color.argb((255f * a * 0.55f).roundToInt(), 0, 0, 0),
            Color.argb((255f * a * 0.92f).roundToInt(), 0, 0, 0)
        )
        val stops = floatArrayOf(0f, 0.45f, 0.8f, 1f)
        val shader = RadialGradient(0f, 0f, 1f, colors, stops, Shader.TileMode.CLAMP)
        shader.setLocalMatrix(Matrix().apply {
            setScale(r.width() * 0.72f, r.height() * 0.72f)
            postTranslate(r.centerX(), r.centerY())
        })
        val p = Paint().apply { this.shader = shader }
        c.save()
        c.clipRect(r)
        c.drawRect(r, p)
        c.restore()
    }

    /** Снегопад: короткие штрихи под углом ветра; положения детерминированы, поэтому превью и экспорт совпадают. */
    private fun snow(c: Canvas, r: RectF, fx: Fx, ppm: Float) {
        val rnd = java.util.Random(fx.snowSeed.toLong())
        val areaMm2 = r.width() * r.height() / (ppm * ppm)
        val count = (areaMm2 * 0.035f * fx.snow).toInt().coerceIn(0, 4500)
        var dx = -(0.3f + fx.snowWind * 1.2f)
        var dy = 0.6f
        val norm = sqrt(dx * dx + dy * dy)
        dx /= norm; dy /= norm
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        c.save()
        c.clipRect(r)
        for (i in 0 until count) {
            val x = r.left + rnd.nextFloat() * r.width()
            val y = r.top + rnd.nextFloat() * r.height()
            val depth = rnd.nextFloat()
            val d2 = depth * depth
            val radius = (0.10f + d2 * 0.85f) * ppm
            val len = radius * (1.5f + fx.snowWind * 5f) * (0.6f + rnd.nextFloat() * 0.8f)
            val a = (40f + d2 * 215f).roundToInt().coerceIn(0, 255)
            if (d2 > 0.6f) {
                p.alpha = a / 4
                p.strokeWidth = radius * 4.2f
                c.drawLine(x, y, x + dx * len, y + dy * len, p)
            }
            p.alpha = a
            p.strokeWidth = radius * 2f
            c.drawLine(x, y, x + dx * len, y + dy * len, p)
        }
        c.restore()
    }

    private fun makeGrain(): Bitmap {
        val n = 128
        val rnd = java.util.Random(99)
        val px = IntArray(n * n) {
            val v = rnd.nextInt(256)
            if (rnd.nextBoolean()) Color.argb(v, 255, 255, 255) else Color.argb(v, 0, 0, 0)
        }
        return Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }
}
