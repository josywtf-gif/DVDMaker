package com.dvdmaker.app

import android.graphics.Bitmap
import android.util.LruCache

/**
 * Контур вырезанного PNG-объекта (marching squares по альфа-каналу уменьшенной копии).
 * Результат — отрезки [x1, y1, x2, y2, ...] в долях картинки, от -0.5 до 0.5 относительно центра.
 */
object ObjectOutline {
    private val cache = LruCache<String, FloatArray>(64)

    fun get(path: String, src: Bitmap): FloatArray? {
        cache.get(path)?.let { return if (it.isEmpty()) null else it }
        val k = minOf(1f, 220f / maxOf(src.width, src.height))
        val sw = (src.width * k).toInt().coerceAtLeast(2)
        val sh = (src.height * k).toInt().coerceAtLeast(2)
        val small = if (k < 1f) Bitmap.createScaledBitmap(src, sw, sh, true) else src
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (small !== src) small.recycle()
        // Сетка с пустой рамкой в 1 пиксель, чтобы контур всегда замыкался.
        val gw = sw + 2
        val gh = sh + 2
        val g = FloatArray(gw * gh)
        for (y in 0 until sh) for (x in 0 until sw) g[(y + 1) * gw + x + 1] = (px[y * sw + x] ushr 24) / 255f
        val t = 0.5f
        val out = ArrayList<Float>()
        fun lerp(a: Float, b: Float): Float = if (a == b) 0.5f else ((t - a) / (b - a)).coerceIn(0f, 1f)
        for (y in 0 until gh - 1) for (x in 0 until gw - 1) {
            val tl = g[y * gw + x]; val tr = g[y * gw + x + 1]
            val br = g[(y + 1) * gw + x + 1]; val bl = g[(y + 1) * gw + x]
            val idx = (if (tl >= t) 1 else 0) or (if (tr >= t) 2 else 0) or (if (br >= t) 4 else 0) or (if (bl >= t) 8 else 0)
            if (idx == 0 || idx == 15) continue
            // точки на рёбрах клетки (в координатах сетки)
            val topX = x + lerp(tl, tr); val topY = y.toFloat()
            val rightX = (x + 1).toFloat(); val rightY = y + lerp(tr, br)
            val botX = x + lerp(bl, br); val botY = (y + 1).toFloat()
            val leftX = x.toFloat(); val leftY = y + lerp(tl, bl)
            fun seg(ax: Float, ay: Float, bx: Float, by: Float) {
                out.add((ax - 0.5f) / sw - 0.5f); out.add((ay - 0.5f) / sh - 0.5f)
                out.add((bx - 0.5f) / sw - 0.5f); out.add((by - 0.5f) / sh - 0.5f)
            }
            when (idx) {
                1, 14 -> seg(leftX, leftY, topX, topY)
                2, 13 -> seg(topX, topY, rightX, rightY)
                3, 12 -> seg(leftX, leftY, rightX, rightY)
                4, 11 -> seg(rightX, rightY, botX, botY)
                5 -> { seg(leftX, leftY, topX, topY); seg(rightX, rightY, botX, botY) }
                6, 9 -> seg(topX, topY, botX, botY)
                7, 8 -> seg(leftX, leftY, botX, botY)
                10 -> { seg(topX, topY, rightX, rightY); seg(leftX, leftY, botX, botY) }
            }
        }
        val arr = out.toFloatArray()
        cache.put(path, arr)
        return if (arr.isEmpty()) null else arr
    }
}
