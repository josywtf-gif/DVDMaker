package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Shader
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt

/** Материалы заливки букв: 0–4 и 9–14 — градиенты, 5–8 и 15–18 — процедурные текстуры. */
val TextMaterialNames = listOf(
    "Обычный", "Золото", "Серебро", "Лёд", "Обсидиан",
    "Мороз с трещинами", "Камень", "Ржавчина", "Лава",
    "Хром", "Бронза", "Ретро-неон", "Закат 80-х", "Огонь", "Кислота",
    "Кровь", "Сталь шлифованная", "Космос", "Мрамор"
)

/**
 * Процедурные бесшовные текстуры для заливки букв (без внешних файлов).
 * Основа: периодический value-noise + ячейки Вороного, из границ которых получаются трещины.
 */
object TextTextures {
    private const val N = 256
    private val cache = ConcurrentHashMap<Int, Bitmap>()

    /** Шейдер текстуры; один тайл покрывает примерно три кегля, поэтому узор не «ползёт» при смене размера. */
    fun shader(material: Int, sizePx: Float): Shader {
        val bmp = cache.getOrPut(material) { generate(material) }
        val sh = BitmapShader(bmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        val s = (sizePx * 3.2f / N).coerceAtLeast(0.05f)
        sh.setLocalMatrix(Matrix().apply { setScale(s, s) })
        return sh
    }

    /** Вертикальные градиенты для «киношных» букв: хром с горизонтом, бронза, ретро-неон, закат, огонь, кислота. */
    fun gradient(material: Int): Pair<IntArray, FloatArray> = when (material) {
        9 -> intArrayOf(Color.rgb(24, 48, 110), Color.rgb(120, 172, 232), Color.rgb(246, 250, 255), Color.rgb(255, 255, 255),
            Color.rgb(46, 34, 30), Color.rgb(150, 98, 56), Color.rgb(246, 210, 150)) to
            floatArrayOf(0f, 0.30f, 0.47f, 0.50f, 0.52f, 0.76f, 1f)
        10 -> intArrayOf(Color.rgb(70, 36, 12), Color.rgb(205, 127, 50), Color.rgb(255, 214, 150), Color.rgb(160, 90, 30), Color.rgb(92, 48, 16)) to
            floatArrayOf(0f, 0.28f, 0.48f, 0.74f, 1f)
        11 -> intArrayOf(Color.rgb(255, 80, 200), Color.rgb(190, 70, 255), Color.rgb(70, 140, 255), Color.rgb(90, 240, 255)) to
            floatArrayOf(0f, 0.38f, 0.72f, 1f)
        12 -> intArrayOf(Color.rgb(255, 238, 120), Color.rgb(255, 160, 40), Color.rgb(255, 60, 110), Color.rgb(140, 30, 170)) to
            floatArrayOf(0f, 0.34f, 0.70f, 1f)
        13 -> intArrayOf(Color.rgb(90, 8, 4), Color.rgb(220, 40, 10), Color.rgb(255, 150, 30), Color.rgb(255, 238, 140)) to
            floatArrayOf(0f, 0.38f, 0.74f, 1f)
        else -> intArrayOf(Color.rgb(230, 255, 90), Color.rgb(110, 230, 40), Color.rgb(20, 130, 40), Color.rgb(8, 52, 24)) to
            floatArrayOf(0f, 0.32f, 0.68f, 1f)
    }

    private fun smooth(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }

    private fun lerp(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        )
    }

    /** Периодический value-noise: решётка cells×cells заворачивается по краям. */
    private fun valueNoise(lat: FloatArray, cells: Int, fx: Float, fy: Float): Float {
        val x0 = floor(fx).toInt()
        val y0 = floor(fy).toInt()
        val tx = smooth(fx - x0)
        val ty = smooth(fy - y0)
        fun at(ix: Int, iy: Int): Float =
            lat[((iy % cells + cells) % cells) * cells + ((ix % cells + cells) % cells)]
        val a = at(x0, y0)
        val b = at(x0 + 1, y0)
        val c = at(x0, y0 + 1)
        val d = at(x0 + 1, y0 + 1)
        val top = a + (b - a) * tx
        val bottom = c + (d - c) * tx
        return top + (bottom - top) * ty
    }

    private fun generate(material: Int): Bitmap {
        val rnd = java.util.Random(1000L + material)
        val octaves = intArrayOf(4, 8, 16, 32)
        val weights = floatArrayOf(0.50f, 0.27f, 0.15f, 0.08f)
        val lattices = octaves.map { cells -> FloatArray(cells * cells) { rnd.nextFloat() } }
        val fine = FloatArray(64 * 64) { rnd.nextFloat() }

        val g = 7
        val pts = FloatArray(g * g * 2) { rnd.nextFloat() }

        val px = IntArray(N * N)
        for (y in 0 until N) for (x in 0 until N) {
            val u0 = x.toFloat() / N
            val v0 = y.toFloat() / N
            var fbm = 0f
            for (i in octaves.indices) {
                fbm += valueNoise(lattices[i], octaves[i], u0 * octaves[i], v0 * octaves[i]) * weights[i]
            }
            val speck = valueNoise(fine, 64, u0 * 64f, v0 * 64f)

            // Ячейки Вороного с «дрожанием» координат: трещины получаются рваными, а не прямыми.
            val u = u0 * g + (fbm - 0.5f) * 0.55f
            val v = v0 * g + (fbm - 0.5f) * 0.55f
            val cx = floor(u).toInt()
            val cy = floor(v).toInt()
            var f1 = 9f
            var f2 = 9f
            for (j in -1..1) for (i in -1..1) {
                val gx = cx + i
                val gy = cy + j
                val wx = (gx % g + g) % g
                val wy = (gy % g + g) % g
                val dx = gx + pts[(wy * g + wx) * 2] - u
                val dy = gy + pts[(wy * g + wx) * 2 + 1] - v
                val d = sqrt(dx * dx + dy * dy)
                if (d < f1) { f2 = f1; f1 = d } else if (d < f2) f2 = d
            }
            val crack = 1f - smooth((f2 - f1) / 0.09f)
            val t = ((fbm - 0.25f) / 0.55f).coerceIn(0f, 1f)

            px[y * N + x] = when (material) {
                5 -> {
                    var c = lerp(Color.rgb(62, 118, 182), Color.rgb(238, 248, 255), smooth(t + 0.3f))
                    if (speck > 0.72f) c = lerp(c, Color.WHITE, (speck - 0.72f) * 3f)
                    lerp(c, Color.rgb(16, 48, 104), crack * 0.92f)
                }
                6 -> {
                    val gv = 70 + (t * 110f).toInt() + ((speck - 0.5f) * 40f).toInt()
                    val c = Color.rgb(gv.coerceIn(0, 255), gv.coerceIn(0, 255), (gv + 6).coerceIn(0, 255))
                    lerp(c, Color.rgb(14, 14, 16), crack * 0.9f)
                }
                7 -> {
                    var c = lerp(Color.rgb(88, 36, 16), Color.rgb(208, 116, 52), smooth(t))
                    if (speck > 0.68f) c = lerp(c, Color.rgb(40, 16, 8), (speck - 0.68f) * 2.6f)
                    lerp(c, Color.rgb(30, 12, 6), crack * 0.8f)
                }
                15 -> {
                    // кровь: тёмные сгустки, глянцевые блики
                    var c = lerp(Color.rgb(62, 0, 2), Color.rgb(176, 8, 14), smooth(t + 0.1f))
                    if (speck > 0.72f) c = lerp(c, Color.rgb(30, 0, 0), (speck - 0.72f) * 3f)
                    lerp(c, Color.rgb(238, 70, 58), smooth((fbm - 0.6f) * 7f) * 0.55f)
                }
                16 -> {
                    // шлифованная сталь: горизонтальные штрихи и блик
                    val streak = valueNoise(fine, 64, u0 * 3f, v0 * 64f)
                    val sheen = 0.5f + 0.5f * sin(u0 * 2f * PI.toFloat() * 2f + fbm * 3f)
                    val gv = (120 + (streak - 0.5f) * 90f + sheen * 70f + (fbm - 0.5f) * 30f).toInt().coerceIn(0, 255)
                    Color.rgb(gv, (gv + 3).coerceAtMost(255), (gv + 9).coerceAtMost(255))
                }
                17 -> {
                    // космос: туманность и звёзды
                    val n2 = valueNoise(lattices[2], 16, u0 * 16f + 3.1f, v0 * 16f)
                    var c = lerp(Color.rgb(6, 4, 26), Color.rgb(96, 44, 160), smooth(t))
                    c = lerp(c, Color.rgb(34, 128, 200), smooth((n2 - 0.45f) * 3f) * 0.75f)
                    if (speck > 0.85f) c = lerp(c, Color.WHITE, ((speck - 0.85f) * 7f).coerceIn(0f, 1f))
                    c
                }
                18 -> {
                    // белый мрамор с тёмными прожилками
                    val ph = (u0 + v0) * 2f * PI.toFloat() * 2f + fbm * 10f
                    val vein = 1f - smooth(abs(sin(ph)) * 7f)
                    val fineV = 1f - smooth(abs(sin(ph * 3f + speck * 4f)) * 10f)
                    val base = lerp(Color.rgb(228, 228, 232), Color.rgb(252, 252, 253), speck)
                    lerp(lerp(base, Color.rgb(58, 60, 70), vein * 0.9f), Color.rgb(110, 112, 124), fineV * 0.35f)
                }
                else -> {
                    val c = lerp(Color.rgb(18, 14, 14), Color.rgb(66, 44, 38), smooth(t))
                    val glow = lerp(c, Color.rgb(255, 128, 24), crack)
                    if (crack > 0.82f) lerp(glow, Color.rgb(255, 232, 130), (crack - 0.82f) * 5f) else glow
                }
            }
        }
        return Bitmap.createBitmap(px, N, N, Bitmap.Config.ARGB_8888)
    }
}
