package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import androidx.core.graphics.ColorUtils
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

object Fonts {
    class Entry(val name: String, val sys: Int, val file: String)

    private val sysFam = listOf(
        "sans-serif-medium", "sans-serif-black", "sans-serif-condensed", "sans-serif-light",
        "serif", "cursive", "casual", "monospace"
    )
    private val sysNames = listOf("Классика", "Жирный", "Узкий", "Тонкий", "Засечки", "Рукопись", "Casual", "Моно")
    // системные шрифты с кириллицей (cursive/casual без неё — оставлены только как запасные)
    private val shown = listOf(0, 1, 2, 3, 4, 7)

    var entries: List<Entry> = shown.map { Entry(sysNames[it], it, "") }
        private set
    private var assets: android.content.res.AssetManager? = null
    private val cache = HashMap<String, Typeface>()

    fun init(am: android.content.res.AssetManager) {
        assets = am
        val files = runCatching { am.list("fonts")?.toList() }.getOrNull().orEmpty()
            .filter { it.endsWith(".ttf") || it.endsWith(".otf") }.sorted()
        entries = shown.map { Entry(sysNames[it], it, "") } +
            files.map { Entry(it.substringBeforeLast('.').replace('_', ' '), 0, it) }
        cache.clear()
    }

    fun get(sys: Int, file: String, italic: Boolean): Typeface = cache.getOrPut("$sys|$file|$italic") {
        val fromAsset = if (file.isNotEmpty()) runCatching { Typeface.createFromAsset(assets, "fonts/$file") }.getOrNull() else null
        val base = fromAsset ?: Typeface.create(sysFam[sys.coerceIn(0, sysFam.lastIndex)], Typeface.NORMAL)
        Typeface.create(base, if (italic) Typeface.ITALIC else Typeface.NORMAL)
    }
}

object Bitmaps {
    private val cache = object : LruCache<String, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(path: String): Bitmap? {
        cache.get(path)?.let { return it }
        if (path.isEmpty() || !File(path).exists()) return null
        val b = android.graphics.BitmapFactory.decodeFile(path) ?: return null
        cache.put(path, b)
        return b
    }
}

object SymbolAssets {
    var bluray: Bitmap? = null
    fun init(am: android.content.res.AssetManager) {
        bluray = runCatching { am.open("symbols_bluray.png").use { BitmapFactory.decodeStream(it) } }.getOrNull()
    }
}

private fun textLayout(l: Layer, ppm: Float): StaticLayout {
    val size = (l.sizeMm * ppm).coerceAtLeast(1f)
    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = l.color
        textSize = size
        typeface = Fonts.get(l.font, l.fontFile, l.italic)
        letterSpacing = l.spacing
        if (l.shadow) setShadowLayer(size * 0.08f, 0f, size * 0.05f, 0xB0000000.toInt())
    }
    val raw = if (l.upper) l.text.uppercase() else l.text
    val s = if (raw.isEmpty()) " " else raw
    val width = if (l.boxMm > 0f) {
        (l.boxMm * ppm).toInt().coerceAtLeast(1)
    } else {
        var m = 1f
        for (line in s.split("\n")) m = maxOf(m, tp.measureText(line))
        ceil(m).toInt() + ceil(size * 0.15f).toInt() + 1
    }
    val align = when (l.align) {
        0 -> Layout.Alignment.ALIGN_NORMAL
        2 -> Layout.Alignment.ALIGN_OPPOSITE
        else -> Layout.Alignment.ALIGN_CENTER
    }
    return StaticLayout.Builder.obtain(s, 0, s.length, tp, width)
        .setAlignment(align)
        .setLineSpacing(0f, 1.08f)
        .setIncludePad(false)
        .build()
}

fun layerSize(l: Layer, ppm: Float): Pair<Float, Float> = when (l.kind) {
    Kind.TEXT -> textLayout(l, ppm).let { it.width.toFloat() to it.height.toFloat() }
    Kind.RECT -> (l.widthMm * ppm) to (l.sizeMm * ppm)
    Kind.SYMBOL -> (l.widthMm * ppm) to (l.widthMm * ppm * 0.527f)
    Kind.IMAGE -> {
        val b = Bitmaps.get(l.path)
        val w = l.widthMm * ppm
        w to (if (b != null) w * b.height / b.width else w)
    }
}

fun drawLayer(c: Canvas, l: Layer, w: Float, h: Float, ppm: Float) {
    c.save()
    c.translate(l.x * w, l.y * h)
    c.rotate(l.rot)
    when (l.kind) {
        Kind.TEXT -> {
            val sl = textLayout(l, ppm)
            c.translate(-sl.width / 2f, -sl.height / 2f)
            sl.draw(c)
        }
        Kind.SYMBOL -> drawSpecialMark(c, l, ppm)
        Kind.RECT -> {
            val rw = l.widthMm * ppm
            val rh = l.sizeMm * ppm
            val rp = Paint(Paint.ANTI_ALIAS_FLAG)
            rp.color = l.color
            rp.alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
            c.drawRect(-rw / 2, -rh / 2, rw / 2, rh / 2, rp)
        }
        Kind.IMAGE -> {
            val b = Bitmaps.get(l.path)
            if (b != null) {
                val bw = l.widthMm * ppm
                val bh = bw * b.height / b.width
                val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
                p.alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
                c.drawBitmap(b, null, RectF(-bw / 2, -bh / 2, bw / 2, bh / 2), p)
            }
        }
    }
    c.restore()
}

/** Логотипы рисуются графикой, а не системным шрифтом. */
private fun drawSpecialMark(c: Canvas, l: Layer, ppm: Float) {
    val w = l.widthMm * ppm
    val h = w * 0.527f
    val color = l.color
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
        style = Paint.Style.FILL
    }
    c.save()
    c.translate(-w / 2f, -h / 2f)
    c.scale(w / 872f, h / 459f)
    val key = l.text.uppercase()
    if (key == "BLURAY") {
        val logo = SymbolAssets.bluray
        if (logo != null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = paint.alpha
                colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
            }
            c.drawBitmap(logo!!, null, RectF(0f, 0f, 872f, 459f), p)
        } else {
            // Safe fallback: recognizable disc + orbital sweep, entirely vector.
            val path = android.graphics.Path().apply {
                moveTo(18f, 42f); cubicTo(245f, -12f, 708f, 0f, 842f, 185f)
                cubicTo(922f, 300f, 760f, 442f, 275f, 450f)
                cubicTo(620f, 405f, 765f, 320f, 710f, 205f)
                cubicTo(640f, 60f, 260f, 30f, 18f, 42f); close()
            }
            c.drawPath(path, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 38f
            c.drawOval(120f, 150f, 560f, 315f, paint)
        }
    } else {
        // Each mark is assembled from vector geometry; no text glyphs are used.
        val stroke = Paint(paint).apply { style = Paint.Style.STROKE; strokeWidth = 34f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        when (key) {
            "DVD" -> {
                c.drawOval(25f, 60f, 300f, 335f, stroke); c.drawCircle(162f, 197f, 35f, paint)
                val p = android.graphics.Path().apply { moveTo(340f,90f); lineTo(470f,90f); lineTo(420f,300f); lineTo(315f,300f); close(); moveTo(510f,90f); lineTo(650f,90f); lineTo(600f,300f); lineTo(480f,300f); close() }
                c.drawPath(p, paint); c.drawLine(675f,100f,825f,100f,stroke); c.drawLine(675f,195f,790f,195f,stroke); c.drawLine(675f,290f,755f,290f,stroke)
            }
            "CD" -> { c.drawCircle(430f, 225f, 175f, stroke); c.drawCircle(430f,225f,34f,paint); for (a in 0..7) { val r= Math.toRadians(a*45.0); c.drawLine(430f,225f,(430+150*kotlin.math.cos(r)).toFloat(),(225+150*kotlin.math.sin(r)).toFloat(), Paint(stroke).apply { strokeWidth=9f }) } }
            "HIRES" -> { c.drawCircle(180f,210f,110f,stroke); c.drawLine(90f,210f,270f,210f,stroke); c.drawLine(180f,120f,180f,300f,stroke); for(i in 0..5) c.drawLine(360f+i*75f,280f,360f+i*75f, (230-i*28).toFloat(),stroke) }
            "DOLBY", "ATMOS" -> { c.drawArc(60f,70f,400f,390f,-90f,180f,false,stroke); c.drawArc(250f,70f,590f,390f,90f,180f,false,stroke); c.drawLine(430f,100f,430f,360f,stroke); c.drawLine(650f,100f,650f,360f,stroke) }
            "DTS", "DTSHD" -> { for(i in 0..4) { val x=70f+i*155f; c.drawRoundRect(x,95f,x+95f,345f,24f,24f,paint) }; c.drawLine(55f,385f,820f,385f,stroke) }
            "4K", "HDR", "THX", "STEREO", "169", "1080P", "2160P" -> {
                val path=android.graphics.Path().apply { moveTo(75f,95f); lineTo(795f,95f); lineTo(795f,365f); lineTo(75f,365f); close() }
                c.drawPath(path,stroke); c.drawLine(160f,230f,710f,230f,stroke); c.drawCircle(435f,230f,58f,paint)
            }
            else -> { c.drawCircle(436f,230f,165f,stroke); c.drawLine(180f,230f,692f,230f,stroke) }
        }
    }
    c.restore()
}

fun drawPanel(c: Canvas, p: PanelData, w: Float, h: Float, ppm: Float) {
    val bg = Paint()
    if (p.c1 == p.c2) {
        bg.color = p.c1
    } else {
        val rad = Math.toRadians(p.angle.toDouble())
        val dx = cos(rad).toFloat()
        val dy = sin(rad).toFloat()
        val half = (abs(w * dx) + abs(h * dy)) / 2f
        bg.shader = LinearGradient(
            w / 2 - dx * half, h / 2 - dy * half, w / 2 + dx * half, h / 2 + dy * half,
            p.c1, p.c2, Shader.TileMode.CLAMP
        )
    }
    c.drawRect(0f, 0f, w, h, bg)
    drawPanelLayers(c, p, w, h, ppm)
}

private fun drawPanelLayers(c: Canvas, p: PanelData, w: Float, h: Float, ppm: Float) {
    for (l in p.layers) {
        if (l.kind == Kind.SYMBOL) {
            val under = samplePanelEdge(p.copy(layers = p.layers.takeWhile { it.id != l.id }), w, h, l.x * w, l.y * h)
            val luminance = (0.299 * Color.red(under) + 0.587 * Color.green(under) + 0.114 * Color.blue(under))
            val autoColor = if (luminance > 145.0) android.graphics.Color.BLACK else android.graphics.Color.WHITE
            drawLayer(c, l.copy(color = autoColor), w, h, ppm)
        } else drawLayer(c, l, w, h, ppm)
    }
}

fun colorAt(p: PanelData, w: Float, h: Float, x: Float, y: Float): Int {
    if (p.c1 == p.c2) return p.c1
    val rad = Math.toRadians(p.angle.toDouble())
    val dx = cos(rad).toFloat()
    val dy = sin(rad).toFloat()
    val half = (abs(w * dx) + abs(h * dy)) / 2f
    val t = if (half <= 0f) 0f else (((x - w / 2) * dx + (y - h / 2) * dy) / (2 * half) + 0.5f).coerceIn(0f, 1f)
    return ColorUtils.blendARGB(p.c1, p.c2, t)
}

/** Цвет фактического содержимого у края панели: учитывает фотографии и фигуры поверх градиента. */
fun samplePanelEdge(p: PanelData, w: Float, h: Float, x: Float, y: Float): Int {
    var result = colorAt(p, w, h, x, y)
    for (layer in p.layers) {
        val dx = x - layer.x * w
        val dy = y - layer.y * h
        val rad = Math.toRadians(-layer.rot.toDouble())
        val lx = (dx * kotlin.math.cos(rad) - dy * kotlin.math.sin(rad)).toFloat()
        val ly = (dx * kotlin.math.sin(rad) + dy * kotlin.math.cos(rad)).toFloat()
        when (layer.kind) {
            Kind.IMAGE -> {
                val bitmap = Bitmaps.get(layer.path) ?: continue
                val iw = layer.widthMm
                val ih = iw * bitmap.height / bitmap.width.toFloat()
                if (kotlin.math.abs(lx) <= iw / 2f && kotlin.math.abs(ly) <= ih / 2f) {
                    val bx = (((lx / iw) + 0.5f) * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
                    val by = (((ly / ih) + 0.5f) * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
                    result = ColorUtils.blendARGB(result, bitmap.getPixel(bx, by), layer.alpha.coerceIn(0f, 1f))
                }
            }
            Kind.RECT -> if (kotlin.math.abs(lx) <= layer.widthMm / 2f && kotlin.math.abs(ly) <= layer.sizeMm / 2f) {
                result = ColorUtils.blendARGB(result, layer.color, layer.alpha.coerceIn(0f, 1f))
            }
            Kind.TEXT, Kind.SYMBOL -> Unit
        }
    }
    return result
}

/** Фон корешка всегда подстраивается под соседние части: плавный переход оборот → корешок → лицо. */
fun effectivePanel(p: Project, id: PanelId, instance: Int = 0): PanelData {
    val pd = p.panel(id)
    if (id != PanelId.SPINE) return pd
    val f = p.format
    val back = p.panel(PanelId.BACK)
    val front = p.panel(PanelId.FRONT)
    // Сплошной цвет корешка (например, выбранный пипеткой) имеет приоритет.
    // Градиентный режим по умолчанию по-прежнему подбирает оттенки с соседних панелей.
    if (pd.c1 == pd.c2) return pd
    return if (!f.tray) {
        val backEdge = samplePanelEdge(back, f.backW, f.backH, f.backW, f.backH / 2)
        val frontEdge = samplePanelEdge(front, f.frontW, f.frontH, 0f, f.frontH / 2)
        val spineTone = colorAt(pd, f.spineW, f.backH, f.spineW / 2f, f.backH / 2f)
        // Края корешка получают точные цвета соседних панелей: на стыке нет цветового скачка.
        pd.copy(c1 = backEdge, c2 = frontEdge, angle = 0)
    } else {
        val edge = if (instance == 0) samplePanelEdge(back, f.backW, f.backH, 0f, f.backH / 2)
        else samplePanelEdge(back, f.backW, f.backH, f.backW, f.backH / 2)
        val spineTone = colorAt(pd, f.spineW, f.backH, f.spineW / 2f, f.backH / 2f)
        pd.copy(c1 = edge, c2 = edge)
    }
}

/** Тень на сгибе: на корешке {@link SHADOW_SPINE_MM} мм от края внутрь, на обложке {@link SHADOW_COVER_MM} мм наружу. */
const val SHADOW_SPINE_MM = 1f
const val SHADOW_COVER_MM = 2f
const val SHADOW_ALPHA = 0.6f

/** Тёмная полоса, самая тёмная у линии сгиба [edgeX] и плавно гаснущая на [widthPx] в сторону [dir] (+1 вправо, -1 влево). */
private fun drawFoldShadow(c: Canvas, edgeX: Float, widthPx: Float, dir: Int, h: Float) {
    if (widthPx <= 0f) return
    val n = 8
    val pos = FloatArray(n + 1) { it / n.toFloat() }
    val col = IntArray(n + 1) { i ->
        val t = i / n.toFloat()
        val k = (1f - t)
        Color.argb((255f * SHADOW_ALPHA * k * k).roundToInt(), 0, 0, 0)
    }
    val x2 = edgeX + dir * widthPx
    val paint = Paint().apply { shader = LinearGradient(edgeX, 0f, x2, 0f, col, pos, Shader.TileMode.CLAMP) }
    c.drawRect(minOf(edgeX, x2), 0f, maxOf(edgeX, x2), h, paint)
}

fun drawPanelIn(c: Canvas, p: Project, id: PanelId, instance: Int, w: Float, h: Float, ppm: Float, maskDisc: Boolean = false) {
    if (id == PanelId.DISC) {
        c.save()
        if (maskDisc) {
            val cx = w / 2f
            val cy = h / 2f
            val outer = android.graphics.Path().apply { addCircle(cx, cy, DISC_OUTER_MM * ppm / 2f, android.graphics.Path.Direction.CW) }
            val hole = android.graphics.Path().apply { addCircle(cx, cy, DISC_INNER_MM * ppm / 2f, android.graphics.Path.Direction.CW) }
            c.clipPath(outer)
            c.clipOutPath(hole)
        }
        drawPanel(c, p.panel(id), w, h, ppm)
        c.restore()
        return
    }
    val f = p.format
    // Фон и содержимое панели рисуются как есть — без размытия и подмешивания соседей.
    drawPanel(c, p.panel(id), w, h, ppm)
    if (!p.foldShadow || p.seamlessSpine()) return
    val cover = SHADOW_COVER_MM * ppm
    when (id) {
        PanelId.FRONT -> if (!f.tray) drawFoldShadow(c, 0f, cover, +1, h)
        PanelId.BACK -> if (!f.tray) drawFoldShadow(c, w, cover, -1, h) else {
            drawFoldShadow(c, 0f, cover, +1, h)
            drawFoldShadow(c, w, cover, -1, h)
        }
        PanelId.SPINE -> {
            val inner = minOf(SHADOW_SPINE_MM * ppm, w * 0.2f)
            if (!f.tray) {
                drawFoldShadow(c, 0f, inner, +1, h)
                drawFoldShadow(c, w, inner, -1, h)
            } else if (instance == 0) drawFoldShadow(c, w, inner, -1, h)   // справа — оборот
            else drawFoldShadow(c, 0f, inner, +1, h)                       // слева — оборот
        }
        PanelId.DISC -> Unit
    }
}

fun sheetSizeMm(p: Project, a4: Boolean, marks: Boolean, disc: Boolean = false): Pair<Float, Float> {
    val lay = if (disc) p.format.discLayout() else p.format.layout()
    if (a4) return 297f to 210f
    val m = if (marks) 8f else 0f
    return (lay.w + 2 * m) to (lay.h + 2 * m)
}

fun renderSheet(p: Project, ppm: Float, a4: Boolean, marks: Boolean, disc: Boolean = false): Bitmap {
    val lay = if (disc) p.format.discLayout() else p.format.layout()
    val (sw, sh) = sheetSizeMm(p, a4, marks, disc)
    val bmp = Bitmap.createBitmap((sw * ppm).roundToInt(), (sh * ppm).roundToInt(), Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(Color.WHITE)
    val ox = (sw - lay.w) / 2f
    val oy = (sh - lay.h) / 2f
    drawPlaces(c, p, lay.places, ox, oy, ppm, true)
    if (marks) {
        val mp = Paint().apply {
            color = Color.BLACK
            strokeWidth = maxOf(1f, 0.15f * ppm)
            style = Paint.Style.STROKE
        }
        val gap = 1.5f * ppm
        val len = 4f * ppm
        if (disc) {
            // Метки: четыре засечки снаружи круга и крестик в центре отверстия.
            val cx = (ox + DISC_SIZE_MM / 2f) * ppm
            val cy = (oy + DISC_SIZE_MM / 2f) * ppm
            val ro = DISC_OUTER_MM / 2f * ppm
            for ((dx, dy) in listOf(1f to 0f, -1f to 0f, 0f to 1f, 0f to -1f)) {
                c.drawLine(cx + dx * (ro + gap), cy + dy * (ro + gap), cx + dx * (ro + gap + len), cy + dy * (ro + gap + len), mp)
            }
            val cr = 2f * ppm
            c.drawLine(cx - cr, cy, cx + cr, cy, mp)
            c.drawLine(cx, cy - cr, cx, cy + cr, mp)
        }
        for (g in if (disc) emptyList() else lay.groups) {
            val x0 = (ox + g.x) * ppm
            val y0 = (oy + g.y) * ppm
            val x1 = x0 + g.w * ppm
            val y1 = y0 + g.h * ppm
            for ((cx, cy) in listOf(x0 to y0, x1 to y0, x0 to y1, x1 to y1)) {
                val sx = if (cx == x0) -1f else 1f
                val sy = if (cy == y0) -1f else 1f
                c.drawLine(cx + sx * gap, cy, cx + sx * (gap + len), cy, mp)
                c.drawLine(cx, cy + sy * gap, cx, cy + sy * (gap + len), mp)
            }
            for (f in g.folds) {
                val fx = x0 + f * ppm
                c.drawLine(fx, y0 - gap, fx, y0 - gap - len, mp)
                c.drawLine(fx, y1 + gap, fx, y1 + gap + len, mp)
            }
        }
    }
    return bmp
}

/** Корешок с плавным переходом «цвета с оборота и лица»: тень на сгибе отключается, стыка не видно. */
fun Project.seamlessSpine(): Boolean = panel(PanelId.SPINE).layers.any {
    it.kind == Kind.IMAGE && File(it.path).name.startsWith("spine-")
}

/** Рисует панели листа. Корешок с плавным переходом рисуется последним, а его растушёвка заходит на оборот и лицо: стыка не видно. */
fun drawPlaces(c: Canvas, p: Project, places: List<Place>, ox: Float, oy: Float, ppm: Float, maskDisc: Boolean) {
    val spineLayer = p.panel(PanelId.SPINE).layers.firstOrNull {
        it.kind == Kind.IMAGE && File(it.path).name.startsWith("spine-")
    }
    val ordered = places.filter { it.id != PanelId.SPINE } + places.filter { it.id == PanelId.SPINE }
    for (pl in ordered) {
        val w = pl.w * ppm
        val h = pl.h * ppm
        val inst = if (pl.id == PanelId.SPINE && pl.x > 0f) 1 else 0
        c.save()
        c.translate((ox + pl.x) * ppm, (oy + pl.y) * ppm)
        c.clipRect(0f, 0f, w, h)
        drawPanelIn(c, p, pl.id, inst, w, h, ppm, maskDisc)
        c.restore()
        if (pl.id == PanelId.SPINE && spineLayer != null) drawSpineFeather(c, p, spineLayer, pl, inst, ox, oy, ppm)
    }
}

/** Прозрачные края картинки корешка (имя файла spine-<fc>-<sw>-…) рисуются за границами корешка поверх соседних панелей. */
private fun drawSpineFeather(c: Canvas, p: Project, l: Layer, pl: Place, inst: Int, ox: Float, oy: Float, ppm: Float) {
    val parts = File(l.path).name.removePrefix("spine-").split("-")
    val fc = parts.getOrNull(0)?.toIntOrNull() ?: return
    val sw = parts.getOrNull(1)?.toIntOrNull() ?: return
    val bmp = Bitmaps.get(l.path) ?: return
    if (bmp.width != sw + 2 * fc || fc <= 0) return
    val w = pl.w * ppm
    val h = pl.h * ppm
    val fw = fc * w / sw
    val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    c.save()
    c.translate((ox + pl.x) * ppm, (oy + pl.y) * ppm)
    val tray = p.format.tray
    if (!(tray && inst == 0)) c.drawBitmap(bmp, android.graphics.Rect(0, 0, fc, bmp.height), RectF(-fw, 0f, 0f, h), paint)
    if (!(tray && inst == 1)) c.drawBitmap(bmp, android.graphics.Rect(fc + sw, 0, bmp.width, bmp.height), RectF(w, 0f, w + fw, h), paint)
    c.restore()
}
