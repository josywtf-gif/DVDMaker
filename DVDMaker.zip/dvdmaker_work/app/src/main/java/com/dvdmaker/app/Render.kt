package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.PorterDuffXfermode
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import androidx.core.graphics.ColorUtils
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

object Fonts {
    class Entry(val name: String, val sys: Int, val file: String)

    private val sysFam = listOf(
        "sans-serif-medium", "sans-serif-black", "sans-serif-condensed", "sans-serif-light",
        "serif", "cursive", "casual", "monospace"
    )
    private val sysNames = listOf("Классика", "Жирный", "Узкий", "Тонкий", "Засечки", "Рукопись", "Casual", "Моно")
    // системные шрифты с кириллицей (cursive/casual без неё — оставлены только как запасные)
    private val shown = listOf(0, 1, 2, 3, 4, 7)

    var entries: List<Entry> = shown.map { Entry(sysNames[it], it, "") }
        private set
    private var assets: android.content.res.AssetManager? = null
    private val cache = HashMap<String, Typeface>()

    fun init(am: android.content.res.AssetManager) {
        assets = am
        val files = runCatching { am.list("fonts")?.toList() }.getOrNull().orEmpty()
            .filter { it.endsWith(".ttf") || it.endsWith(".otf") }.sorted()
        entries = shown.map { Entry(sysNames[it], it, "") } +
            files.map { Entry(it.substringBeforeLast('.').replace('_', ' '), 0, it) }
        cache.clear()
    }

    fun get(sys: Int, file: String, italic: Boolean): Typeface = cache.getOrPut("$sys|$file|$italic") {
        val fromAsset = if (file.isNotEmpty()) runCatching { Typeface.createFromAsset(assets, "fonts/$file") }.getOrNull() else null
        val base = fromAsset ?: Typeface.create(sysFam[sys.coerceIn(0, sysFam.lastIndex)], Typeface.NORMAL)
        Typeface.create(base, if (italic) Typeface.ITALIC else Typeface.NORMAL)
    }
}

object Bitmaps {
    private val cache = object : LruCache<String, Bitmap>(96 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(path: String): Bitmap? {
        cache.get(path)?.let { return it }
        if (path.isEmpty() || !File(path).exists()) return null
        val b = android.graphics.BitmapFactory.decodeFile(path) ?: return null
        cache.put(path, b)
        return b
    }
}


/** Локальные процедурные текстуры для заливки букв; не требуют внешних файлов или сети. */
private object TextMaterialTextures {
    private val cache = HashMap<Int, Shader>()
    fun shader(material: Int): Shader = cache.getOrPut(material) {
        val w = 256; val h = 256
        val pixels = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val n = (sin(x * 0.071f + y * 0.037f) * 0.34f +
                sin(x * 0.023f - y * 0.061f) * 0.28f +
                sin(x * 0.137f + y * 0.119f) * 0.18f +
                sin(x * 0.011f + y * 0.017f) * 0.20f)
            val c = if (material == 5) {
                // Камень: холодная минеральная основа с тонкими светлыми прожилками.
                val vein = (sin((x * 0.075f + y * 0.041f) + sin(y * 0.027f) * 2.2f) > 0.965f)
                val v = (105 + n * 58 + if (vein) 82 else 0).toInt().coerceIn(35, 220)
                Color.rgb(v, (v * 1.02f).toInt().coerceIn(0,255), (v * 1.08f).toInt().coerceIn(0,255))
            } else {
                // Огонь: вертикальный переход от тёмно-красного к жёлто-оранжевому с языками пламени.
                val flame = (sin(x * 0.083f + sin(y * 0.035f) * 3f) + sin(x * 0.19f - y * 0.021f) * 0.35f)
                val t = (1f - y / (h - 1f) + flame * 0.17f + n * 0.12f).coerceIn(0f, 1f)
                val r = (115 + 140 * t).toInt().coerceIn(0,255)
                val g = (18 + 205 * t * t).toInt().coerceIn(0,255)
                val b = (3 + 38 * t * t * t).toInt().coerceIn(0,255)
                Color.rgb(r,g,b)
            }
            pixels[y * w + x] = c
        }
        BitmapShader(Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }
}

/** Небольшая детерминированная маска для органичного, негеометрического края. */
private object OrganicFadeMasks {
    private val cache = object : LruCache<String, Bitmap>(4 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(edges: Int, fadeFraction: Float): Bitmap {
        val fade = fadeFraction.coerceIn(0.01f, 0.45f)
        val key = "$edges|${(fade * 1000).roundToInt()}"
        cache.get(key)?.let { return it }
        val side = 256
        val pixels = IntArray(side * side)
        fun smooth(t0: Float): Float {
            val t = t0.coerceIn(0f, 1f)
            return t * t * (3f - 2f * t)
        }
        for (y in 0 until side) for (x in 0 until side) {
            val nx = x / (side - 1f)
            val ny = y / (side - 1f)
            // Многомасштабное возмущение ломает идеально прямую линию края,
            // но не создаёт заметного зерна внутри изображения.
            val noise = (kotlin.math.sin(x * 0.071f + y * 0.037f) * 0.55f +
                kotlin.math.sin(x * 0.023f - y * 0.061f) * 0.30f +
                kotlin.math.sin(x * 0.137f + y * 0.119f) * 0.15f)
            var alpha = 1f
            val edgeOffset = 0.045f + noise * 0.025f
            val transition = (fade - 0.045f).coerceAtLeast(0.01f)
            fun edgeAlpha(distance: Float) = smooth((distance - edgeOffset) / transition)
            if (edges and 1 != 0) alpha = minOf(alpha, edgeAlpha(nx))
            if (edges and 2 != 0) alpha = minOf(alpha, edgeAlpha(1f - nx))
            if (edges and 4 != 0) alpha = minOf(alpha, edgeAlpha(ny))
            if (edges and 8 != 0) alpha = minOf(alpha, edgeAlpha(1f - ny))
            val a = (alpha * 255f).roundToInt().coerceIn(0, 255)
            pixels[y * side + x] = (a shl 24) or 0x00FFFFFF
        }
        val bitmap = Bitmap.createBitmap(pixels, side, side, Bitmap.Config.ARGB_8888)
        cache.put(key, bitmap)
        return bitmap
    }
}

object SymbolAssets {
    var bluray: Bitmap? = null
    fun init(am: android.content.res.AssetManager) {
        bluray = runCatching { am.open("symbols_bluray.png").use { BitmapFactory.decodeStream(it) } }.getOrNull()
    }
}

private fun textLayout(l: Layer, ppm: Float, outline: Boolean = false, glow: Boolean = false, solidColor: Int? = null): StaticLayout {
    val size = (l.sizeMm * ppm).coerceAtLeast(1f)
    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = if (outline) l.textOutlineColor else if (glow) l.textGlowColor else l.color
        textSize = size
        if (outline) {
            style = Paint.Style.STROKE
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            strokeWidth = (size * l.textOutlineWidth).coerceAtLeast(0.1f) * 2f
        }
        if (glow) setShadowLayer(size * l.textGlowRadius, 0f, 0f, l.textGlowColor)
        if (!outline && !glow && solidColor == null && l.textMaterial in 1..6) {
            if (l.textMaterial >= 5) {
                shader = TextMaterialTextures.shader(l.textMaterial)
            } else {
            val stops = when (l.textMaterial) {
                1 -> intArrayOf(Color.rgb(92, 48, 10), Color.rgb(255, 224, 132), Color.rgb(184, 119, 28), Color.rgb(255, 241, 190), Color.rgb(105, 61, 15))
                2 -> intArrayOf(Color.rgb(55, 63, 74), Color.rgb(245, 249, 255), Color.rgb(132, 146, 164), Color.rgb(255, 255, 255), Color.rgb(75, 84, 98))
                3 -> intArrayOf(Color.rgb(12, 72, 115), Color.rgb(198, 245, 255), Color.rgb(66, 174, 220), Color.rgb(240, 255, 255), Color.rgb(24, 103, 157))
                else -> intArrayOf(Color.rgb(5, 7, 13), Color.rgb(105, 115, 132), Color.rgb(18, 23, 34), Color.rgb(155, 165, 180), Color.rgb(3, 5, 10))
            }
            shader = LinearGradient(0f, 0f, 0f, (size * 1.25f).coerceAtLeast(1f), stops, null, Shader.TileMode.CLAMP)
            }
        }
        typeface = Fonts.get(l.font, l.fontFile, l.italic)
        letterSpacing = l.spacing
        if (l.shadow) setShadowLayer(size * 0.08f, 0f, size * 0.05f, 0xB0000000.toInt())
    }
    val raw = if (l.upper) l.text.uppercase() else l.text
    val s = if (raw.isEmpty()) " " else raw
    val width = if (l.boxMm > 0f) {
        (l.boxMm * ppm).toInt().coerceAtLeast(1)
    } else {
        var m = 1f
        for (line in s.split("\n")) m = maxOf(m, tp.measureText(line))
        ceil(m).toInt() + ceil(size * 0.15f).toInt() + 1
    }
    val align = when (l.align) {
        0 -> Layout.Alignment.ALIGN_NORMAL
        2 -> Layout.Alignment.ALIGN_OPPOSITE
        else -> Layout.Alignment.ALIGN_CENTER
    }
    return StaticLayout.Builder.obtain(s, 0, s.length, tp, width)
        .setAlignment(align)
        .setLineSpacing(0f, 1.08f)
        .setIncludePad(false)
        .build()
}

fun layerSize(l: Layer, ppm: Float): Pair<Float, Float> = when (l.kind) {
    Kind.TEXT -> textLayout(l, ppm).let { it.width.toFloat() to it.height.toFloat() }
    Kind.RECT -> (l.widthMm * ppm) to (l.sizeMm * ppm)
    Kind.SYMBOL -> (l.widthMm * ppm) to (l.widthMm * ppm * 0.527f)
    Kind.IMAGE -> {
        val b = Bitmaps.get(l.path)
        val w = l.widthMm * ppm
        w to (if (b != null) w * b.height / b.width else w)
    }
}

fun drawLayer(c: Canvas, l: Layer, w: Float, h: Float, ppm: Float) {
    c.save()
    c.translate(l.x * w, l.y * h)
    c.rotate(l.rot)
    when (l.kind) {
        Kind.TEXT -> {
            val sl = textLayout(l, ppm)
            // Подложка рисуется под текстом; её мягкая тень создаёт регулируемый ореол/блюр.
            if (l.textShade > 0f || l.textBlur > 0) {
                val pad = (l.sizeMm * ppm * 0.22f).coerceAtLeast(2f)
                val r = RectF(-sl.width / 2f - pad, -sl.height / 2f - pad,
                    sl.width / 2f + pad, sl.height / 2f + pad)
                val blurRadius = when (l.textBlur) {
                    1 -> l.sizeMm * ppm * 0.18f
                    2 -> l.sizeMm * ppm * 0.38f
                    3 -> l.sizeMm * ppm * 0.65f
                    else -> 0f
                }
                if (blurRadius > 0f) {
                    val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.argb(1, 0, 0, 0)
                        setShadowLayer(blurRadius, 0f, 0f, 0x99000000.toInt())
                    }
                    c.drawRoundRect(r, pad * 0.35f, pad * 0.35f, halo)
                    halo.clearShadowLayer()
                }
                if (l.textShade > 0f) {
                    val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.argb((l.textShade.coerceIn(0f, 0.85f) * 255).roundToInt(), 0, 0, 0)
                    }
                    c.drawRoundRect(r, pad * 0.35f, pad * 0.35f, bg)
                }
            }
            c.save()
            c.translate(-sl.width / 2f, -sl.height / 2f)
            // Псевдо-3D экструзия: несколько коротких смещённых проходов создают боковую грань букв.
            if (l.textExtrudeDepth > 0.001f) {
                val depth = (l.sizeMm * ppm * l.textExtrudeDepth).coerceAtLeast(1f)
                val steps = (depth / 2f).toInt().coerceIn(2, 24)
                val sideLayout = textLayout(l, ppm, solidColor = l.textExtrudeColor)
                for (step in steps downTo 1) {
                    val offset = depth * step / steps
                    c.save()
                    c.translate(offset * 0.55f, offset)
                    sideLayout.draw(c)
                    c.restore()
                }
            }
            if (l.textGlowRadius > 0.001f) textLayout(l, ppm, glow = true).draw(c)
            if (l.textOutlineWidth > 0.001f) textLayout(l, ppm, outline = true).draw(c)
            sl.draw(c)
            c.restore()
        }
        Kind.SYMBOL -> drawSpecialMark(c, l, ppm)
        Kind.RECT -> {
            val rw = l.widthMm * ppm
            val rh = l.sizeMm * ppm
            val rp = Paint(Paint.ANTI_ALIAS_FLAG)
            rp.color = l.color
            rp.alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
            c.drawRect(-rw / 2, -rh / 2, rw / 2, rh / 2, rp)
            if (l.atmosphereStyle in 1..4 && l.atmosphereIntensity > 0.001f) {
                drawAtmosphere(c, RectF(-rw / 2, -rh / 2, rw / 2, rh / 2), l)
            }
        }
        Kind.IMAGE -> {
            val b = Bitmaps.get(l.path)
            if (b != null) {
                val bw = l.widthMm * ppm
                val bh = bw * b.height / b.width
                val dst = RectF(-bw / 2, -bh / 2, bw / 2, bh / 2)
                val alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
                val photoPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply { this.alpha = alpha }

                // Мягкая тень рисуется под фото; старые проекты без параметров остаются без изменений.
                if (l.photoShadowBlur > 0.001f && l.photoShadowAlpha > 0.001f) {
                    val blur = (bw * l.photoShadowBlur.coerceIn(0f, 0.2f)).coerceAtLeast(1f)
                    val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = Color.BLACK
                        alpha = (l.photoShadowAlpha.coerceIn(0f, 1f) * 255f).roundToInt()
                        setShadowLayer(blur, 0f, bh * l.photoShadowOffsetY.coerceIn(-0.1f, 0.1f),
                            Color.argb(alpha, 0, 0, 0))
                    }
                    val shadowRect = RectF(dst)
                    when (l.photoShadowShape.coerceIn(0, 2)) {
                        0 -> c.drawRect(shadowRect, shadowPaint)
                        1 -> c.drawRoundRect(shadowRect, (bw * 0.035f).coerceAtLeast(1f), (bw * 0.035f).coerceAtLeast(1f), shadowPaint)
                        else -> c.drawOval(shadowRect, shadowPaint)
                    }
                    shadowPaint.clearShadowLayer()
                }

                // Цветное свечение рисуется под фотографией и не изменяет исходный bitmap.
                if (l.photoGlowRadius > 0.001f && l.photoGlowAlpha > 0.001f) {
                    val radius = (bw * l.photoGlowRadius.coerceIn(0f, 0.18f)).coerceAtLeast(1f)
                    val glowColor = l.photoGlowColor
                    val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                        color = glowColor
                        this.alpha = (l.photoGlowAlpha.coerceIn(0f, 1f) * 105f).roundToInt()
                        setShadowLayer(radius, 0f, 0f, android.graphics.Color.argb(
                            (l.photoGlowAlpha.coerceIn(0f, 1f) * 230f).roundToInt(),
                            android.graphics.Color.red(glowColor), android.graphics.Color.green(glowColor), android.graphics.Color.blue(glowColor)))
                    }
                    c.drawRect(dst, glowPaint)
                    glowPaint.clearShadowLayer()
                }

                // Геометрическая маска применяется только к фото; значение 0 полностью
                // сохраняет прежний прямоугольный рендеринг старых проектов.
                val hasImageMask = l.imageMaskShape != 0
                if (hasImageMask) {
                    val maskPath = android.graphics.Path().apply {
                        when (l.imageMaskShape.coerceIn(0, 2)) {
                            1 -> addRoundRect(dst, (minOf(dst.width(), dst.height()) * l.imageCornerRadius.coerceIn(0f, 0.5f)),
                                (minOf(dst.width(), dst.height()) * l.imageCornerRadius.coerceIn(0f, 0.5f)), android.graphics.Path.Direction.CW)
                            2 -> addOval(dst, android.graphics.Path.Direction.CW)
                        }
                    }
                    c.save()
                    c.clipPath(maskPath)
                }

                if (l.imageFade > 0.001f) {
                    // Маска должна перекрывать слой с запасом: иначе по антиалиасингу границы
                    // (особенно при повороте) остаётся тонкая светлая линия контура фото.
                    val big = RectF(dst).apply { inset(-4f, -4f) }
                    c.saveLayer(big, null)
                    c.drawBitmap(b, null, dst, photoPaint)

                    val fw = (bw * l.imageFade.coerceIn(0f, 0.45f)).coerceAtLeast(1f)
                    val fh = (bh * l.imageFade.coerceIn(0f, 0.45f)).coerceAtLeast(1f)
                    // Несколько промежуточных точек приближают smoothstep: переход
                    // начинается и заканчивается мягче, чем у обычного LinearGradient.
                    val edges = l.imageFadeEdges.coerceIn(1, 15)
                    val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
                    }
                    if (l.imageFadeStyle == 1) {
                        // Органическая маска: переходная линия слегка неровная,
                        // поэтому край не выглядит как ровно отрезанный прямоугольник.
                        val mb = OrganicFadeMasks.get(edges, l.imageFade)
                        val sh = android.graphics.BitmapShader(mb, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                        sh.setLocalMatrix(android.graphics.Matrix().apply {
                            setScale(dst.width() / mb.width, dst.height() / mb.height)
                            postTranslate(dst.left, dst.top)
                        })
                        maskPaint.shader = sh
                        c.drawRect(big, maskPaint)
                    } else {
                        val positions = floatArrayOf(0f, 0.12f, 0.35f, 0.65f, 0.88f, 1f)
                        val rise = intArrayOf(0x00000000, 0x16000000, 0x66000000,
                            0xCC000000.toInt(), Color.WHITE, Color.WHITE)
                        val fall = intArrayOf(Color.WHITE, Color.WHITE, 0xCC000000.toInt(),
                            0x66000000, 0x16000000, 0x00000000)
                        val masks = ArrayList<Shader>(4)
                        if (edges and 1 != 0) masks += LinearGradient(dst.left, 0f, dst.left + fw, 0f, rise, positions, Shader.TileMode.CLAMP)
                        if (edges and 2 != 0) masks += LinearGradient(dst.right - fw, 0f, dst.right, 0f, fall, positions, Shader.TileMode.CLAMP)
                        if (edges and 4 != 0) masks += LinearGradient(0f, dst.top, 0f, dst.top + fh, rise, positions, Shader.TileMode.CLAMP)
                        if (edges and 8 != 0) masks += LinearGradient(0f, dst.bottom - fh, 0f, dst.bottom, fall, positions, Shader.TileMode.CLAMP)
                        if (masks.isNotEmpty()) {
                            val combined = masks.drop(1).fold(masks.first()) { acc, shader ->
                                ComposeShader(acc, shader, PorterDuff.Mode.MULTIPLY)
                            }
                            maskPaint.shader = combined
                            c.drawRect(big, maskPaint)
                        }
                    }
                    c.restore()
                } else {
                    c.drawBitmap(b, null, dst, photoPaint)
                }
                if (hasImageMask) c.restore()
            }
        }
    }
    if (l.frame != 0) {
        val (lw, lh) = layerSize(l, ppm)
        drawFrame(c, l, lw, lh, ppm)
    }
    c.restore()
}

/** Локальные процедурные атмосферные наложения для прямоугольного слоя. */
private fun drawAtmosphere(c: Canvas, bounds: RectF, layer: Layer) {
    val intensity = layer.atmosphereIntensity.coerceIn(0f, 1f)
    val color = layer.atmosphereColor
    val save = c.save()
    c.clipRect(bounds)
    when (layer.atmosphereStyle) {
        1 -> { // туман
            for (i in 0..5) {
                val y = bounds.top + bounds.height() * (0.16f + i * 0.145f)
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = color
                    alpha = (intensity * (24 + (i % 3) * 10)).roundToInt()
                    maskFilter = android.graphics.BlurMaskFilter((bounds.height() * 0.055f).coerceAtLeast(2f), android.graphics.BlurMaskFilter.Blur.NORMAL)
                }
                val shift = sin(i * 1.7).toFloat() * bounds.width() * 0.12f
                c.drawOval(RectF(bounds.left - bounds.width() * 0.15f + shift, y,
                    bounds.right + bounds.width() * 0.15f + shift, y + bounds.height() * 0.18f), p)
            }
        }
        2 -> { // световые лучи
            for (i in 0..6) {
                val x = bounds.left + bounds.width() * (i / 6f)
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = LinearGradient(x, bounds.top, x + bounds.width() * 0.22f, bounds.bottom,
                        intArrayOf(Color.TRANSPARENT, android.graphics.ColorUtils.setAlphaComponent(color, (intensity * 42).roundToInt()), Color.TRANSPARENT),
                        floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                }
                val path = android.graphics.Path().apply {
                    moveTo(x - bounds.width() * 0.025f, bounds.top)
                    lineTo(x + bounds.width() * 0.12f, bounds.top)
                    lineTo(x + bounds.width() * 0.34f, bounds.bottom)
                    lineTo(x + bounds.width() * 0.19f, bounds.bottom)
                    close()
                }
                c.drawPath(path, p)
            }
        }
        3, 4 -> { // дождь или снег
            val snow = layer.atmosphereStyle == 4
            val count = if (snow) 95 else 125
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
                alpha = (intensity * if (snow) 190f else 115f).roundToInt()
                strokeWidth = if (snow) 1.4f else 1.1f
                strokeCap = Paint.Cap.ROUND
            }
            for (i in 0 until count) {
                val fx = ((i * 73 + 19) % 997) / 997f
                val fy = ((i * 191 + 47) % 991) / 991f
                val x = bounds.left + fx * bounds.width()
                val y = bounds.top + fy * bounds.height()
                if (snow) c.drawCircle(x, y, 1.2f + (i % 4) * 0.65f, p)
                else {
                    val len = bounds.height() * (0.018f + (i % 5) * 0.004f)
                    c.drawLine(x, y, x - len * 0.22f, y + len, p)
                }
            }
        }
    }
    c.restoreToCount(save)
}

/** Рамка вокруг объекта (рисуется в его повёрнутой системе координат с центром в нуле). */
private fun drawFrame(c: Canvas, l: Layer, lw: Float, lh: Float, ppm: Float) {
    // и толщина, и отступ — доли размера объекта: рамка всегда обнимает объект и масштабируется с ним
    val ref = l.frameRef() * ppm
    val sw = (l.frameWidth * ref).coerceAtLeast(1f)
    val pad = l.framePad * ref
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = l.frameColor; strokeWidth = sw; strokeJoin = Paint.Join.MITER
    }
    fun rect(grow: Float, w: Float = sw) = RectF(-lw / 2 - pad - grow, -lh / 2 - pad - grow, lw / 2 + pad + grow, lh / 2 + pad + grow).also { p.strokeWidth = w }
    when (l.frame) {
        1 -> c.drawRect(rect(0f), p)
        2 -> { c.drawRect(rect(sw * 1.8f), p); c.drawRect(rect(0f), p) }
        3 -> {
            val r = rect(0f)
            val rad = minOf(r.width(), r.height()) * 0.2f
            c.drawRoundRect(r, rad, rad, p)
        }
        4 -> {
            p.pathEffect = android.graphics.DashPathEffect(floatArrayOf(sw * 4f, sw * 3f), 0f)
            c.drawRect(rect(0f), p)
        }
        5 -> {
            val r = rect(0f)
            val len = minOf(r.width(), r.height()) * 0.28f
            p.strokeCap = Paint.Cap.SQUARE
            for ((x, y, sx, sy) in listOf(
                listOf(r.left, r.top, 1f, 1f), listOf(r.right, r.top, -1f, 1f),
                listOf(r.left, r.bottom, 1f, -1f), listOf(r.right, r.bottom, -1f, -1f)
            )) {
                c.drawLine(x, y, x + sx * len, y, p)
                c.drawLine(x, y, x, y + sy * len, p)
            }
        }
        6 -> { c.drawRect(rect(sw * 2.2f, sw * 2f), p); c.drawRect(rect(0f, sw * 0.6f), p) }
        7 -> { val r = rect(-sw * 1.5f); c.drawRect(r, p) }
        8 -> { val r = rect(0f); c.drawOval(r, p) }
        9 -> { p.pathEffect = android.graphics.DashPathEffect(floatArrayOf(sw * 5f, sw * 2f, sw, sw * 2f), 0f); c.drawRect(rect(0f), p) }
        10 -> { c.drawRect(rect(sw * 2.5f), p); c.drawRect(rect(0f), p); c.drawRect(rect(-sw * 2.5f), p) }
        11 -> { val r = rect(0f); c.drawLine(r.left, r.top, r.left, r.bottom, p); c.drawLine(r.right, r.top, r.right, r.bottom, p) }
        12 -> {
            val r = rect(0f); val len = minOf(r.width(), r.height()) * 0.18f
            for ((x, y, sx, sy) in listOf(listOf(r.left,r.top,1f,1f), listOf(r.right,r.top,-1f,1f), listOf(r.left,r.bottom,1f,-1f), listOf(r.right,r.bottom,-1f,-1f))) {
                c.drawLine(x, y, x + sx * len, y, p); c.drawLine(x, y, x, y + sy * len, p)
            }
        }
    }
}

/** Логотипы рисуются графикой, а не системным шрифтом. */
private fun drawSpecialMark(c: Canvas, l: Layer, ppm: Float) {
    val w = l.widthMm * ppm
    val h = w * 0.527f
    val color = l.color
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
        style = Paint.Style.FILL
    }
    c.save()
    c.translate(-w / 2f, -h / 2f)
    c.scale(w / 872f, h / 459f)
    val key = l.text.uppercase()
    if (key == "BLURAY") {
        val logo = SymbolAssets.bluray
        if (logo != null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = paint.alpha
                colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
            }
            c.drawBitmap(logo!!, null, RectF(0f, 0f, 872f, 459f), p)
        } else {
            // Safe fallback: recognizable disc + orbital sweep, entirely vector.
            val path = android.graphics.Path().apply {
                moveTo(18f, 42f); cubicTo(245f, -12f, 708f, 0f, 842f, 185f)
                cubicTo(922f, 300f, 760f, 442f, 275f, 450f)
                cubicTo(620f, 405f, 765f, 320f, 710f, 205f)
                cubicTo(640f, 60f, 260f, 30f, 18f, 42f); close()
            }
            c.drawPath(path, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 38f
            c.drawOval(120f, 150f, 560f, 315f, paint)
        }
    } else {
        // Each mark is assembled from vector geometry; no text glyphs are used.
        val stroke = Paint(paint).apply { style = Paint.Style.STROKE; strokeWidth = 34f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        when (key) {
            "DVD" -> {
                c.drawOval(25f, 60f, 300f, 335f, stroke); c.drawCircle(162f, 197f, 35f, paint)
                val p = android.graphics.Path().apply { moveTo(340f,90f); lineTo(470f,90f); lineTo(420f,300f); lineTo(315f,300f); close(); moveTo(510f,90f); lineTo(650f,90f); lineTo(600f,300f); lineTo(480f,300f); close() }
                c.drawPath(p, paint); c.drawLine(675f,100f,825f,100f,stroke); c.drawLine(675f,195f,790f,195f,stroke); c.drawLine(675f,290f,755f,290f,stroke)
            }
            "CD" -> { c.drawCircle(430f, 225f, 175f, stroke); c.drawCircle(430f,225f,34f,paint); for (a in 0..7) { val r= Math.toRadians(a*45.0); c.drawLine(430f,225f,(430+150*kotlin.math.cos(r)).toFloat(),(225+150*kotlin.math.sin(r)).toFloat(), Paint(stroke).apply { strokeWidth=9f }) } }
            "HIRES" -> { c.drawCircle(180f,210f,110f,stroke); c.drawLine(90f,210f,270f,210f,stroke); c.drawLine(180f,120f,180f,300f,stroke); for(i in 0..5) c.drawLine(360f+i*75f,280f,360f+i*75f, (230-i*28).toFloat(),stroke) }
            "DOLBY", "ATMOS" -> { c.drawArc(60f,70f,400f,390f,-90f,180f,false,stroke); c.drawArc(250f,70f,590f,390f,90f,180f,false,stroke); c.drawLine(430f,100f,430f,360f,stroke); c.drawLine(650f,100f,650f,360f,stroke) }
            "DTS", "DTSHD" -> { for(i in 0..4) { val x=70f+i*155f; c.drawRoundRect(x,95f,x+95f,345f,24f,24f,paint) }; c.drawLine(55f,385f,820f,385f,stroke) }
            "4K", "HDR", "THX", "STEREO", "169", "1080P", "2160P" -> {
                val path=android.graphics.Path().apply { moveTo(75f,95f); lineTo(795f,95f); lineTo(795f,365f); lineTo(75f,365f); close() }
                c.drawPath(path,stroke); c.drawLine(160f,230f,710f,230f,stroke); c.drawCircle(435f,230f,58f,paint)
            }
            else -> { c.drawCircle(436f,230f,165f,stroke); c.drawLine(180f,230f,692f,230f,stroke) }
        }
    }
    c.restore()
}

fun drawPanel(c: Canvas, p: PanelData, w: Float, h: Float, ppm: Float) {
    val bg = Paint()
    if (p.c1 == p.c2) {
        bg.color = p.c1
    } else {
        val rad = Math.toRadians(p.angle.toDouble())
        val dx = cos(rad).toFloat()
        val dy = sin(rad).toFloat()
        val half = (abs(w * dx) + abs(h * dy)) / 2f
        bg.shader = LinearGradient(
            w / 2 - dx * half, h / 2 - dy * half, w / 2 + dx * half, h / 2 + dy * half,
            p.c1, p.c2, Shader.TileMode.CLAMP
        )
    }
    c.drawRect(0f, 0f, w, h, bg)
    drawPanelLayers(c, p, w, h, ppm)
}

private fun drawPanelLayers(c: Canvas, p: PanelData, w: Float, h: Float, ppm: Float) {
    for (l in p.layers) {
        if (l.kind == Kind.SYMBOL) {
            val under = samplePanelEdge(p.copy(layers = p.layers.takeWhile { it.id != l.id }), w, h, l.x * w, l.y * h, ppm)
            val luminance = (0.299 * Color.red(under) + 0.587 * Color.green(under) + 0.114 * Color.blue(under))
            val autoColor = if (luminance > 145.0) android.graphics.Color.BLACK else android.graphics.Color.WHITE
            drawLayer(c, l.copy(color = autoColor), w, h, ppm)
        } else {
            drawLayer(c, l, w, h, ppm)
        }
    }
}

fun colorAt(p: PanelData, w: Float, h: Float, x: Float, y: Float): Int {
    if (p.c1 == p.c2) return p.c1
    val rad = Math.toRadians(p.angle.toDouble())
    val dx = cos(rad).toFloat()
    val dy = sin(rad).toFloat()
    val half = (abs(w * dx) + abs(h * dy)) / 2f
    val t = if (half <= 0f) 0f else (((x - w / 2) * dx + (y - h / 2) * dy) / (2 * half) + 0.5f).coerceIn(0f, 1f)
    return ColorUtils.blendARGB(p.c1, p.c2, t)
}

/** Цвет фактического содержимого у края панели: учитывает фотографии и фигуры поверх градиента. */
fun samplePanelEdge(p: PanelData, w: Float, h: Float, x: Float, y: Float, ppm: Float = 1f): Int {
    var result = colorAt(p, w, h, x, y)
    val pixelsPerMm = ppm.coerceAtLeast(0.0001f)
    for (layer in p.layers) {
        // x/y/w/h здесь в пикселях, размеры слоёв — в миллиметрах.
        // Переводим точку в локальные координаты слоя до проверки его границ.
        val dx = (x - layer.x * w) / pixelsPerMm
        val dy = (y - layer.y * h) / pixelsPerMm
        val rad = Math.toRadians(-layer.rot.toDouble())
        val lx = (dx * kotlin.math.cos(rad) - dy * kotlin.math.sin(rad)).toFloat()
        val ly = (dx * kotlin.math.sin(rad) + dy * kotlin.math.cos(rad)).toFloat()
        when (layer.kind) {
            Kind.IMAGE -> {
                val bitmap = Bitmaps.get(layer.path) ?: continue
                val iw = layer.widthMm
                val ih = iw * bitmap.height / bitmap.width.toFloat()
                if (kotlin.math.abs(lx) <= iw / 2f && kotlin.math.abs(ly) <= ih / 2f) {
                    val bx = (((lx / iw) + 0.5f) * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
                    val by = (((ly / ih) + 0.5f) * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
                    val pixel = bitmap.getPixel(bx, by)
                    val effectiveAlpha = layer.alpha.coerceIn(0f, 1f) * (Color.alpha(pixel) / 255f)
                    if (effectiveAlpha > 0f) result = ColorUtils.blendARGB(result, pixel, effectiveAlpha)
                }
            }
            Kind.RECT -> if (kotlin.math.abs(lx) <= layer.widthMm / 2f && kotlin.math.abs(ly) <= layer.sizeMm / 2f) {
                result = ColorUtils.blendARGB(result, layer.color, layer.alpha.coerceIn(0f, 1f))
            }
            Kind.TEXT, Kind.SYMBOL -> Unit
        }
    }
    return result
}

/** Фон корешка всегда подстраивается под соседние части: плавный переход оборот → корешок → лицо. */
fun effectivePanel(p: Project, id: PanelId, instance: Int = 0): PanelData {
    val pd = p.panel(id)
    if (id != PanelId.SPINE) return pd
    val f = p.format
    val back = p.panel(PanelId.BACK)
    val front = p.panel(PanelId.FRONT)
    // Сплошной цвет корешка (например, выбранный пипеткой) имеет приоритет.
    // Градиентный режим по умолчанию по-прежнему подбирает оттенки с соседних панелей.
    if (pd.c1 == pd.c2) return pd
    return if (!f.tray) {
        val backEdge = samplePanelEdge(back, f.backW, f.backH, f.backW, f.backH / 2)
        val frontEdge = samplePanelEdge(front, f.frontW, f.frontH, 0f, f.frontH / 2)
        val spineTone = colorAt(pd, f.spineW, f.backH, f.spineW / 2f, f.backH / 2f)
        // Края корешка получают точные цвета соседних панелей: на стыке нет цветового скачка.
        pd.copy(c1 = backEdge, c2 = frontEdge, angle = 0)
    } else {
        val edge = if (instance == 0) samplePanelEdge(back, f.backW, f.backH, 0f, f.backH / 2)
        else samplePanelEdge(back, f.backW, f.backH, f.backW, f.backH / 2)
        val spineTone = colorAt(pd, f.spineW, f.backH, f.spineW / 2f, f.backH / 2f)
        pd.copy(c1 = edge, c2 = edge)
    }
}

/** Тень на сгибе: на корешке {@link SHADOW_SPINE_MM} мм от края внутрь, на обложке {@link SHADOW_COVER_MM} мм наружу. */
const val SHADOW_SPINE_MM = 1f
const val SHADOW_COVER_MM = 2f
const val SHADOW_ALPHA = 0.6f

/** Тёмная полоса, самая тёмная у линии сгиба [edgeX] и плавно гаснущая на [widthPx] в сторону [dir] (+1 вправо, -1 влево). */
private fun drawFoldShadow(c: Canvas, edgeX: Float, widthPx: Float, dir: Int, h: Float) {
    if (widthPx <= 0f) return
    val n = 8
    val pos = FloatArray(n + 1) { it / n.toFloat() }
    val col = IntArray(n + 1) { i ->
        val t = i / n.toFloat()
        val k = (1f - t)
        Color.argb((255f * SHADOW_ALPHA * k * k).roundToInt(), 0, 0, 0)
    }
    val x2 = edgeX + dir * widthPx
    val paint = Paint().apply { shader = LinearGradient(edgeX, 0f, x2, 0f, col, pos, Shader.TileMode.CLAMP) }
    c.drawRect(minOf(edgeX, x2), 0f, maxOf(edgeX, x2), h, paint)
}

fun drawPanelIn(c: Canvas, p: Project, id: PanelId, instance: Int, w: Float, h: Float, ppm: Float, maskDisc: Boolean = false) {
    if (id == PanelId.DISC) {
        c.save()
        if (maskDisc) {
            val cx = w / 2f
            val cy = h / 2f
            val outer = android.graphics.Path().apply { addCircle(cx, cy, DISC_OUTER_MM * ppm / 2f, android.graphics.Path.Direction.CW) }
            val hole = android.graphics.Path().apply { addCircle(cx, cy, DISC_INNER_MM * ppm / 2f, android.graphics.Path.Direction.CW) }
            c.clipPath(outer)
            c.clipOutPath(hole)
        }
        drawPanel(c, p.panel(id), w, h, ppm)
        c.restore()
        return
    }
    val f = p.format
    // Фон и содержимое панели рисуются как есть — без размытия и подмешивания соседей.
    drawPanel(c, p.panel(id), w, h, ppm)
    if (!p.foldShadow || p.seamlessSpine()) return
    val cover = SHADOW_COVER_MM * ppm
    when (id) {
        PanelId.FRONT -> if (!f.tray) drawFoldShadow(c, 0f, cover, +1, h)
        PanelId.BACK -> if (!f.tray) drawFoldShadow(c, w, cover, -1, h) else {
            drawFoldShadow(c, 0f, cover, +1, h)
            drawFoldShadow(c, w, cover, -1, h)
        }
        PanelId.SPINE -> {
            val inner = minOf(SHADOW_SPINE_MM * ppm, w * 0.2f)
            if (!f.tray) {
                drawFoldShadow(c, 0f, inner, +1, h)
                drawFoldShadow(c, w, inner, -1, h)
            } else if (instance == 0) drawFoldShadow(c, w, inner, -1, h)   // справа — оборот
            else drawFoldShadow(c, 0f, inner, +1, h)                       // слева — оборот
        }
        PanelId.DISC -> Unit
    }
}

fun sheetSizeMm(p: Project, a4: Boolean, marks: Boolean, disc: Boolean = false): Pair<Float, Float> {
    val lay = if (disc) p.format.discLayout() else p.format.layout()
    if (a4) return 297f to 210f
    val m = if (marks) 8f else 0f
    return (lay.w + 2 * m) to (lay.h + 2 * m)
}

fun renderSheet(p: Project, ppm: Float, a4: Boolean, marks: Boolean, disc: Boolean = false): Bitmap {
    val lay = if (disc) p.format.discLayout() else p.format.layout()
    val (sw, sh) = sheetSizeMm(p, a4, marks, disc)
    val bmp = Bitmap.createBitmap((sw * ppm).roundToInt(), (sh * ppm).roundToInt(), Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(Color.WHITE)
    val ox = (sw - lay.w) / 2f
    val oy = (sh - lay.h) / 2f
    drawPlaces(c, p, lay.places, ox, oy, ppm, true)
    if (marks) {
        val mp = Paint().apply {
            color = Color.BLACK
            strokeWidth = maxOf(1f, 0.15f * ppm)
            style = Paint.Style.STROKE
        }
        val gap = 1.5f * ppm
        val len = 4f * ppm
        if (disc) {
            // Метки: четыре засечки снаружи круга и крестик в центре отверстия.
            val cx = (ox + DISC_SIZE_MM / 2f) * ppm
            val cy = (oy + DISC_SIZE_MM / 2f) * ppm
            val ro = DISC_OUTER_MM / 2f * ppm
            for ((dx, dy) in listOf(1f to 0f, -1f to 0f, 0f to 1f, 0f to -1f)) {
                c.drawLine(cx + dx * (ro + gap), cy + dy * (ro + gap), cx + dx * (ro + gap + len), cy + dy * (ro + gap + len), mp)
            }
            val cr = 2f * ppm
            c.drawLine(cx - cr, cy, cx + cr, cy, mp)
            c.drawLine(cx, cy - cr, cx, cy + cr, mp)
        }
        for (g in if (disc) emptyList() else lay.groups) {
            val x0 = (ox + g.x) * ppm
            val y0 = (oy + g.y) * ppm
            val x1 = x0 + g.w * ppm
            val y1 = y0 + g.h * ppm
            for ((cx, cy) in listOf(x0 to y0, x1 to y0, x0 to y1, x1 to y1)) {
                val sx = if (cx == x0) -1f else 1f
                val sy = if (cy == y0) -1f else 1f
                c.drawLine(cx + sx * gap, cy, cx + sx * (gap + len), cy, mp)
                c.drawLine(cx, cy + sy * gap, cx, cy + sy * (gap + len), mp)
            }
            for (f in g.folds) {
                val fx = x0 + f * ppm
                c.drawLine(fx, y0 - gap, fx, y0 - gap - len, mp)
                c.drawLine(fx, y1 + gap, fx, y1 + gap + len, mp)
            }
        }
    }
    return bmp
}

/** Корешок с плавным переходом «цвета с оборота и лица»: тень на сгибе отключается, стыка не видно. */
fun Project.seamlessSpine(): Boolean = panel(PanelId.SPINE).layers.any {
    it.kind == Kind.IMAGE && File(it.path).name.startsWith("spine-")
}

/** Рисует панели листа. Корешок с плавным переходом рисуется последним, а его растушёвка заходит на оборот и лицо: стыка не видно. */
fun drawPlaces(c: Canvas, p: Project, places: List<Place>, ox: Float, oy: Float, ppm: Float, maskDisc: Boolean) {
    val spineLayer = p.panel(PanelId.SPINE).layers.firstOrNull {
        it.kind == Kind.IMAGE && File(it.path).name.startsWith("spine-")
    }
    val ordered = places.filter { it.id != PanelId.SPINE } + places.filter { it.id == PanelId.SPINE }
    for (pl in ordered) {
        val w = pl.w * ppm
        val h = pl.h * ppm
        val inst = if (pl.id == PanelId.SPINE && pl.x > 0f) 1 else 0
        c.save()
        c.translate((ox + pl.x) * ppm, (oy + pl.y) * ppm)
        c.clipRect(0f, 0f, w, h)
        drawPanelIn(c, p, pl.id, inst, w, h, ppm, maskDisc)
        c.restore()
        if (pl.id == PanelId.SPINE && spineLayer != null) drawSpineFeather(c, p, spineLayer, pl, inst, ox, oy, ppm)
    }
}

/** Прозрачные края картинки корешка (имя файла spine-<fc>-<sw>-…) рисуются за границами корешка поверх соседних панелей. */
private fun drawSpineFeather(c: Canvas, p: Project, l: Layer, pl: Place, inst: Int, ox: Float, oy: Float, ppm: Float) {
    val parts = File(l.path).name.removePrefix("spine-").split("-")
    val fc = parts.getOrNull(0)?.toIntOrNull() ?: return
    val sw = parts.getOrNull(1)?.toIntOrNull() ?: return
    val bmp = Bitmaps.get(l.path) ?: return
    if (bmp.width != sw + 2 * fc || fc <= 0) return
    val w = pl.w * ppm
    val h = pl.h * ppm
    val fw = fc * w / sw
    val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    c.save()
    c.translate((ox + pl.x) * ppm, (oy + pl.y) * ppm)
    val tray = p.format.tray
    if (!(tray && inst == 0)) c.drawBitmap(bmp, android.graphics.Rect(0, 0, fc, bmp.height), RectF(-fw, 0f, 0f, h), paint)
    if (!(tray && inst == 1)) c.drawBitmap(bmp, android.graphics.Rect(fc + sw, 0, bmp.width, bmp.height), RectF(w, 0f, w + fw, h), paint)
    c.restore()
}
