package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.ComposeShader
import android.graphics.PorterDuffXfermode
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import androidx.core.graphics.ColorUtils
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

object Fonts {
    class Entry(val name: String, val sys: Int, val file: String)

    private val sysFam = listOf(
        "sans-serif-medium", "sans-serif-black", "sans-serif-condensed", "sans-serif-light",
        "serif", "cursive", "casual", "monospace"
    )
    private val sysNames = listOf("Классика", "Жирный", "Узкий", "Тонкий", "Засечки", "Рукопись", "Casual", "Моно")
    // системные шрифты с кириллицей (cursive/casual без неё — оставлены только как запасные)
    private val shown = listOf(0, 1, 2, 3, 4, 7)

    var entries: List<Entry> = shown.map { Entry(sysNames[it], it, "") }
        private set
    private var assets: android.content.res.AssetManager? = null
    private val cache = HashMap<String, Typeface>()

    fun init(am: android.content.res.AssetManager) {
        assets = am
        val files = runCatching { am.list("fonts")?.toList() }.getOrNull().orEmpty()
            .filter { it.endsWith(".ttf") || it.endsWith(".otf") }.sorted()
        entries = shown.map { Entry(sysNames[it], it, "") } +
            files.map { Entry(it.substringBeforeLast('.').replace('_', ' '), 0, it) }
        cache.clear()
    }

    fun get(sys: Int, file: String, italic: Boolean): Typeface = cache.getOrPut("$sys|$file|$italic") {
        val fromAsset = if (file.isNotEmpty()) runCatching { Typeface.createFromAsset(assets, "fonts/$file") }.getOrNull() else null
        val base = fromAsset ?: Typeface.create(sysFam[sys.coerceIn(0, sysFam.lastIndex)], Typeface.NORMAL)
        Typeface.create(base, if (italic) Typeface.ITALIC else Typeface.NORMAL)
    }
}

object Bitmaps {
    private const val MAX_SIDE = 3072
    private const val MAX_BYTES = 40L * 1024 * 1024
    private val cache = object : LruCache<String, Bitmap>(128 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(path: String): Bitmap? {
        cache.get(path)?.let { return it }
        if (path.isEmpty() || !File(path).exists()) return null
        val name = File(path).name
        val opts = android.graphics.BitmapFactory.Options()
        // Огромные вырезки не должны вытеснять друг друга из кэша: иначе файл декодируется заново на каждом кадре.
        if (!name.startsWith("spine-") && !name.startsWith("blur-")) {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(path, bounds)
            var s = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / s > MAX_SIDE ||
                (bounds.outWidth / s).toLong() * (bounds.outHeight / s) * 4L > MAX_BYTES) s *= 2
            opts.inSampleSize = s
        }
        val b = android.graphics.BitmapFactory.decodeFile(path, opts) ?: return null
        cache.put(path, b)
        return b
    }
}

/** Идёт перетаскивание слоя: тяжёлые пересчёты (анализ фона и т.п.) заменяются последним результатом. */
object Interactive {
    private val st = androidx.compose.runtime.mutableStateOf(false)
    var dragging: Boolean
        get() = st.value
        set(v) { st.value = v }
    val backdrops = java.util.concurrent.ConcurrentHashMap<String, BackdropLight>()
}

/** Небольшая детерминированная маска для органичного, негеометрического края. */
private object OrganicFadeMasks {
    private val cache = object : LruCache<String, Bitmap>(4 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun get(edges: Int, fadeFraction: Float): Bitmap {
        val fade = fadeFraction.coerceIn(0.01f, 0.45f)
        val key = "$edges|${(fade * 1000).roundToInt()}"
        cache.get(key)?.let { return it }
        val side = 256
        val pixels = IntArray(side * side)
        fun smooth(t0: Float): Float {
            val t = t0.coerceIn(0f, 1f)
            return t * t * (3f - 2f * t)
        }
        for (y in 0 until side) for (x in 0 until side) {
            val nx = x / (side - 1f)
            val ny = y / (side - 1f)
            // Многомасштабное возмущение ломает идеально прямую линию края,
            // но не создаёт заметного зерна внутри изображения.
            val noise = (kotlin.math.sin(x * 0.071f + y * 0.037f) * 0.55f +
                kotlin.math.sin(x * 0.023f - y * 0.061f) * 0.30f +
                kotlin.math.sin(x * 0.137f + y * 0.119f) * 0.15f)
            var alpha = 1f
            val edgeOffset = 0.045f + noise * 0.025f
            val transition = (fade - 0.045f).coerceAtLeast(0.01f)
            fun edgeAlpha(distance: Float) = smooth((distance - edgeOffset) / transition)
            if (edges and 1 != 0) alpha = minOf(alpha, edgeAlpha(nx))
            if (edges and 2 != 0) alpha = minOf(alpha, edgeAlpha(1f - nx))
            if (edges and 4 != 0) alpha = minOf(alpha, edgeAlpha(ny))
            if (edges and 8 != 0) alpha = minOf(alpha, edgeAlpha(1f - ny))
            val a = (alpha * 255f).roundToInt().coerceIn(0, 255)
            pixels[y * side + x] = (a shl 24) or 0x00FFFFFF
        }
        val bitmap = Bitmap.createBitmap(pixels, side, side, Bitmap.Config.ARGB_8888)
        cache.put(key, bitmap)
        return bitmap
    }
}

object SymbolAssets {
    var bluray: Bitmap? = null
    fun init(am: android.content.res.AssetManager) {
        bluray = runCatching { am.open("symbols_bluray.png").use { BitmapFactory.decodeStream(it) } }.getOrNull()
    }
}

/** Тень под текстом по контуру букв: буквы раздуваются, размываются по альфа-каналу и кэшируются (при перетаскивании пересчёта нет). */
private object TextHalo {
    class Halo(val bmp: Bitmap, val margin: Float)

    private val cache = object : LruCache<String, Halo>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Halo): Int = value.bmp.byteCount
    }

    fun get(l: Layer, ppm: Float, sl: StaticLayout): Halo? {
        val size = (l.sizeMm * ppm).coerceAtLeast(1f)
        val key = "${l.text}|${l.upper}|${l.font}|${l.fontFile}|${l.italic}|${(size * 10).roundToInt()}|" +
            "${(l.spacing * 1000).roundToInt()}|${(l.boxMm * ppm).roundToInt()}|${l.align}|${l.textBlur}"
        cache.get(key)?.let { return it }
        val blurR = size * when (l.textBlur) { 1 -> 0.18f; 2 -> 0.38f; 3 -> 0.65f; else -> 0.05f }
        val spread = size * when (l.textBlur) { 1 -> 0.10f; 2 -> 0.16f; 3 -> 0.22f; else -> 0.06f }
        val margin = ceil(spread + blurR * 2f) + 2f
        val fw = sl.width + margin * 2f
        val fh = sl.height + margin * 2f
        val k = minOf(1f, 512f / maxOf(fw, fh))
        val bw = (fw * k).roundToInt().coerceAtLeast(2)
        val bh = (fh * k).roundToInt().coerceAtLeast(2)
        val bmp = runCatching {
            val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b)
            cv.scale(k, k)
            cv.translate(margin, margin)
            textLayout(l, ppm, halo = spread).draw(cv)
            val px = IntArray(bw * bh)
            b.getPixels(px, 0, bw, 0, 0, bw, bh)
            val a = IntArray(bw * bh) { px[it] ushr 24 }
            boxBlurAlpha(a, bw, bh, blurR * k)
            for (i in a.indices) px[i] = a[i] shl 24
            b.setPixels(px, 0, bw, 0, 0, bw, bh)
            b
        }.getOrNull() ?: return null
        val h = Halo(bmp, margin)
        cache.put(key, h)
        return h
    }

    /** Три прохода box-blur по одному каналу ≈ гауссово размытие. */
    fun boxBlurAlpha(a: IntArray, w: Int, h: Int, sigma: Float) {
        if (sigma < 0.5f) return
        val r = (sigma * 1.2f).roundToInt().coerceAtLeast(1)
        val tmp = IntArray(a.size)
        val div = 2 * r + 1
        repeat(3) {
            for (y in 0 until h) {
                val row = y * w
                var sum = 0
                for (i in -r..r) sum += a[row + i.coerceIn(0, w - 1)]
                for (x in 0 until w) {
                    tmp[row + x] = sum / div
                    sum += a[row + minOf(x + r + 1, w - 1)] - a[row + maxOf(x - r, 0)]
                }
            }
            for (x in 0 until w) {
                var sum = 0
                for (i in -r..r) sum += tmp[i.coerceIn(0, h - 1) * w + x]
                for (y in 0 until h) {
                    a[y * w + x] = sum / div
                    sum += tmp[minOf(y + r + 1, h - 1) * w + x] - tmp[maxOf(y - r, 0) * w + x]
                }
            }
        }
    }
}

/**
 * Растворение PNG по контуру объекта. Если у картинки есть прозрачность (вырезанный объект),
 * маска строится не по прямоугольнику файла, а по реальной форме объекта: дистанция от его контура внутрь
 * (все края) или градиент от границ самого объекта (выбранные стороны).
 */
private object ObjectMasks {
    class Info(val hasAlpha: Boolean, val sw: Int, val sh: Int, val alpha: IntArray?, val l: Int, val t: Int, val r: Int, val b: Int)

    private val infos = LruCache<String, Info>(48)
    private val masks = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val NONE = Info(false, 0, 0, null, 0, 0, 0, 0)

    fun info(path: String, src: Bitmap): Info {
        infos.get(path)?.let { return it }
        val res = compute(src)
        infos.put(path, res)
        return res
    }

    private fun compute(src: Bitmap): Info {
        if (!src.hasAlpha()) return NONE
        val k = minOf(1f, 1536f / maxOf(src.width, src.height))
        val sw = (src.width * k).roundToInt().coerceAtLeast(2)
        val sh = (src.height * k).roundToInt().coerceAtLeast(2)
        val small = runCatching { Blur.scaleSmooth(src, sw, sh) }.getOrNull() ?: return NONE
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (small !== src) small.recycle()
        val alpha = IntArray(sw * sh) { px[it] ushr 24 }
        var clear = 0
        var l = sw; var t = sh; var r = -1; var b = -1
        for (y in 0 until sh) for (x in 0 until sw) {
            val a = alpha[y * sw + x]
            if (a < 128) clear++
            if (a > 24) { if (x < l) l = x; if (x > r) r = x; if (y < t) t = y; if (y > b) b = y }
        }
        // «PNG с вырезанным объектом»: заметная доля прозрачных пикселей и есть что растворять
        if (r < l || b < t || clear < sw * sh * 0.004f) return NONE
        return Info(true, sw, sh, alpha, l, t, r + 1, b + 1)
    }

    fun mask(path: String, src: Bitmap, fade: Float, style: Int, edges: Int): Bitmap? {
        val info = info(path, src)
        if (!info.hasAlpha || info.alpha == null) return null
        val key = "$path|${(fade * 1000).roundToInt()}|$style|$edges"
        masks.get(key)?.let { return it }
        val sw = info.sw; val sh = info.sh
        val objW = (info.r - info.l).toFloat().coerceAtLeast(1f)
        val objH = (info.b - info.t).toFloat().coerceAtLeast(1f)
        val fadePx = (fade.coerceIn(0.001f, 0.45f) * minOf(objW, objH)).coerceAtLeast(0.75f)
        fun smooth(t0: Float): Float { val t = t0.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }
        fun noise(x: Int, y: Int): Float = (kotlin.math.sin(x * 0.19f + y * 0.097f) * 0.55f +
            kotlin.math.sin(x * 0.061f - y * 0.157f) * 0.30f + kotlin.math.sin(x * 0.37f + y * 0.31f) * 0.15f)
        val organic = style == 1
        val out = IntArray(sw * sh)
        if ((edges and 15) == 15) {
            // расстояние от контура объекта внутрь (двухпроходная метрика)
            val inf = 1e9f
            val d = FloatArray(sw * sh)
            for (y in 0 until sh) for (x in 0 until sw) {
                val i = y * sw + x
                // Нулевой альфа-канал задаёт внешний фон. Нельзя отсекать все значения <128:
                // так пропадают полупрозрачные волосы, дымка и антиалиасные пиксели PNG.
                d[i] = if (info.alpha[i] == 0) 0f else if (x == 0 || y == 0 || x == sw - 1 || y == sh - 1) 1f else inf
            }
            val s2 = 1.4142f
            for (y in 0 until sh) for (x in 0 until sw) {
                val i = y * sw + x
                var v = d[i]
                if (v == 0f) continue
                if (x > 0) v = minOf(v, d[i - 1] + 1f)
                if (y > 0) {
                    v = minOf(v, d[i - sw] + 1f)
                    if (x > 0) v = minOf(v, d[i - sw - 1] + s2)
                    if (x < sw - 1) v = minOf(v, d[i - sw + 1] + s2)
                }
                d[i] = v
            }
            for (y in sh - 1 downTo 0) for (x in sw - 1 downTo 0) {
                val i = y * sw + x
                var v = d[i]
                if (v == 0f) continue
                if (x < sw - 1) v = minOf(v, d[i + 1] + 1f)
                if (y < sh - 1) {
                    v = minOf(v, d[i + sw] + 1f)
                    if (x < sw - 1) v = minOf(v, d[i + sw + 1] + s2)
                    if (x > 0) v = minOf(v, d[i + sw - 1] + s2)
                }
                d[i] = v
            }
            for (y in 0 until sh) for (x in 0 until sw) {
                val i = y * sw + x
                val dist = if (organic) d[i] + noise(x, y) * fadePx * 0.22f else d[i]
                // Сохраняем исходную полупрозрачность антиалиасного края PNG.
                // Маска задаёт только дополнительное растворение, а не заменяет альфа-канал вырезки.
                val sourceAlpha = info.alpha[i] / 255f
                val feather = smooth(dist / fadePx)
                val a = (sourceAlpha * feather * 255f).roundToInt().coerceIn(0, 255)
                out[i] = (a shl 24) or 0x00FFFFFF
            }
        } else {
            // направленное растворение: края отсчитываются от границ самого объекта, а не от рамки файла
            for (y in 0 until sh) for (x in 0 until sw) {
                val dl = x + 0.5f - info.l
                val dr = info.r - (x + 0.5f)
                val dt = y + 0.5f - info.t
                val db = info.b - (y + 0.5f)
                val n = if (organic) noise(x, y) * fadePx * 0.22f else 0f
                var m = 1f
                if (edges and 1 != 0) m = minOf(m, smooth((dl + n) / fadePx))
                if (edges and 2 != 0) m = minOf(m, smooth((dr + n) / fadePx))
                if (edges and 4 != 0) m = minOf(m, smooth((dt + n) / fadePx))
                if (edges and 8 != 0) m = minOf(m, smooth((db + n) / fadePx))
                out[y * sw + x] = ((m * 255f).roundToInt().coerceIn(0, 255) shl 24) or 0x00FFFFFF
            }
        }
        // Не размываем готовую маску: исходный PNG уже содержит антиалиасинг
        // альфа-канала. Дополнительный blur превращал тонкие волосы и мелкие детали
        // в мягкую кайму. Плавность здесь задаёт smoothstep по distance field.
        val bmp = Bitmap.createBitmap(out, sw, sh, Bitmap.Config.ARGB_8888)
        masks.put(key, bmp)
        return bmp
    }
}

/** У картинки есть вырезанный (прозрачный) фон — растворение пойдёт по контуру объекта. */
fun hasObjectTransparency(path: String): Boolean {
    val b = Bitmaps.get(path) ?: return false
    return ObjectMasks.info(path, b).hasAlpha
}

private fun textLayout(l: Layer, ppm: Float, outline: Boolean = false, glow: Boolean = false, halo: Float = -1f): StaticLayout {
    val size = (l.sizeMm * ppm).coerceAtLeast(1f)
    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = if (outline) l.textOutlineColor else if (glow) l.textGlowColor else l.color
        textSize = size
        if (outline) {
            style = Paint.Style.STROKE
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            strokeWidth = (size * l.textOutlineWidth).coerceAtLeast(0.1f) * 2f
        }
        if (glow) setShadowLayer(size * l.textGlowRadius, 0f, 0f, l.textGlowColor)
        if (!outline && !glow && l.textMaterial in 9..14) {
            val (cols, pos) = TextTextures.gradient(l.textMaterial)
            shader = LinearGradient(0f, size * 0.12f, 0f, size * 1.0f, cols, pos, Shader.TileMode.CLAMP)
        } else if (!outline && !glow && l.textMaterial in 1..4) {
            val stops = when (l.textMaterial) {
                1 -> intArrayOf(Color.rgb(92, 48, 10), Color.rgb(255, 224, 132), Color.rgb(184, 119, 28), Color.rgb(255, 241, 190), Color.rgb(105, 61, 15))
                2 -> intArrayOf(Color.rgb(55, 63, 74), Color.rgb(245, 249, 255), Color.rgb(132, 146, 164), Color.rgb(255, 255, 255), Color.rgb(75, 84, 98))
                3 -> intArrayOf(Color.rgb(12, 72, 115), Color.rgb(198, 245, 255), Color.rgb(66, 174, 220), Color.rgb(240, 255, 255), Color.rgb(24, 103, 157))
                else -> intArrayOf(Color.rgb(5, 7, 13), Color.rgb(105, 115, 132), Color.rgb(18, 23, 34), Color.rgb(155, 165, 180), Color.rgb(3, 5, 10))
            }
            shader = LinearGradient(0f, 0f, 0f, (size * 1.25f).coerceAtLeast(1f), stops, null, Shader.TileMode.CLAMP)
        } else if (!outline && !glow && (l.textMaterial in 5..8 || l.textMaterial >= 15)) {
            shader = TextTextures.shader(l.textMaterial, size)
        }
        typeface = Fonts.get(l.font, l.fontFile, l.italic)
        letterSpacing = l.spacing
        if (l.shadow) setShadowLayer(size * 0.08f, 0f, size * 0.05f, 0xB0000000.toInt())
        if (halo >= 0f) {
            // Маска для тени по контуру: те же буквы, но чёрные и «раздутые» на halo пикселей во все стороны.
            shader = null
            clearShadowLayer()
            color = Color.BLACK
            style = Paint.Style.FILL_AND_STROKE
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
            strokeWidth = (halo * 2f).coerceAtLeast(0.01f)
        }
    }
    val raw = if (l.upper) l.text.uppercase() else l.text
    val s = if (raw.isEmpty()) " " else raw
    val width = if (l.boxMm > 0f) {
        (l.boxMm * ppm).toInt().coerceAtLeast(1)
    } else {
        var m = 1f
        for (line in s.split("\n")) m = maxOf(m, tp.measureText(line))
        ceil(m).toInt() + ceil(size * 0.15f).toInt() + 1
    }
    val align = when (l.align) {
        0 -> Layout.Alignment.ALIGN_NORMAL
        2 -> Layout.Alignment.ALIGN_OPPOSITE
        else -> Layout.Alignment.ALIGN_CENTER
    }
    return StaticLayout.Builder.obtain(s, 0, s.length, tp, width)
        .setAlignment(align)
        .setLineSpacing(0f, 1.08f)
        .setIncludePad(false)
        .build()
}

fun layerSize(l: Layer, ppm: Float): Pair<Float, Float> = when (l.kind) {
    Kind.TEXT -> textLayout(l, ppm).let { it.width.toFloat() to it.height.toFloat() }
    Kind.RECT -> (l.widthMm * ppm) to (l.sizeMm * ppm)
    Kind.SYMBOL -> (l.widthMm * ppm) to (l.widthMm * ppm * 0.527f)
    Kind.IMAGE -> {
        val b = Bitmaps.get(l.path)
        val w = l.widthMm * ppm
        w to (if (b != null) w * b.height / b.width else w)
    }
}

fun drawLayer(c: Canvas, l: Layer, w: Float, h: Float, ppm: Float, backdrop: BackdropLight? = null) {
    c.save()
    c.translate(l.x * w, l.y * h)
    c.rotate(l.rot)
    c.scale(if (l.flipX) -1f else 1f, if (l.flipY) -1f else 1f)
    when (l.kind) {
        Kind.TEXT -> {
            val sl = textLayout(l, ppm)
            val alphaLayer = if (l.alpha < 0.999f) c.saveLayerAlpha(null, (l.alpha.coerceIn(0f, 1f) * 255f).roundToInt()) else -1
            // Тень-подложка повторяет контур букв (а не прямоугольник): сила — textShade, мягкость — textBlur.
            val shadeAlpha = l.textShade.coerceIn(0f, 0.85f)
            if (shadeAlpha > 0f) {
                TextHalo.get(l, ppm, sl)?.let { halo ->
                    val hp = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = (shadeAlpha * 255f).roundToInt().coerceIn(0, 255) }
                    c.drawBitmap(halo.bmp, null, RectF(
                        -sl.width / 2f - halo.margin, -sl.height / 2f - halo.margin,
                        sl.width / 2f + halo.margin, sl.height / 2f + halo.margin), hp)
                }
            }
            c.save()
            c.translate(-sl.width / 2f, -sl.height / 2f)
            if (l.textGlowRadius > 0.001f) textLayout(l, ppm, glow = true).draw(c)
            if (l.textOutlineWidth > 0.001f) textLayout(l, ppm, outline = true).draw(c)
            sl.draw(c)
            c.restore()
            if (l.textRules > 0.001f) drawTextRules(c, l, sl.width.toFloat(), ppm)
            if (alphaLayer >= 0) c.restoreToCount(alphaLayer)
        }
        Kind.SYMBOL -> drawSpecialMark(c, l, ppm)
        Kind.RECT -> {
            val rw = l.widthMm * ppm
            val rh = l.sizeMm * ppm
            val rp = Paint(Paint.ANTI_ALIAS_FLAG)
            rp.color = l.color
            rp.alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
            c.drawRect(-rw / 2, -rh / 2, rw / 2, rh / 2, rp)
        }
        Kind.IMAGE -> {
            val sourceBitmap = Bitmaps.get(l.path)
            if (sourceBitmap != null) {
                val b = if (backdrop != null) EdgeIntegration.process(
                    l.path, sourceBitmap, l.imageEdgeClean, l.imageLightWrap * backdrop.strength, l.imageEdgeRelight * backdrop.strength,
                    backdrop.color, backdrop.lx, backdrop.ly, backdrop.amount, l.imageChoke
                ) else EdgeIntegration.process(l.path, sourceBitmap, l.imageEdgeClean, l.imageLightWrap, l.imageEdgeRelight, l.imageWrapColor, choke = l.imageChoke)
                val bw = l.widthMm * ppm
                val bh = bw * b.height / b.width
                val dst = RectF(-bw / 2, -bh / 2, bw / 2, bh / 2)
                val alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
                val photoPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
                    this.alpha = alpha
                    if (l.hasImageGrade) colorFilter = ColorMatrixColorFilter(FxPainter.imageMatrix(l))
                }

                if (l.imageFade > 0.001f) {
                    // Маска должна перекрывать слой с запасом: иначе по антиалиасингу границы
                    // (особенно при повороте) остаётся тонкая светлая линия контура фото.
                    val big = RectF(dst).apply { inset(-4f, -4f) }
                    c.saveLayer(big, null)
                    c.drawBitmap(b, null, dst, photoPaint)

                    val fw = (bw * l.imageFade.coerceIn(0f, 0.45f)).coerceAtLeast(1f)
                    val fh = (bh * l.imageFade.coerceIn(0f, 0.45f)).coerceAtLeast(1f)
                    // Несколько промежуточных точек приближают smoothstep: переход
                    // начинается и заканчивается мягче, чем у обычного LinearGradient.
                    val edges = l.imageFadeEdges.coerceIn(1, 15)
                    val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
                    }
                    // PNG с вырезанным объектом: растворяем по форме объекта, а не по квадрату файла
                    val objectMask = ObjectMasks.mask(l.path, b, l.imageFade, l.imageFadeStyle, edges)
                    if (objectMask != null) {
                        c.drawBitmap(objectMask, null, dst, maskPaint)
                    } else if (l.imageFadeStyle == 1) {
                        // Органическая маска: переходная линия слегка неровная,
                        // поэтому край не выглядит как ровно отрезанный прямоугольник.
                        val mb = OrganicFadeMasks.get(edges, l.imageFade)
                        val sh = android.graphics.BitmapShader(mb, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                        sh.setLocalMatrix(android.graphics.Matrix().apply {
                            setScale(dst.width() / mb.width, dst.height() / mb.height)
                            postTranslate(dst.left, dst.top)
                        })
                        maskPaint.shader = sh
                        c.drawRect(big, maskPaint)
                    } else {
                        val positions = floatArrayOf(0f, 0.12f, 0.35f, 0.65f, 0.88f, 1f)
                        val rise = intArrayOf(0x00000000, 0x16000000, 0x66000000,
                            0xCC000000.toInt(), Color.WHITE, Color.WHITE)
                        val fall = intArrayOf(Color.WHITE, Color.WHITE, 0xCC000000.toInt(),
                            0x66000000, 0x16000000, 0x00000000)
                        val masks = ArrayList<Shader>(4)
                        if (edges and 1 != 0) masks += LinearGradient(dst.left, 0f, dst.left + fw, 0f, rise, positions, Shader.TileMode.CLAMP)
                        if (edges and 2 != 0) masks += LinearGradient(dst.right - fw, 0f, dst.right, 0f, fall, positions, Shader.TileMode.CLAMP)
                        if (edges and 4 != 0) masks += LinearGradient(0f, dst.top, 0f, dst.top + fh, rise, positions, Shader.TileMode.CLAMP)
                        if (edges and 8 != 0) masks += LinearGradient(0f, dst.bottom - fh, 0f, dst.bottom, fall, positions, Shader.TileMode.CLAMP)
                        if (masks.isNotEmpty()) {
                            val combined = masks.drop(1).fold(masks.first()) { acc, shader ->
                                ComposeShader(acc, shader, PorterDuff.Mode.MULTIPLY)
                            }
                            maskPaint.shader = combined
                            c.drawRect(big, maskPaint)
                        }
                    }
                    c.restore()
                } else {
                    c.drawBitmap(b, null, dst, photoPaint)
                }
            }
        }
    }
    if (l.frame != 0) {
        val (lw, lh) = layerSize(l, ppm)
        drawFrame(c, l, lw, lh, ppm)
    }
    c.restore()
}

/** Тонкие линии по бокам текста, как у подзаголовка «— 1982 —». Центр — в нуле. */
private fun drawTextRules(c: Canvas, l: Layer, textW: Float, ppm: Float) {
    val size = l.sizeMm * ppm
    val len = size * 10f * l.textRules
    val gap = size * 0.9f
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = l.color
        style = Paint.Style.STROKE
        strokeWidth = (size * 0.045f).coerceAtLeast(1f)
        strokeCap = Paint.Cap.BUTT
    }
    val half = textW / 2f
    c.drawLine(-half - gap - len, 0f, -half - gap, 0f, p)
    c.drawLine(half + gap, 0f, half + gap + len, 0f, p)
}

/** Рамка вокруг объекта (рисуется в его повёрнутой системе координат с центром в нуле). */
private fun drawFrame(c: Canvas, l: Layer, lw: Float, lh: Float, ppm: Float) {
    // и толщина, и отступ — доли размера объекта: рамка всегда обнимает объект и масштабируется с ним
    val ref = l.frameRef() * ppm
    val sw = (l.frameWidth * ref).coerceAtLeast(1f)
    val pad = l.framePad * ref
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = l.frameColor; strokeWidth = sw; strokeJoin = Paint.Join.MITER
    }
    fun rect(grow: Float, w: Float = sw) = RectF(-lw / 2 - pad - grow, -lh / 2 - pad - grow, lw / 2 + pad + grow, lh / 2 + pad + grow).also { p.strokeWidth = w }
    when (l.frame) {
        1 -> c.drawRect(rect(0f), p)
        2 -> { c.drawRect(rect(sw * 1.8f), p); c.drawRect(rect(0f), p) }
        3 -> {
            val r = rect(0f)
            val rad = minOf(r.width(), r.height()) * 0.2f
            c.drawRoundRect(r, rad, rad, p)
        }
        4 -> {
            p.pathEffect = android.graphics.DashPathEffect(floatArrayOf(sw * 4f, sw * 3f), 0f)
            c.drawRect(rect(0f), p)
        }
        5 -> {
            val r = rect(0f)
            val len = minOf(r.width(), r.height()) * 0.28f
            p.strokeCap = Paint.Cap.SQUARE
            for ((x, y, sx, sy) in listOf(
                listOf(r.left, r.top, 1f, 1f), listOf(r.right, r.top, -1f, 1f),
                listOf(r.left, r.bottom, 1f, -1f), listOf(r.right, r.bottom, -1f, -1f)
            )) {
                c.drawLine(x, y, x + sx * len, y, p)
                c.drawLine(x, y, x, y + sy * len, p)
            }
        }
        6 -> { c.drawRect(rect(sw * 2.2f, sw * 2f), p); c.drawRect(rect(0f, sw * 0.6f), p) }
        7 -> { val r = rect(-sw * 1.5f); c.drawRect(r, p) }
        8 -> { val r = rect(0f); c.drawOval(r, p) }
        9 -> { p.pathEffect = android.graphics.DashPathEffect(floatArrayOf(sw * 5f, sw * 2f, sw, sw * 2f), 0f); c.drawRect(rect(0f), p) }
        10 -> { c.drawRect(rect(sw * 2.5f), p); c.drawRect(rect(0f), p); c.drawRect(rect(-sw * 2.5f), p) }
        11 -> { val r = rect(0f); c.drawLine(r.left, r.top, r.left, r.bottom, p); c.drawLine(r.right, r.top, r.right, r.bottom, p) }
        12 -> {
            val r = rect(0f); val len = minOf(r.width(), r.height()) * 0.18f
            for ((x, y, sx, sy) in listOf(listOf(r.left,r.top,1f,1f), listOf(r.right,r.top,-1f,1f), listOf(r.left,r.bottom,1f,-1f), listOf(r.right,r.bottom,-1f,-1f))) {
                c.drawLine(x, y, x + sx * len, y, p); c.drawLine(x, y, x, y + sy * len, p)
            }
        }
    }
}

/** Логотипы рисуются графикой, а не системным шрифтом. */
private fun drawSpecialMark(c: Canvas, l: Layer, ppm: Float) {
    val w = l.widthMm * ppm
    val h = w * 0.527f
    val color = l.color
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        alpha = (l.alpha.coerceIn(0f, 1f) * 255).roundToInt()
        style = Paint.Style.FILL
    }
    c.save()
    c.translate(-w / 2f, -h / 2f)
    c.scale(w / 872f, h / 459f)
    val key = l.text.uppercase()
    if (key == "BLURAY") {
        val logo = SymbolAssets.bluray
        if (logo != null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                alpha = paint.alpha
                colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
            }
            c.drawBitmap(logo!!, null, RectF(0f, 0f, 872f, 459f), p)
        } else {
            // Safe fallback: recognizable disc + orbital sweep, entirely vector.
            val path = android.graphics.Path().apply {
                moveTo(18f, 42f); cubicTo(245f, -12f, 708f, 0f, 842f, 185f)
                cubicTo(922f, 300f, 760f, 442f, 275f, 450f)
                cubicTo(620f, 405f, 765f, 320f, 710f, 205f)
                cubicTo(640f, 60f, 260f, 30f, 18f, 42f); close()
            }
            c.drawPath(path, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 38f
            c.drawOval(120f, 150f, 560f, 315f, paint)
        }
    } else {
        // Each mark is assembled from vector geometry; no text glyphs are used.
        val stroke = Paint(paint).apply { style = Paint.Style.STROKE; strokeWidth = 34f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        when (key) {
            "DVD" -> {
                c.drawOval(25f, 60f, 300f, 335f, stroke); c.drawCircle(162f, 197f, 35f, paint)
                val p = android.graphics.Path().apply { moveTo(340f,90f); lineTo(470f,90f); lineTo(420f,300f); lineTo(315f,300f); close(); moveTo(510f,90f); lineTo(650f,90f); lineTo(600f,300f); lineTo(480f,300f); close() }
                c.drawPath(p, paint); c.drawLine(675f,100f,825f,100f,stroke); c.drawLine(675f,195f,790f,195f,stroke); c.drawLine(675f,290f,755f,290f,stroke)
            }
            "CD" -> { c.drawCircle(430f, 225f, 175f, stroke); c.drawCircle(430f,225f,34f,paint); for (a in 0..7) { val r= Math.toRadians(a*45.0); c.drawLine(430f,225f,(430+150*kotlin.math.cos(r)).toFloat(),(225+150*kotlin.math.sin(r)).toFloat(), Paint(stroke).apply { strokeWidth=9f }) } }
            "HIRES" -> { c.drawCircle(180f,210f,110f,stroke); c.drawLine(90f,210f,270f,210f,stroke); c.drawLine(180f,120f,180f,300f,stroke); for(i in 0..5) c.drawLine(360f+i*75f,280f,360f+i*75f, (230-i*28).toFloat(),stroke) }
            "DOLBY", "ATMOS" -> { c.drawArc(60f,70f,400f,390f,-90f,180f,false,stroke); c.drawArc(250f,70f,590f,390f,90f,180f,false,stroke); c.drawLine(430f,100f,430f,360f,stroke); c.drawLine(650f,100f,650f,360f,stroke) }
            "DTS", "DTSHD" -> { for(i in 0..4) { val x=70f+i*155f; c.drawRoundRect(x,95f,x+95f,345f,24f,24f,paint) }; c.drawLine(55f,385f,820f,385f,stroke) }
            "4K", "HDR", "THX", "STEREO", "169", "1080P", "2160P" -> {
                val path=android.graphics.Path().apply { moveTo(75f,95f); lineTo(795f,95f); lineTo(795f,365f); lineTo(75f,365f); close() }
                c.drawPath(path,stroke); c.drawLine(160f,230f,710f,230f,stroke); c.drawCircle(435f,230f,58f,paint)
            }
            else -> { c.drawCircle(436f,230f,165f,stroke); c.drawLine(180f,230f,692f,230f,stroke) }
        }
    }
    c.restore()
}

fun drawPanel(c: Canvas, p: PanelData, w: Float, h: Float, ppm: Float) {
    val bg = Paint()
    if (p.c1 == p.c2) {
        bg.color = p.c1
    } else {
        val rad = Math.toRadians(p.angle.toDouble())
        val dx = cos(rad).toFloat()
        val dy = sin(rad).toFloat()
        val half = (abs(w * dx) + abs(h * dy)) / 2f
        bg.shader = LinearGradient(
            w / 2 - dx * half, h / 2 - dy * half, w / 2 + dx * half, h / 2 + dy * half,
            p.c1, p.c2, Shader.TileMode.CLAMP
        )
    }
    c.drawRect(0f, 0f, w, h, bg)
    drawPanelLayers(c, p, w, h, ppm)
}

private fun drawPanelLayers(c: Canvas, p: PanelData, w: Float, h: Float, ppm: Float) {
    for (l in p.layers) {
        if (!l.visible) continue
        if (l.kind == Kind.SYMBOL) {
            val under = samplePanelEdge(p.copy(layers = p.layers.takeWhile { it.id != l.id }), w, h, l.x * w, l.y * h, ppm)
            val luminance = (0.299 * Color.red(under) + 0.587 * Color.green(under) + 0.114 * Color.blue(under))
            val autoColor = if (luminance > 145.0) android.graphics.Color.BLACK else android.graphics.Color.WHITE
            drawLayer(c, l.copy(color = autoColor), w, h, ppm)
        } else if (l.kind == Kind.IMAGE && l.imageWrapAuto && l.imageLightWrap > 0.001f) {
            val cached = if (Interactive.dragging) Interactive.backdrops[l.id] else null
            val bd = cached ?: analyzeBackdrop(p.copy(layers = p.layers.takeWhile { it.id != l.id }), l, w, h, ppm)?.also { Interactive.backdrops[l.id] = it }
            drawLayer(c, l, w, h, ppm, bd)
        } else {
            drawLayer(c, l, w, h, ppm)
        }
    }
}

/** Результат анализа фона: цвет света, направление (в системе координат картинки) и его выраженность. */
class BackdropLight(val color: Int, val lx: Float, val ly: Float, val amount: Float, val strength: Float)

/**
 * Рисует всё, что лежит под слоем (фон панели + нижние слои), в маленький битмап и вычисляет
 * цвет света (взвешен по яркости) и направление к самой светлой стороне вокруг слоя.
 */
fun analyzeBackdrop(under: PanelData, l: Layer, w: Float, h: Float, ppm: Float): BackdropLight? {
    val bmp0 = Bitmaps.get(l.path) ?: return null
    val s = (96f / maxOf(w, h)).coerceAtMost(1f)
    val bw = (w * s).roundToInt().coerceAtLeast(2)
    val bh = (h * s).roundToInt().coerceAtLeast(2)
    val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
    val cv = Canvas(bmp)
    cv.scale(bw / w, bh / h)
    drawPanel(cv, under, w, h, ppm)
    val px = IntArray(bw * bh)
    bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
    bmp.recycle()
    // Область слоя, расширенная на 30% (с учётом поворота — по описанному прямоугольнику).
    val iw = l.widthMm * ppm
    val ih = iw * bmp0.height / bmp0.width
    val rad = Math.toRadians(l.rot.toDouble())
    val ex = (abs(iw * cos(rad)) + abs(ih * sin(rad))).toFloat() * 0.65f
    val ey = (abs(iw * sin(rad)) + abs(ih * cos(rad))).toFloat() * 0.65f
    val cx = l.x * w
    val cy = l.y * h
    val x0 = ((cx - ex) * s).toInt().coerceIn(0, bw - 1)
    val x1 = ((cx + ex) * s).toInt().coerceIn(x0 + 1, bw)
    val y0 = ((cy - ey) * s).toInt().coerceIn(0, bh - 1)
    val y1 = ((cy + ey) * s).toInt().coerceIn(y0 + 1, bh)
    var sw = 0.0; var sr = 0.0; var sg = 0.0; var sb = 0.0
    var dx = 0.0; var dy = 0.0; var lumSum = 0.0; var n = 0
    val mx = (x0 + x1) / 2.0
    val my = (y0 + y1) / 2.0
    for (y in y0 until y1) for (x in x0 until x1) {
        val p = px[y * bw + x]
        val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
        val lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        val wt = lum * lum + 0.02
        sw += wt; sr += r * wt; sg += g * wt; sb += b * wt
        dx += (x - mx) * wt; dy += (y - my) * wt
        lumSum += lum; n++
    }
    if (n == 0 || sw <= 0.0) return null
    val avgLum = (lumSum / n).toFloat()
    // Нормируем смещение центра яркости на полуразмер области: 0 — ровный свет, ~1 — свет с одной стороны.
    val hx = ((x1 - x0) / 2.0).coerceAtLeast(1.0)
    val hy = ((y1 - y0) / 2.0).coerceAtLeast(1.0)
    var vx = (dx / sw / hx).toFloat()
    var vy = (dy / sw / hy).toFloat()
    val mag = kotlin.math.sqrt(vx * vx + vy * vy)
    val amount = (mag * 3f).coerceIn(0f, 1f)
    if (mag > 1e-4f) { vx /= mag; vy /= mag }
    // В систему координат картинки (слой повёрнут на l.rot).
    val cr = Math.cos(-rad).toFloat(); val sr2 = Math.sin(-rad).toFloat()
    val lx = vx * cr - vy * sr2
    val ly = vx * sr2 + vy * cr
    var col = Color.rgb((sr / sw).roundToInt().coerceIn(0, 255), (sg / sw).roundToInt().coerceIn(0, 255), (sb / sw).roundToInt().coerceIn(0, 255))
    // Лёгкое осветление: свет, обёрнутый вокруг объекта, всегда светлее самого фона.
    col = ColorUtils.blendARGB(col, Color.WHITE, 0.06f)
    // Тёмный фон — слабый wrap, светлый — полный.
    val strength = (0.35f + avgLum * 1.2f).coerceIn(0.35f, 1f)
    return BackdropLight(col, lx, ly, amount, strength)
}

fun colorAt(p: PanelData, w: Float, h: Float, x: Float, y: Float): Int {
    if (p.c1 == p.c2) return p.c1
    val rad = Math.toRadians(p.angle.toDouble())
    val dx = cos(rad).toFloat()
    val dy = sin(rad).toFloat()
    val half = (abs(w * dx) + abs(h * dy)) / 2f
    val t = if (half <= 0f) 0f else (((x - w / 2) * dx + (y - h / 2) * dy) / (2 * half) + 0.5f).coerceIn(0f, 1f)
    return ColorUtils.blendARGB(p.c1, p.c2, t)
}

/** Цвет фактического содержимого у края панели: учитывает фотографии и фигуры поверх градиента. */
fun samplePanelEdge(p: PanelData, w: Float, h: Float, x: Float, y: Float, ppm: Float = 1f): Int {
    var result = colorAt(p, w, h, x, y)
    val pixelsPerMm = ppm.coerceAtLeast(0.0001f)
    for (layer in p.layers) {
        // x/y/w/h здесь в пикселях, размеры слоёв — в миллиметрах.
        // Переводим точку в локальные координаты слоя до проверки его границ.
        val dx = (x - layer.x * w) / pixelsPerMm
        val dy = (y - layer.y * h) / pixelsPerMm
        val rad = Math.toRadians(-layer.rot.toDouble())
        val lx = (dx * kotlin.math.cos(rad) - dy * kotlin.math.sin(rad)).toFloat()
        val ly = (dx * kotlin.math.sin(rad) + dy * kotlin.math.cos(rad)).toFloat()
        when (layer.kind) {
            Kind.IMAGE -> {
                val bitmap = Bitmaps.get(layer.path) ?: continue
                val iw = layer.widthMm
                val ih = iw * bitmap.height / bitmap.width.toFloat()
                if (kotlin.math.abs(lx) <= iw / 2f && kotlin.math.abs(ly) <= ih / 2f) {
                    val bx = (((lx / iw) + 0.5f) * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
                    val by = (((ly / ih) + 0.5f) * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
                    val pixel = bitmap.getPixel(bx, by)
                    val effectiveAlpha = layer.alpha.coerceIn(0f, 1f) * (Color.alpha(pixel) / 255f)
                    if (effectiveAlpha > 0f) result = ColorUtils.blendARGB(result, pixel, effectiveAlpha)
                }
            }
            Kind.RECT -> if (kotlin.math.abs(lx) <= layer.widthMm / 2f && kotlin.math.abs(ly) <= layer.sizeMm / 2f) {
                result = ColorUtils.blendARGB(result, layer.color, layer.alpha.coerceIn(0f, 1f))
            }
            Kind.TEXT, Kind.SYMBOL -> Unit
        }
    }
    return result
}

/** Фон корешка всегда подстраивается под соседние части: плавный переход оборот → корешок → лицо. */
fun effectivePanel(p: Project, id: PanelId, instance: Int = 0): PanelData {
    val pd = p.panel(id)
    if (id != PanelId.SPINE) return pd
    val f = p.format
    val back = p.panel(PanelId.BACK)
    val front = p.panel(PanelId.FRONT)
    // Сплошной цвет корешка (например, выбранный пипеткой) имеет приоритет.
    // Градиентный режим по умолчанию по-прежнему подбирает оттенки с соседних панелей.
    if (pd.c1 == pd.c2) return pd
    return if (!f.tray) {
        val backEdge = samplePanelEdge(back, f.backW, f.backH, f.backW, f.backH / 2)
        val frontEdge = samplePanelEdge(front, f.frontW, f.frontH, 0f, f.frontH / 2)
        val spineTone = colorAt(pd, f.spineW, f.backH, f.spineW / 2f, f.backH / 2f)
        // Края корешка получают точные цвета соседних панелей: на стыке нет цветового скачка.
        pd.copy(c1 = backEdge, c2 = frontEdge, angle = 0)
    } else {
        val edge = if (instance == 0) samplePanelEdge(back, f.backW, f.backH, 0f, f.backH / 2)
        else samplePanelEdge(back, f.backW, f.backH, f.backW, f.backH / 2)
        val spineTone = colorAt(pd, f.spineW, f.backH, f.spineW / 2f, f.backH / 2f)
        pd.copy(c1 = edge, c2 = edge)
    }
}

/** Тень на сгибе: на корешке {@link SHADOW_SPINE_MM} мм от края внутрь, на обложке {@link SHADOW_COVER_MM} мм наружу. */
const val SHADOW_SPINE_MM = 1f
const val SHADOW_COVER_MM = 2f
const val SHADOW_ALPHA = 0.6f

/** Тёмная полоса, самая тёмная у линии сгиба [edgeX] и плавно гаснущая на [widthPx] в сторону [dir] (+1 вправо, -1 влево). */
private fun drawFoldShadow(c: Canvas, edgeX: Float, widthPx: Float, dir: Int, h: Float) {
    if (widthPx <= 0f) return
    val n = 8
    val pos = FloatArray(n + 1) { it / n.toFloat() }
    val col = IntArray(n + 1) { i ->
        val t = i / n.toFloat()
        val k = (1f - t)
        Color.argb((255f * SHADOW_ALPHA * k * k).roundToInt(), 0, 0, 0)
    }
    val x2 = edgeX + dir * widthPx
    val paint = Paint().apply { shader = LinearGradient(edgeX, 0f, x2, 0f, col, pos, Shader.TileMode.CLAMP) }
    c.drawRect(minOf(edgeX, x2), 0f, maxOf(edgeX, x2), h, paint)
}

fun drawPanelIn(c: Canvas, p: Project, id: PanelId, instance: Int, w: Float, h: Float, ppm: Float, maskDisc: Boolean = false) {
    if (id == PanelId.DISC) {
        c.save()
        if (maskDisc) {
            val cx = w / 2f
            val cy = h / 2f
            val outer = android.graphics.Path().apply { addCircle(cx, cy, DISC_OUTER_MM * ppm / 2f, android.graphics.Path.Direction.CW) }
            val hole = android.graphics.Path().apply { addCircle(cx, cy, DISC_INNER_MM * ppm / 2f, android.graphics.Path.Direction.CW) }
            c.clipPath(outer)
            c.clipOutPath(hole)
        }
        drawPanel(c, p.panel(id), w, h, ppm)
        c.restore()
        return
    }
    val f = p.format
    // Фон и содержимое панели рисуются как есть — без размытия и подмешивания соседей.
    drawPanel(c, p.panel(id), w, h, ppm)
    // Тень на сгибе корешка убрана полностью: стык оборота, корешка и лица без тёмной полосы.
}

fun sheetSizeMm(p: Project, a4: Boolean, marks: Boolean, disc: Boolean = false): Pair<Float, Float> {
    val lay = if (disc) p.format.discLayout() else p.format.layout()
    if (a4) return 297f to 210f
    val m = if (marks) 8f else 0f
    return (lay.w + 2 * m) to (lay.h + 2 * m)
}

fun renderSheet(p: Project, ppm: Float, a4: Boolean, marks: Boolean, disc: Boolean = false): Bitmap {
    val lay = if (disc) p.format.discLayout() else p.format.layout()
    val (sw, sh) = sheetSizeMm(p, a4, marks, disc)
    val bmp = Bitmap.createBitmap((sw * ppm).roundToInt(), (sh * ppm).roundToInt(), Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(Color.WHITE)
    val ox = (sw - lay.w) / 2f
    val oy = (sh - lay.h) / 2f
    drawPlaces(c, p, lay.places, ox, oy, ppm, true)
    if (marks) {
        val mp = Paint().apply {
            color = Color.BLACK
            strokeWidth = maxOf(1f, 0.15f * ppm)
            style = Paint.Style.STROKE
        }
        val gap = 1.5f * ppm
        val len = 4f * ppm
        if (disc) {
            // Метки: четыре засечки снаружи круга и крестик в центре отверстия.
            val cx = (ox + DISC_SIZE_MM / 2f) * ppm
            val cy = (oy + DISC_SIZE_MM / 2f) * ppm
            val ro = DISC_OUTER_MM / 2f * ppm
            for ((dx, dy) in listOf(1f to 0f, -1f to 0f, 0f to 1f, 0f to -1f)) {
                c.drawLine(cx + dx * (ro + gap), cy + dy * (ro + gap), cx + dx * (ro + gap + len), cy + dy * (ro + gap + len), mp)
            }
            val cr = 2f * ppm
            c.drawLine(cx - cr, cy, cx + cr, cy, mp)
            c.drawLine(cx, cy - cr, cx, cy + cr, mp)
        }
        for (g in if (disc) emptyList() else lay.groups) {
            val x0 = (ox + g.x) * ppm
            val y0 = (oy + g.y) * ppm
            val x1 = x0 + g.w * ppm
            val y1 = y0 + g.h * ppm
            for ((cx, cy) in listOf(x0 to y0, x1 to y0, x0 to y1, x1 to y1)) {
                val sx = if (cx == x0) -1f else 1f
                val sy = if (cy == y0) -1f else 1f
                c.drawLine(cx + sx * gap, cy, cx + sx * (gap + len), cy, mp)
                c.drawLine(cx, cy + sy * gap, cx, cy + sy * (gap + len), mp)
            }
            for (f in g.folds) {
                val fx = x0 + f * ppm
                c.drawLine(fx, y0 - gap, fx, y0 - gap - len, mp)
                c.drawLine(fx, y1 + gap, fx, y1 + gap + len, mp)
            }
        }
    }
    return bmp
}

/** Корешок с плавным переходом «цвета с оборота и лица»: тень на сгибе отключается, стыка не видно. */
fun Project.seamlessSpine(): Boolean = panel(PanelId.SPINE).layers.any {
    it.kind == Kind.IMAGE && File(it.path).name.startsWith("spine-")
}

/** Рисует лист с учётом эффектов проекта: цветокор оборачивает всё содержимое, остальное ложится сверху. */
fun drawPlaces(c: Canvas, p: Project, places: List<Place>, ox: Float, oy: Float, ppm: Float, maskDisc: Boolean) {
    val fx = p.fx
    if (!fx.active || places.isEmpty()) {
        drawPlacesContent(c, p, places, ox, oy, ppm, maskDisc)
        return
    }
    val bounds = RectF(
        (ox + places.minOf { it.x }) * ppm, (oy + places.minOf { it.y }) * ppm,
        (ox + places.maxOf { it.x + it.w }) * ppm, (oy + places.maxOf { it.y + it.h }) * ppm
    )
    c.save()
    c.clipRect(bounds)
    if (maskDisc && places.any { it.id == PanelId.DISC }) {
        // На диске эффекты ложатся только на печатное кольцо, а не на белое поле листа.
        val cx = bounds.centerX(); val cy = bounds.centerY()
        c.clipPath(android.graphics.Path().apply { addCircle(cx, cy, DISC_OUTER_MM * ppm / 2f, android.graphics.Path.Direction.CW) })
        c.clipOutPath(android.graphics.Path().apply { addCircle(cx, cy, DISC_INNER_MM * ppm / 2f, android.graphics.Path.Direction.CW) })
    }
    if (fx.hasGrade) {
        val gp = Paint().apply { colorFilter = ColorMatrixColorFilter(FxPainter.gradeMatrix(fx)) }
        c.saveLayer(bounds, gp)
        drawPlacesContent(c, p, places, ox, oy, ppm, maskDisc)
        c.restore()
    } else {
        drawPlacesContent(c, p, places, ox, oy, ppm, maskDisc)
    }
    FxPainter.drawOverlays(c, fx, places, ox, oy, ppm, p.format.tray)
    c.restore()
}

/** Рисует панели листа. Корешок с плавным переходом рисуется последним, а его растушёвка заходит на оборот и лицо: стыка не видно. */
private fun drawPlacesContent(c: Canvas, p: Project, places: List<Place>, ox: Float, oy: Float, ppm: Float, maskDisc: Boolean) {
    val spineLayer = p.panel(PanelId.SPINE).layers.firstOrNull {
        it.kind == Kind.IMAGE && File(it.path).name.startsWith("spine-")
    }
    val ordered = places.filter { it.id != PanelId.SPINE } + places.filter { it.id == PanelId.SPINE }
    for (pl in ordered) {
        val w = pl.w * ppm
        val h = pl.h * ppm
        val inst = if (pl.id == PanelId.SPINE && pl.x > 0f) 1 else 0
        c.save()
        c.translate((ox + pl.x) * ppm, (oy + pl.y) * ppm)
        c.clipRect(0f, 0f, w, h)
        drawPanelIn(c, p, pl.id, inst, w, h, ppm, maskDisc)
        c.restore()
        if (pl.id == PanelId.SPINE && spineLayer != null) drawSpineFeather(c, p, spineLayer, pl, inst, ox, oy, ppm)
    }
    // Общие слои рисуются после всех панелей в координатах единого холста.
    // Clip ограничивает их физическим размером разворота, но не границами отдельных панелей.
    if (p.canvasLayers.isNotEmpty() && places.any { it.id == PanelId.FRONT } && places.isNotEmpty()) {
        val minX = places.minOf { it.x }
        val minY = places.minOf { it.y }
        val maxX = places.maxOf { it.x + it.w }
        val maxY = places.maxOf { it.y + it.h }
        val totalW = (maxX - minX) * ppm
        val totalH = (maxY - minY) * ppm
        c.save()
        c.translate((ox + minX) * ppm, (oy + minY) * ppm)
        c.clipRect(0f, 0f, totalW, totalH)
        p.canvasLayers.filter { it.visible }.forEach { layer -> drawLayer(c, layer, totalW, totalH, ppm) }
        c.restore()
    }
}

/** Прозрачные края картинки корешка (имя файла spine-<fc>-<sw>-…) рисуются за границами корешка поверх соседних панелей. */
private fun drawSpineFeather(c: Canvas, p: Project, l: Layer, pl: Place, inst: Int, ox: Float, oy: Float, ppm: Float) {
    val parts = File(l.path).name.removePrefix("spine-").split("-")
    val fc = parts.getOrNull(0)?.toIntOrNull() ?: return
    val sw = parts.getOrNull(1)?.toIntOrNull() ?: return
    val bmp = Bitmaps.get(l.path) ?: return
    if (bmp.width != sw + 2 * fc || fc <= 0) return
    val w = pl.w * ppm
    val h = pl.h * ppm
    val fw = fc * w / sw
    val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    c.save()
    c.translate((ox + pl.x) * ppm, (oy + pl.y) * ppm)
    val tray = p.format.tray
    if (!(tray && inst == 0)) c.drawBitmap(bmp, android.graphics.Rect(0, 0, fc, bmp.height), RectF(-fw, 0f, 0f, h), paint)
    if (!(tray && inst == 1)) c.drawBitmap(bmp, android.graphics.Rect(fc + sw, 0, bmp.width, bmp.height), RectF(w, 0f, w + fw, h), paint)
    c.restore()
}


/** Одна панель (вкладки «Лицо», «Корешок», «Оборот», «Диск») с теми же эффектами, что и на «Обзоре». */
fun drawPanelWithFx(c: Canvas, p: Project, id: PanelId, instance: Int, w: Float, h: Float, ppm: Float, maskDisc: Boolean = false) {
    val fx = p.fx
    if (!fx.active) {
        drawPanelIn(c, p, id, instance, w, h, ppm, maskDisc)
        return
    }
    val bounds = RectF(0f, 0f, w, h)
    val place = Place(id, 0f, 0f, w / ppm, h / ppm)
    c.save()
    c.clipRect(bounds)
    if (id == PanelId.DISC && maskDisc) {
        c.clipPath(android.graphics.Path().apply { addCircle(w / 2f, h / 2f, DISC_OUTER_MM * ppm / 2f, android.graphics.Path.Direction.CW) })
        c.clipOutPath(android.graphics.Path().apply { addCircle(w / 2f, h / 2f, DISC_INNER_MM * ppm / 2f, android.graphics.Path.Direction.CW) })
    }
    if (fx.hasGrade) {
        val gp = Paint().apply { colorFilter = ColorMatrixColorFilter(FxPainter.gradeMatrix(fx)) }
        c.saveLayer(bounds, gp)
        drawPanelIn(c, p, id, instance, w, h, ppm, maskDisc)
        c.restore()
    } else {
        drawPanelIn(c, p, id, instance, w, h, ppm, maskDisc)
    }
    FxPainter.drawOverlays(c, fx, listOf(place), 0f, 0f, ppm, false)
    c.restore()
}
