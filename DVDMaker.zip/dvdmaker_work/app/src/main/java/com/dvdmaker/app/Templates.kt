package com.dvdmaker.app

import android.graphics.Color
import kotlin.math.roundToInt

class CoverStyle(val name: String, val note: String)

/** Параметры стиля оформления: как выглядят название, подзаголовок и описание и какая атмосфера у разворота. */
private class Spec(
    val titleFonts: List<String>,
    val titleColor: Int,
    val titleMaterial: Int,
    val titleOutlineW: Float,
    val titleOutlineColor: Int,
    val titleGlowR: Float,
    val titleGlowColor: Int,
    val titleSpacing: Float,
    val subFonts: List<String>,
    val subColor: Int,
    val subSpacing: Float,
    val bodyFonts: List<String>,
    val bodyColor: Int,
    val fx: Fx
)

object Templates {
    val styles = listOf(
        CoverStyle("Ледяной триллер", "Как на референсе: морозные буквы с трещинами, холодный цветокор, снег"),
        CoverStyle("Золотая классика", "Золотые буквы с засечками, тёплое виньетирование"),
        CoverStyle("Неон", "Яркое свечение букв, пурпурный цветокор"),
        CoverStyle("Огонь и лава", "Буквы с раскалённой лавой, тёмная виньетка, красный оттенок"),
        CoverStyle("Минимализм", "Чистые белые буквы без эффектов, лёгкая виньетка")
    )

    private val specs = listOf(
        Spec(
            titleFonts = listOf("Russo_One", "Dela_Gothic_One", "Fira_Sans_Black"),
            titleColor = Color.WHITE, titleMaterial = 5,
            titleOutlineW = 0.012f, titleOutlineColor = Color.rgb(205, 232, 255),
            titleGlowR = 0.05f, titleGlowColor = Color.rgb(70, 160, 235),
            titleSpacing = 0.02f,
            subFonts = listOf("Montserrat", "Raleway", "Fira_Sans_Light"), subColor = Color.rgb(220, 236, 252), subSpacing = 0.45f,
            bodyFonts = listOf("Oswald", "Roboto_Condensed", "Fira_Sans_Condensed_Bold"), bodyColor = Color.rgb(236, 244, 252),
            fx = Fx(vignette = 0.55f, tint = Color.rgb(46, 111, 208), tintAmount = 0.18f, contrast = 1.08f,
                saturation = 0.9f, grain = 0.25f, snow = 0.5f, snowWind = 0.55f)
        ),
        Spec(
            titleFonts = listOf("Playfair_Display_SC_Bold", "Playfair_Display", "Old_Standard_TT_Bold"),
            titleColor = Color.rgb(255, 224, 140), titleMaterial = 1,
            titleOutlineW = 0.02f, titleOutlineColor = Color.rgb(64, 38, 8),
            titleGlowR = 0.03f, titleGlowColor = Color.rgb(255, 190, 80),
            titleSpacing = 0.06f,
            subFonts = listOf("Cormorant_Garamond", "Cormorant", "PT_Serif"), subColor = Color.rgb(232, 202, 134), subSpacing = 0.4f,
            bodyFonts = listOf("PT_Serif", "Merriweather", "Tinos"), bodyColor = Color.rgb(246, 236, 216),
            fx = Fx(vignette = 0.5f, tint = Color.rgb(200, 140, 40), tintAmount = 0.12f, contrast = 1.06f,
                saturation = 1f, grain = 0.2f)
        ),
        Spec(
            titleFonts = listOf("Unbounded", "Exo_2", "Russo_One"),
            titleColor = Color.WHITE, titleMaterial = 0,
            titleOutlineW = 0.02f, titleOutlineColor = Color.rgb(0, 230, 255),
            titleGlowR = 0.22f, titleGlowColor = Color.rgb(255, 45, 200),
            titleSpacing = 0.04f,
            subFonts = listOf("Jura", "Exo_2", "Montserrat"), subColor = Color.rgb(130, 240, 255), subSpacing = 0.5f,
            bodyFonts = listOf("Exo_2", "Jura", "Roboto_Condensed"), bodyColor = Color.WHITE,
            fx = Fx(vignette = 0.55f, tint = Color.rgb(150, 40, 220), tintAmount = 0.22f, contrast = 1.1f,
                saturation = 1.15f, grain = 0.12f)
        ),
        Spec(
            titleFonts = listOf("Dela_Gothic_One", "Russo_One", "Fira_Sans_Black"),
            titleColor = Color.WHITE, titleMaterial = 8,
            titleOutlineW = 0.02f, titleOutlineColor = Color.BLACK,
            titleGlowR = 0.08f, titleGlowColor = Color.rgb(255, 120, 20),
            titleSpacing = 0.02f,
            subFonts = listOf("Oswald", "Roboto_Condensed", "Montserrat"), subColor = Color.rgb(255, 176, 128), subSpacing = 0.4f,
            bodyFonts = listOf("Oswald", "Roboto_Condensed", "Fira_Sans_Condensed_Bold"), bodyColor = Color.rgb(240, 226, 216),
            fx = Fx(vignette = 0.7f, tint = Color.rgb(200, 30, 20), tintAmount = 0.16f, contrast = 1.12f,
                saturation = 0.95f, grain = 0.3f)
        ),
        Spec(
            titleFonts = listOf("Fira_Sans_Black", "PT_Sans_Bold", "Montserrat"),
            titleColor = Color.WHITE, titleMaterial = 0,
            titleOutlineW = 0f, titleOutlineColor = Color.BLACK,
            titleGlowR = 0f, titleGlowColor = Color.WHITE,
            titleSpacing = 0.08f,
            subFonts = listOf("Fira_Sans_Light", "Raleway", "PT_Sans"), subColor = Color.rgb(214, 214, 214), subSpacing = 0.5f,
            bodyFonts = listOf("Fira_Sans_Light", "PT_Sans", "Roboto"), bodyColor = Color.rgb(240, 240, 240),
            fx = Fx(vignette = 0.25f)
        )
    )

    /** Атмосфера стиля без надписей: для быстрых пресетов в окне эффектов. */
    fun fxOf(style: Int): Fx = specs[style.coerceIn(0, specs.lastIndex)].fx

    /** Ищет шрифт среди загруженных; без него остаётся системный жирный (или узкий для основного текста). */
    private fun pick(names: List<String>, fallbackSys: Int): Pair<Int, String> {
        for (n in names) {
            val e = Fonts.entries.firstOrNull { it.file == "$n.ttf" || it.file == "$n.otf" }
            if (e != null) return e.sys to e.file
        }
        return fallbackSys to ""
    }

    /** Текст, уже поставленный шаблоном: чтобы окно оформления показывало прежние значения. */
    fun existingText(p: Project, id: String): String? =
        (p.canvasLayers + p.panels.values.flatMap { it.layers }).firstOrNull { it.id == id }?.text

    private const val MEASURE = 4f

    private fun sizeOfMm(l: Layer): Pair<Float, Float> {
        val (w, h) = layerSize(l, MEASURE)
        return (w / MEASURE) to (h / MEASURE)
    }

    private fun fitWidth(l: Layer, maxW: Float, maxSize: Float): Layer {
        var cur = l.copy(sizeMm = maxSize)
        val w = sizeOfMm(cur).first
        if (w > maxW && w > 0f) cur = cur.copy(sizeMm = (maxSize * maxW / w).coerceAtLeast(2f))
        return cur
    }

    private fun titleLayer(s: Spec, text: String): Layer {
        val (sys, file) = pick(s.titleFonts, 1)
        return Layer(
            id = "tpl-title", kind = Kind.TEXT, text = text, upper = true,
            font = sys, fontFile = file, color = s.titleColor, textMaterial = s.titleMaterial,
            textOutlineWidth = s.titleOutlineW, textOutlineColor = s.titleOutlineColor,
            textGlowRadius = s.titleGlowR, textGlowColor = s.titleGlowColor,
            spacing = s.titleSpacing, align = 1
        )
    }

    private fun subLayer(s: Spec, text: String): Layer {
        val (sys, file) = pick(s.subFonts, 2)
        return Layer(
            id = "tpl-sub", kind = Kind.TEXT, text = text, upper = true,
            font = sys, fontFile = file, color = s.subColor, spacing = s.subSpacing, align = 1
        )
    }

    /** Название + подзаголовок на лицевой стороне. Координаты — в миллиметрах внутри области areaW×areaH, лицо начинается с [left]. */
    private fun frontLayers(s: Spec, f: DiscFormat, title: String, sub: String, areaW: Float, areaH: Float, left: Float): List<Layer> {
        val out = ArrayList<Layer>()
        if (title.isBlank()) return out
        val cx = left + f.frontW / 2f
        val t = fitWidth(titleLayer(s, title.trim()), f.frontW * 0.78f, minOf(f.frontH * 0.24f, 38f))
        val (_, th) = sizeOfMm(t)
        val ty = f.frontH * 0.42f
        out += t.copy(x = cx / areaW, y = ty / areaH)
        if (sub.isNotBlank()) {
            var sl = subLayer(s, sub.trim())
            sl = fitWidth(sl, f.frontW * 0.5f, minOf(t.sizeMm * 0.22f, 9f))
            val (sw, sh) = sizeOfMm(sl)
            val gapMm = sl.sizeMm * 0.9f
            val allowed = f.frontW * 0.82f
            val rules = ((allowed - sw - 2f * gapMm) / 2f / (sl.sizeMm * 10f)).coerceIn(0f, 1f)
            val sy = ty + th / 2f + f.frontH * 0.045f + sh / 2f
            out += sl.copy(x = cx / areaW, y = sy / areaH, textRules = rules)
        }
        return out
    }

    /** Описание на обороте: блок с выравниванием по левому краю, размер подбирается так, чтобы текст поместился. */
    private fun backLayer(s: Spec, f: DiscFormat, synopsis: String, areaW: Float, areaH: Float, left: Float): Layer? {
        if (synopsis.isBlank()) return null
        val (sys, file) = pick(s.bodyFonts, 2)
        val box = f.backW * 0.78f
        var size = f.backH * 0.026f
        var l = Layer(
            id = "tpl-synopsis", kind = Kind.TEXT, text = synopsis.trim(),
            font = sys, fontFile = file, color = s.bodyColor, align = 0, boxMm = box,
            spacing = 0.01f, textBlur = 1, sizeMm = size
        )
        var guard = 0
        while (sizeOfMm(l).second > f.backH * 0.66f && size > 2.2f && guard < 12) {
            size *= 0.92f
            l = l.copy(sizeMm = size)
            guard++
        }
        val (_, h) = sizeOfMm(l)
        val cx = left + f.backW / 2f
        val cy = f.backH * 0.09f + h / 2f
        return l.copy(x = cx / areaW, y = cy / areaH)
    }

    /** Надписи на корешке: название по вертикали и (если короткий) подзаголовок-год под ним. */
    private fun spineLayers(s: Spec, f: DiscFormat, title: String, sub: String, areaW: Float, areaH: Float): List<Layer> {
        val out = ArrayList<Layer>()
        if (title.isBlank() || f.spineW < 4f) return out
        val cx = (f.backW + f.spineW / 2f) / areaW
        var t = titleLayer(s, title.trim().replace("\n", " ")).copy(rot = 90f, textGlowRadius = s.titleGlowR * 0.6f)
        t = fitWidth(t.copy(sizeMm = f.spineW * 0.66f), f.backH * 0.46f, f.spineW * 0.66f)
        val (len, _) = sizeOfMm(t)
        val top = f.backH * 0.08f
        out += t.copy(x = cx, y = (top + len / 2f) / areaH)
        val year = sub.trim()
        if (year.isNotEmpty() && year.length <= 8) {
            var y = subLayer(s, year).copy(rot = 90f)
            y = fitWidth(y.copy(sizeMm = f.spineW * 0.42f), f.backH * 0.2f, f.spineW * 0.42f)
            val (yl, _) = sizeOfMm(y)
            out += y.copy(x = cx, y = (top + len + f.backH * 0.03f + yl / 2f) / areaH)
        }
        return out
    }

    fun apply(p: Project, style: Int, title: String, sub: String, synopsis: String): Project {
        val s = specs[style.coerceIn(0, specs.lastIndex)]
        val f = p.format
        fun notTpl(l: Layer) = !l.id.startsWith("tpl-")
        if (!f.tray) {
            val lay = f.layout()
            val shared = frontLayers(s, f, title, sub, lay.w, lay.h, f.backW + f.spineW) +
                listOfNotNull(backLayer(s, f, synopsis, lay.w, lay.h, 0f)) +
                spineLayers(s, f, title, sub, lay.w, lay.h)
            return p.copy(canvasLayers = p.canvasLayers.filter(::notTpl) + shared, fx = s.fx)
        }
        val front = frontLayers(s, f, title, sub, f.frontW, f.frontH, 0f)
        val back = listOfNotNull(backLayer(s, f, synopsis, f.backW, f.backH, 0f))
        val panels = p.panels.toMutableMap()
        panels[PanelId.FRONT] = p.panel(PanelId.FRONT).let { it.copy(layers = it.layers.filter(::notTpl) + front) }
        panels[PanelId.BACK] = p.panel(PanelId.BACK).let { it.copy(layers = it.layers.filter(::notTpl) + back) }
        return p.copy(panels = panels, fx = s.fx)
    }
}

/** Генерирует текстовое описание для ИИ-генератора картинок: правильные пропорции и расположение зон разворота. */
object PromptBuilder {
    val moods = listOf(
        "Хоррор / триллер" to "dark horror thriller mood, freezing blue and teal palette, blizzard, cinematic 1980s",
        "Sci-Fi" to "epic science fiction, vast scale, glowing technology, deep space colors",
        "Фэнтези" to "epic fantasy painting, magical atmosphere, dramatic volumetric light",
        "Боевик" to "high-octane action blockbuster, explosions, orange and teal color grading",
        "Драма / ретро" to "moody cinematic drama, film grain, muted warm tones, shallow depth of field",
        "Мультфильм" to "colorful 3D animated movie style, vibrant, friendly, rich lighting"
    )

    fun build(f: DiscFormat, subject: String, mood: String): String {
        val lay = f.layout()
        val total = lay.w
        fun pct(v: Float) = (v / total * 100f).roundToInt()
        val back = pct(f.backW)
        val spine = pct(f.spineW)
        val front = 100 - back - spine
        val ratio = "${fmt(lay.w)}:${fmt(lay.h)}"
        return "Panoramic wrap-around ${f.title} case cover artwork: ONE single continuous image, aspect ratio $ratio (wide horizontal), $mood, " +
            "ultra detailed, cinematic lighting. Subject: ${subject.trim().ifBlank { "movie scene" }}. " +
            "Composition from left to right: BACK COVER = left $back% of the width: atmospheric continuation of the scene, " +
            "the upper-left area calm and darker, left free for a block of text; " +
            "SPINE = narrow vertical strip of $spine% of the width in the exact middle: simple, low detail, smoothly continuing the neighbouring areas, no faces, no important objects; " +
            "FRONT COVER = right $front% of the width: the main hero subject and key visual, with calm empty space in the upper-middle reserved for the movie title. " +
            "The three zones must look like one connected scene. " +
            "NO text, NO letters, NO numbers, NO logos, NO watermark, NO borders, NO frames, NO case mockup."
    }
}
