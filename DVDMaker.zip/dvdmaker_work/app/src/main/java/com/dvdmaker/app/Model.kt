package com.dvdmaker.app

import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class PanelId(val title: String) { FRONT("Лицо"), SPINE("Корешок"), BACK("Оборот"), DISC("Диск") }

/** Печать на самом диске: холст 120×120 мм, печатная зона — кольцо 118 мм снаружи и 22 мм отверстие. */
const val DISC_SIZE_MM = 120f
const val DISC_OUTER_MM = 118f
const val DISC_INNER_MM = 22f

data class Place(val id: PanelId, val x: Float, val y: Float, val w: Float, val h: Float)
data class Group(val x: Float, val y: Float, val w: Float, val h: Float, val folds: List<Float>)
data class SheetLayout(val groups: List<Group>, val places: List<Place>, val w: Float, val h: Float)

fun fmt(v: Float): String = if (v % 1f == 0f) v.toInt().toString() else v.toString()

enum class DiscFormat(
    val title: String,
    val subtitle: String,
    val frontW: Float,
    val frontH: Float,
    val spineW: Float,
    val backW: Float,
    val backH: Float,
    val tray: Boolean
) {
    DVD("DVD", "Стандартный кейс", 129.5f, 183f, 14f, 129.5f, 183f, false),
    DVD_SLIM("DVD Slim", "Тонкий кейс", 129.5f, 183f, 7f, 129.5f, 183f, false),
    CD("CD", "Jewel case", 120f, 120f, 6.5f, 137f, 118f, true),
    BLURAY("Blu-ray", "Стандартный кейс", 129f, 150f, 11f, 129f, 150f, false);

    fun size(id: PanelId): Pair<Float, Float> = when (id) {
        PanelId.FRONT -> frontW to frontH
        PanelId.SPINE -> spineW to backH
        PanelId.BACK -> backW to backH
        PanelId.DISC -> DISC_SIZE_MM to DISC_SIZE_MM
    }

    /** Лист для печати на диске: один квадрат 120×120 мм. */
    fun discLayout(): SheetLayout = SheetLayout(
        listOf(Group(0f, 0f, DISC_SIZE_MM, DISC_SIZE_MM, emptyList())),
        listOf(Place(PanelId.DISC, 0f, 0f, DISC_SIZE_MM, DISC_SIZE_MM)),
        DISC_SIZE_MM, DISC_SIZE_MM
    )

    val specText: String
        get() = if (tray)
            "Лицо ${fmt(frontW)}×${fmt(frontH)} · трей ${fmt(spineW * 2 + backW)}×${fmt(backH)} мм"
        else
            "${fmt(backW + spineW + frontW)}×${fmt(backH)} мм · корешок ${fmt(spineW)} мм"

    fun layout(): SheetLayout {
        val h = maxOf(frontH, backH)
        if (!tray) {
            val w = backW + spineW + frontW
            val places = listOf(
                Place(PanelId.BACK, 0f, 0f, backW, backH),
                Place(PanelId.SPINE, backW, 0f, spineW, backH),
                Place(PanelId.FRONT, backW + spineW, 0f, frontW, frontH)
            )
            return SheetLayout(listOf(Group(0f, 0f, w, h, listOf(backW, backW + spineW))), places, w, h)
        }
        val trayW = spineW * 2 + backW
        val gap = 8f
        val ty = (h - backH) / 2f
        val fy = (h - frontH) / 2f
        val places = listOf(
            Place(PanelId.SPINE, 0f, ty, spineW, backH),
            Place(PanelId.BACK, spineW, ty, backW, backH),
            Place(PanelId.SPINE, spineW + backW, ty, spineW, backH),
            Place(PanelId.FRONT, trayW + gap, fy, frontW, frontH)
        )
        val groups = listOf(
            Group(0f, ty, trayW, backH, listOf(spineW, spineW + backW)),
            Group(trayW + gap, fy, frontW, frontH, emptyList())
        )
        return SheetLayout(groups, places, trayW + gap + frontW, h)
    }
}

val FrameNames = listOf("Нет", "Линия", "Двойная", "Скруглённая", "Пунктир", "Уголки", "Толстая+тонкая")

enum class Kind { TEXT, IMAGE, RECT, SYMBOL }

data class Layer(
    val id: String = UUID.randomUUID().toString(),
    val kind: Kind = Kind.TEXT,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val rot: Float = 0f,
    val text: String = "",
    val sizeMm: Float = 10f,
    val color: Int = Color.WHITE,
    val font: Int = 0,
    val fontFile: String = "",
    val italic: Boolean = false,
    val upper: Boolean = false,
    val shadow: Boolean = false,
    val spacing: Float = 0f,
    val align: Int = 1,
    val boxMm: Float = 0f,
    val path: String = "",
    val widthMm: Float = 50f,
    val alpha: Float = 1f,
    /** Рамка вокруг объекта: 0 — нет, остальное см. [FrameNames]. */
    val frame: Int = 0,
    val frameColor: Int = Color.WHITE,
    val frameWidthMm: Float = 0.6f,
    val framePadMm: Float = 2f
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("kind", kind.name)
        put("x", x.toDouble()); put("y", y.toDouble()); put("rot", rot.toDouble())
        put("text", text); put("sizeMm", sizeMm.toDouble()); put("color", color)
        put("font", font); put("fontFile", fontFile); put("italic", italic); put("upper", upper); put("shadow", shadow)
        put("spacing", spacing.toDouble()); put("align", align); put("boxMm", boxMm.toDouble())
        put("path", path); put("widthMm", widthMm.toDouble()); put("alpha", alpha.toDouble())
        put("frame", frame); put("frameColor", frameColor)
        put("frameWidthMm", frameWidthMm.toDouble()); put("framePadMm", framePadMm.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject) = Layer(
            id = o.optString("id", UUID.randomUUID().toString()),
            kind = runCatching { Kind.valueOf(o.optString("kind", "TEXT")) }.getOrDefault(Kind.TEXT),
            x = o.optDouble("x", 0.5).toFloat(), y = o.optDouble("y", 0.5).toFloat(),
            rot = o.optDouble("rot", 0.0).toFloat(),
            text = o.optString("text", ""), sizeMm = o.optDouble("sizeMm", 10.0).toFloat(),
            color = o.optInt("color", Color.WHITE), font = o.optInt("font", 0), fontFile = o.optString("fontFile", ""),
            italic = o.optBoolean("italic", false), upper = o.optBoolean("upper", false),
            shadow = o.optBoolean("shadow", false), spacing = o.optDouble("spacing", 0.0).toFloat(),
            align = o.optInt("align", 1), boxMm = o.optDouble("boxMm", 0.0).toFloat(),
            path = o.optString("path", ""), widthMm = o.optDouble("widthMm", 50.0).toFloat(),
            alpha = o.optDouble("alpha", 1.0).toFloat(),
            frame = o.optInt("frame", 0), frameColor = o.optInt("frameColor", Color.WHITE),
            frameWidthMm = o.optDouble("frameWidthMm", 0.6).toFloat(),
            framePadMm = o.optDouble("framePadMm", 2.0).toFloat()
        )
    }
}

data class PanelData(
    val c1: Int,
    val c2: Int,
    val angle: Int = 45,
    val layers: List<Layer> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("c1", c1); put("c2", c2); put("angle", angle)
        put("layers", JSONArray().also { a -> layers.forEach { a.put(it.toJson()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): PanelData {
            val arr = o.optJSONArray("layers") ?: JSONArray()
            val ls = (0 until arr.length()).map { Layer.fromJson(arr.getJSONObject(it)) }
            return PanelData(o.optInt("c1", Color.BLACK), o.optInt("c2", Color.BLACK), o.optInt("angle", 45), ls)
        }
    }
}

data class Project(
    val id: String,
    val name: String,
    val format: DiscFormat,
    val panels: Map<PanelId, PanelData>,
    val updated: Long,
    val foldShadow: Boolean = true
) {
    fun panel(id: PanelId): PanelData = panels[id] ?: PanelData(Color.BLACK, Color.BLACK)

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("format", format.name); put("updated", updated); put("foldShadow", foldShadow)
        put("panels", JSONObject().also { o -> panels.forEach { (k, v) -> o.put(k.name, v.toJson()) } })
    }

    fun imagePaths(): Set<String> =
        panels.values.flatMap { it.layers }.filter { it.kind == Kind.IMAGE }.map { it.path }.toSet()

    companion object {
        fun fromJson(o: JSONObject): Project {
            val po = o.getJSONObject("panels")
            val map = PanelId.values().associateWith { pid ->
                po.optJSONObject(pid.name)?.let { PanelData.fromJson(it) } ?: PanelData(Color.BLACK, Color.BLACK)
            }
            return Project(
                o.getString("id"), o.optString("name", "Проект"),
                DiscFormat.valueOf(o.getString("format")), map, o.optLong("updated", 0L),
                o.optBoolean("foldShadow", true)
            )
        }
    }
}

class GradientPreset(val name: String, val c1: Int, val c2: Int, val angle: Int)

val GradientPresets = listOf(
    GradientPreset("Ночь", 0xFF0F0C29.toInt(), 0xFF302B63.toInt(), 60),
    GradientPreset("Закат", 0xFFFF512F.toInt(), 0xFFDD2476.toInt(), 45),
    GradientPreset("Океан", 0xFF2193B0.toInt(), 0xFF6DD5ED.toInt(), 45),
    GradientPreset("Неон", 0xFF8E2DE2.toInt(), 0xFF4A00E0.toInt(), 60),
    GradientPreset("Золото", 0xFFF7971E.toInt(), 0xFFFFD200.toInt(), 45),
    GradientPreset("Лес", 0xFF134E5E.toInt(), 0xFF71B280.toInt(), 60),
    GradientPreset("Мята", 0xFF11998E.toInt(), 0xFF38EF7D.toInt(), 45),
    GradientPreset("Рубин", 0xFFCB2D3E.toInt(), 0xFFEF473A.toInt(), 60),
    GradientPreset("Королевский", 0xFF1A2980.toInt(), 0xFF26D0CE.toInt(), 45),
    GradientPreset("Уголь", 0xFF232526.toInt(), 0xFF414345.toInt(), 80),
    GradientPreset("Чёрный", 0xFF000000.toInt(), 0xFF111111.toInt(), 45),
    GradientPreset("Лёд", 0xFFE0EAFC.toInt(), 0xFFCFDEF3.toInt(), 60),
    GradientPreset("Белый", 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0)
)

val TextPalette = listOf(
    0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFFB547.toInt(), 0xFFFF4D8D.toInt(),
    0xFF8B6CFF.toInt(), 0xFF38BDF8.toInt(), 0xFF34D399.toInt(), 0xFFEF4444.toInt(),
    0xFFFACC15.toInt(), 0xFFE5E7EB.toInt(), 0xFF9CA3AF.toInt(), 0xFF1F2937.toInt()
)

/** Новый проект: чистые панели без заготовленных названий и заголовков — только фон по умолчанию. */
fun newProject(format: DiscFormat, name: String): Project {
    val pr = GradientPresets[0]
    fun bg() = PanelData(pr.c1, pr.c2, pr.angle)
    return Project(
        UUID.randomUUID().toString(), name, format,
        mapOf(PanelId.FRONT to bg(), PanelId.SPINE to bg(), PanelId.BACK to bg(), PanelId.DISC to bg()),
        System.currentTimeMillis()
    )
}
