package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cbrt
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Перенос цвета с лицевой стороны на оборот/корешок:
 * 1) палитра лица: уменьшение до 256 px → Lab → k-means (k=5) → dominant / secondary / accent;
 * 2) схема оборота: bg, accent, text (WCAG ≥ 4.5:1), градиент из двух главных цветов;
 * 3) применение: режим A (тонирование шаблона, рабочий по умолчанию) и режим B (Reinhard, отдельная функция).
 */
object ColorTransfer {
    enum class Mode { TONE, REINHARD }

    class Scheme(
        val dominant: Int, val secondary: Int, val accent: Int,
        val bg: Int, val bg2: Int, val text: Int, val accentText: Int
    )

    // ---------- Lab ----------
    /** Возвращает [L, a, b] (D65). */
    fun rgbToLab(c: Int, out: FloatArray = FloatArray(3)): FloatArray {
        fun lin(v: Int): Float { val s = v / 255f; return if (s <= 0.04045f) s / 12.92f else ((s + 0.055f) / 1.055f).pow(2.4f) }
        val r = lin((c shr 16) and 255); val g = lin((c shr 8) and 255); val b = lin(c and 255)
        val x = (0.4124564f * r + 0.3575761f * g + 0.1804375f * b) / 0.95047f
        val y = 0.2126729f * r + 0.7151522f * g + 0.0721750f * b
        val z = (0.0193339f * r + 0.1191920f * g + 0.9503041f * b) / 1.08883f
        fun f(t: Float) = if (t > 0.008856f) cbrt(t) else 7.787f * t + 16f / 116f
        val fx = f(x); val fy = f(y); val fz = f(z)
        out[0] = 116f * fy - 16f; out[1] = 500f * (fx - fy); out[2] = 200f * (fy - fz)
        return out
    }

    fun labToRgb(L: Float, a: Float, b: Float): Int {
        val fy = (L + 16f) / 116f; val fx = fy + a / 500f; val fz = fy - b / 200f
        fun inv(t: Float) = if (t * t * t > 0.008856f) t * t * t else (t - 16f / 116f) / 7.787f
        val x = inv(fx) * 0.95047f; val y = inv(fy); val z = inv(fz) * 1.08883f
        val r = 3.2404542f * x - 1.5371385f * y - 0.4985314f * z
        val g = -0.9692660f * x + 1.8760108f * y + 0.0415560f * z
        val bl = 0.0556434f * x - 0.2040259f * y + 1.0572252f * z
        fun gam(v: Float): Int {
            val c = v.coerceIn(0f, 1f)
            val s = if (c <= 0.0031308f) 12.92f * c else 1.055f * c.pow(1f / 2.4f) - 0.055f
            return (s * 255f).roundToInt().coerceIn(0, 255)
        }
        return (0xFF shl 24) or (gam(r) shl 16) or (gam(g) shl 8) or gam(bl)
    }

    private fun chroma(lab: FloatArray) = sqrt(lab[1] * lab[1] + lab[2] * lab[2])

    // ---------- WCAG ----------
    fun luminance(c: Int): Float {
        fun lin(v: Int): Float { val s = v / 255f; return if (s <= 0.03928f) s / 12.92f else ((s + 0.055f) / 1.055f).pow(2.4f) }
        return 0.2126f * lin((c shr 16) and 255) + 0.7152f * lin((c shr 8) and 255) + 0.0722f * lin(c and 255)
    }

    fun contrast(a: Int, b: Int): Float {
        val la = luminance(a); val lb = luminance(b)
        return (max(la, lb) + 0.05f) / (min(la, lb) + 0.05f)
    }

    // ---------- 1. палитра ----------
    fun kMeansLab(src: Bitmap, k: Int = 5, maxSide: Int = 256): List<Cluster2> {
        val sc = min(1f, maxSide / max(src.width, src.height).toFloat())
        val w = (src.width * sc).roundToInt().coerceAtLeast(1)
        val h = (src.height * sc).roundToInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small !== src) small.recycle()
        val n = px.size
        val pts = FloatArray(n * 3)
        val tmp = FloatArray(3)
        for (i in 0 until n) { rgbToLab(px[i], tmp); pts[i * 3] = tmp[0]; pts[i * 3 + 1] = tmp[1]; pts[i * 3 + 2] = tmp[2] }
        fun d2(i: Int, c: FloatArray): Float {
            val a = pts[i * 3] - c[0]; val b = pts[i * 3 + 1] - c[1]; val d = pts[i * 3 + 2] - c[2]
            return a * a + b * b + d * d
        }
        val kk = min(k, n)
        val cen = Array(kk) { FloatArray(3) }
        // k-means++ (детерминированно: каждый раз берём самую далёкую точку)
        cen[0] = floatArrayOf(pts[(n / 2) * 3], pts[(n / 2) * 3 + 1], pts[(n / 2) * 3 + 2])
        for (c in 1 until kk) {
            var bi = 0; var bd = -1f
            for (i in 0 until n) {
                var m = Float.MAX_VALUE
                for (j in 0 until c) m = min(m, d2(i, cen[j]))
                if (m > bd) { bd = m; bi = i }
            }
            cen[c] = floatArrayOf(pts[bi * 3], pts[bi * 3 + 1], pts[bi * 3 + 2])
        }
        val asg = IntArray(n)
        val cnt = IntArray(kk)
        repeat(14) {
            for (i in 0 until n) {
                var bj = 0; var bd = Float.MAX_VALUE
                for (j in 0 until kk) { val d = d2(i, cen[j]); if (d < bd) { bd = d; bj = j } }
                asg[i] = bj
            }
            val sum = Array(kk) { FloatArray(3) }
            cnt.fill(0)
            for (i in 0 until n) {
                val j = asg[i]; cnt[j]++
                sum[j][0] += pts[i * 3]; sum[j][1] += pts[i * 3 + 1]; sum[j][2] += pts[i * 3 + 2]
            }
            for (j in 0 until kk) if (cnt[j] > 0) for (a in 0..2) cen[j][a] = sum[j][a] / cnt[j]
        }
        return (0 until kk).filter { cnt[it] > 0 }.map { Cluster2(cen[it], cnt[it]) }.sortedByDescending { it.size }
    }

    class Cluster2(val lab: FloatArray, val size: Int)

    fun extractScheme(front: Bitmap): Scheme {
        val all = kMeansLab(front)
        // почти чёрные и почти белые кластеры — шум фона
        val kept = all.filter { c -> !(c.lab[0] < 9f || (c.lab[0] > 94f && sqrt(c.lab[1] * c.lab[1] + c.lab[2] * c.lab[2]) < 8f)) }
            .ifEmpty { all }
        fun rgb(c: Cluster2) = labToRgb(c.lab[0], c.lab[1], c.lab[2])
        val dom = kept[0]
        val sec = kept.getOrNull(1) ?: dom
        val acc = kept.maxByOrNull { chroma(it.lab) } ?: dom
        val dominant = rgb(dom); val secondary = rgb(sec); val accent = rgb(acc)
        val bg = readableBg(dom.lab)
        val bg2 = readableBg(sec.lab)
        val text = if (contrast(bg, 0xFFFFFFFF.toInt()) >= contrast(bg, 0xFF000000.toInt())) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
        // акцент для заголовков/рамок: подгоняем светлоту, чтобы он читался на bg
        val accentText = ensureContrast(accent, bg, 4.5f)
        return Scheme(dominant, secondary, accent, bg, bg2, text, accentText)
    }

    /** bg: насыщенность −25%, светлота сдвигается, пока на фоне читается белый или чёрный текст (≥ 4.5:1). */
    private fun readableBg(lab: FloatArray): Int {
        val a = lab[1] * 0.75f; val b = lab[2] * 0.75f
        var L = lab[0]
        var c = labToRgb(L, a, b)
        if (max(contrast(c, 0xFFFFFFFF.toInt()), contrast(c, 0xFF000000.toInt())) >= 4.5f) return c
        // средние тона читаются плохо с обоими — сдвигаем к ближайшему краю
        val dir = if (L >= 50f) 1f else -1f
        repeat(60) {
            L = (L + dir).coerceIn(0f, 100f)
            c = labToRgb(L, a, b)
            if (max(contrast(c, 0xFFFFFFFF.toInt()), contrast(c, 0xFF000000.toInt())) >= 4.5f) return c
        }
        return c
    }

    private fun ensureContrast(color: Int, bg: Int, target: Float): Int {
        if (contrast(color, bg) >= target) return color
        val lab = rgbToLab(color)
        val lighter = luminance(bg) < 0.4f
        var L = lab[0]
        var c = color
        repeat(100) {
            L = (L + if (lighter) 1f else -1f).coerceIn(0f, 100f)
            c = labToRgb(L, lab[1], lab[2])
            if (contrast(c, bg) >= target) return c
        }
        return if (lighter) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
    }

    // ---------- 3A. тонирование шаблона ----------
    private fun overlayCh(base: Int, top: Int): Int {
        val a = base / 255f; val b = top / 255f
        val r = if (a < 0.5f) 2f * a * b else 1f - 2f * (1f - a) * (1f - b)
        return (r * 255f).roundToInt().coerceIn(0, 255)
    }

    /**
     * Режим A. Градиент bg→bg2 (по высоте). Если задний шаблон — просто фон, результат и есть градиент.
     * Если на нём есть картинка ([template] != null), градиент смешивается с ней как overlay с прозрачностью 0.6.
     */
    fun tone(scheme: Scheme, w: Int, h: Int, template: Bitmap? = null, alpha: Float = 0.6f): Bitmap {
        val grad = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(grad).drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, h.toFloat(), scheme.bg, scheme.bg2, Shader.TileMode.CLAMP)
        })
        if (template == null) return Blur.gaussian(grad, sigmaFrac = 0.02f).also { grad.recycle() }
        val tp = IntArray(w * h); val gp = IntArray(w * h)
        template.getPixels(tp, 0, w, 0, 0, w, h); grad.getPixels(gp, 0, w, 0, 0, w, h)
        for (i in tp.indices) {
            val t = tp[i]; val g = gp[i]
            val r = overlayCh((t shr 16) and 255, (g shr 16) and 255)
            val gr = overlayCh((t shr 8) and 255, (g shr 8) and 255)
            val b = overlayCh(t and 255, g and 255)
            val tr = (t shr 16) and 255; val tg = (t shr 8) and 255; val tb = t and 255
            tp[i] = (0xFF shl 24) or ((tr + ((r - tr) * alpha)).toInt() shl 16) or
                ((tg + ((gr - tg) * alpha)).toInt() shl 8) or (tb + ((b - tb) * alpha)).toInt()
        }
        grad.recycle()
        return Bitmap.createBitmap(tp, w, h, Bitmap.Config.ARGB_8888)
    }

    // ---------- 3B. Reinhard color transfer ----------
    /** Совмещает среднее и стандартное отклонение каналов Lab у [target] с [reference]. Возвращает новый bitmap. */
    fun reinhard(target: Bitmap, reference: Bitmap): Bitmap {
        fun stats(b: Bitmap): Pair<FloatArray, FloatArray> {
            val s = max(1, (max(b.width, b.height) / 200))
            val tmp = FloatArray(3); val mean = FloatArray(3); val sq = FloatArray(3); var n = 0
            var y = 0
            while (y < b.height) {
                var x = 0
                while (x < b.width) {
                    rgbToLab(b.getPixel(x, y), tmp)
                    for (c in 0..2) { mean[c] += tmp[c]; sq[c] += tmp[c] * tmp[c] }
                    n++; x += s
                }
                y += s
            }
            val sd = FloatArray(3)
            for (c in 0..2) { mean[c] /= n; sd[c] = sqrt(max(sq[c] / n - mean[c] * mean[c], 1e-3f)) }
            return mean to sd
        }
        val (tm, ts) = stats(target)
        val (rm, rs) = stats(reference)
        val w = target.width; val h = target.height
        val px = IntArray(w * h)
        target.getPixels(px, 0, w, 0, 0, w, h)
        val lab = FloatArray(3)
        for (i in px.indices) {
            rgbToLab(px[i], lab)
            val L = (lab[0] - tm[0]) * (rs[0] / ts[0]) + rm[0]
            val a = (lab[1] - tm[1]) * (rs[1] / ts[1]) + rm[1]
            val b = (lab[2] - tm[2]) * (rs[2] / ts[2]) + rm[2]
            px[i] = labToRgb(L.coerceIn(0f, 100f), a, b)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Корешок: горизонтальный переход от цвета оборота (bg) к реальному цвету левого края лица — стык по цвету с передней. */
    fun spineBlend(left: Int, right: Int, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(b).drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, w.toFloat(), 0f, left, right, Shader.TileMode.CLAMP)
        })
        return b
    }
}
