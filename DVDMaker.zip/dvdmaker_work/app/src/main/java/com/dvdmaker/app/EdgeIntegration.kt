package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Color
import android.util.LruCache
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Полностью офлайн-обработка края PNG-вырезок: удаление цветной каймы (старый фон по контуру),
 * лёгкое сжатие края (choke) и Light Wrap. Цвет края восстанавливается по ближайшим «твёрдым»
 * пикселям самого объекта; тонкие детали (верёвка, волосы) не затрагиваются.
 */
object EdgeIntegration {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun process(
        path: String,
        source: Bitmap,
        amount: Float,
        lightWrap: Float = 0f,
        edgeRelight: Float = 0f,
        wrapColor: Int = Color.WHITE,
        lightX: Float = 0f,
        lightY: Float = 0f,
        dirAmount: Float = 0f,
        choke: Float = 0f
    ): Bitmap {
        val strength = amount.coerceIn(0f, 1f)
        val wrap = lightWrap.coerceIn(0f, 1f)
        val relight = edgeRelight.coerceIn(0f, 1f)
        val ck = choke.coerceIn(0f, 1f)
        if (strength <= 0.001f && wrap <= 0.001f && relight <= 0.001f && ck <= 0.001f || !source.hasAlpha()) return source
        val key = "$path|${(strength * 100).roundToInt()}|${(wrap * 100).roundToInt()}|${(relight * 100).roundToInt()}|${(ck * 100).roundToInt()}|$wrapColor|${(lightX * 20).roundToInt()}|${(lightY * 20).roundToInt()}|${(dirAmount * 20).roundToInt()}|${source.width}x${source.height}"
        cache.get(key)?.let { return it }

        val scale = minOf(1f, 1800f / max(source.width, source.height))
        val work = if (scale < 1f) Bitmap.createScaledBitmap(
            source, (source.width * scale).roundToInt().coerceAtLeast(1),
            (source.height * scale).roundToInt().coerceAtLeast(1), true
        ) else source
        val w = work.width
        val h = work.height
        val pixels = IntArray(w * h)
        work.getPixels(pixels, 0, w, 0, 0, w, h)
        if (work !== source) work.recycle()
        val original = pixels.copyOf()
        val maxDim = max(w, h)
        val alphaB = ByteArray(w * h) { (original[it] ushr 24).toByte() }

        // --- Очистка каймы: «твёрдое ядро» = пиксели, вокруг которых на радиусе r всё непрозрачно.
        val r = max(3, maxDim / 300)
        val rs = r + 2
        val core: BooleanArray? = if (strength > 0.001f) {
            val er = minFilter(alphaB, w, h, r)
            BooleanArray(w * h) { (er[it].toInt() and 255) >= 247 }
        } else null

        val blurR = max(3, maxDim / 220)
        val step = max(1, blurR / 2)
        val blurA = if (wrap > 0.001f || relight > 0.001f)
            boxBlur(FloatArray(w * h) { (original[it] ushr 24) / 255f }, w, h, blurR) else FloatArray(0)
        val wr = Color.red(wrapColor).toFloat()
        val wg = Color.green(wrapColor).toFloat()
        val wb = Color.blue(wrapColor).toFloat()

        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val p = original[i]
            val a = p ushr 24
            if (a < 12) continue
            var current = p

            if (core != null && !core[i]) {
                var best = Int.MAX_VALUE
                val y0 = max(0, y - rs); val y1 = minOf(h - 1, y + rs)
                val x0 = max(0, x - rs); val x1 = minOf(w - 1, x + rs)
                for (ny in y0..y1) for (nx in x0..x1) {
                    if (!core[ny * w + nx]) continue
                    val dx = nx - x; val dy = ny - y
                    val d2 = dx * dx + dy * dy
                    if (d2 < best) best = d2
                }
                if (best != Int.MAX_VALUE) {
                    val dc = kotlin.math.sqrt(best.toFloat())
                    val lim = (dc + 1.5f) * (dc + 1.5f)
                    var sr = 0; var sg = 0; var sb = 0; var n = 0
                    for (ny in y0..y1) for (nx in x0..x1) {
                        if (!core[ny * w + nx]) continue
                        val dx = nx - x; val dy = ny - y
                        if (dx * dx + dy * dy > lim) continue
                        val c = original[ny * w + nx]
                        sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255; n++
                    }
                    if (n > 0) {
                        val distW = (dc / (r + 1f)).coerceIn(0f, 1f)
                        val fringe = 1f - a / 255f
                        val k = (strength * max(distW, fringe)).coerceIn(0f, 1f)
                        val br = (p shr 16) and 255; val bg = (p shr 8) and 255; val bb = p and 255
                        val nr = (br + (sr / n - br) * k).roundToInt().coerceIn(0, 255)
                        val ng = (bg + (sg / n - bg) * k).roundToInt().coerceIn(0, 255)
                        val nb = (bb + (sb / n - bb) * k).roundToInt().coerceIn(0, 255)
                        current = (a shl 24) or (nr shl 16) or (ng shl 8) or nb
                    }
                }
            }

            // Light Wrap / подсветка: плавная внутренняя полоса по размытой альфе, только по твёрдым пикселям.
            if ((wrap > 0.001f || relight > 0.001f) && a >= 160) {
                val ba = blurA[i]
                val solid = ((a - 160) / 80f).coerceIn(0f, 1f)
                var innerBand = ((1f - ba) * 2f).coerceIn(0f, 1f) * solid
                if (dirAmount > 0.001f && innerBand > 0f) {
                    val gx = blurA[y * w + max(0, x - step)] - blurA[y * w + minOf(w - 1, x + step)]
                    val gy = blurA[max(0, y - step) * w + x] - blurA[minOf(h - 1, y + step) * w + x]
                    val len = kotlin.math.sqrt(gx * gx + gy * gy)
                    val facing = if (len < 0.004f) 0.5f else ((gx * lightX + gy * lightY) / len).coerceIn(0f, 1f)
                    innerBand *= ((1f - dirAmount) + dirAmount * facing * 1.4f).coerceIn(0.05f, 1.2f)
                }
                var cr = ((current shr 16) and 255).toFloat()
                var cg = ((current shr 8) and 255).toFloat()
                var cb = (current and 255).toFloat()
                if (wrap > 0.001f) {
                    val t = (wrap * innerBand * 0.42f).coerceIn(0f, 0.42f)
                    cr += (wr - cr) * t; cg += (wg - cg) * t; cb += (wb - cb) * t
                }
                if (relight > 0.001f) {
                    val lift = (relight * innerBand * 22f).coerceIn(0f, 22f)
                    cr += lift; cg += lift; cb += lift
                }
                current = (a shl 24) or (cr.roundToInt().coerceIn(0, 255) shl 16) or
                    (cg.roundToInt().coerceIn(0, 255) shl 8) or cb.roundToInt().coerceIn(0, 255)
            }
            pixels[i] = current
        }

        // --- Сжатие края: альфа слегка «съедается» по контуру и сглаживается — убирает остаточный светлый след.
        if (ck > 0.001f) {
            val rc = max(1, maxDim / 900)
            val mn = minFilter(alphaB, w, h, rc)
            val soft = boxBlur(FloatArray(w * h) { (mn[it].toInt() and 255).toFloat() }, w, h, 1)
            for (i in 0 until w * h) {
                val a0 = (alphaB[i].toInt() and 255).toFloat()
                val na = (a0 * (1f - ck) + minOf(a0, soft[i]) * ck).roundToInt().coerceIn(0, 255)
                pixels[i] = (na shl 24) or (pixels[i] and 0x00FFFFFF)
            }
        }

        val corrected = Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
        val result = if (corrected.width != source.width || corrected.height != source.height) {
            val enlarged = Bitmap.createScaledBitmap(corrected, source.width, source.height, true)
            corrected.recycle()
            if (ck <= 0.001f) {
                // Без сжатия края исходная альфа сохраняется байт в байт.
                val row = IntArray(source.width)
                val alphaRow = IntArray(source.width)
                for (y in 0 until source.height) {
                    enlarged.getPixels(row, 0, source.width, 0, y, source.width, 1)
                    source.getPixels(alphaRow, 0, source.width, 0, y, source.width, 1)
                    for (x in row.indices) row[x] = (alphaRow[x] and -0x1000000) or (row[x] and 0x00FFFFFF)
                    enlarged.setPixels(row, 0, source.width, 0, y, source.width, 1)
                }
            }
            enlarged
        } else corrected
        cache.put(key, result)
        return result
    }

    private fun minFilter(src: ByteArray, w: Int, h: Int, r: Int): ByteArray {
        val tmp = ByteArray(w * h)
        val out = ByteArray(w * h)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                var m = 255
                for (k in max(0, x - r)..minOf(w - 1, x + r)) {
                    val v = src[row + k].toInt() and 255
                    if (v < m) m = v
                }
                tmp[row + x] = m.toByte()
            }
        }
        for (x in 0 until w) {
            for (y in 0 until h) {
                var m = 255
                for (k in max(0, y - r)..minOf(h - 1, y + r)) {
                    val v = tmp[k * w + x].toInt() and 255
                    if (v < m) m = v
                }
                out[y * w + x] = m.toByte()
            }
        }
        return out
    }

    private fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(w * h)
        val out = FloatArray(w * h)
        val d = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            var sum = 0f
            for (k in -r..r) sum += src[y * w + k.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[y * w + x] = sum / d
                sum += src[y * w + (x + r + 1).coerceIn(0, w - 1)] - src[y * w + (x - r).coerceIn(0, w - 1)]
            }
        }
        for (x in 0 until w) {
            var sum = 0f
            for (k in -r..r) sum += tmp[k.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = sum / d
                sum += tmp[(y + r + 1).coerceIn(0, h - 1) * w + x] - tmp[(y - r).coerceIn(0, h - 1) * w + x]
            }
        }
        return out
    }
}
