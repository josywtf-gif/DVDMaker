package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Color
import android.util.LruCache
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Полностью офлайн-очистка цветной каймы у PNG-вырезок.
 * Альфа-канал не меняется: корректируется только RGB полупрозрачных краевых пикселей.
 * Цвет края восстанавливается по ближайшим непрозрачным пикселям самого объекта.
 */
object EdgeIntegration {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun process(
        path: String,
        source: Bitmap,
        amount: Float,
        lightWrap: Float = 0f,
        edgeRelight: Float = 0f,
        wrapColor: Int = Color.WHITE,
        lightX: Float = 0f,
        lightY: Float = 0f,
        dirAmount: Float = 0f
    ): Bitmap {
        val strength = amount.coerceIn(0f, 1f)
        val wrap = lightWrap.coerceIn(0f, 1f)
        val relight = edgeRelight.coerceIn(0f, 1f)
        if (strength <= 0.001f && wrap <= 0.001f && relight <= 0.001f || !source.hasAlpha()) return source
        val key = "$path|${(strength * 100).roundToInt()}|${(wrap * 100).roundToInt()}|${(relight * 100).roundToInt()}|$wrapColor|${(lightX * 20).roundToInt()}|${(lightY * 20).roundToInt()}|${(dirAmount * 20).roundToInt()}|${source.width}x${source.height}"
        cache.get(key)?.let { return it }

        // Work on a bounded working copy on very large images to keep memory predictable.
        val scale = minOf(1f, 1800f / max(source.width, source.height))
        val work = if (scale < 1f) Bitmap.createScaledBitmap(
            source, (source.width * scale).roundToInt().coerceAtLeast(1),
            (source.height * scale).roundToInt().coerceAtLeast(1), true
        ) else source
        val w = work.width
        val h = work.height
        val pixels = IntArray(w * h)
        work.getPixels(pixels, 0, w, 0, 0, w, h)
        if (work !== source) work.recycle()
        val original = pixels.copyOf()
        val R = max(3, max(w, h) / 220)
        val step = max(1, R / 2)
        val blurA = if (wrap > 0.001f || relight > 0.001f) boxBlur(FloatArray(w * h) { (original[it] ushr 24) / 255f }, w, h, R) else FloatArray(0)
        val radius = 5
        val wr = Color.red(wrapColor).toFloat()
        val wg = Color.green(wrapColor).toFloat()
        val wb = Color.blue(wrapColor).toFloat()

        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val p = original[i]
            val a = p ushr 24
            // Fully transparent pixels are irrelevant to visible compositing.
            if (a < 12) continue

            var current = p
            if (strength > 0.001f && a <= 246) {
                var best = -1
            var bestScore = Float.POSITIVE_INFINITY
                for (r in 1..radius) {
                    val y0 = max(0, y - r)
                val y1 = minOf(h - 1, y + r)
                val x0 = max(0, x - r)
                val x1 = minOf(w - 1, x + r)
                    for (ny in y0..y1) for (nx in x0..x1) {
                        val dx = nx - x
                        val dy = ny - y
                        val d2 = dx * dx + dy * dy
                        if (d2 == 0 || d2 > r * r) continue
                        val candidate = original[ny * w + nx]
                        val ca = candidate ushr 24
                        if (ca < 238) continue
                        val score = d2.toFloat() + (255 - ca) * 0.002f
                        if (score < bestScore) { bestScore = score; best = candidate }
                    }
                    if (best >= 0) break
                }
                if (best >= 0) {
                    val edgeWeight = ((1f - a / 255f) * strength).coerceIn(0f, 1f)
                    val br = (current shr 16) and 255
                    val bg = (current shr 8) and 255
                    val bb = current and 255
                    val fr = (best shr 16) and 255
                    val fg = (best shr 8) and 255
                    val fb = best and 255
                    val r = (br + (fr - br) * edgeWeight).roundToInt().coerceIn(0, 255)
                    val g = (bg + (fg - bg) * edgeWeight).roundToInt().coerceIn(0, 255)
                    val b = (bb + (fb - bb) * edgeWeight).roundToInt().coerceIn(0, 255)
                    current = (a shl 24) or (r shl 16) or (g shl 8) or b
                }
            }

            // Плавная внутренняя полоса по размытой альфе (без «ступенек» и рваных кусков).
            // Полупрозрачную кайму (a < ~160) не трогаем: именно она давала светлые обрезки.
            if ((wrap > 0.001f || relight > 0.001f) && a >= 160) {
                val ba = blurA[i]
                val solid = ((a - 160) / 80f).coerceIn(0f, 1f)
                var innerBand = ((1f - ba) * 2f).coerceIn(0f, 1f) * solid
                if (dirAmount > 0.001f && innerBand > 0f) {
                    val gx = blurA[y * w + max(0, x - step)] - blurA[y * w + minOf(w - 1, x + step)]
                    val gy = blurA[max(0, y - step) * w + x] - blurA[minOf(h - 1, y + step) * w + x]
                    val len = kotlin.math.sqrt(gx * gx + gy * gy)
                    val facing = if (len < 0.004f) 0.5f else ((gx * lightX + gy * lightY) / len).coerceIn(0f, 1f)
                    innerBand *= ((1f - dirAmount) + dirAmount * facing * 1.4f).coerceIn(0.05f, 1.2f)
                }
                var cr = ((current shr 16) and 255).toFloat()
                var cg = ((current shr 8) and 255).toFloat()
                var cb = (current and 255).toFloat()
                if (wrap > 0.001f) {
                    val t = (wrap * innerBand * 0.42f).coerceIn(0f, 0.42f)
                    cr += (wr - cr) * t
                    cg += (wg - cg) * t
                    cb += (wb - cb) * t
                }
                if (relight > 0.001f) {
                    // Subtle edge lift; capped to avoid a synthetic bright outline.
                    val lift = (relight * innerBand * 22f).coerceIn(0f, 22f)
                    cr += lift; cg += lift; cb += lift
                }
                current = (a shl 24) or (cr.roundToInt().coerceIn(0, 255) shl 16) or
                    (cg.roundToInt().coerceIn(0, 255) shl 8) or cb.roundToInt().coerceIn(0, 255)
            }
            pixels[i] = current
        }

        val corrected = Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
        val result = if (corrected.width != source.width || corrected.height != source.height) {
            val enlarged = Bitmap.createScaledBitmap(corrected, source.width, source.height, true)
            corrected.recycle()
            // Keep the original alpha channel byte-for-byte even when RGB was processed at a reduced working size.
            val row = IntArray(source.width)
            val alphaRow = IntArray(source.width)
            for (y in 0 until source.height) {
                enlarged.getPixels(row, 0, source.width, 0, y, source.width, 1)
                source.getPixels(alphaRow, 0, source.width, 0, y, source.width, 1)
                for (x in row.indices) row[x] = (alphaRow[x] and -0x1000000) or (row[x] and 0x00FFFFFF)
                enlarged.setPixels(row, 0, source.width, 0, y, source.width, 1)
            }
            enlarged
        } else corrected
        cache.put(key, result)
        return result
    }

    private fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(w * h)
        val out = FloatArray(w * h)
        val d = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            var sum = 0f
            for (k in -r..r) sum += src[y * w + k.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[y * w + x] = sum / d
                sum += src[y * w + (x + r + 1).coerceIn(0, w - 1)] - src[y * w + (x - r).coerceIn(0, w - 1)]
            }
        }
        for (x in 0 until w) {
            var sum = 0f
            for (k in -r..r) sum += tmp[k.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = sum / d
                sum += tmp[(y + r + 1).coerceIn(0, h - 1) * w + x] - tmp[(y - r).coerceIn(0, h - 1) * w + x]
            }
        }
        return out
    }
}
