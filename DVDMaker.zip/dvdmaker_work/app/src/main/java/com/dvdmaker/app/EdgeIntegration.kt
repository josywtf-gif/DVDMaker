package com.dvdmaker.app

import android.graphics.Bitmap
import android.graphics.Color
import android.util.LruCache
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Полностью офлайн-очистка цветной каймы у PNG-вырезок.
 * Альфа-канал не меняется: корректируется только RGB полупрозрачных краевых пикселей.
 * Цвет края восстанавливается по ближайшим непрозрачным пикселям самого объекта.
 */
object EdgeIntegration {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun process(
        path: String,
        source: Bitmap,
        amount: Float,
        lightWrap: Float = 0f,
        edgeRelight: Float = 0f,
        wrapColor: Int = Color.WHITE,
        lightX: Float = 0f,
        lightY: Float = 0f,
        dirAmount: Float = 0f
    ): Bitmap {
        val strength = amount.coerceIn(0f, 1f)
        val wrap = lightWrap.coerceIn(0f, 1f)
        val relight = edgeRelight.coerceIn(0f, 1f)
        if (strength <= 0.001f && wrap <= 0.001f && relight <= 0.001f || !source.hasAlpha()) return source
        val key = "$path|${(strength * 100).roundToInt()}|${(wrap * 100).roundToInt()}|${(relight * 100).roundToInt()}|$wrapColor|${(lightX * 20).roundToInt()}|${(lightY * 20).roundToInt()}|${(dirAmount * 20).roundToInt()}|${source.width}x${source.height}"
        cache.get(key)?.let { return it }

        // Work on a bounded working copy on very large images to keep memory predictable.
        val scale = minOf(1f, 1800f / max(source.width, source.height))
        val work = if (scale < 1f) Bitmap.createScaledBitmap(
            source, (source.width * scale).roundToInt().coerceAtLeast(1),
            (source.height * scale).roundToInt().coerceAtLeast(1), true
        ) else source
        val w = work.width
        val h = work.height
        val pixels = IntArray(w * h)
        work.getPixels(pixels, 0, w, 0, 0, w, h)
        if (work !== source) work.recycle()
        val original = pixels.copyOf()
        val radius = 5
        val wr = Color.red(wrapColor).toFloat()
        val wg = Color.green(wrapColor).toFloat()
        val wb = Color.blue(wrapColor).toFloat()

        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            val p = original[i]
            val a = p ushr 24
            // Fully transparent pixels are irrelevant to visible compositing.
            if (a < 12) continue

            var current = p
            if (strength > 0.001f && a <= 246) {
                var best = -1
            var bestScore = Float.POSITIVE_INFINITY
                for (r in 1..radius) {
                    val y0 = max(0, y - r)
                val y1 = minOf(h - 1, y + r)
                val x0 = max(0, x - r)
                val x1 = minOf(w - 1, x + r)
                    for (ny in y0..y1) for (nx in x0..x1) {
                        val dx = nx - x
                        val dy = ny - y
                        val d2 = dx * dx + dy * dy
                        if (d2 == 0 || d2 > r * r) continue
                        val candidate = original[ny * w + nx]
                        val ca = candidate ushr 24
                        if (ca < 238) continue
                        val score = d2.toFloat() + (255 - ca) * 0.002f
                        if (score < bestScore) { bestScore = score; best = candidate }
                    }
                    if (best >= 0) break
                }
                if (best >= 0) {
                    val edgeWeight = ((1f - a / 255f) * strength).coerceIn(0f, 1f)
                    val br = (current shr 16) and 255
                    val bg = (current shr 8) and 255
                    val bb = current and 255
                    val fr = (best shr 16) and 255
                    val fg = (best shr 8) and 255
                    val fb = best and 255
                    val r = (br + (fr - br) * edgeWeight).roundToInt().coerceIn(0, 255)
                    val g = (bg + (fg - bg) * edgeWeight).roundToInt().coerceIn(0, 255)
                    val b = (bb + (fb - bb) * edgeWeight).roundToInt().coerceIn(0, 255)
                    current = (a shl 24) or (r shl 16) or (g shl 8) or b
                }
            }

            // Estimate an inner silhouette band from nearby transparency. Effects are
            // confined to this band, so the face, clothing and solid interior stay intact.
            if (wrap > 0.001f || relight > 0.001f) {
                var minAlpha = 255
                for (ny in max(0, y - 2)..minOf(h - 1, y + 2)) {
                    for (nx in max(0, x - 2)..minOf(w - 1, x + 2)) {
                        if (nx == x && ny == y) continue
                        minAlpha = minOf(minAlpha, original[ny * w + nx] ushr 24)
                    }
                }
                val coverage = a / 255f
                val edgeBand = (coverage * (1f - minAlpha / 255f)).coerceIn(0f, 1f)
                var innerBand = (edgeBand * coverage).coerceIn(0f, 1f)
                if (dirAmount > 0.001f && innerBand > 0f) {
                    // Внешняя нормаль края (в сторону прозрачности) против направления света фона.
                    val gx = (original[y * w + max(0, x - 2)] ushr 24) - (original[y * w + minOf(w - 1, x + 2)] ushr 24)
                    val gy = (original[max(0, y - 2) * w + x] ushr 24) - (original[minOf(h - 1, y + 2) * w + x] ushr 24)
                    val len = kotlin.math.sqrt((gx * gx + gy * gy).toFloat())
                    val facing = if (len < 1f) 0.5f else ((gx * lightX + gy * lightY) / len).coerceIn(0f, 1f)
                    innerBand *= ((1f - dirAmount) + dirAmount * facing * 1.6f).coerceIn(0.05f, 1.3f)
                }
                var cr = ((current shr 16) and 255).toFloat()
                var cg = ((current shr 8) and 255).toFloat()
                var cb = (current and 255).toFloat()
                if (wrap > 0.001f) {
                    val t = (wrap * innerBand * 0.42f).coerceIn(0f, 0.42f)
                    cr += (wr - cr) * t
                    cg += (wg - cg) * t
                    cb += (wb - cb) * t
                }
                if (relight > 0.001f) {
                    // Subtle edge lift; capped to avoid a synthetic bright outline.
                    val lift = (relight * innerBand * 22f).coerceIn(0f, 22f)
                    cr += lift; cg += lift; cb += lift
                }
                current = (a shl 24) or (cr.roundToInt().coerceIn(0, 255) shl 16) or
                    (cg.roundToInt().coerceIn(0, 255) shl 8) or cb.roundToInt().coerceIn(0, 255)
            }
            pixels[i] = current
        }

        val corrected = Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
        val result = if (corrected.width != source.width || corrected.height != source.height) {
            val enlarged = Bitmap.createScaledBitmap(corrected, source.width, source.height, true)
            corrected.recycle()
            // Keep the original alpha channel byte-for-byte even when RGB was processed at a reduced working size.
            val row = IntArray(source.width)
            val alphaRow = IntArray(source.width)
            for (y in 0 until source.height) {
                enlarged.getPixels(row, 0, source.width, 0, y, source.width, 1)
                source.getPixels(alphaRow, 0, source.width, 0, y, source.width, 1)
                for (x in row.indices) row[x] = (alphaRow[x] and -0x1000000) or (row[x] and 0x00FFFFFF)
                enlarged.setPixels(row, 0, source.width, 0, y, source.width, 1)
            }
            enlarged
        } else corrected
        cache.put(key, result)
        return result
    }
}
