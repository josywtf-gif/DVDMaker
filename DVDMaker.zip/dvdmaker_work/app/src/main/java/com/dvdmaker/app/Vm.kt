package com.dvdmaker.app

import android.app.Application
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

private class SpineRes(val path: String, val c1: Int, val c2: Int, val widthMm: Float)

class AppVm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    var projects by mutableStateOf(store.loadAll())
    var current by mutableStateOf<Project?>(null)
    var panel by mutableStateOf(PanelId.FRONT)
    var overview by mutableStateOf(false)
    var selected by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)
    var checker by mutableStateOf(false)
    /** Направляющие, видимые только пока объект двигают. */
    var guideLines by mutableStateOf<List<GuideLine>>(emptyList())
        private set

    private val prefs = app.getSharedPreferences("dvdmaker_prefs", android.content.Context.MODE_PRIVATE)
    /** Последний выбранный шрифт: применяется ко всем новым текстам. */
    private var lastFont = prefs.getInt("font_sys", 0)
    private var lastFontFile = prefs.getString("font_file", "") ?: ""
    private var lastItalic = prefs.getBoolean("font_italic", false)

    fun rememberFont(sys: Int, file: String, italic: Boolean) {
        lastFont = sys; lastFontFile = file; lastItalic = italic
        prefs.edit().putInt("font_sys", sys).putString("font_file", file).putBoolean("font_italic", italic).apply()
    }

    /** Выбор шрифта для слоя: применяется к слою и запоминается для следующих текстов. */
    fun applyFont(layerId: String, sys: Int, file: String, italic: Boolean? = null) {
        val it0 = current?.panel(panel)?.layers?.firstOrNull { it.id == layerId }
        val ital = italic ?: it0?.italic ?: false
        updateLayer(layerId) { it.copy(font = sys, fontFile = file, italic = ital) }
        rememberFont(sys, file, ital)
    }

    var update by mutableStateOf<UpdateInfo?>(null)
    var checking by mutableStateOf(false)
    var progress by mutableStateOf<Float?>(null)
    var updateMsg by mutableStateOf<String?>(null)

    private val undo = ArrayList<Project>()
    private var lastKey = ""
    private var lastEdit = 0L
    private var saveJob: Job? = null

    fun create(format: DiscFormat) {
        val p = newProject(format, "Новый ${format.title}")
        store.save(p)
        projects = store.loadAll()
        enter(p)
    }

    fun open(p: Project) = enter(p)

    /** Создаёт проект из готового Project (например, после подгонки готовой обложки) и открывает его. */
    fun createFrom(p: Project) {
        store.save(p)
        projects = store.loadAll()
        checker = false
        enter(p)
    }

    fun toggleFoldShadow() = edit { it.copy(foldShadow = !it.foldShadow) }

    /** Диск: берёт фон и главное изображение с лицевой стороны и подгоняет под круг диска. */
    fun discFromFront() {
        val p = current ?: return
        val front = p.panel(PanelId.FRONT)
        val img = front.layers.firstOrNull { it.kind == Kind.IMAGE }
        updatePanel(PanelId.DISC) { d ->
            var nd = d.copy(c1 = front.c1, c2 = front.c2, angle = front.angle)
            if (img != null) {
                val b = Bitmaps.get(img.path)
                val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                val layer = img.copy(
                    id = java.util.UUID.randomUUID().toString(),
                    x = 0.5f, y = 0.5f, rot = 0f, alpha = 1f,
                    widthMm = max(DISC_SIZE_MM, DISC_SIZE_MM * aspect)
                )
                nd = nd.copy(layers = listOf(layer) + nd.layers.filter { it.kind != Kind.IMAGE })
            }
            nd
        }
        selected = null
    }

    private fun enter(p: Project) {
        current = p; panel = PanelId.FRONT; overview = false; selected = null
        undo.clear(); canUndo = false; lastKey = ""
    }

    fun close() {
        flush()
        current = null
        selected = null
        projects = store.loadAll()
    }

    fun delete(p: Project) {
        store.delete(p)
        projects = store.loadAll()
    }

    fun flush() {
        saveJob?.cancel()
        current?.let { store.save(it) }
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(500)
            current?.let { p -> withContext(Dispatchers.IO) { store.save(p) } }
        }
    }

    fun edit(key: String = "", block: (Project) -> Project) {
        val p = current ?: return
        val now = SystemClock.elapsedRealtime()
        if (key.isEmpty() || key != lastKey || now - lastEdit > 1200) {
            undo.add(p)
            if (undo.size > 40) undo.removeAt(0)
            canUndo = true
        }
        lastKey = key
        lastEdit = now
        current = block(p).copy(updated = System.currentTimeMillis())
        scheduleSave()
    }

    fun undoLast() {
        if (undo.isEmpty()) return
        current = undo.removeAt(undo.lastIndex)
        canUndo = undo.isNotEmpty()
        lastKey = ""
        val p = current
        if (p != null && selected != null &&
            p.panel(panel).layers.none { it.id == selected }) selected = null
        scheduleSave()
    }

    fun rename(name: String) = edit { it.copy(name = name.ifBlank { it.name }) }

    fun updatePanel(id: PanelId, key: String = "", f: (PanelData) -> PanelData) =
        edit(key) { p -> p.copy(panels = p.panels + (id to f(p.panel(id)))) }

    fun updateLayer(layerId: String, key: String = "", f: (Layer) -> Layer) =
        updatePanel(panel, key) { pd ->
            pd.copy(layers = pd.layers.map { if (it.id == layerId) f(it) else it })
        }

    fun addLayer(l: Layer) {
        updatePanel(panel) { it.copy(layers = it.layers + l) }
        selected = l.id
    }

    fun addText() {
        val p = current ?: return
        val (w, h) = p.format.size(panel)
        val spine = panel == PanelId.SPINE
        addLayer(
            Layer(
                kind = Kind.TEXT, text = "Текст",
                sizeMm = if (spine) minOf(w * 0.55f, 7f) else 9f,
                font = lastFont, fontFile = lastFontFile, italic = lastItalic,
                rot = if (spine) 90f else 0f
            )
        )
    }

    fun addRect() {
        val p = current ?: return
        val (w, _) = p.format.size(panel)
        addLayer(Layer(kind = Kind.RECT, widthMm = w * 0.6f, sizeMm = 8f, color = 0xFFFFB547.toInt()))
    }

    fun removeSelected() {
        val id = selected ?: return
        updatePanel(panel) { it.copy(layers = it.layers.filter { l -> l.id != id }) }
        selected = null
    }

    fun duplicateSelected() {
        val id = selected ?: return
        val src = current?.panel(panel)?.layers?.firstOrNull { it.id == id } ?: return
        addLayer(src.copy(id = java.util.UUID.randomUUID().toString(),
            x = (src.x + 0.05f).coerceAtMost(0.95f), y = (src.y + 0.05f).coerceAtMost(0.95f)))
    }

    fun moveSelected(up: Boolean) {
        val id = selected ?: return
        updatePanel(panel) { pd ->
            val list = pd.layers.toMutableList()
            val i = list.indexOfFirst { it.id == id }
            val j = if (up) i + 1 else i - 1
            if (i >= 0 && j in list.indices) {
                val t = list[i]; list[i] = list[j]; list[j] = t
            }
            pd.copy(layers = list)
        }
    }

    /**
     * Двигает/масштабирует/вращает слой. [rawX]/[rawY]/[rawRot] — «сырое» положение пальца (без привязки),
     * поэтому объект можно спокойно вывести из примагничивания. Возвращённая привязка рисует направляющие.
     */
    fun transform(
        id: String, rawX: Float, rawY: Float, rawRot: Float, zoom: Float,
        cw: Float, snapPx: Float, showPx: Float
    ) {
        val p = current ?: return
        val pd = p.panel(panel)
        val layer = pd.layers.firstOrNull { it.id == id } ?: return
        val (wMm, hMm) = p.format.size(panel)
        val ppm = cw / wMm
        val snappedRot = run {
            val snap = listOf(0f, 90f, -90f, 180f, -180f).minByOrNull { kotlin.math.abs((((rawRot - it + 180f) % 360f + 360f) % 360f) - 180f) }
            if (snap != null && kotlin.math.abs((((rawRot - snap + 180f) % 360f + 360f) % 360f) - 180f) <= 1.5f) snap else rawRot
        }
        // размер меняем первым — привязка должна учитывать уже новые габариты
        val sized = when (layer.kind) {
            Kind.TEXT -> layer.copy(sizeMm = (layer.sizeMm * zoom).coerceIn(1f, 120f))
            Kind.IMAGE -> layer.copy(widthMm = (layer.widthMm * zoom).coerceIn(2f, 900f))
            Kind.RECT -> layer.copy(
                widthMm = (layer.widthMm * zoom).coerceIn(0.5f, 900f),
                sizeMm = (layer.sizeMm * zoom).coerceIn(0.3f, 900f)
            )
            Kind.SYMBOL -> layer.copy(widthMm = (layer.widthMm * zoom).coerceIn(4f, 900f))
        }.copy(rot = snappedRot)
        val res = Snap.compute(
            sized, rawX.coerceIn(-0.2f, 1.2f), rawY.coerceIn(-0.2f, 1.2f),
            pd.layers.filter { it.id != id }, wMm, hMm, panel,
            snapMm = snapPx / ppm, showMm = showPx / ppm
        )
        guideLines = res.guides
        updateLayer(id, "g$id") { sized.copy(x = res.x, y = res.y) }
    }

    fun clearGuides() { if (guideLines.isNotEmpty()) guideLines = emptyList() }

    fun addSpecialSymbol(symbol: String) {
        val p = current ?: return
        val spine = panel == PanelId.SPINE
        addLayer(Layer(kind = Kind.SYMBOL, text = symbol, widthMm = if (spine) 7f else 42f,
            rot = if (spine) 90f else 0f, color = 0xFFFFFFFF.toInt()))
    }

    /** Аккуратно подгоняет уже добавленные изображения и текст, не удаляя слои. */
    fun autoFitAll() {
        val p = current ?: return
        val fallbackImage = p.panels.values.asSequence().flatMap { it.layers.asSequence() }
            .firstOrNull { it.kind == Kind.IMAGE }
        val panels = p.panels.mapValues { (id, data) ->
            val (w, h) = p.format.size(id)
            var firstImage = true
            val sourceLayers = if (data.layers.none { it.kind == Kind.IMAGE } && fallbackImage != null) {
                val b = Bitmaps.get(fallbackImage.path)
                val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                val coverW = max(w, h * aspect)
                data.layers + fallbackImage.copy(id = java.util.UUID.randomUUID().toString(),
                    x = 0.5f, y = 0.5f, widthMm = coverW, rot = 0f)
            } else data.layers
            val fitted = sourceLayers.map { layer ->
                when (layer.kind) {
                    Kind.IMAGE -> {
                        if (!firstImage) layer.copy(x = layer.x.coerceIn(0.05f, 0.95f), y = layer.y.coerceIn(0.05f, 0.95f))
                        else {
                            firstImage = false
                            val b = Bitmaps.get(layer.path)
                            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                            val coverW = max(w, h * aspect)
                            layer.copy(x = 0.5f, y = 0.5f, widthMm = coverW, rot = 0f)
                        }
                    }
                    Kind.TEXT -> layer.copy(
                        x = layer.x.coerceIn(0.08f, 0.92f), y = layer.y.coerceIn(0.08f, 0.92f),
                        rot = run { val r = (((layer.rot + 180f) % 360f + 360f) % 360f) - 180f; if (kotlin.math.abs(r) <= 3.5f) 0f else r }
                    )
                    Kind.RECT, Kind.SYMBOL -> layer.copy(x = layer.x.coerceIn(0.05f, 0.95f), y = layer.y.coerceIn(0.05f, 0.95f))
                }
            }
            data.copy(layers = fitted)
        }
        edit("auto-fit") { it.copy(panels = panels) }
        selected = null
    }

    fun addImage(uri: Uri, asBackground: Boolean) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { store.importImage(uri) } ?: return@launch
            val p = current ?: return@launch
            val (pw, ph) = p.format.size(panel)
            val b = Bitmaps.get(path)
            val aspect = if (b != null) b.width.toFloat() / b.height else 1f
            val w = if (asBackground) max(pw, ph * aspect) else minOf(pw * 0.7f, ph * 0.7f * aspect)
            addLayer(Layer(kind = Kind.IMAGE, path = path, widthMm = w))
        }
    }

    fun fillSelected(cover: Boolean) {
        val id = selected ?: return
        val p = current ?: return
        val l = p.panel(panel).layers.firstOrNull { it.id == id } ?: return
        val b = Bitmaps.get(l.path) ?: return
        val (pw, ph) = p.format.size(panel)
        val aspect = b.width.toFloat() / b.height
        val w = if (cover) max(pw, ph * aspect) else minOf(pw, ph * aspect)
        updateLayer(id) { it.copy(widthMm = w, x = 0.5f, y = 0.5f, rot = 0f) }
    }


    /** Устанавливает выбранный пипеткой цвет как сплошной фон текущей панели. */
    fun setPanelBackgroundColor(target: PanelId, color: Int) {
        updatePanel(target, "sampled-bg-$target") {
            it.copy(c1 = color, c2 = color, angle = 0, layers = it.layers.filterNot { l -> isGenerated(l) })
        }
    }

    /** Возвращает фон панели к исходному: убирает размытие/палитру/переход и ставит градиент по умолчанию. */
    fun resetBackground(target: PanelId = panel) {
        val d = GradientPresets[0]
        updatePanel(target) {
            it.copy(c1 = d.c1, c2 = d.c2, angle = d.angle, layers = it.layers.filterNot { l -> isGenerated(l) })
        }
        selected = null
    }

    fun hasGeneratedBackground(target: PanelId = panel): Boolean =
        current?.panel(target)?.layers?.any { isGenerated(it) } == true

    private fun isGenerated(l: Layer): Boolean {
        if (l.kind != Kind.IMAGE) return false
        val n = java.io.File(l.path).name
        return n.startsWith("blur-") || n.startsWith("spine-")
    }

    /** Размытый фон из того, как реально выглядит лицевая сторона (фон + картинки, без текста), для оборота/корешка. */
    fun useBlurredFrontAsBackground(target: PanelId) {
        val p = current ?: return
        viewModelScope.launch {
            val path = withContext(Dispatchers.Default) {
                runCatching {
                    val front = p.panel(PanelId.FRONT)
                    val (fw, fh) = p.format.size(PanelId.FRONT)
                    val wpx = 1200
                    val ppm = wpx / fw
                    val hpx = (fh * ppm).roundToInt().coerceAtLeast(1)
                    val shot = Bitmap.createBitmap(wpx, hpx, Bitmap.Config.ARGB_8888)
                    drawPanel(Canvas(shot), front.copy(layers = front.layers.filter { it.kind == Kind.IMAGE || it.kind == Kind.RECT }),
                        wpx.toFloat(), hpx.toFloat(), ppm)
                    val blurred = Blur.gaussian(shot)
                    shot.recycle()
                    val saved = store.saveBitmap(blurred, prefix = "blur-")
                    blurred.recycle()
                    saved
                }.getOrNull()
            } ?: return@launch
            val project = current ?: return@launch
            val (pw, ph) = project.format.size(target)
            val b = Bitmaps.get(path)
            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
            val layer = Layer(
                kind = Kind.IMAGE, path = path, x = 0.5f, y = 0.5f, rot = 0f,
                widthMm = max(pw, ph * aspect), alpha = 1f
            )
            updatePanel(target, "blurred-front-$target") { data ->
                data.copy(layers = listOf(layer) + data.layers.filterNot { isGenerated(it) })
            }
            panel = target
            selected = layer.id
        }
    }

    /**
     * «Палитра с лица»: самый частый цвет лицевой стороны занимает ~85% панели, остальные цвета обложки
     * мягко размазаны блюром у края, противоположного корешку. Исходный фон панели (c1/c2) не трогаем —
     * при удалении слоя фон возвращается к тому, что был.
     */
    fun paletteFromFront(target: PanelId) {
        val p = current ?: return
        viewModelScope.launch {
            val saved = withContext(Dispatchers.Default) {
                runCatching {
                    val front = p.panel(PanelId.FRONT)
                    val (fw, fh) = p.format.size(PanelId.FRONT)
                    val wpx = 600
                    val ppm = wpx / fw
                    val hpx = (fh * ppm).roundToInt().coerceAtLeast(1)
                    val shot = Bitmap.createBitmap(wpx, hpx, Bitmap.Config.ARGB_8888)
                    drawPanel(Canvas(shot), front.copy(layers = front.layers.filter { it.kind == Kind.IMAGE || it.kind == Kind.RECT }),
                        wpx.toFloat(), hpx.toFloat(), ppm)
                    val sw = Palette.extract(shot, plain = true)
                    shot.recycle()
                    if (sw.isEmpty()) return@runCatching null
                    val (pw, ph) = p.format.size(target)
                    val k = 1200f / max(pw, ph)
                    // корешок и трей-оборот: «дальний от корешка» край — нижний; у обычного оборота корешок справа, значит дальний — левый
                    val far = if (target == PanelId.BACK && !p.format.tray) Palette.Far.LEFT else Palette.Far.BOTTOM
                    val bmp = Palette.renderDominant(sw, (pw * k).roundToInt().coerceAtLeast(8), (ph * k).roundToInt().coerceAtLeast(8), far)
                    val path = store.saveBitmap(bmp, prefix = "blur-")
                    bmp.recycle()
                    path
                }.getOrNull()
            } ?: return@launch
            val (pw, ph) = p.format.size(target)
            val b = Bitmaps.get(saved)
            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else pw / ph
            val layer = Layer(kind = Kind.IMAGE, path = saved, x = 0.5f, y = 0.5f, rot = 0f, widthMm = max(pw, ph * aspect))
            updatePanel(target, "palette-front-$target") { d ->
                d.copy(layers = listOf(layer) + d.layers.filterNot { isGenerated(it) })
            }
            panel = target
            selected = null
        }
    }

    private fun renderPanelBmp(p: Project, id: PanelId, ppm: Float): Bitmap {
        val (w, h) = p.format.size(id)
        val b = Bitmap.createBitmap((w * ppm).roundToInt().coerceAtLeast(1), (h * ppm).roundToInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        drawPanel(Canvas(b), p.panel(id), b.width.toFloat(), b.height.toFloat(), ppm)
        return b
    }

    /** Средний цвет узкой полосы у края панели для каждой из [rows] строк. */
    private fun edgeColors(b: Bitmap, fromRight: Boolean, rows: Int): IntArray {
        val w = b.width
        val h = b.height
        val sw = minOf(w, 2)
        val px = IntArray(sw * h)
        b.getPixels(px, 0, sw, if (fromRight) w - sw else 0, 0, sw, h)
        return IntArray(rows) { y ->
            val sy = (y.toLong() * h / rows).toInt().coerceIn(0, h - 1)
            var r = 0; var g = 0; var bl = 0
            for (x in 0 until sw) {
                val c = px[sy * sw + x]
                r += (c shr 16) and 255; g += (c shr 8) and 255; bl += c and 255
            }
            (0xFF shl 24) or ((r / sw) shl 16) or ((g / sw) shl 8) or (bl / sw)
        }
    }

    private fun avgColor(a: IntArray): Int {
        var r = 0L; var g = 0L; var b = 0L
        for (c in a) { r += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255 }
        val n = a.size.coerceAtLeast(1)
        return (0xFF shl 24) or ((r / n).toInt() shl 16) or ((g / n).toInt() shl 8) or (b / n).toInt()
    }

    /** Корешок: цвета краёв оборота и лица (построчно, со сглаживанием) плавно перетекают друг в друга. */
    fun spineFromNeighbors() {
        val p = current ?: return
        viewModelScope.launch {
            val res = withContext(Dispatchers.Default) {
                runCatching {
                    val f = p.format
                    val ppm = 4f
                    val back = renderPanelBmp(p, PanelId.BACK, ppm)
                    val rows = back.height
                    val left: IntArray
                    val right: IntArray
                    if (!f.tray) {
                        val front = renderPanelBmp(p, PanelId.FRONT, ppm)
                        left = edgeColors(back, true, rows)
                        right = edgeColors(front, false, rows)
                        front.recycle()
                    } else {
                        val a = edgeColors(back, false, rows)
                        val b = edgeColors(back, true, rows)
                        left = IntArray(rows) { androidx.core.graphics.ColorUtils.blendARGB(a[it], b[it], 0.5f) }
                        right = left
                    }
                    back.recycle()
                    val lh = left.copyOf(); val rh = right.copyOf()
                    Blur.blurPixels(lh, 1, rows, rows * 0.02f)     // мягкий цвет внутри корешка
                    Blur.blurPixels(left, 1, rows, rows * 0.004f)  // точный цвет на самом стыке
                    Blur.blurPixels(right, 1, rows, rows * 0.004f)
                    val sw = (rows * f.spineW / f.backH).roundToInt().coerceAtLeast(8)
                    val fc = (rows * 5f / f.backH).roundToInt().coerceAtLeast(4)   // растушёвка 5 мм за краями корешка
                    val tw = sw + 2 * fc
                    val px = IntArray(tw * rows)
                    fun mix(a: Int, b: Int, t: Float) = androidx.core.graphics.ColorUtils.blendARGB(a, b, t.coerceIn(0f, 1f))
                    for (x in 0 until tw) {
                        for (y in 0 until rows) {
                            val c: Int
                            var alpha = 1f
                            if (x < fc) {
                                c = left[y]
                                val u = (fc - x - 0.5f) / fc
                                alpha = 1f - u * u * (3f - 2f * u)
                            } else if (x >= fc + sw) {
                                c = right[y]
                                val u = (x - fc - sw + 0.5f) / fc
                                alpha = 1f - u * u * (3f - 2f * u)
                            } else {
                                val t = (x - fc + 0.5f) / sw
                                val lc = mix(left[y], lh[y], t * 4f)
                                val rc = mix(right[y], rh[y], (1f - t) * 4f)
                                c = mix(lc, rc, t * t * (3f - 2f * t))
                            }
                            px[y * tw + x] = ((alpha * 255f).roundToInt().coerceIn(0, 255) shl 24) or (c and 0x00FFFFFF)
                        }
                    }
                    val bmp = Bitmap.createBitmap(px, tw, rows, Bitmap.Config.ARGB_8888)
                    val saved = store.saveBitmap(bmp, png = true, prefix = "spine-$fc-$sw-")
                    bmp.recycle()
                    val l2 = lh; val r2 = rh
                    if (saved == null) null else SpineRes(saved, avgColor(l2), avgColor(r2), tw * f.backH / rows)
                }.getOrNull()
            } ?: return@launch
            val layer = Layer(kind = Kind.IMAGE, path = res.path, x = 0.5f, y = 0.5f, rot = 0f, widthMm = res.widthMm)
            updatePanel(PanelId.SPINE, "spine-blend") { d ->
                d.copy(layers = listOf(layer) + d.layers.filterNot { isGenerated(it) })
            }
            panel = PanelId.SPINE
            selected = null
        }
    }

    fun checkUpdate(manual: Boolean) {
        if (checking) return
        viewModelScope.launch {
            checking = true
            if (manual) updateMsg = null
            val u = Updater.check()
            update = u
            if (manual) updateMsg = if (u == null) "У вас последняя версия" else null
            checking = false
        }
    }

    fun downloadAndInstall() {
        val u = update ?: return
        if (progress != null) return
        viewModelScope.launch {
            progress = 0f
            updateMsg = null
            val f = Updater.download(getApplication(), u) { progress = it }
            progress = null
            if (f == null) {
                updateMsg = "Не удалось скачать обновление"
            } else if (!Updater.install(getApplication(), f)) {
                updateMsg = "Разрешите установку из этого источника и нажмите «Обновить» ещё раз"
            }
        }
    }
}
