package com.dvdmaker.app

import android.app.Application
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

class AppVm(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    var projects by mutableStateOf(store.loadAll())
    var current by mutableStateOf<Project?>(null)
    var panel by mutableStateOf(PanelId.FRONT)
    var overview by mutableStateOf(false)
    var selected by mutableStateOf<String?>(null)
    var canUndo by mutableStateOf(false)
    var checker by mutableStateOf(false)

    var update by mutableStateOf<UpdateInfo?>(null)
    var checking by mutableStateOf(false)
    var progress by mutableStateOf<Float?>(null)
    var updateMsg by mutableStateOf<String?>(null)

    private val undo = ArrayList<Project>()
    private var lastKey = ""
    private var lastEdit = 0L
    private var saveJob: Job? = null

    fun create(format: DiscFormat) {
        val p = newProject(format, "Новый ${format.title}")
        store.save(p)
        projects = store.loadAll()
        enter(p)
    }

    fun open(p: Project) = enter(p)

    /** Создаёт проект из готового Project (например, после подгонки готовой обложки) и открывает его. */
    fun createFrom(p: Project) {
        store.save(p)
        projects = store.loadAll()
        checker = false
        enter(p)
    }

    fun toggleFoldShadow() = edit { it.copy(foldShadow = !it.foldShadow) }

    /** Диск: берёт фон и главное изображение с лицевой стороны и подгоняет под круг диска. */
    fun discFromFront() {
        val p = current ?: return
        val front = p.panel(PanelId.FRONT)
        val img = front.layers.firstOrNull { it.kind == Kind.IMAGE }
        updatePanel(PanelId.DISC) { d ->
            var nd = d.copy(c1 = front.c1, c2 = front.c2, angle = front.angle)
            if (img != null) {
                val b = Bitmaps.get(img.path)
                val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                val layer = img.copy(
                    id = java.util.UUID.randomUUID().toString(),
                    x = 0.5f, y = 0.5f, rot = 0f, alpha = 1f,
                    widthMm = max(DISC_SIZE_MM, DISC_SIZE_MM * aspect)
                )
                nd = nd.copy(layers = listOf(layer) + nd.layers.filter { it.kind != Kind.IMAGE })
            }
            nd
        }
        selected = null
    }

    private fun enter(p: Project) {
        current = p; panel = PanelId.FRONT; overview = false; selected = null
        undo.clear(); canUndo = false; lastKey = ""
    }

    fun close() {
        flush()
        current = null
        selected = null
        projects = store.loadAll()
    }

    fun delete(p: Project) {
        store.delete(p)
        projects = store.loadAll()
    }

    fun flush() {
        saveJob?.cancel()
        current?.let { store.save(it) }
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(500)
            current?.let { p -> withContext(Dispatchers.IO) { store.save(p) } }
        }
    }

    fun edit(key: String = "", block: (Project) -> Project) {
        val p = current ?: return
        val now = SystemClock.elapsedRealtime()
        if (key.isEmpty() || key != lastKey || now - lastEdit > 1200) {
            undo.add(p)
            if (undo.size > 40) undo.removeAt(0)
            canUndo = true
        }
        lastKey = key
        lastEdit = now
        current = block(p).copy(updated = System.currentTimeMillis())
        scheduleSave()
    }

    fun undoLast() {
        if (undo.isEmpty()) return
        current = undo.removeAt(undo.lastIndex)
        canUndo = undo.isNotEmpty()
        lastKey = ""
        val p = current
        if (p != null && selected != null &&
            p.panel(panel).layers.none { it.id == selected }) selected = null
        scheduleSave()
    }

    fun rename(name: String) = edit { it.copy(name = name.ifBlank { it.name }) }

    fun updatePanel(id: PanelId, key: String = "", f: (PanelData) -> PanelData) =
        edit(key) { p -> p.copy(panels = p.panels + (id to f(p.panel(id)))) }

    fun updateLayer(layerId: String, key: String = "", f: (Layer) -> Layer) =
        updatePanel(panel, key) { pd ->
            pd.copy(layers = pd.layers.map { if (it.id == layerId) f(it) else it })
        }

    fun addLayer(l: Layer) {
        updatePanel(panel) { it.copy(layers = it.layers + l) }
        selected = l.id
    }

    fun addText() {
        val p = current ?: return
        val (w, h) = p.format.size(panel)
        val spine = panel == PanelId.SPINE
        addLayer(
            Layer(
                kind = Kind.TEXT, text = "Текст",
                sizeMm = if (spine) minOf(w * 0.55f, 7f) else 9f,
                font = 0, rot = if (spine) 90f else 0f
            )
        )
    }

    fun addRect() {
        val p = current ?: return
        val (w, _) = p.format.size(panel)
        addLayer(Layer(kind = Kind.RECT, widthMm = w * 0.6f, sizeMm = 8f, color = 0xFFFFB547.toInt()))
    }

    fun removeSelected() {
        val id = selected ?: return
        updatePanel(panel) { it.copy(layers = it.layers.filter { l -> l.id != id }) }
        selected = null
    }

    fun duplicateSelected() {
        val id = selected ?: return
        val src = current?.panel(panel)?.layers?.firstOrNull { it.id == id } ?: return
        addLayer(src.copy(id = java.util.UUID.randomUUID().toString(),
            x = (src.x + 0.05f).coerceAtMost(0.95f), y = (src.y + 0.05f).coerceAtMost(0.95f)))
    }

    fun moveSelected(up: Boolean) {
        val id = selected ?: return
        updatePanel(panel) { pd ->
            val list = pd.layers.toMutableList()
            val i = list.indexOfFirst { it.id == id }
            val j = if (up) i + 1 else i - 1
            if (i >= 0 && j in list.indices) {
                val t = list[i]; list[i] = list[j]; list[j] = t
            }
            pd.copy(layers = list)
        }
    }

    fun transform(id: String, pan: Offset, zoom: Float, rot: Float, cw: Float, ch: Float) {
        updateLayer(id, "g$id") { l ->
            val rawX = (l.x + pan.x / cw).coerceIn(-0.2f, 1.2f)
            val rawY = (l.y + pan.y / ch).coerceIn(-0.2f, 1.2f)
            fun align(v: Float): Float = listOf(0.05f, 0.5f, 0.95f).minByOrNull { kotlin.math.abs(v - it) }
                ?.let { if (kotlin.math.abs(v - it) <= 0.0035f) it else v } ?: v
            val nl = l.copy(
                x = align(rawX),
                y = align(rawY),
                rot = run {
                    val raw = l.rot + rot
                    val snap = listOf(0f, 90f, -90f, 180f, -180f).minByOrNull { kotlin.math.abs((((raw - it + 180f) % 360f + 360f) % 360f) - 180f) }
                    if (snap != null && kotlin.math.abs((((raw - snap + 180f) % 360f + 360f) % 360f) - 180f) <= 1.2f) snap else raw
                }
            )
            when (l.kind) {
                Kind.TEXT -> nl.copy(sizeMm = (l.sizeMm * zoom).coerceIn(1f, 120f))
                Kind.IMAGE -> nl.copy(widthMm = (l.widthMm * zoom).coerceIn(2f, 900f))
                Kind.RECT -> nl.copy(
                    widthMm = (l.widthMm * zoom).coerceIn(0.5f, 900f),
                    sizeMm = (l.sizeMm * zoom).coerceIn(0.3f, 900f)
                )
                Kind.SYMBOL -> nl.copy(widthMm = (l.widthMm * zoom).coerceIn(4f, 900f))
            }
        }
    }

    fun addSpecialSymbol(symbol: String) {
        val p = current ?: return
        val spine = panel == PanelId.SPINE
        addLayer(Layer(kind = Kind.SYMBOL, text = symbol, widthMm = if (spine) 7f else 42f,
            rot = if (spine) 90f else 0f, color = 0xFFFFFFFF.toInt()))
    }

    /** Аккуратно подгоняет уже добавленные изображения и текст, не удаляя слои. */
    fun autoFitAll() {
        val p = current ?: return
        val fallbackImage = p.panels.values.asSequence().flatMap { it.layers.asSequence() }
            .firstOrNull { it.kind == Kind.IMAGE }
        val panels = p.panels.mapValues { (id, data) ->
            val (w, h) = p.format.size(id)
            var firstImage = true
            val sourceLayers = if (data.layers.none { it.kind == Kind.IMAGE } && fallbackImage != null) {
                val b = Bitmaps.get(fallbackImage.path)
                val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                val coverW = max(w, h * aspect)
                data.layers + fallbackImage.copy(id = java.util.UUID.randomUUID().toString(),
                    x = 0.5f, y = 0.5f, widthMm = coverW, rot = 0f)
            } else data.layers
            val fitted = sourceLayers.map { layer ->
                when (layer.kind) {
                    Kind.IMAGE -> {
                        if (!firstImage) layer.copy(x = layer.x.coerceIn(0.05f, 0.95f), y = layer.y.coerceIn(0.05f, 0.95f))
                        else {
                            firstImage = false
                            val b = Bitmaps.get(layer.path)
                            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
                            val coverW = max(w, h * aspect)
                            layer.copy(x = 0.5f, y = 0.5f, widthMm = coverW, rot = 0f)
                        }
                    }
                    Kind.TEXT -> layer.copy(
                        x = layer.x.coerceIn(0.08f, 0.92f), y = layer.y.coerceIn(0.08f, 0.92f),
                        rot = run { val r = (((layer.rot + 180f) % 360f + 360f) % 360f) - 180f; if (kotlin.math.abs(r) <= 3.5f) 0f else r }
                    )
                    Kind.RECT, Kind.SYMBOL -> layer.copy(x = layer.x.coerceIn(0.05f, 0.95f), y = layer.y.coerceIn(0.05f, 0.95f))
                }
            }
            data.copy(layers = fitted)
        }
        edit("auto-fit") { it.copy(panels = panels) }
        selected = null
    }

    fun addImage(uri: Uri, asBackground: Boolean) {
        viewModelScope.launch {
            val path = withContext(Dispatchers.IO) { store.importImage(uri) } ?: return@launch
            val p = current ?: return@launch
            val (pw, ph) = p.format.size(panel)
            val b = Bitmaps.get(path)
            val aspect = if (b != null) b.width.toFloat() / b.height else 1f
            val w = if (asBackground) max(pw, ph * aspect) else minOf(pw * 0.7f, ph * 0.7f * aspect)
            addLayer(Layer(kind = Kind.IMAGE, path = path, widthMm = w))
        }
    }

    fun fillSelected(cover: Boolean) {
        val id = selected ?: return
        val p = current ?: return
        val l = p.panel(panel).layers.firstOrNull { it.id == id } ?: return
        val b = Bitmaps.get(l.path) ?: return
        val (pw, ph) = p.format.size(panel)
        val aspect = b.width.toFloat() / b.height
        val w = if (cover) max(pw, ph * aspect) else minOf(pw, ph * aspect)
        updateLayer(id) { it.copy(widthMm = w, x = 0.5f, y = 0.5f, rot = 0f) }
    }


    /** Устанавливает выбранный пипеткой цвет как сплошной фон текущей панели. */
    fun setPanelBackgroundColor(target: PanelId, color: Int) {
        updatePanel(target, "sampled-bg-$target") { it.copy(c1 = color, c2 = color, angle = 0) }
    }

    private fun isGenerated(l: Layer): Boolean {
        if (l.kind != Kind.IMAGE) return false
        val n = java.io.File(l.path).name
        return n.startsWith("blur-") || n.startsWith("spine-")
    }

    /** Размытый фон из того, как реально выглядит лицевая сторона (фон + картинки, без текста), для оборота/корешка. */
    fun useBlurredFrontAsBackground(target: PanelId) {
        val p = current ?: return
        viewModelScope.launch {
            val path = withContext(Dispatchers.Default) {
                runCatching {
                    val front = p.panel(PanelId.FRONT)
                    val (fw, fh) = p.format.size(PanelId.FRONT)
                    val wpx = 1200
                    val ppm = wpx / fw
                    val hpx = (fh * ppm).roundToInt().coerceAtLeast(1)
                    val shot = Bitmap.createBitmap(wpx, hpx, Bitmap.Config.ARGB_8888)
                    drawPanel(Canvas(shot), front.copy(layers = front.layers.filter { it.kind == Kind.IMAGE || it.kind == Kind.RECT }),
                        wpx.toFloat(), hpx.toFloat(), ppm)
                    val blurred = Blur.gaussian(shot)
                    shot.recycle()
                    val saved = store.saveBitmap(blurred, prefix = "blur-")
                    blurred.recycle()
                    saved
                }.getOrNull()
            } ?: return@launch
            val project = current ?: return@launch
            val (pw, ph) = project.format.size(target)
            val b = Bitmaps.get(path)
            val aspect = if (b != null && b.height > 0) b.width.toFloat() / b.height else 1f
            val layer = Layer(
                kind = Kind.IMAGE, path = path, x = 0.5f, y = 0.5f, rot = 0f,
                widthMm = max(pw, ph * aspect), alpha = 1f
            )
            updatePanel(target, "blurred-front-$target") { data ->
                data.copy(layers = listOf(layer) + data.layers.filterNot { isGenerated(it) })
            }
            panel = target
            selected = layer.id
        }
    }

    private fun renderPanelBmp(p: Project, id: PanelId, ppm: Float): Bitmap {
        val (w, h) = p.format.size(id)
        val b = Bitmap.createBitmap((w * ppm).roundToInt().coerceAtLeast(1), (h * ppm).roundToInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        drawPanel(Canvas(b), p.panel(id), b.width.toFloat(), b.height.toFloat(), ppm)
        return b
    }

    /** Средний цвет узкой полосы у края панели для каждой из [rows] строк. */
    private fun edgeColors(b: Bitmap, fromRight: Boolean, rows: Int): IntArray {
        val w = b.width
        val h = b.height
        val sw = minOf(w, 10)
        val px = IntArray(sw * h)
        b.getPixels(px, 0, sw, if (fromRight) w - sw else 0, 0, sw, h)
        return IntArray(rows) { y ->
            val sy = (y.toLong() * h / rows).toInt().coerceIn(0, h - 1)
            var r = 0; var g = 0; var bl = 0
            for (x in 0 until sw) {
                val c = px[sy * sw + x]
                r += (c shr 16) and 255; g += (c shr 8) and 255; bl += c and 255
            }
            (0xFF shl 24) or ((r / sw) shl 16) or ((g / sw) shl 8) or (bl / sw)
        }
    }

    private fun avgColor(a: IntArray): Int {
        var r = 0L; var g = 0L; var b = 0L
        for (c in a) { r += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255 }
        val n = a.size.coerceAtLeast(1)
        return (0xFF shl 24) or ((r / n).toInt() shl 16) or ((g / n).toInt() shl 8) or (b / n).toInt()
    }

    /** Корешок: цвета краёв оборота и лица (построчно, со сглаживанием) плавно перетекают друг в друга. */
    fun spineFromNeighbors() {
        val p = current ?: return
        viewModelScope.launch {
            val res = withContext(Dispatchers.Default) {
                runCatching {
                    val f = p.format
                    val ppm = 4f
                    val back = renderPanelBmp(p, PanelId.BACK, ppm)
                    val rows = back.height
                    val left: IntArray
                    val right: IntArray
                    if (!f.tray) {
                        val front = renderPanelBmp(p, PanelId.FRONT, ppm)
                        left = edgeColors(back, true, rows)
                        right = edgeColors(front, false, rows)
                        front.recycle()
                    } else {
                        val a = edgeColors(back, false, rows)
                        val b = edgeColors(back, true, rows)
                        left = IntArray(rows) { androidx.core.graphics.ColorUtils.blendARGB(a[it], b[it], 0.5f) }
                        right = left
                    }
                    back.recycle()
                    val sigma = rows * 0.02f
                    val l2 = left.copyOf()
                    val r2 = right.copyOf()
                    Blur.blurPixels(l2, 1, rows, sigma)
                    Blur.blurPixels(r2, 1, rows, sigma)
                    val sw = (rows * f.spineW / f.backH).roundToInt().coerceAtLeast(8)
                    val px = IntArray(sw * rows)
                    for (x in 0 until sw) {
                        val t = (x + 0.5f) / sw
                        val s = t * t * (3f - 2f * t)
                        for (y in 0 until rows) px[y * sw + x] = androidx.core.graphics.ColorUtils.blendARGB(l2[y], r2[y], s)
                    }
                    val bmp = Bitmap.createBitmap(px, sw, rows, Bitmap.Config.ARGB_8888)
                    val saved = store.saveBitmap(bmp, png = true, prefix = "spine-")
                    bmp.recycle()
                    if (saved == null) null else Triple(saved, avgColor(l2), avgColor(r2))
                }.getOrNull()
            } ?: return@launch
            val layer = Layer(kind = Kind.IMAGE, path = res.first, x = 0.5f, y = 0.5f, rot = 0f, widthMm = p.format.spineW)
            updatePanel(PanelId.SPINE, "spine-blend") { d ->
                d.copy(c1 = res.second, c2 = res.third, angle = 0,
                    layers = listOf(layer) + d.layers.filterNot { isGenerated(it) })
            }
            panel = PanelId.SPINE
            selected = null
        }
    }

    fun checkUpdate(manual: Boolean) {
        if (checking) return
        viewModelScope.launch {
            checking = true
            if (manual) updateMsg = null
            val u = Updater.check()
            update = u
            if (manual) updateMsg = if (u == null) "У вас последняя версия" else null
            checking = false
        }
    }

    fun downloadAndInstall() {
        val u = update ?: return
        if (progress != null) return
        viewModelScope.launch {
            progress = 0f
            updateMsg = null
            val f = Updater.download(getApplication(), u) { progress = it }
            progress = null
            if (f == null) {
                updateMsg = "Не удалось скачать обновление"
            } else if (!Updater.install(getApplication(), f)) {
                updateMsg = "Разрешите установку из этого источника и нажмите «Обновить» ещё раз"
            }
        }
    }
}
