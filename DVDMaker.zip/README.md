# DVDMaker

Android-приложение для создания обложек DVD / DVD Slim / CD / Blu-ray.

Сборка: положите DVDMaker.zip в корень репозитория (или распакуйте проект) — GitHub Actions
(.github/workflows/build.yml) соберёт APK и опубликует Release `v<номер>`. Приложение само
проверяет последний Release и предлагает обновиться поверх установленной версии.
